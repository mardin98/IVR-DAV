# Agent Desktop — Call Manager AI Davivienda (JavaScript)

Panel web para los 15 agentes humanos del Call Center.

## Stack

- **Frontend:** Next.js 14 (App Router) + Tailwind + JavaScript puro (sin TypeScript)
- **Softphone:** JsSIP (WebRTC SIP)
- **Auth:** JWT local con bcrypt
- **DB:** Firestore (compartido con Orchestrator)
- **Estado:** Zustand
- **Iconos:** Lucide React

## Funcionalidades

- Login con usuario/password local
- Estados del agente: Disponible / Ocupado / En pausa / En llamada
- Cola de llamadas escaladas en tiempo real
- Vista de llamada activa con brief de IA, transcripción, controles
- Softphone WebRTC integrado
- Modal de llamada entrante

## Instalación (RHEL 9 — junto a Asterisk)

```bash
scp -r agent-desktop-js/ mardin@IP-VM:~/
ssh mardin@IP-VM
cd agent-desktop-js
sudo bash install.sh

sudo nano /etc/callmanager/agent-desktop.env

cd /opt/callmanager/agent-desktop
sudo -u callmanager node scripts/seed-agents.js
# ⚠️  ANOTAR las passwords

sudo systemctl start callmanager-agent-desktop
```

## HTTPS

JsSIP requiere HTTPS para el micrófono. Ver `docs/HTTPS-SETUP.md`.

## Estructura

```
src/
├── app/
│   ├── login/page.jsx
│   ├── dashboard/page.jsx
│   ├── api/
│   │   ├── auth/{login,logout,me}/route.js
│   │   ├── calls/{queue,[callId],[callId]/accept}/route.js
│   │   └── agent/status/route.js
│   ├── layout.jsx
│   └── page.jsx
├── components/
│   ├── DashboardClient.jsx
│   ├── AgentHeader.jsx
│   ├── StatusSelector.jsx
│   ├── CallQueue.jsx
│   ├── ActiveCall.jsx
│   └── IncomingCallModal.jsx
├── hooks/
│   ├── useSoftphone.js
│   └── useCallQueue.js
├── store/
│   └── agentStore.js
└── lib/
    ├── auth.js
    ├── firestore.js
    └── ari.js
```
