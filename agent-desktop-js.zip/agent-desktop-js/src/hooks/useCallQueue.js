// hooks/useCallQueue.js — Cola de llamadas escaladas (polling cada 3s)
'use client';

import { useEffect } from 'react';
import { useAgentStore } from '@/store/agentStore';

export function useCallQueue() {
  const setQueuedCalls = useAgentStore((s) => s.setQueuedCalls);

  useEffect(() => {
    let cancelled = false;

    async function fetchQueue() {
      try {
        const res = await fetch('/api/calls/queue', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!cancelled) setQueuedCalls(data.calls);
      } catch (e) {
        console.error('[Queue] Error:', e);
      }
    }

    fetchQueue();
    const interval = setInterval(fetchQueue, 3000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [setQueuedCalls]);
}
