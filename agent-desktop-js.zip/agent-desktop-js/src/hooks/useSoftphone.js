// hooks/useSoftphone.js — Softphone WebRTC con JsSIP
'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useAgentStore } from '@/store/agentStore';

// JsSIP solo carga en el browser
let JsSIP = null;
if (typeof window !== 'undefined') {
  JsSIP = require('jssip');
}

export function useSoftphone(creds) {
  const uaRef    = useRef(null);
  const audioRef = useRef(null);

  const setSipStatus    = useAgentStore((s) => s.setSipStatus);
  const setIncomingCall = useAgentStore((s) => s.setIncomingCall);

  useEffect(() => {
    if (!creds || !JsSIP) return;

    // Crear elemento <audio> oculto para reproducir audio remoto
    if (!audioRef.current) {
      const audio = document.createElement('audio');
      audio.id = 'sip-remote-audio';
      audio.autoplay = true;
      audio.style.display = 'none';
      document.body.appendChild(audio);
      audioRef.current = audio;
    }

    const socket = new JsSIP.WebSocketInterface(creds.wssUrl);
    const config = {
      sockets:        [socket],
      uri:            `sip:${creds.extension}@${creds.domain}`,
      password:       creds.password,
      register:       true,
      session_timers: false,
      user_agent:     'CallManagerAgent/1.0',
    };

    const ua = new JsSIP.UA(config);

    // Eventos de registro
    ua.on('connecting',         () => setSipStatus('connecting'));
    ua.on('connected',          () => setSipStatus('connecting'));
    ua.on('registered',         () => setSipStatus('registered'));
    ua.on('unregistered',       () => setSipStatus('unregistered'));
    ua.on('registrationFailed', (e) => {
      console.error('[SIP] Registro fallido:', e.cause);
      setSipStatus('error');
    });
    ua.on('disconnected',       () => setSipStatus('disconnected'));

    // Llamada entrante
    ua.on('newRTCSession', (data) => {
      const session = data.session;
      if (session.direction !== 'incoming') return;

      const fromNumber = session.remote_identity.uri.user;
      const callId     = session.request.getHeader('X-Session-Id');

      console.log(`[SIP] Llamada entrante de ${fromNumber}, callId: ${callId}`);
      setIncomingCall({ session, fromNumber, callId });

      // Audio remoto
      session.on('peerconnection', (e) => {
        const pc = e.peerconnection;
        pc.addEventListener('track', (ev) => {
          if (ev.streams && ev.streams[0] && audioRef.current) {
            audioRef.current.srcObject = ev.streams[0];
          }
        });
      });

      session.on('ended',      () => setIncomingCall(null));
      session.on('failed',     () => setIncomingCall(null));
      session.on('terminated', () => setIncomingCall(null));
    });

    ua.start();
    uaRef.current = ua;

    return () => {
      ua.stop();
      uaRef.current = null;
    };
  }, [creds, setSipStatus, setIncomingCall]);

  const answerCall = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (!incoming) return;
    incoming.session.answer({
      mediaConstraints: { audio: true, video: false },
    });
    useAgentStore.getState().setStatus('oncall');
  }, []);

  const hangupCall = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (incoming?.session) incoming.session.terminate();
    setIncomingCall(null);
    useAgentStore.getState().setStatus('available');
    useAgentStore.getState().setActiveCall(null);
  }, [setIncomingCall]);

  const toggleMute = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (!incoming?.session) return;

    const tracks = incoming.session.connection
      .getSenders()
      .map((s) => s.track)
      .filter((t) => t && t.kind === 'audio');

    tracks.forEach((t) => { t.enabled = !t.enabled; });
    return tracks[0]?.enabled === false;
  }, []);

  return { answerCall, hangupCall, toggleMute };
}
