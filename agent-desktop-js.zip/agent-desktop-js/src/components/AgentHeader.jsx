// components/AgentHeader.jsx — Barra superior
'use client';

import { useRouter } from 'next/navigation';
import { Phone, LogOut, Wifi, WifiOff } from 'lucide-react';
import { useAgentStore } from '@/store/agentStore';
import { StatusSelector } from './StatusSelector';
import clsx from 'clsx';

export function AgentHeader() {
  const router    = useRouter();
  const session   = useAgentStore((s) => s.session);
  const sipStatus = useAgentStore((s) => s.sipStatus);
  const reset     = useAgentStore((s) => s.reset);

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    reset();
    router.push('/login');
    router.refresh();
  }

  if (!session) return null;

  const sipOk = sipStatus === 'registered';

  return (
    <header className="bg-white border-b border-davivienda-gray-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-davivienda-red flex items-center justify-center">
              <Phone className="text-white w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-davivienda-gray-900 leading-tight">
                Call Manager
              </p>
              <p className="text-xs text-davivienda-gray-500 leading-tight">
                Davivienda
              </p>
            </div>
          </div>

          <div className={clsx(
            'hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium',
            sipOk
              ? 'bg-green-50 text-green-700 border border-green-200'
              : 'bg-red-50 text-red-700 border border-red-200'
          )}>
            {sipOk ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            <span>{sipOk ? 'Conectado' : 'Desconectado'}</span>
          </div>

          <div className="flex items-center gap-3">
            <StatusSelector />

            <div className="hidden md:block text-right">
              <p className="text-sm font-medium text-davivienda-gray-900 leading-tight">
                {session.fullName}
              </p>
              <p className="text-xs text-davivienda-gray-500 leading-tight">
                Ext. {session.extension}
              </p>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 text-davivienda-gray-500 hover:text-davivienda-red hover:bg-davivienda-gray-100 rounded-lg transition"
              title="Cerrar sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
