// components/DashboardClient.jsx — Vista principal del agente
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAgentStore } from '@/store/agentStore';
import { useSoftphone } from '@/hooks/useSoftphone';
import { useCallQueue } from '@/hooks/useCallQueue';
import { AgentHeader } from './AgentHeader';
import { CallQueue } from './CallQueue';
import { ActiveCall } from './ActiveCall';
import { IncomingCallModal } from './IncomingCallModal';

export function DashboardClient({ session }) {
  const router       = useRouter();
  const setSession   = useAgentStore((s) => s.setSession);
  const activeCall   = useAgentStore((s) => s.activeCall);
  const incomingCall = useAgentStore((s) => s.incomingCall);

  const [sipCreds, setSipCreds] = useState(null);

  useEffect(() => {
    setSession(session);

    (async () => {
      try {
        const res = await fetch('/api/auth/me');
        if (!res.ok) {
          router.push('/login');
          return;
        }
        const me = await res.json();
        setSipCreds({
          extension: me.extension,
          password:  me.sipPassword,
          domain:    process.env.NEXT_PUBLIC_ASTERISK_DOMAIN,
          wssUrl:    process.env.NEXT_PUBLIC_ASTERISK_WSS_URL,
        });
      } catch (e) {
        console.error('Error cargando credenciales SIP:', e);
      }
    })();
  }, [session, setSession, router]);

  useSoftphone(sipCreds);
  useCallQueue();

  return (
    <div className="min-h-screen bg-davivienda-gray-50">
      <AgentHeader />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeCall ? <ActiveCall call={activeCall} /> : <CallQueue />}
      </main>
      {incomingCall && <IncomingCallModal />}
    </div>
  );
}
