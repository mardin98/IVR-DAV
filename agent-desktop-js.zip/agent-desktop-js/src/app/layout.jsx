import './globals.css';

export const metadata = {
  title:       'Call Manager — Davivienda',
  description: 'Panel de agentes de Call Center con IA',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
