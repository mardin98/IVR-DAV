// app/dashboard/page.jsx — Server component, verifica sesión
import { redirect } from 'next/navigation';
import { getCurrentSession } from '@/lib/auth';
import { DashboardClient } from '@/components/DashboardClient';

export default async function DashboardPage() {
  const session = await getCurrentSession();
  if (!session) redirect('/login');

  return <DashboardClient session={session} />;
}
