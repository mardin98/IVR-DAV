// store/agentStore.js — Estado global del Agent Desktop
'use client';

import { create } from 'zustand';

export const useAgentStore = create((set) => ({
  session: null,
  setSession: (s) => set({ session: s }),

  status: 'offline',
  setStatus: (s) => set({ status: s }),

  sipStatus: 'disconnected',
  setSipStatus: (s) => set({ sipStatus: s }),

  activeCall: null,
  setActiveCall: (c) => set({ activeCall: c }),

  queuedCalls: [],
  setQueuedCalls: (calls) => set({ queuedCalls: calls }),

  incomingCall: null,
  setIncomingCall: (c) => set({ incomingCall: c }),

  reset: () => set({
    session:      null,
    status:       'offline',
    sipStatus:    'disconnected',
    activeCall:   null,
    queuedCalls:  [],
    incomingCall: null,
  }),
}));
