"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/hooks/useAuth";
import toast from "react-hot-toast";

export default function LoginPage() {
  const { user, loading, signInWithGoogle } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) router.replace("/dashboard");
  }, [user, loading, router]);

  const handleLogin = async () => {
    try {
      await signInWithGoogle();
      router.replace("/dashboard");
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Error al iniciar sesión";
      if (message.includes("popup-closed")) return;
      toast.error("Solo se permiten cuentas @davivienda.com.sv");
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#060b14",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-dm-sans, sans-serif)",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Background grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(rgba(34,211,238,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.03) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
      }} />
      {/* Glow */}
      <div style={{
        position: "absolute", top: "20%", left: "50%", transform: "translateX(-50%)",
        width: 600, height: 300, borderRadius: "50%",
        background: "radial-gradient(ellipse, rgba(34,211,238,0.08) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div style={{
        position: "relative", zIndex: 10, width: "100%", maxWidth: 420, padding: "0 24px",
      }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16,
            background: "linear-gradient(135deg, #22d3ee, #a78bfa)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 28, fontWeight: 900, margin: "0 auto 20px",
            boxShadow: "0 0 40px rgba(34,211,238,0.3)",
          }}>◈</div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: "#f1f5f9", marginBottom: 6 }}>
            Initiative Tracker
          </h1>
          <p style={{ fontSize: 13, color: "#475569" }}>
            Davivienda · AI & Automations
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 20, padding: "36px 32px",
          backdropFilter: "blur(12px)",
        }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: "#e2e8f0", marginBottom: 8, textAlign: "center" }}>
            Acceso corporativo
          </h2>
          <p style={{ fontSize: 13, color: "#475569", textAlign: "center", marginBottom: 28, lineHeight: 1.6 }}>
            Usa tu cuenta Google de Davivienda<br />
            <span style={{ color: "#22d3ee" }}>@davivienda.com.sv</span>
          </p>

          <button
            onClick={handleLogin}
            disabled={loading}
            style={{
              width: "100%", padding: "14px 20px",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: 12, cursor: loading ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 12,
              color: "#f1f5f9", fontSize: 14, fontWeight: 600,
              fontFamily: "inherit", transition: "all 0.2s",
              opacity: loading ? 0.6 : 1,
            }}
            onMouseEnter={e => {
              if (!loading) {
                (e.target as HTMLButtonElement).style.borderColor = "rgba(34,211,238,0.4)";
                (e.target as HTMLButtonElement).style.background = "rgba(34,211,238,0.08)";
              }
            }}
            onMouseLeave={e => {
              (e.target as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.12)";
              (e.target as HTMLButtonElement).style.background = "rgba(255,255,255,0.06)";
            }}
          >
            {/* Google icon */}
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            {loading ? "Iniciando sesión..." : "Continuar con Google"}
          </button>
        </div>

        <p style={{ textAlign: "center", fontSize: 12, color: "#1e3a5f", marginTop: 24 }}>
          Acceso restringido · Solo personal autorizado
        </p>
      </div>
    </div>
  );
}
