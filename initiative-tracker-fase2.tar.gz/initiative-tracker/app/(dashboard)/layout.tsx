"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/hooks/useAuth";
import { useNotifications } from "@/lib/hooks/useTasks";
import { fmtRelative } from "@/lib/utils";
import toast from "react-hot-toast";

const NAV_ITEMS = [
  { href: "/dashboard",             icon: "◈",  label: "Dashboard" },
  { href: "/dashboard/initiatives", icon: "▦",  label: "Iniciativas" },
  { href: "/dashboard/reports",     icon: "▤",  label: "Reportes" },
  { href: "/dashboard/team",        icon: "◉",  label: "Equipo" },
];

const ADMIN_ITEMS = [
  { href: "/dashboard/admin",       icon: "⚙",  label: "Admin" },
];

function NotifIcon({ type }: { type: string }) {
  const icons: Record<string, string> = {
    warning: "⚠", success: "✓", error: "✗", info: "ℹ",
  };
  const colors: Record<string, string> = {
    warning: "#f59e0b", success: "#4ade80", error: "#f87171", info: "#22d3ee",
  };
  return (
    <span style={{ fontSize: 12, color: colors[type] || "#64748b" }}>
      {icons[type] || "ℹ"}
    </span>
  );
}

function Avatar({ name, size = 32 }: { name: string; size?: number }) {
  const initials = name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  const colors = ["#22d3ee","#a78bfa","#4ade80","#f59e0b","#f87171","#818cf8"];
  const color = colors[name.charCodeAt(0) % colors.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: `${color}22`, border: `1.5px solid ${color}44`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.35, fontWeight: 700, color, flexShrink: 0,
    }}>{initials}</div>
  );
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, loading, signOut, isAdmin } = useAuth();
  const { notifications, unreadCount, markRead, markAllRead } = useNotifications();
  const router = useRouter();
  const pathname = usePathname();
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <div style={{ minHeight: "100vh", background: "#060b14", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #22d3ee, #a78bfa)" }} />
      </div>
    );
  }

  const handleSignOut = async () => {
    await signOut();
    router.replace("/login");
    toast.success("Sesión cerrada");
  };

  const navItems = isAdmin ? [...NAV_ITEMS, ...ADMIN_ITEMS] : NAV_ITEMS;

  return (
    <div style={{ minHeight: "100vh", background: "#060b14", fontFamily: "var(--font-dm-sans, sans-serif)", display: "flex", flexDirection: "column" }}>
      {/* TOPBAR */}
      <header style={{
        position: "sticky", top: 0, zIndex: 100,
        background: "rgba(6,11,20,0.95)", backdropFilter: "blur(12px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "0 24px", height: 56,
        display: "flex", alignItems: "center", gap: 24,
      }}>
        {/* Logo */}
        <Link href="/dashboard" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none", flexShrink: 0 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 8,
            background: "linear-gradient(135deg, #22d3ee, #a78bfa)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, fontWeight: 900, color: "#fff",
          }}>◈</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 800, color: "#f1f5f9", lineHeight: 1 }}>Initiative Tracker</div>
            <div style={{ fontSize: 9, color: "#334155", letterSpacing: "0.1em", textTransform: "uppercase" }}>Davivienda AI & Automations</div>
          </div>
        </Link>

        {/* Nav */}
        <nav style={{ display: "flex", gap: 4, flex: 1, justifyContent: "center" }}>
          {navItems.map(item => {
            const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href} style={{
                padding: "6px 14px",
                background: active ? "rgba(34,211,238,0.1)" : "none",
                border: active ? "1px solid rgba(34,211,238,0.2)" : "1px solid transparent",
                borderRadius: 10, textDecoration: "none",
                display: "flex", alignItems: "center", gap: 6,
                color: active ? "#22d3ee" : "#475569",
                fontSize: 13, fontWeight: active ? 700 : 500,
                transition: "all 0.15s",
              }}
              onMouseEnter={e => { if (!active) (e.currentTarget as HTMLAnchorElement).style.color = "#94a3b8"; }}
              onMouseLeave={e => { if (!active) (e.currentTarget as HTMLAnchorElement).style.color = "#475569"; }}
              >
                <span>{item.icon}</span> {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Right */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
          {/* Notifications */}
          <div style={{ position: "relative" }}>
            <button
              onClick={() => { setNotifOpen(p => !p); setUserMenuOpen(false); }}
              style={{
                width: 36, height: 36, borderRadius: 10,
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.08)",
                cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 15, position: "relative", color: "#94a3b8",
              }}
            >🔔
              {unreadCount > 0 && (
                <span style={{
                  position: "absolute", top: -4, right: -4, width: 16, height: 16,
                  borderRadius: "50%", background: "#f87171",
                  fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center",
                  justifyContent: "center", color: "#fff",
                }}>{unreadCount}</span>
              )}
            </button>

            {notifOpen && (
              <div style={{
                position: "absolute", right: 0, top: 44, width: 350, zIndex: 200,
                background: "#0d1628", border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 14, boxShadow: "0 20px 60px rgba(0,0,0,0.5)", overflow: "hidden",
              }}>
                <div style={{ padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)", display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0" }}>Notificaciones</span>
                  {unreadCount > 0 && (
                    <button onClick={markAllRead} style={{ fontSize: 11, color: "#22d3ee", background: "none", border: "none", cursor: "pointer", fontFamily: "inherit" }}>
                      Marcar todo leído
                    </button>
                  )}
                </div>
                {notifications.length === 0 ? (
                  <div style={{ padding: 24, textAlign: "center", color: "#334155", fontSize: 13 }}>Sin notificaciones</div>
                ) : (
                  notifications.slice(0, 8).map(n => (
                    <div key={n.id} onClick={() => markRead(n.id)}
                      style={{ padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.04)", background: n.read ? "none" : "rgba(34,211,238,0.04)", display: "flex", gap: 10, cursor: "pointer" }}>
                      <NotifIcon type={n.type} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: "#e2e8f0", marginBottom: 2 }}>{n.title}</div>
                        <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.4 }}>{n.body}</div>
                        <div style={{ fontSize: 11, color: "#334155", marginTop: 3 }}>{fmtRelative(n.createdAt)}</div>
                      </div>
                      {!n.read && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#22d3ee", flexShrink: 0, marginTop: 3 }} />}
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* User menu */}
          <div style={{ position: "relative" }}>
            <button
              onClick={() => { setUserMenuOpen(p => !p); setNotifOpen(false); }}
              style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: "none", cursor: "pointer", padding: "4px 8px", borderRadius: 10 }}
            >
              <Avatar name={user.name} size={30} />
              <span style={{ fontSize: 13, fontWeight: 600, color: "#94a3b8" }}>
                {user.name.split(" ")[0]}
              </span>
            </button>
            {userMenuOpen && (
              <div style={{
                position: "absolute", right: 0, top: 44, width: 220, zIndex: 200,
                background: "#0d1628", border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 12, boxShadow: "0 20px 60px rgba(0,0,0,0.5)", overflow: "hidden",
              }}>
                <div style={{ padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0" }}>{user.name}</div>
                  <div style={{ fontSize: 11, color: "#475569" }}>{user.email}</div>
                  <span style={{
                    fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 20, marginTop: 6, display: "inline-block",
                    color: user.globalRole === "admin" ? "#f59e0b" : user.globalRole === "leader" ? "#a78bfa" : "#22d3ee",
                    background: user.globalRole === "admin" ? "rgba(245,158,11,0.1)" : user.globalRole === "leader" ? "rgba(167,139,250,0.1)" : "rgba(34,211,238,0.1)",
                  }}>
                    {user.globalRole === "admin" ? "Admin" : user.globalRole === "leader" ? "Líder" : "Responsable"}
                  </span>
                </div>
                <button onClick={handleSignOut} style={{
                  width: "100%", padding: "12px 16px", background: "none", border: "none",
                  color: "#f87171", fontSize: 13, cursor: "pointer", textAlign: "left",
                  fontFamily: "inherit", display: "flex", alignItems: "center", gap: 8,
                }}>
                  ⎋ Cerrar sesión
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* MAIN */}
      <main style={{ flex: 1, padding: "28px 24px", maxWidth: 1200, margin: "0 auto", width: "100%" }}>
        {children}
      </main>

      {/* Click outside overlays */}
      {(notifOpen || userMenuOpen) && (
        <div style={{ position: "fixed", inset: 0, zIndex: 150 }}
          onClick={() => { setNotifOpen(false); setUserMenuOpen(false); }} />
      )}
    </div>
  );
}
