import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  getDoc, getDocs, query, where, orderBy,
  onSnapshot, serverTimestamp, Timestamp,
  writeBatch, increment,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Initiative, InitiativeFormData, InitiativeStatus, MemberRole } from "@/types";
import { dateToTimestamp, generateInitiativeCode } from "@/lib/utils";
import { logActivity } from "./activityLog";

const COL = "initiatives";

// ─── READ ─────────────────────────────────────────────────────────────────────

export async function getInitiative(id: string): Promise<Initiative | null> {
  const snap = await getDoc(doc(db, COL, id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Initiative;
}

export async function getAllInitiatives(): Promise<Initiative[]> {
  const snap = await getDocs(query(collection(db, COL), orderBy("createdAt", "desc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Initiative));
}

export async function getInitiativesForUser(uid: string): Promise<Initiative[]> {
  const snap = await getDocs(
    query(collection(db, COL), where("members", "array-contains", uid), orderBy("createdAt", "desc"))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Initiative));
}

// ─── REAL-TIME ────────────────────────────────────────────────────────────────

export function subscribeAllInitiatives(
  callback: (initiatives: Initiative[]) => void
): () => void {
  const q = query(collection(db, COL), orderBy("updatedAt", "desc"));
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Initiative)));
  });
}

export function subscribeUserInitiatives(
  uid: string,
  callback: (initiatives: Initiative[]) => void
): () => void {
  const q = query(
    collection(db, COL),
    where("members", "array-contains", uid),
    orderBy("updatedAt", "desc")
  );
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Initiative)));
  });
}

export function subscribeInitiative(
  id: string,
  callback: (initiative: Initiative | null) => void
): () => void {
  return onSnapshot(doc(db, COL, id), snap => {
    callback(snap.exists() ? ({ id: snap.id, ...snap.data() } as Initiative) : null);
  });
}

// ─── WRITE ────────────────────────────────────────────────────────────────────

export async function createInitiative(
  data: InitiativeFormData,
  createdBy: string
): Promise<Initiative> {
  // Generate next code
  const all = await getAllInitiatives();
  const code = generateInitiativeCode(all.length);

  const now = serverTimestamp() as Timestamp;
  const payload: Omit<Initiative, "id"> = {
    code,
    title: data.title,
    description: data.description,
    status: data.status,
    priority: data.priority,
    category: data.category,
    leaderId: data.leaderId,
    members: [data.leaderId, createdBy].filter((v, i, a) => a.indexOf(v) === i),
    memberRoles: { [data.leaderId]: "leader" as MemberRole },
    progress: 0,
    startDate: dateToTimestamp(data.startDate),
    dueDate: dateToTimestamp(data.dueDate),
    budget: data.budget,
    budgetSpent: 0,
    createdBy,
    createdAt: now,
    updatedAt: now,
  };

  const ref = await addDoc(collection(db, COL), payload);
  await logActivity(createdBy, "created", "initiative", ref.id, undefined, payload);
  return { id: ref.id, ...payload };
}

export async function updateInitiative(
  id: string,
  data: Partial<InitiativeFormData>,
  updatedBy: string
): Promise<void> {
  const existing = await getInitiative(id);
  const updateData: Record<string, unknown> = { ...data, updatedAt: serverTimestamp() };
  if (data.startDate) updateData.startDate = dateToTimestamp(data.startDate);
  if (data.dueDate) updateData.dueDate = dateToTimestamp(data.dueDate);
  await updateDoc(doc(db, COL, id), updateData);
  await logActivity(updatedBy, "updated", "initiative", id, existing ?? undefined, data);
}

export async function updateInitiativeStatus(
  id: string,
  status: InitiativeStatus,
  updatedBy: string
): Promise<void> {
  const patch: Record<string, unknown> = { status, updatedAt: serverTimestamp() };
  if (status === "completed") patch.completedAt = serverTimestamp();
  await updateDoc(doc(db, COL, id), patch);
  await logActivity(updatedBy, "status_changed", "initiative", id, undefined, { status });
}

export async function updateInitiativeProgress(id: string, progress: number): Promise<void> {
  await updateDoc(doc(db, COL, id), { progress, updatedAt: serverTimestamp() });
}

export async function addMemberToInitiative(
  initiativeId: string,
  uid: string,
  role: MemberRole,
  updatedBy: string
): Promise<void> {
  const ini = await getInitiative(initiativeId);
  if (!ini) throw new Error("Initiative not found");
  const members = [...new Set([...ini.members, uid])];
  const memberRoles = { ...ini.memberRoles, [uid]: role };
  await updateDoc(doc(db, COL, initiativeId), {
    members, memberRoles, updatedAt: serverTimestamp(),
  });
  await logActivity(updatedBy, "member_added", "initiative", initiativeId, undefined, { uid, role });
}

export async function removeMemberFromInitiative(
  initiativeId: string,
  uid: string,
  updatedBy: string
): Promise<void> {
  const ini = await getInitiative(initiativeId);
  if (!ini) throw new Error("Initiative not found");
  const members = ini.members.filter(m => m !== uid);
  const memberRoles = { ...ini.memberRoles };
  delete memberRoles[uid];
  await updateDoc(doc(db, COL, initiativeId), {
    members, memberRoles, updatedAt: serverTimestamp(),
  });
  await logActivity(updatedBy, "member_removed", "initiative", initiativeId, undefined, { uid });
}

export async function updateBudgetSpent(
  initiativeId: string,
  amount: number
): Promise<void> {
  await updateDoc(doc(db, COL, initiativeId), {
    budgetSpent: increment(amount),
    updatedAt: serverTimestamp(),
  });
}

export async function deleteInitiative(id: string, deletedBy: string): Promise<void> {
  await logActivity(deletedBy, "deleted", "initiative", id);
  await deleteDoc(doc(db, COL, id));
}
