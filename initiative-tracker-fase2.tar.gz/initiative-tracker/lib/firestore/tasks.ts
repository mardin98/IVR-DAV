import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  getDocs, query, orderBy, onSnapshot,
  serverTimestamp, Timestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Task, TaskFormData, TaskStatus } from "@/types";
import { dateToTimestamp } from "@/lib/utils";
import { updateInitiativeProgress } from "./initiatives";
import { logActivity } from "./activityLog";

function tasksCol(initiativeId: string) {
  return collection(db, "initiatives", initiativeId, "tasks");
}

function taskDoc(initiativeId: string, taskId: string) {
  return doc(db, "initiatives", initiativeId, "tasks", taskId);
}

// ─── READ ─────────────────────────────────────────────────────────────────────

export async function getTasks(initiativeId: string): Promise<Task[]> {
  const snap = await getDocs(query(tasksCol(initiativeId), orderBy("orderIndex", "asc")));
  return snap.docs.map(d => ({ id: d.id, initiativeId, ...d.data() } as Task));
}

export function subscribeTasks(
  initiativeId: string,
  callback: (tasks: Task[]) => void
): () => void {
  const q = query(tasksCol(initiativeId), orderBy("orderIndex", "asc"));
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, initiativeId, ...d.data() } as Task)));
  });
}

// ─── WRITE ────────────────────────────────────────────────────────────────────

export async function createTask(
  initiativeId: string,
  data: TaskFormData,
  createdBy: string
): Promise<Task> {
  const existing = await getTasks(initiativeId);
  const rootTasks = existing.filter(t => !t.parentTaskId);
  const orderIndex = data.parentTaskId
    ? existing.filter(t => t.parentTaskId === data.parentTaskId).length
    : rootTasks.length;

  const now = serverTimestamp() as Timestamp;
  const payload: Omit<Task, "id"> = {
    initiativeId,
    parentTaskId: data.parentTaskId,
    title: data.title,
    description: data.description,
    assigneeId: data.assigneeId,
    status: data.status,
    priority: data.priority,
    progress: data.progress,
    estimatedHours: data.estimatedHours,
    loggedHours: 0,
    dueDate: data.dueDate ? dateToTimestamp(data.dueDate) : undefined,
    orderIndex,
    createdAt: now,
    updatedAt: now,
  };

  const ref = await addDoc(tasksCol(initiativeId), payload);
  await logActivity(createdBy, "task_created", "task", ref.id, undefined, payload);
  return { id: ref.id, ...payload };
}

export async function updateTask(
  initiativeId: string,
  taskId: string,
  data: Partial<TaskFormData>,
  updatedBy: string
): Promise<void> {
  const updateData: Record<string, unknown> = { ...data, updatedAt: serverTimestamp() };
  if (data.dueDate) updateData.dueDate = dateToTimestamp(data.dueDate);
  await updateDoc(taskDoc(initiativeId, taskId), updateData);
  await logActivity(updatedBy, "task_updated", "task", taskId, undefined, data);
  await recalcInitiativeProgress(initiativeId);
}

export async function updateTaskStatus(
  initiativeId: string,
  taskId: string,
  status: TaskStatus,
  updatedBy: string
): Promise<void> {
  const progress = status === "done" ? 100 : status === "todo" ? 0 : undefined;
  const patch: Record<string, unknown> = { status, updatedAt: serverTimestamp() };
  if (progress !== undefined) patch.progress = progress;
  await updateDoc(taskDoc(initiativeId, taskId), patch);
  await logActivity(updatedBy, "task_status_changed", "task", taskId, undefined, { status });
  await recalcInitiativeProgress(initiativeId);
}

export async function updateTaskProgress(
  initiativeId: string,
  taskId: string,
  progress: number
): Promise<void> {
  const status: TaskStatus = progress === 100 ? "done" : progress === 0 ? "todo" : "in_progress";
  await updateDoc(taskDoc(initiativeId, taskId), {
    progress, status, updatedAt: serverTimestamp(),
  });
  await recalcInitiativeProgress(initiativeId);
}

export async function logHours(
  initiativeId: string,
  taskId: string,
  hours: number
): Promise<void> {
  const taskRef = taskDoc(initiativeId, taskId);
  const snap = await getDocs(query(tasksCol(initiativeId), orderBy("orderIndex")));
  const task = snap.docs.find(d => d.id === taskId);
  if (!task) return;
  const current = (task.data().loggedHours as number) || 0;
  await updateDoc(taskRef, { loggedHours: current + hours, updatedAt: serverTimestamp() });
}

export async function deleteTask(
  initiativeId: string,
  taskId: string,
  deletedBy: string
): Promise<void> {
  // Delete subtasks first
  const all = await getTasks(initiativeId);
  const subtasks = all.filter(t => t.parentTaskId === taskId);
  for (const st of subtasks) {
    await deleteDoc(taskDoc(initiativeId, st.id));
  }
  await logActivity(deletedBy, "task_deleted", "task", taskId);
  await deleteDoc(taskDoc(initiativeId, taskId));
  await recalcInitiativeProgress(initiativeId);
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

async function recalcInitiativeProgress(initiativeId: string): Promise<void> {
  const tasks = await getTasks(initiativeId);
  const rootTasks = tasks.filter(t => !t.parentTaskId);
  if (!rootTasks.length) return;
  const avg = rootTasks.reduce((sum, t) => sum + (t.progress || 0), 0) / rootTasks.length;
  await updateInitiativeProgress(initiativeId, Math.round(avg));
}

// ─── TREE BUILDER ────────────────────────────────────────────────────────────

export function buildTaskTree(tasks: Task[]): Task[] {
  const roots = tasks.filter(t => !t.parentTaskId);
  return roots.map(root => ({
    ...root,
    subtasks: tasks.filter(t => t.parentTaskId === root.id),
  }));
}
