import {
  doc, getDoc, setDoc, updateDoc, collection,
  query, where, getDocs, serverTimestamp, Timestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { User, GlobalRole } from "@/types";
import { getInitials } from "@/lib/utils";

const COL = "users";

export async function getUser(uid: string): Promise<User | null> {
  const snap = await getDoc(doc(db, COL, uid));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as User;
}

export async function getAllUsers(): Promise<User[]> {
  const snap = await getDocs(query(collection(db, COL), where("active", "==", true)));
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as User));
}

export async function createOrUpdateUser(uid: string, data: {
  name: string;
  email: string;
  photoURL?: string;
}): Promise<User> {
  const existing = await getUser(uid);
  if (existing) {
    await updateDoc(doc(db, COL, uid), {
      name: data.name,
      email: data.email,
      photoURL: data.photoURL ?? null,
    });
    return { ...existing, ...data };
  }
  const newUser: Omit<User, "id"> = {
    name: data.name,
    email: data.email,
    avatar: getInitials(data.name),
    photoURL: data.photoURL,
    globalRole: "responsible", // default — admin promotes manually
    active: true,
    createdAt: serverTimestamp() as Timestamp,
  };
  await setDoc(doc(db, COL, uid), newUser);
  return { id: uid, ...newUser };
}

export async function updateUserRole(uid: string, role: GlobalRole): Promise<void> {
  await updateDoc(doc(db, COL, uid), { globalRole: role });
}

export async function deactivateUser(uid: string): Promise<void> {
  await updateDoc(doc(db, COL, uid), { active: false });
}
