import {
  collection, doc, addDoc, updateDoc, getDocs,
  query, orderBy, limit, onSnapshot,
  serverTimestamp, Timestamp, where, writeBatch,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Notification, NotificationType, ActivityLog } from "@/types";

// ─── NOTIFICATIONS ───────────────────────────────────────────────────────────

function notifCol(uid: string) {
  return collection(db, "notifications", uid, "items");
}

export async function createNotification(
  uid: string,
  data: {
    type: NotificationType;
    title: string;
    body: string;
    entityType?: "initiative" | "task" | "comment";
    entityId?: string;
  }
): Promise<void> {
  await addDoc(notifCol(uid), {
    ...data,
    read: false,
    createdAt: serverTimestamp(),
  });
}

export function subscribeNotifications(
  uid: string,
  callback: (notifications: Notification[]) => void
): () => void {
  const q = query(notifCol(uid), orderBy("createdAt", "desc"), limit(30));
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notification)));
  });
}

export async function markNotificationRead(uid: string, notifId: string): Promise<void> {
  await updateDoc(doc(db, "notifications", uid, "items", notifId), { read: true });
}

export async function markAllNotificationsRead(uid: string): Promise<void> {
  const snap = await getDocs(
    query(notifCol(uid), where("read", "==", false))
  );
  const batch = writeBatch(db);
  snap.docs.forEach(d => batch.update(d.ref, { read: true }));
  await batch.commit();
}

// ─── ACTIVITY LOG ─────────────────────────────────────────────────────────────

export async function logActivity(
  userId: string,
  action: string,
  entityType: "initiative" | "task" | "comment" | "user",
  entityId: string,
  oldValue?: Record<string, unknown> | Partial<unknown>,
  newValue?: Record<string, unknown> | Partial<unknown>
): Promise<void> {
  try {
    await addDoc(collection(db, "activityLog"), {
      userId,
      action,
      entityType,
      entityId,
      oldValue: oldValue ?? null,
      newValue: newValue ?? null,
      createdAt: serverTimestamp(),
    });
  } catch {
    // Non-blocking — log errors shouldn't break the main flow
    console.warn("Failed to log activity:", action, entityId);
  }
}

export async function getRecentActivity(limitCount = 20): Promise<ActivityLog[]> {
  const snap = await getDocs(
    query(collection(db, "activityLog"), orderBy("createdAt", "desc"), limit(limitCount))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog));
}

export function subscribeRecentActivity(
  callback: (logs: ActivityLog[]) => void,
  limitCount = 20
): () => void {
  const q = query(
    collection(db, "activityLog"),
    orderBy("createdAt", "desc"),
    limit(limitCount)
  );
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)));
  });
}
