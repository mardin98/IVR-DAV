import { Timestamp } from "firebase/firestore";
import { format, formatDistanceToNow, differenceInDays } from "date-fns";
import { es } from "date-fns/locale";
import {
  InitiativeStatus, InitiativePriority, InitiativeCategory,
  TaskStatus, MemberRole, GlobalRole,
} from "@/types";

// ─── DATE HELPERS ────────────────────────────────────────────────────────────

export function tsToDate(ts: Timestamp | undefined): Date | null {
  if (!ts) return null;
  return ts.toDate();
}

export function fmtDate(ts: Timestamp | undefined): string {
  const d = tsToDate(ts);
  if (!d) return "—";
  return format(d, "dd MMM yyyy", { locale: es });
}

export function fmtRelative(ts: Timestamp | undefined): string {
  const d = tsToDate(ts);
  if (!d) return "—";
  return formatDistanceToNow(d, { addSuffix: true, locale: es });
}

export function daysLeft(ts: Timestamp | undefined): number | null {
  const d = tsToDate(ts);
  if (!d) return null;
  return differenceInDays(d, new Date());
}

export function daysLeftLabel(ts: Timestamp | undefined): { label: string; color: string } {
  const days = daysLeft(ts);
  if (days === null) return { label: "Sin fecha", color: "#64748b" };
  if (days < 0) return { label: `Venció hace ${Math.abs(days)}d`, color: "#f87171" };
  if (days === 0) return { label: "Vence hoy", color: "#f87171" };
  if (days <= 3) return { label: `${days}d restantes`, color: "#f87171" };
  if (days <= 7) return { label: `${days}d restantes`, color: "#f59e0b" };
  return { label: `${days}d restantes`, color: "#64748b" };
}

export function dateToTimestamp(dateStr: string): Timestamp {
  return Timestamp.fromDate(new Date(dateStr));
}

// ─── CODE GENERATOR ──────────────────────────────────────────────────────────

export function generateInitiativeCode(count: number): string {
  return `INI-${String(count + 1).padStart(3, "0")}`;
}

// ─── PROGRESS CALCULATOR ─────────────────────────────────────────────────────

export function calcInitiativeProgress(tasks: { status: TaskStatus; progress: number }[]): number {
  if (!tasks.length) return 0;
  const rootTasks = tasks.filter(t => t.status !== undefined);
  if (!rootTasks.length) return 0;
  const avg = rootTasks.reduce((sum, t) => sum + t.progress, 0) / rootTasks.length;
  return Math.round(avg);
}

// ─── AVATAR INITIALS ─────────────────────────────────────────────────────────

export function getInitials(name: string): string {
  return name
    .split(" ")
    .slice(0, 2)
    .map(n => n[0])
    .join("")
    .toUpperCase();
}

// ─── STATUS CONFIG ───────────────────────────────────────────────────────────

export const INITIATIVE_STATUS: Record<InitiativeStatus, { label: string; color: string; bg: string }> = {
  draft:     { label: "Borrador",    color: "#64748b", bg: "rgba(100,116,139,0.15)" },
  active:    { label: "Activa",      color: "#22d3ee", bg: "rgba(34,211,238,0.12)" },
  on_hold:   { label: "En pausa",    color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
  completed: { label: "Completada",  color: "#4ade80", bg: "rgba(74,222,128,0.12)" },
  cancelled: { label: "Cancelada",   color: "#f87171", bg: "rgba(248,113,113,0.12)" },
};

export const TASK_STATUS: Record<TaskStatus, { label: string; color: string }> = {
  todo:        { label: "Pendiente",   color: "#64748b" },
  in_progress: { label: "En progreso", color: "#22d3ee" },
  blocked:     { label: "Bloqueada",   color: "#f87171" },
  review:      { label: "En revisión", color: "#a78bfa" },
  done:        { label: "Completada",  color: "#4ade80" },
};

export const PRIORITY_CONFIG: Record<InitiativePriority, { label: string; color: string }> = {
  critical: { label: "Crítica", color: "#f87171" },
  high:     { label: "Alta",    color: "#fb923c" },
  medium:   { label: "Media",   color: "#facc15" },
  low:      { label: "Baja",    color: "#4ade80" },
};

export const CATEGORY_CONFIG: Record<InitiativeCategory, { label: string; icon: string }> = {
  ai:         { label: "IA",              icon: "◈" },
  automation: { label: "Automatización",  icon: "⚙" },
  infra:      { label: "Infraestructura", icon: "⬡" },
  process:    { label: "Proceso",         icon: "◎" },
};

export const ROLE_CONFIG: Record<GlobalRole | MemberRole, { label: string; color: string; bg: string }> = {
  admin:       { label: "Admin",       color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
  leader:      { label: "Líder",       color: "#a78bfa", bg: "rgba(167,139,250,0.12)" },
  responsible: { label: "Responsable", color: "#22d3ee", bg: "rgba(34,211,238,0.12)" },
  observer:    { label: "Observador",  color: "#64748b", bg: "rgba(100,116,139,0.12)" },
};

// ─── PROGRESS COLOR ──────────────────────────────────────────────────────────

export function progressColor(pct: number): string {
  if (pct >= 80) return "#4ade80";
  if (pct >= 50) return "#22d3ee";
  return "#f59e0b";
}

// ─── BUDGET HELPERS ──────────────────────────────────────────────────────────

export function budgetPct(spent: number, total: number): number {
  if (!total) return 0;
  return Math.round((spent / total) * 100);
}

export function budgetColor(spent: number, total: number): string {
  const pct = budgetPct(spent, total);
  if (pct > 85) return "#f87171";
  if (pct > 60) return "#f59e0b";
  return "#22d3ee";
}

// ─── CSS CLASS HELPER ────────────────────────────────────────────────────────

export function cx(...classes: (string | undefined | null | false)[]): string {
  return classes.filter(Boolean).join(" ");
}
