"use client";

import { useState, useEffect } from "react";
import {
  subscribeAllInitiatives, subscribeUserInitiatives,
  createInitiative, updateInitiative, updateInitiativeStatus,
  deleteInitiative, addMemberToInitiative, removeMemberFromInitiative,
} from "@/lib/firestore/initiatives";
import { Initiative, InitiativeFormData, InitiativeStatus, MemberRole } from "@/types";
import { useAuth } from "./useAuth";

export function useInitiatives() {
  const { user } = useAuth();
  const [initiatives, setInitiatives] = useState<Initiative[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    const isAdminOrLeader = user.globalRole === "admin" || user.globalRole === "leader";
    const unsub = isAdminOrLeader
      ? subscribeAllInitiatives(data => { setInitiatives(data); setLoading(false); })
      : subscribeUserInitiatives(user.id, data => { setInitiatives(data); setLoading(false); });
    return unsub;
  }, [user]);

  const create = async (data: InitiativeFormData) => {
    if (!user) throw new Error("Not authenticated");
    return createInitiative(data, user.id);
  };

  const update = async (id: string, data: Partial<InitiativeFormData>) => {
    if (!user) throw new Error("Not authenticated");
    return updateInitiative(id, data, user.id);
  };

  const changeStatus = async (id: string, status: InitiativeStatus) => {
    if (!user) throw new Error("Not authenticated");
    return updateInitiativeStatus(id, status, user.id);
  };

  const remove = async (id: string) => {
    if (!user) throw new Error("Not authenticated");
    return deleteInitiative(id, user.id);
  };

  const addMember = async (initiativeId: string, uid: string, role: MemberRole) => {
    if (!user) throw new Error("Not authenticated");
    return addMemberToInitiative(initiativeId, uid, role, user.id);
  };

  const removeMember = async (initiativeId: string, uid: string) => {
    if (!user) throw new Error("Not authenticated");
    return removeMemberFromInitiative(initiativeId, uid, user.id);
  };

  return { initiatives, loading, create, update, changeStatus, remove, addMember, removeMember };
}
