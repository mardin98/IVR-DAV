"use client";

import { useState, useEffect } from "react";
import {
  subscribeTasks, createTask, updateTask, updateTaskStatus,
  updateTaskProgress, logHours, deleteTask, buildTaskTree,
} from "@/lib/firestore/tasks";
import {
  subscribeNotifications, markNotificationRead, markAllNotificationsRead,
} from "@/lib/firestore/notifications";
import { Task, TaskFormData, TaskStatus, Notification } from "@/types";
import { useAuth } from "./useAuth";

// ─── TASKS ────────────────────────────────────────────────────────────────────

export function useTasks(initiativeId: string) {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskTree, setTaskTree] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!initiativeId) return;
    setLoading(true);
    const unsub = subscribeTasks(initiativeId, data => {
      setTasks(data);
      setTaskTree(buildTaskTree(data));
      setLoading(false);
    });
    return unsub;
  }, [initiativeId]);

  const create = async (data: TaskFormData) => {
    if (!user) throw new Error("Not authenticated");
    return createTask(initiativeId, data, user.id);
  };

  const update = async (taskId: string, data: Partial<TaskFormData>) => {
    if (!user) throw new Error("Not authenticated");
    return updateTask(initiativeId, taskId, data, user.id);
  };

  const changeStatus = async (taskId: string, status: TaskStatus) => {
    if (!user) throw new Error("Not authenticated");
    return updateTaskStatus(initiativeId, taskId, status, user.id);
  };

  const changeProgress = async (taskId: string, progress: number) => {
    return updateTaskProgress(initiativeId, taskId, progress);
  };

  const addHours = async (taskId: string, hours: number) => {
    return logHours(initiativeId, taskId, hours);
  };

  const remove = async (taskId: string) => {
    if (!user) throw new Error("Not authenticated");
    return deleteTask(initiativeId, taskId, user.id);
  };

  return { tasks, taskTree, loading, create, update, changeStatus, changeProgress, addHours, remove };
}

// ─── NOTIFICATIONS ───────────────────────────────────────────────────────────

export function useNotifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsub = subscribeNotifications(user.id, data => {
      setNotifications(data);
      setLoading(false);
    });
    return unsub;
  }, [user]);

  const markRead = async (notifId: string) => {
    if (!user) return;
    return markNotificationRead(user.id, notifId);
  };

  const markAllRead = async () => {
    if (!user) return;
    return markAllNotificationsRead(user.id);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return { notifications, unreadCount, loading, markRead, markAllRead };
}
