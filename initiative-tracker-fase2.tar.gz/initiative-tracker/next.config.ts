import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // Skip static generation for pages that require Firebase
  experimental: {
    missingSuspenseWithCSRBailout: false,
  },
};

export default nextConfig;
