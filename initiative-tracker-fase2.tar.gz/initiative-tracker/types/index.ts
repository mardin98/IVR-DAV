import { Timestamp } from "firebase/firestore";

// ─── ENUMS ────────────────────────────────────────────────────────────────────

export type GlobalRole = "admin" | "leader" | "responsible";
export type InitiativeStatus = "draft" | "active" | "on_hold" | "completed" | "cancelled";
export type InitiativePriority = "critical" | "high" | "medium" | "low";
export type InitiativeCategory = "ai" | "automation" | "infra" | "process";
export type TaskStatus = "todo" | "in_progress" | "blocked" | "review" | "done";
export type MemberRole = "leader" | "responsible" | "observer";
export type NotificationType = "info" | "warning" | "success" | "error";

// ─── USER ─────────────────────────────────────────────────────────────────────

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string; // Initials e.g. "MT"
  photoURL?: string;
  globalRole: GlobalRole;
  active: boolean;
  createdAt: Timestamp;
}

// ─── INITIATIVE ───────────────────────────────────────────────────────────────

export interface Initiative {
  id: string;
  code: string; // INI-001
  title: string;
  description: string;
  status: InitiativeStatus;
  priority: InitiativePriority;
  category: InitiativeCategory;
  leaderId: string;
  members: string[]; // UIDs
  memberRoles: Record<string, MemberRole>; // { uid: role }
  progress: number; // 0-100, auto-calculated
  startDate: Timestamp;
  dueDate: Timestamp;
  completedAt?: Timestamp;
  budget: number;
  budgetSpent: number;
  googleDriveFolderId?: string;
  googleCalendarEventId?: string;
  createdBy: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface InitiativeFormData {
  title: string;
  description: string;
  status: InitiativeStatus;
  priority: InitiativePriority;
  category: InitiativeCategory;
  leaderId: string;
  startDate: string;
  dueDate: string;
  budget: number;
}

// ─── TASK ─────────────────────────────────────────────────────────────────────

export interface Task {
  id: string;
  initiativeId: string;
  parentTaskId?: string; // null = root task
  title: string;
  description?: string;
  assigneeId: string;
  status: TaskStatus;
  priority: InitiativePriority;
  progress: number; // 0-100
  estimatedHours: number;
  loggedHours: number;
  dueDate?: Timestamp;
  orderIndex: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  // Populated client-side
  subtasks?: Task[];
}

export interface TaskFormData {
  title: string;
  description?: string;
  assigneeId: string;
  status: TaskStatus;
  priority: InitiativePriority;
  progress: number;
  estimatedHours: number;
  dueDate?: string;
  parentTaskId?: string;
}

// ─── COMMENT ──────────────────────────────────────────────────────────────────

export interface Comment {
  id: string;
  taskId: string;
  initiativeId: string;
  userId: string;
  body: string;
  createdAt: Timestamp;
}

// ─── NOTIFICATION ─────────────────────────────────────────────────────────────

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  entityType?: "initiative" | "task" | "comment";
  entityId?: string;
  read: boolean;
  createdAt: Timestamp;
}

// ─── ACTIVITY LOG ─────────────────────────────────────────────────────────────

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  entityType: "initiative" | "task" | "comment" | "user";
  entityId: string;
  oldValue?: Record<string, unknown>;
  newValue?: Record<string, unknown>;
  createdAt: Timestamp;
}

// ─── SCHEDULED REPORT ────────────────────────────────────────────────────────

export interface ScheduledReport {
  id: string;
  name: string;
  frequency: "daily" | "weekly" | "monthly";
  recipients: string[];
  filters: {
    status?: InitiativeStatus[];
    leaderId?: string;
    category?: InitiativeCategory[];
  };
  active: boolean;
  lastSentAt?: Timestamp;
}

// ─── UI HELPERS ───────────────────────────────────────────────────────────────

export interface SelectOption {
  value: string;
  label: string;
}

export interface DashboardStats {
  activeCount: number;
  onHoldCount: number;
  completedCount: number;
  criticalCount: number;
  avgProgress: number;
  overBudgetCount: number;
  totalBudget: number;
  totalSpent: number;
}
