/**
 * transferencias.js — Módulo de ejemplo para probar TESTFORGE
 *
 * Simula utilidades de un sistema bancario interno.
 * Sube este archivo en la UI → Upload para ver el pipeline completo.
 */

// ─── Validaciones ──────────────────────────────────────────────────────────────

/**
 * Valida formato de cuenta bancaria salvadoreña
 * Formato: 2 letras + 10 dígitos (ej: DV1234567890)
 */
function validarCuenta(cuenta) {
  if (!cuenta || typeof cuenta !== 'string') return false;
  return /^[A-Z]{2}\d{10}$/.test(cuenta.trim().toUpperCase());
}

/**
 * Valida que un monto sea válido para transferencia
 * - Mayor a 0
 * - Máximo $50,000 por operación
 * - Máximo 2 decimales
 */
function validarMonto(monto) {
  if (monto === null || monto === undefined) return { valido: false, error: 'Monto requerido' };
  if (typeof monto !== 'number' || isNaN(monto)) return { valido: false, error: 'Monto debe ser número' };
  if (monto <= 0)      return { valido: false, error: 'Monto debe ser mayor a 0' };
  if (monto > 50000)   return { valido: false, error: 'Monto supera límite de $50,000' };
  if (!/^\d+(\.\d{1,2})?$/.test(String(monto))) return { valido: false, error: 'Máximo 2 decimales' };
  return { valido: true };
}

// ─── Cálculos ─────────────────────────────────────────────────────────────────

/**
 * Calcula comisión de transferencia
 * - Hasta $500: sin comisión
 * - $500.01 - $5000: 0.5%
 * - Mayor a $5000: 1%
 */
function calcularComision(monto) {
  if (typeof monto !== 'number' || monto <= 0) return 0;
  if (monto <= 500)  return 0;
  if (monto <= 5000) return Math.round(monto * 0.005 * 100) / 100;
  return Math.round(monto * 0.01 * 100) / 100;
}

/**
 * Formatea monto como moneda USD
 */
function formatearMonto(monto) {
  if (typeof monto !== 'number') return '$0.00';
  return `$${monto.toFixed(2)}`;
}

// ─── Lógica de transferencia ───────────────────────────────────────────────────

/**
 * Prepara una transferencia bancaria
 * @returns { ok, error, detalle }
 */
function prepararTransferencia({ origen, destino, monto, descripcion }) {
  // Validar cuentas
  if (!validarCuenta(origen))  return { ok: false, error: 'Cuenta origen inválida' };
  if (!validarCuenta(destino)) return { ok: false, error: 'Cuenta destino inválida' };
  if (origen === destino)      return { ok: false, error: 'Origen y destino no pueden ser iguales' };

  // Validar monto
  const validMonto = validarMonto(monto);
  if (!validMonto.valido) return { ok: false, error: validMonto.error };

  const comision  = calcularComision(monto);
  const totalDebi = Math.round((monto + comision) * 100) / 100;

  return {
    ok: true,
    detalle: {
      origen,
      destino,
      monto,
      comision,
      totalDebito: totalDebi,
      descripcion: descripcion || 'Transferencia',
      montoFormateado:     formatearMonto(monto),
      comisionFormateada:  formatearMonto(comision),
      totalFormateado:     formatearMonto(totalDebi),
      timestamp:           new Date().toISOString(),
    },
  };
}

module.exports = {
  validarCuenta,
  validarMonto,
  calcularComision,
  formatearMonto,
  prepararTransferencia,
};
