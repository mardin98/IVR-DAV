/**
 * TESTFORGE — Executor Service
 * Corre los scripts aprobados y guarda resultados en DB + disco.
 * Runners: playwright, jest, pytest, node
 */

require('dotenv').config();

const { execFile } = require('child_process');
const path   = require('path');
const fs     = require('fs');
const logger = require('../shared/logger').forModule('Executor');
const db     = require('../shared/db');

const RESULTS_DIR = process.env.RESULTS_DIR || path.join(process.cwd(), 'data', 'results');
fs.mkdirSync(RESULTS_DIR, { recursive: true });

// ─── Runners ──────────────────────────────────────────────────────────────────
function runNode(scriptPath, jobId) {
  return runProcess('node', [scriptPath], jobId, { timeout: 60000 });
}

function runJest(scriptPath, jobId) {
  const jestBin    = path.join(process.cwd(), 'node_modules', '.bin', 'jest');
  const outputFile = path.join(RESULTS_DIR, jobId, 'jest-results.json');
  fs.mkdirSync(path.dirname(outputFile), { recursive: true });
  return runProcess(jestBin, [
    scriptPath,
    '--json',
    `--outputFile=${outputFile}`,
    '--no-coverage',
    '--forceExit',
    '--testTimeout=30000',
  ], jobId, { timeout: 120000 });
}

function runPytest(scriptPath, jobId) {
  const resultFile = path.join(RESULTS_DIR, jobId, 'pytest-results.json');
  fs.mkdirSync(path.dirname(resultFile), { recursive: true });
  return runProcess('python3', [
    '-m', 'pytest', scriptPath,
    '--json-report',
    `--json-report-file=${resultFile}`,
    '-v',
  ], jobId, { timeout: 120000 });
}

function runPlaywright(scriptPath, jobId) {
  const playwrightBin = path.join(process.cwd(), 'node_modules', '.bin', 'playwright');
  const reportDir     = path.join(RESULTS_DIR, jobId, 'playwright-report');
  return runProcess(playwrightBin, [
    'test', scriptPath,
    '--reporter=json',
    `--output=${reportDir}`,
  ], jobId, { timeout: 180000 });
}

// ─── Proceso base ─────────────────────────────────────────────────────────────
function runProcess(cmd, args, jobId, opts = {}) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const logsDir   = path.join(RESULTS_DIR, jobId);
    fs.mkdirSync(logsDir, { recursive: true });

    const logFile   = path.join(logsDir, 'execution.log');
    const logStream = fs.createWriteStream(logFile, { flags: 'a' });

    logStream.write(`=== TESTFORGE Execution ===\n`);
    logStream.write(`Command: ${cmd} ${args.join(' ')}\n`);
    logStream.write(`Started: ${new Date().toISOString()}\n\n`);

    execFile(cmd, args, {
      timeout:   opts.timeout || 60000,
      maxBuffer: 10 * 1024 * 1024,
      cwd:       process.cwd(),
      env:       { ...process.env, FORCE_COLOR: '0' },
    }, (error, stdout, stderr) => {
      const duration = Date.now() - startTime;
      logStream.write(`\n--- STDOUT ---\n${stdout}`);
      if (stderr) logStream.write(`\n--- STDERR ---\n${stderr}`);
      logStream.write(`\n--- Finished in ${duration}ms | exit: ${error?.code ?? 0} ---\n`);
      logStream.end();

      resolve({
        passed:   !error || error.code === 0,
        exitCode: error?.code ?? 0,
        stdout:   stdout.substring(0, 5000),
        stderr:   stderr.substring(0, 2000),
        duration,
        logFile,
        error:    error ? { message: error.message, killed: error.killed } : null,
      });
    });
  });
}

function runScript(runner, scriptPath, jobId) {
  switch (runner) {
    case 'playwright': return runPlaywright(scriptPath, jobId);
    case 'jest':       return runJest(scriptPath, jobId);
    case 'pytest':     return runPytest(scriptPath, jobId);
    case 'node':
    default:           return runNode(scriptPath, jobId);
  }
}

// ─── Parsear approved_script de forma segura ──────────────────────────────────
function parseApprovedScript(raw) {
  if (!raw) return null;
  if (typeof raw === 'object') return raw;
  try { return JSON.parse(raw); } catch { return null; }
}

// ─── Procesador principal ─────────────────────────────────────────────────────
async function processExecuteJob(job) {
  const { id } = job.data;
  logger.info('Ejecutando job', { id });

  const jobData = await db.getJob(id);
  if (!jobData) throw new Error(`Job ${id} no encontrado en DB`);

  const approvedScript = parseApprovedScript(jobData.approved_script);
  if (!approvedScript?.code) throw new Error(`Job ${id} sin script aprobado válido`);

  await db.updateJob(id, { status: 'running' });

  // Guardar script a disco (puede haber sido editado en UI)
  const execDir    = path.join(RESULTS_DIR, id, 'exec');
  fs.mkdirSync(execDir, { recursive: true });
  const filename   = approvedScript.filename || 'test.js';
  const scriptPath = path.join(execDir, filename);
  fs.writeFileSync(scriptPath, approvedScript.code, 'utf-8');

  logger.info('Corriendo script', { id, runner: approvedScript.runner, scriptPath });

  const result = await runScript(approvedScript.runner || 'node', scriptPath, id);

  const executionResults = {
    passed:      result.passed,
    exitCode:    result.exitCode,
    duration:    result.duration,
    stdout:      result.stdout,
    stderr:      result.stderr,
    logFile:     result.logFile,
    runner:      approvedScript.runner,
    executedAt:  new Date().toISOString(),
    scriptPath,
  };

  // Leer resultados estructurados de Jest si existen
  const jestFile = path.join(RESULTS_DIR, id, 'jest-results.json');
  if (fs.existsSync(jestFile)) {
    try {
      const jd = JSON.parse(fs.readFileSync(jestFile, 'utf-8'));
      executionResults.testSummary = {
        total:   jd.numTotalTests,
        passed:  jd.numPassedTests,
        failed:  jd.numFailedTests,
        skipped: jd.numPendingTests,
      };
    } catch {}
  }

  const finalStatus = result.passed ? 'passed' : 'failed';
  await db.updateJob(id, { status: finalStatus, executionResults });
  logger.info(`Job ${finalStatus}`, { id, duration: result.duration });

  // Notificar
  const { enqueue } = require('../shared/queue');
  await enqueue('notify', {
    jobId: id,
    type:  result.passed ? 'job_passed' : 'job_failed',
  });
}

// ─── Worker ───────────────────────────────────────────────────────────────────
function start() {
  const { queues } = require('../shared/queue');

  queues.execute.process(2, async (job) => {
    try {
      await processExecuteJob(job);
    } catch (err) {
      logger.error('Error en Executor', { jobId: job.data?.id, error: err.message });
      try { await db.updateJob(job.data?.id, { status: 'error', errorMessage: err.message }); } catch {}
      throw err;
    }
  });

  logger.info('Executor worker activo — escuchando cola "execute"');
}

start();
module.exports = { runScript, processExecuteJob };
