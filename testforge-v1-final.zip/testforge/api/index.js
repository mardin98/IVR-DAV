/**
 * TESTFORGE — API Server
 * REST endpoints consumidos por la UI Next.js
 */

require('dotenv').config();

const express = require('express');
const path    = require('path');
const fs      = require('fs');
const logger  = require('../shared/logger').forModule('API');
const db      = require('../shared/db');
const { enqueue, getQueueStats } = require('../shared/queue');

const router = express.Router();

// ─── CORS ─────────────────────────────────────────────────────────────────────
router.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// ─── Jobs ─────────────────────────────────────────────────────────────────────
router.get('/jobs', async (req, res) => {
  try {
    const { status, sourceType, limit } = req.query;
    const jobs = await db.listJobs({
      status,
      sourceType,
      limit: limit ? parseInt(limit) : 50,
    });
    res.json({ jobs, count: jobs.length });
  } catch (err) {
    logger.error('GET /jobs', { error: err.message });
    res.status(500).json({ error: err.message });
  }
});

router.get('/jobs/:id', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });
    res.json(job);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Aprobar ──────────────────────────────────────────────────────────────────
router.post('/jobs/:id/approve', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });
    if (job.status !== 'pending_approval') {
      return res.status(400).json({ error: `Estado actual: "${job.status}" — no se puede aprobar` });
    }

    const { approvedBy, editedScript } = req.body;

    // generated_scripts ya viene parseado como array por rowToJob
    let scriptToRun;
    if (editedScript?.code) {
      scriptToRun = editedScript;
    } else {
      const scripts = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];
      scriptToRun  = scripts[0];
    }

    if (!scriptToRun?.code) {
      return res.status(400).json({ error: 'No hay script para aprobar' });
    }

    await db.updateJob(req.params.id, {
      status:         'approved',
      approvedBy:     approvedBy || 'admin',
      approvedAt:     new Date().toISOString(),
      approvedScript: scriptToRun,
    });

    await enqueue('execute', { id: req.params.id });

    logger.info('Job aprobado', { jobId: req.params.id, approvedBy });
    res.json({ message: 'Job aprobado. Ejecutando...', jobId: req.params.id });
  } catch (err) {
    logger.error('POST /approve', { error: err.message });
    res.status(500).json({ error: err.message });
  }
});

// ─── Rechazar ─────────────────────────────────────────────────────────────────
router.post('/jobs/:id/reject', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });

    const { reason, rejectedBy } = req.body;
    await db.updateJob(req.params.id, {
      status:         'rejected',
      rejectedReason: reason || 'Sin motivo especificado',
      approvedBy:     rejectedBy || 'admin',
    });

    logger.info('Job rechazado', { jobId: req.params.id, reason });
    res.json({ message: 'Job rechazado', jobId: req.params.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Resultados ───────────────────────────────────────────────────────────────
router.get('/jobs/:id/results', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });

    const RESULTS_DIR = process.env.RESULTS_DIR || path.join(process.cwd(), 'data', 'results');
    const logFile     = path.join(RESULTS_DIR, job.id, 'execution.log');

    res.json({
      jobId:            job.id,
      status:           job.status,
      executionResults: job.execution_results,
      log:              fs.existsSync(logFile)
                          ? fs.readFileSync(logFile, 'utf-8').substring(0, 20000)
                          : null,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Stats ────────────────────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [allJobs, queueStats] = await Promise.all([
      db.listJobs({ limit: 500 }),
      getQueueStats(),
    ]);

    const byStatus = allJobs.reduce((acc, job) => {
      acc[job.status] = (acc[job.status] || 0) + 1;
      return acc;
    }, {});

    const totalRan = (byStatus.passed || 0) + (byStatus.failed || 0);
    res.json({
      jobs: {
        total:    allJobs.length,
        byStatus,
        passRate: totalRan > 0 ? Math.round((byStatus.passed || 0) / totalRan * 100) : null,
      },
      queues: queueStats,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Notificaciones ───────────────────────────────────────────────────────────
router.get('/notifications', async (req, res) => {
  try {
    const dbConn = await db.getDb();
    const result = dbConn.exec(
      `SELECT n.*, j.app_type, j.source_type
       FROM notifications n
       LEFT JOIN jobs j ON n.job_id = j.id
       ORDER BY n.id DESC LIMIT 50`
    );
    if (!result.length) return res.json({ notifications: [] });
    const rows = result[0].values.map(row => {
      const obj = {};
      result[0].columns.forEach((col, i) => { obj[col] = row[i]; });
      return obj;
    });
    res.json({ notifications: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Sources ──────────────────────────────────────────────────────────────────
router.get('/sources', async (req, res) => {
  try {
    res.json({ sources: await db.listSources() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── App ──────────────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '10mb' }));
app.use('/api', router);
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'api', uptime: process.uptime() }));

const PORT = process.env.API_PORT || 3002;
app.listen(PORT, () => {
  logger.info(`API Server en puerto ${PORT}`);
});

module.exports = app;
