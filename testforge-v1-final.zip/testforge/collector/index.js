/**
 * TESTFORGE — Collector Service
 * 
 * Recibe código desde 3 fuentes:
 *   1. GitLab Webhook (push / merge_request events)
 *   2. Folder Watcher (chokidar — monitorea carpetas locales)
 *   3. Upload Manual (multipart form via API REST)
 * 
 * Normaliza el input, crea un Job en SQLite y lo encola para análisis.
 */

require('dotenv').config();

const express    = require('express');
const crypto     = require('crypto');
const multer     = require('multer');
const path       = require('path');
const fs         = require('fs');
const { v4: uuidv4 } = require('uuid');
const chokidar   = require('chokidar');

const logger  = require('../shared/logger').forModule('Collector');
const db      = require('../shared/db');
const { enqueue } = require('../shared/queue');

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Dirs ────────────────────────────────────────────────────────────────────
const UPLOAD_DIR  = process.env.UPLOAD_DIR  || path.join(process.cwd(), 'data', 'uploads');
const SCRIPTS_DIR = process.env.SCRIPTS_DIR || path.join(process.cwd(), 'data', 'scripts');
[UPLOAD_DIR, SCRIPTS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ─── Multer (uploads manuales) ────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.js', '.ts', '.py', '.json', '.yaml', '.yml', '.txt', '.rb'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) return cb(null, true);
    cb(new Error(`Extensión no soportada: ${ext}. Permitidas: ${allowed.join(', ')}`));
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// FUENTE 1: GitLab Webhook
// ─────────────────────────────────────────────────────────────────────────────
app.post('/webhook/gitlab', async (req, res) => {
  // 1. Validar firma HMAC
  const secret = process.env.GITLAB_WEBHOOK_SECRET;
  if (secret) {
    const token = req.headers['x-gitlab-token'];
    if (!token || token !== secret) {
      logger.warn('Webhook rechazado — token inválido', { ip: req.ip });
      return res.status(401).json({ error: 'Token inválido' });
    }
  }

  const event = req.headers['x-gitlab-event'];
  const payload = req.body;

  logger.info('Webhook GitLab recibido', { event, project: payload.project?.name });

  // 2. Solo procesar Push y Merge Request
  if (!['Push Hook', 'Merge Request Hook'].includes(event)) {
    return res.json({ message: 'Evento ignorado', event });
  }

  try {
    // 3. Extraer archivos modificados
    const files = extractModifiedFiles(event, payload);
    if (!files.length) {
      logger.info('No hay archivos relevantes en el evento');
      return res.json({ message: 'Sin archivos relevantes' });
    }

    // 4. Crear un job por cada archivo (o uno agrupado — aquí uno por archivo para granularidad)
    const jobs = [];
    for (const file of files) {
      const jobId = uuidv4();
      const sourceMeta = {
        event,
        project:    payload.project?.name,
        projectUrl: payload.project?.web_url,
        branch:     payload.ref?.replace('refs/heads/', ''),
        commit:     payload.checkout_sha || payload.object_attributes?.last_commit?.id,
        author:     payload.user_username || payload.user?.username,
        filePath:   file.path,
        fileAction: file.action, // added | modified | removed
      };

      const job = await db.createJob({
        id: jobId,
        sourceType: 'gitlab',
        status: 'analyzing',
        sourceMeta,
        rawContent: file.content || null, // contenido si viene en payload (raro en GitLab)
      });

      await enqueue('analyze', { id: jobId, sourceType: 'gitlab', sourceMeta, rawContent: file.content });
      jobs.push(jobId);
      logger.info('Job creado desde GitLab', { jobId, file: file.path });
    }

    res.json({ message: 'Jobs creados', count: jobs.length, jobIds: jobs });

  } catch (err) {
    logger.error('Error procesando webhook', { error: err.message });
    res.status(500).json({ error: 'Error interno procesando webhook' });
  }
});

function extractModifiedFiles(event, payload) {
  const ignoredExtensions = ['.md', '.txt', '.lock', '.gitignore', '.env'];
  const files = [];

  const commits = payload.commits || [];
  for (const commit of commits) {
    const allFiles = [
      ...(commit.added    || []).map(f => ({ path: f, action: 'added' })),
      ...(commit.modified || []).map(f => ({ path: f, action: 'modified' })),
    ];
    for (const f of allFiles) {
      const ext = path.extname(f.path).toLowerCase();
      if (!ignoredExtensions.includes(ext)) files.push(f);
    }
  }

  // MR: tomar archivos del último commit
  if (event === 'Merge Request Hook' && payload.object_attributes?.last_commit) {
    const lc = payload.object_attributes.last_commit;
    files.push({ path: lc.url || 'merge-request', action: 'merge_request' });
  }

  return files;
}

// ─────────────────────────────────────────────────────────────────────────────
// FUENTE 2: Upload Manual
// ─────────────────────────────────────────────────────────────────────────────
app.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No se recibió archivo' });
  }

  const { appType, description } = req.body;
  const jobId = uuidv4();
  const filePath = req.file.path;
  const rawContent = fs.readFileSync(filePath, 'utf-8');

  const sourceMeta = {
    originalName: req.file.originalname,
    size: req.file.size,
    mimeType: req.file.mimetype,
    storedPath: filePath,
    description: description || '',
    uploadedAt: new Date().toISOString(),
  };

  try {
    await db.createJob({
      id: jobId,
      sourceType: 'manual',
      appType: appType || null,
      status: 'analyzing',
      sourceMeta,
      rawContent,
    });

    await enqueue('analyze', { id: jobId, sourceType: 'manual', sourceMeta, rawContent, appType });

    logger.info('Job creado desde upload manual', { jobId, file: req.file.originalname });
    res.json({ message: 'Archivo recibido y encolado para análisis', jobId });

  } catch (err) {
    logger.error('Error procesando upload', { error: err.message });
    res.status(500).json({ error: 'Error interno procesando archivo' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// FUENTE 3: Folder Watcher
// ─────────────────────────────────────────────────────────────────────────────
const watchers = new Map();

function startFolderWatcher(sourceConfig) {
  const { id, name, config } = sourceConfig;
  const watchPath = config.path;

  if (!fs.existsSync(watchPath)) {
    logger.warn('Carpeta a monitorear no existe', { path: watchPath });
    return;
  }

  if (watchers.has(id)) {
    logger.info('Watcher ya activo para esta fuente', { name });
    return;
  }

  const ignoredExtensions = ['.md', '.txt', '.lock', '.log', '.gitignore', '.env'];
  const debounceMap = new Map();

  const watcher = chokidar.watch(watchPath, {
    ignored: /(^|[/\\])\../, // ignorar dotfiles
    persistent: true,
    ignoreInitial: true,     // no procesar archivos existentes al arrancar
    awaitWriteFinish: { stabilityThreshold: 1000, pollInterval: 100 },
  });

  const handleFile = async (filePath, action) => {
    const ext = path.extname(filePath).toLowerCase();
    if (ignoredExtensions.includes(ext)) return;

    // Debounce por archivo (evitar múltiples eventos por guardado)
    const debounceKey = filePath;
    if (debounceMap.has(debounceKey)) clearTimeout(debounceMap.get(debounceKey));

    debounceMap.set(debounceKey, setTimeout(async () => {
      debounceMap.delete(debounceKey);
      try {
        const rawContent = fs.readFileSync(filePath, 'utf-8');
        const jobId = uuidv4();
        const sourceMeta = {
          watchSource: name,
          watchPath,
          filePath,
          action,
          detectedAt: new Date().toISOString(),
        };

        await db.createJob({
          id: jobId,
          sourceType: 'folder',
          status: 'analyzing',
          sourceMeta,
          rawContent,
        });

        await enqueue('analyze', { id: jobId, sourceType: 'folder', sourceMeta, rawContent });
        logger.info('Job creado desde folder watcher', { jobId, file: filePath, action });

      } catch (err) {
        logger.error('Error procesando archivo de carpeta', { error: err.message, filePath });
      }
    }, 500));
  };

  watcher.on('add',    fp => handleFile(fp, 'added'));
  watcher.on('change', fp => handleFile(fp, 'modified'));
  watcher.on('error',  err => logger.error('Error en watcher', { error: err.message, path: watchPath }));

  watchers.set(id, watcher);
  logger.info('Folder watcher iniciado', { name, path: watchPath });
}

function stopFolderWatcher(sourceId) {
  const watcher = watchers.get(sourceId);
  if (watcher) {
    watcher.close();
    watchers.delete(sourceId);
    logger.info('Folder watcher detenido', { sourceId });
  }
}

// ─── API interna: gestión de fuentes ─────────────────────────────────────────
app.post('/sources/folder', async (req, res) => {
  const { name, folderPath } = req.body;
  if (!name || !folderPath) return res.status(400).json({ error: 'name y folderPath requeridos' });

  const sourceId = uuid();
  const source = { id: sourceId, name, type: 'folder', config: { path: folderPath } };

  await db.createSource(source);
  startFolderWatcher(source);

  res.json({ message: 'Fuente de carpeta creada y watcher iniciado', sourceId });
});

app.delete('/sources/:id', (req, res) => {
  stopFolderWatcher(req.params.id);
  res.json({ message: 'Watcher detenido', sourceId: req.params.id });
});

// ─── Health & Status ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'collector',
    watchers: watchers.size,
    uptime: process.uptime(),
  });
});

app.get('/jobs/recent', async (req, res) => {
  const jobs = await db.listJobs({ limit: 20 });
  res.json(jobs);
});

// ─── Arranque ────────────────────────────────────────────────────────────────
async function start() {
  // Iniciar watchers de fuentes guardadas en DB
  const sources = await db.listSources();
  const folderSources = sources.filter(s => s.type === 'folder');
  folderSources.forEach(s => startFolderWatcher(s));
  logger.info(`${folderSources.length} folder watcher(s) restaurados desde DB`);

  const PORT = process.env.COLLECTOR_PORT || process.env.PORT || 3001;
  app.listen(PORT, () => {
    logger.info(`Collector escuchando en puerto ${PORT}`);
    logger.info('Endpoints disponibles:');
    logger.info(`  POST /webhook/gitlab   — GitLab webhook`);
    logger.info(`  POST /upload           — Upload manual de archivo`);
    logger.info(`  POST /sources/folder   — Agregar carpeta a monitorear`);
    logger.info(`  GET  /health           — Estado del servicio`);
    logger.info(`  GET  /jobs/recent      — Últimos 20 jobs`);
  });
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM recibido — cerrando watchers...');
  for (const [id, watcher] of watchers) { await watcher.close(); }
  process.exit(0);
});

start().catch(err => {
  logger.error('Error al arrancar Collector', { error: err.message });
  process.exit(1);
});

module.exports = { app, startFolderWatcher, stopFolderWatcher };
