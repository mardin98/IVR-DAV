/**
 * TESTFORGE — Database Layer (SQLite via sql.js)
 * Persiste en archivo binario en data/testforge.db
 */

const initSqlJs = require('sql.js');
const fs   = require('fs');
const path = require('path');
const logger = require('./logger').forModule('DB');

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(), 'data', 'testforge.db');

let _db  = null;
let _SQL = null;

// ─── Init ─────────────────────────────────────────────────────────────────────
async function getDb() {
  if (_db) return _db;

  _SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    _db = new _SQL.Database(fileBuffer);
    logger.info('DB cargada desde archivo', { path: DB_PATH });
  } else {
    _db = new _SQL.Database();
    logger.info('DB nueva creada', { path: DB_PATH });
  }

  _db.run(`
    CREATE TABLE IF NOT EXISTS jobs (
      id                TEXT PRIMARY KEY,
      source_type       TEXT NOT NULL,
      app_type          TEXT,
      status            TEXT NOT NULL DEFAULT 'analyzing',
      source_meta       TEXT,
      raw_content       TEXT,
      context           TEXT,
      generated_scripts TEXT,
      approved_script   TEXT,
      approved_by       TEXT,
      approved_at       TEXT,
      rejected_reason   TEXT,
      execution_results TEXT,
      error_message     TEXT,
      created_at        TEXT NOT NULL,
      updated_at        TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sources (
      id         TEXT PRIMARY KEY,
      name       TEXT NOT NULL,
      type       TEXT NOT NULL,
      config     TEXT NOT NULL,
      active     INTEGER DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id   TEXT NOT NULL,
      type     TEXT NOT NULL,
      sent_at  TEXT,
      error    TEXT,
      FOREIGN KEY(job_id) REFERENCES jobs(id)
    );
  `);

  saveDb();
  return _db;
}

// ─── Persistencia ─────────────────────────────────────────────────────────────
function saveDb() {
  if (!_db) return;
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const data = _db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// ─── camelCase → snake_case ───────────────────────────────────────────────────
function toSnake(str) {
  return str.replace(/([A-Z])/g, '_$1').toLowerCase();
}

// ─── Jobs ─────────────────────────────────────────────────────────────────────
async function createJob(job) {
  const db  = await getDb();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO jobs
       (id, source_type, app_type, status, source_meta, raw_content, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      job.id,
      job.sourceType,
      job.appType   || null,
      job.status    || 'analyzing',
      JSON.stringify(job.sourceMeta || {}),
      job.rawContent || null,
      now, now,
    ]
  );
  saveDb();
  return getJob(job.id);
}

async function updateJob(id, fields) {
  const db  = await getDb();
  const now = new Date().toISOString();

  const ALLOWED_COLS = new Set([
    'status', 'app_type', 'context', 'generated_scripts',
    'approved_script', 'approved_by', 'approved_at',
    'rejected_reason', 'execution_results', 'error_message',
  ]);

  const updates = [];
  const values  = [];

  for (const [key, val] of Object.entries(fields)) {
    const col = toSnake(key);
    if (!ALLOWED_COLS.has(col)) continue;
    updates.push(`${col} = ?`);
    values.push(val !== null && typeof val === 'object' ? JSON.stringify(val) : val);
  }

  if (!updates.length) return getJob(id);

  updates.push('updated_at = ?');
  values.push(now, id);

  db.run(`UPDATE jobs SET ${updates.join(', ')} WHERE id = ?`, values);
  saveDb();
  return getJob(id);
}

async function getJob(id) {
  const db     = await getDb();
  const result = db.exec('SELECT * FROM jobs WHERE id = ?', [id]);
  if (!result.length || !result[0].values.length) return null;
  return rowToJob(result[0].columns, result[0].values[0]);
}

async function listJobs(filters = {}) {
  const db         = await getDb();
  let   query      = 'SELECT * FROM jobs';
  const params     = [];
  const conditions = [];

  if (filters.status)     { conditions.push('status = ?');      params.push(filters.status);     }
  if (filters.sourceType) { conditions.push('source_type = ?'); params.push(filters.sourceType); }
  if (conditions.length)  query += ' WHERE ' + conditions.join(' AND ');

  query += ' ORDER BY created_at DESC';
  if (filters.limit) { query += ' LIMIT ?'; params.push(filters.limit); }

  const result = db.exec(query, params);
  if (!result.length) return [];
  return result[0].values.map(row => rowToJob(result[0].columns, row));
}

const JSON_FIELDS = ['source_meta', 'context', 'generated_scripts', 'execution_results', 'approved_script'];

function rowToJob(columns, values) {
  const obj = {};
  columns.forEach((col, i) => { obj[col] = values[i]; });
  for (const field of JSON_FIELDS) {
    if (obj[field] && typeof obj[field] === 'string') {
      try { obj[field] = JSON.parse(obj[field]); } catch {}
    }
  }
  return obj;
}

// ─── Sources ──────────────────────────────────────────────────────────────────
async function createSource(source) {
  const db  = await getDb();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO sources (id, name, type, config, active, created_at) VALUES (?, ?, ?, ?, 1, ?)`,
    [source.id, source.name, source.type, JSON.stringify(source.config), now]
  );
  saveDb();
}

async function listSources() {
  const db     = await getDb();
  const result = db.exec('SELECT * FROM sources WHERE active = 1');
  if (!result.length) return [];
  return result[0].values.map(row => {
    const obj = {};
    result[0].columns.forEach((col, i) => { obj[col] = row[i]; });
    if (obj.config && typeof obj.config === 'string') {
      try { obj.config = JSON.parse(obj.config); } catch {}
    }
    return obj;
  });
}

module.exports = { getDb, saveDb, createJob, updateJob, getJob, listJobs, createSource, listSources };
