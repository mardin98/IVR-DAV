/**
 * TESTFORGE — Queue Manager (Bull + Redis)
 * Colas: collector → analyzer → generator → (espera aprobación) → executor
 */

const Bull = require('bull');
const logger = require('./logger').forModule('Queue');

const redisConfig = {
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD || undefined,
  }
};

// ─── Definición de colas ──────────────────────────────────────────────────────
const queues = {
  analyze:  new Bull('testforge:analyze',  redisConfig),
  generate: new Bull('testforge:generate', redisConfig),
  execute:  new Bull('testforge:execute',  redisConfig),
  notify:   new Bull('testforge:notify',   redisConfig),
};

// Log de eventos en cada cola
Object.entries(queues).forEach(([name, queue]) => {
  queue.on('completed', (job) => logger.info(`Job completado`, { queue: name, jobId: job.data?.id }));
  queue.on('failed',    (job, err) => logger.error(`Job fallido`, { queue: name, jobId: job.data?.id, error: err.message }));
  queue.on('stalled',   (job) => logger.warn(`Job estancado`, { queue: name, jobId: job.data?.id }));
});

// ─── Helpers ─────────────────────────────────────────────────────────────────
async function enqueue(queueName, data, opts = {}) {
  const queue = queues[queueName];
  if (!queue) throw new Error(`Cola desconocida: ${queueName}`);
  const job = await queue.add(data, {
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
    removeOnComplete: 50,
    removeOnFail: 100,
    ...opts,
  });
  logger.info(`Job encolado`, { queue: queueName, jobId: data.id, bullId: job.id });
  return job;
}

async function getQueueStats() {
  const stats = {};
  for (const [name, queue] of Object.entries(queues)) {
    const counts = await queue.getJobCounts();
    stats[name] = counts;
  }
  return stats;
}

async function closeAll() {
  await Promise.all(Object.values(queues).map(q => q.close()));
  logger.info('Todas las colas cerradas');
}

module.exports = { queues, enqueue, getQueueStats, closeAll };
