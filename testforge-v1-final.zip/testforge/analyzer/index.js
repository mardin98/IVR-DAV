/**
 * TESTFORGE — Analyzer Service
 * 
 * Consume la cola 'analyze', examina el código recibido y extrae contexto
 * estructurado para pasarle a Gemini en el Generator.
 * 
 * Detecta automáticamente el tipo de app si no fue especificado:
 *   - api      → archivos con rutas HTTP, colecciones Postman, OpenAPI
 *   - web      → componentes React/HTML, páginas Next.js
 *   - banking  → archivos con patrones de sistemas bancarios internos
 *   - script   → scripts de automatización, funciones utilitarias
 */

require('dotenv').config();

const path = require('path');
const logger = require('../shared/logger').forModule('Analyzer');
const db     = require('../shared/db');
const { queues, enqueue } = require('../shared/queue');

// ─── Patrones de detección ────────────────────────────────────────────────────
const PATTERNS = {
  api: [
    /app\.(get|post|put|delete|patch)\s*\(/i,    // Express routes
    /router\.(get|post|put|delete|patch)\s*\(/i,
    /"openapi"\s*:/i,                             // OpenAPI spec
    /"swagger"\s*:/i,
    /"info"\s*:.*"paths"\s*:/is,
    /fastify\.(get|post|put|delete)\s*\(/i,
    /collection.*postman/i,                       // Postman collection
  ],
  web: [
    /import\s+React/i,
    /from\s+['"]react['"]/i,
    /export\s+default\s+function\s+\w+\s*\(/,    // Next.js page
    /getServerSideProps|getStaticProps/,
    /<html|<!DOCTYPE html/i,
    /document\.querySelector|getElementById/i,
  ],
  banking: [
    /MIG|CORE\s*BANKING|CBS/i,
    /cuenta|saldo|transacci[oó]n|transferencia/i,
    /monto|debito|credito|extracto/i,
    /AS400|IBM\s*i|RPG|CL\s*program/i,
    /codServicio|codigoProducto|numCuenta/i,
  ],
  script: [
    /def\s+\w+\s*\(/,                            // Python functions
    /import\s+\w+|from\s+\w+\s+import/,          // Python imports
    /function\s+\w+\s*\(|const\s+\w+\s*=\s*(?:async\s*)?\(/,
    /ScriptApp|SpreadsheetApp|DriveApp/,          // Google Apps Script
    /require\s*\(\s*['"][^'"]+['"]\s*\)/,
  ],
};

function detectAppType(content, filePath = '') {
  const ext = path.extname(filePath).toLowerCase();

  // Por extensión primero
  if (['.yaml', '.yml', '.json'].includes(ext)) {
    if (/"openapi"|"swagger"|"paths"/.test(content)) return 'api';
    if (/postman/.test(filePath.toLowerCase()))        return 'api';
  }
  if (['.html', '.htm'].includes(ext)) return 'web';
  if (ext === '.py') return 'script';

  // Por contenido
  const scores = { api: 0, web: 0, banking: 0, script: 0 };
  for (const [type, patterns] of Object.entries(PATTERNS)) {
    for (const pattern of patterns) {
      if (pattern.test(content)) scores[type]++;
    }
  }

  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  return best[1] > 0 ? best[0] : 'script'; // default: script
}

// ─── Extractores por tipo ─────────────────────────────────────────────────────
function extractApiContext(content, filePath) {
  const context = { type: 'api', endpoints: [], schemas: [], notes: [] };

  // Detectar si es OpenAPI/Swagger
  try {
    const parsed = JSON.parse(content);
    if (parsed.openapi || parsed.swagger) {
      context.spec = 'openapi';
      context.title = parsed.info?.title || 'API';
      context.version = parsed.info?.version;
      context.baseUrl = parsed.servers?.[0]?.url || '';

      for (const [pathKey, methods] of Object.entries(parsed.paths || {})) {
        for (const [method, op] of Object.entries(methods)) {
          if (['get','post','put','delete','patch'].includes(method)) {
            context.endpoints.push({
              method: method.toUpperCase(),
              path: pathKey,
              summary: op.summary || '',
              parameters: op.parameters?.map(p => ({ name: p.name, in: p.in, required: p.required })) || [],
              requestBody: op.requestBody?.content?.['application/json']?.schema || null,
              responses: Object.keys(op.responses || {}),
            });
          }
        }
      }
      return context;
    }
  } catch {}

  // Express/Fastify routes (regex)
  const routeRegex = /(?:app|router)\.(get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]/gi;
  let match;
  while ((match = routeRegex.exec(content)) !== null) {
    context.endpoints.push({ method: match[1].toUpperCase(), path: match[2] });
  }

  // Detectar modelos/schemas básicos
  const schemaRegex = /(?:const|let|var)\s+(\w+Schema|\w+Model)\s*=/gi;
  while ((match = schemaRegex.exec(content)) !== null) {
    context.schemas.push(match[1]);
  }

  context.notes.push(`Archivo: ${filePath}`);
  return context;
}

function extractWebContext(content, filePath) {
  const context = { type: 'web', components: [], routes: [], forms: [], notes: [] };

  // Componentes React
  const compRegex = /(?:function|const)\s+([A-Z]\w+)\s*(?:=\s*(?:async\s*)?\(|(?:\([^)]*\))\s*(?:=>|{))/g;
  let match;
  while ((match = compRegex.exec(content)) !== null) {
    context.components.push(match[1]);
  }

  // Rutas Next.js
  if (/getServerSideProps|getStaticProps/.test(content)) {
    context.routes.push({ type: 'next-page', file: filePath });
  }

  // Formularios y botones
  const formElements = [];
  const inputRegex = /<input[^>]+(?:name|id)="([^"]+)"/gi;
  while ((match = inputRegex.exec(content)) !== null) formElements.push(match[1]);
  if (formElements.length) context.forms.push({ fields: formElements });

  // Links/hrefs
  const hrefRegex = /href=["']([^"']+)["']/gi;
  const routes = new Set();
  while ((match = hrefRegex.exec(content)) !== null) {
    if (match[1].startsWith('/')) routes.add(match[1]);
  }
  context.routes.push(...[...routes].map(r => ({ type: 'link', path: r })));

  context.notes.push(`Componentes detectados: ${context.components.length}`);
  return context;
}

function extractBankingContext(content, filePath) {
  const context = { type: 'banking', functions: [], businessRules: [], notes: [] };

  // Funciones expuestas
  const funcRegex = /(?:function|const|def)\s+(\w+)\s*(?:=\s*(?:async\s*)?\(|\()/g;
  let match;
  while ((match = funcRegex.exec(content)) !== null) {
    context.functions.push(match[1]);
  }

  // Detectar reglas de negocio por palabras clave
  const rules = [];
  if (/validar?|validate/i.test(content)) rules.push('Validaciones de entrada');
  if (/monto|amount/i.test(content))       rules.push('Manejo de montos/cantidades');
  if (/fecha|date/i.test(content))         rules.push('Manejo de fechas');
  if (/cuenta|account/i.test(content))     rules.push('Operaciones de cuenta');
  if (/error|exception/i.test(content))    rules.push('Manejo de errores');
  context.businessRules = rules;

  context.notes.push('Sistema bancario interno — generar pruebas con casos borde y validaciones críticas');
  context.notes.push(`Archivo: ${filePath}`);
  return context;
}

function extractScriptContext(content, filePath) {
  const context = { type: 'script', functions: [], imports: [], notes: [] };

  // Funciones JS/TS
  const jsFuncRegex = /(?:function\s+(\w+)|const\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*(?:=>|{))/g;
  let match;
  while ((match = jsFuncRegex.exec(content)) !== null) {
    const name = match[1] || match[2];
    if (name) context.functions.push({ name, lang: 'js' });
  }

  // Funciones Python
  const pyFuncRegex = /def\s+(\w+)\s*\(/g;
  while ((match = pyFuncRegex.exec(content)) !== null) {
    context.functions.push({ name: match[1], lang: 'python' });
  }

  // Imports
  const importRegex = /(?:require\(['"]([^'"]+)['"]\)|import\s+.*?from\s+['"]([^'"]+)['"]|from\s+(\S+)\s+import)/g;
  while ((match = importRegex.exec(content)) !== null) {
    const dep = match[1] || match[2] || match[3];
    if (dep) context.imports.push(dep);
  }

  const lang = filePath.endsWith('.py') ? 'python' : 'javascript';
  context.language = lang;
  context.notes.push(`Lenguaje detectado: ${lang}`);
  return context;
}

// ─── Procesador principal ─────────────────────────────────────────────────────
async function processAnalyzeJob(job) {
  const { id, sourceType, sourceMeta, rawContent, appType: hintAppType } = job.data;
  logger.info('Analizando job', { id, sourceType });

  await db.updateJob(id, { status: 'analyzing' });

  // 1. Detectar tipo si no viene especificado
  const filePath = sourceMeta?.filePath || sourceMeta?.originalName || '';
  const appType = hintAppType || detectAppType(rawContent || '', filePath);
  logger.info('Tipo de app detectado', { id, appType });

  // 2. Extraer contexto según tipo
  let context;
  switch (appType) {
    case 'api':     context = extractApiContext(rawContent, filePath);     break;
    case 'web':     context = extractWebContext(rawContent, filePath);     break;
    case 'banking': context = extractBankingContext(rawContent, filePath); break;
    case 'script':
    default:        context = extractScriptContext(rawContent, filePath);  break;
  }

  // 3. Validar que hay suficiente contexto para generar tests
  const hasContent = (
    (context.endpoints?.length > 0) ||
    (context.components?.length > 0) ||
    (context.functions?.length > 0) ||
    (context.type === 'banking')
  );

  if (!hasContent && (!rawContent || rawContent.trim().length < 50)) {
    logger.warn('Contenido insuficiente para generar tests', { id });
    await db.updateJob(id, {
      status: 'error',
      errorMessage: 'Contenido insuficiente para generar tests. Asegúrate de subir código con funciones, rutas o componentes.',
      appType,
    });
    return;
  }

  // 4. Guardar contexto y encolar para generación
  await db.updateJob(id, { appType, context, status: 'generating' });
  await enqueue('generate', { id, appType, context, rawContent });

  logger.info('Análisis completado, encolado para generación', { id, appType });
}

// ─── Arranque del worker ──────────────────────────────────────────────────────
function start() {
  const { queues } = require('../shared/queue');

  queues.analyze.process(3, async (job) => {
    try {
      await processAnalyzeJob(job);
    } catch (err) {
      logger.error('Error en Analyzer', { jobId: job.data?.id, error: err.message, stack: err.stack });
      try { await db.updateJob(job.data?.id, { status: 'error', errorMessage: err.message }); } catch {}
      throw err;
    }
  });

  logger.info('Analyzer worker activo — escuchando cola "analyze"');
}

start();
module.exports = { detectAppType, extractApiContext, extractWebContext, extractBankingContext, extractScriptContext };
