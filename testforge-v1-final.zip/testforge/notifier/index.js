/**
 * TESTFORGE — Notifier Service
 * 
 * Consume la cola 'notify' y envía emails via SMTP interno.
 * 
 * Eventos manejados:
 *   job_ready   → Script generado, esperando aprobación
 *   job_passed  → Test ejecutado exitosamente
 *   job_failed  → Test falló en ejecución
 *   job_error   → Error en el pipeline
 */

require('dotenv').config();

const nodemailer = require('nodemailer');
const logger     = require('../shared/logger').forModule('Notifier');
const db         = require('../shared/db');

// ─── Transporter SMTP ─────────────────────────────────────────────────────────
function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || '587');
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host) {
    logger.warn('SMTP_HOST no configurado — notificaciones desactivadas');
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: user && pass ? { user, pass } : undefined,
    tls: { rejectUnauthorized: false }, // Para SMTP internos con cert auto-firmado
  });
}

// ─── HTML templates ───────────────────────────────────────────────────────────
const UI_URL = process.env.UI_URL || 'http://localhost:3000';

function baseTemplate(content, accentColor = '#3b82f6') {
  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin: 0; padding: 0; background: #0a0c10; font-family: 'Segoe UI', Arial, sans-serif; }
    .wrapper { max-width: 600px; margin: 0 auto; padding: 32px 16px; }
    .card { background: #0f1117; border: 1px solid #1e2330; border-radius: 12px; overflow: hidden; }
    .header { background: #0a0c10; padding: 20px 28px; border-bottom: 1px solid #1e2330; display: flex; align-items: center; gap: 12px; }
    .logo { background: linear-gradient(135deg, ${accentColor}, #1d4ed8); width: 36px; height: 36px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; }
    .logo-text { font-family: monospace; font-weight: 700; font-size: 15px; color: #e8ecf0; letter-spacing: 1px; }
    .logo-sub { font-size: 11px; color: #6b7280; }
    .body { padding: 28px; }
    .badge { display: inline-block; padding: 4px 12px; border-radius: 99px; font-size: 11px; font-family: monospace; font-weight: 600; border: 1px solid; margin-bottom: 18px; }
    h2 { color: #e8ecf0; font-size: 20px; margin: 0 0 8px; }
    p { color: #9ca3af; font-size: 14px; line-height: 1.6; margin: 0 0 16px; }
    .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 20px 0; }
    .meta-item { background: #141720; border: 1px solid #1e2330; border-radius: 8px; padding: 12px 14px; }
    .meta-label { font-size: 10px; font-family: monospace; color: #6b7280; letter-spacing: 0.5px; margin-bottom: 4px; }
    .meta-value { font-size: 13px; color: #e8ecf0; font-family: monospace; word-break: break-all; }
    .cta { display: inline-block; padding: 12px 24px; border-radius: 8px; background: ${accentColor}; color: #fff; text-decoration: none; font-size: 14px; font-weight: 600; margin-top: 8px; }
    .code-block { background: #050709; border: 1px solid #1e2330; border-radius: 8px; padding: 14px 16px; font-family: monospace; font-size: 12px; color: #e8ecf0; line-height: 1.7; margin: 16px 0; white-space: pre-wrap; word-break: break-all; max-height: 200px; overflow: hidden; }
    .footer { padding: 16px 28px; border-top: 1px solid #1e2330; font-size: 11px; color: #4b5563; text-align: center; }
    .divider { height: 1px; background: #1e2330; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="header">
        <div class="logo">⚡</div>
        <div>
          <div class="logo-text">TESTFORGE</div>
          <div class="logo-sub">Davivienda El Salvador · IA & Automatizaciones</div>
        </div>
      </div>
      <div class="body">
        ${content}
      </div>
      <div class="footer">
        Este es un mensaje automático de TESTFORGE v1 · On-Premise<br>
        Para dejar de recibir notificaciones, ajusta la config en NOTIFY_EMAIL
      </div>
    </div>
  </div>
</body>
</html>`;
}

function templateJobReady(job) {
  const scripts = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];
  const script  = scripts[0];
  const meta    = job.source_meta || {};

  const appTypeLabels = { api: 'API REST', web: 'Web / UI', banking: 'Sistema Bancario', script: 'Script' };
  const srcLabels     = { gitlab: '🦊 GitLab', folder: '📁 Carpeta', manual: '⬆️ Manual' };

  return baseTemplate(`
    <div class="badge" style="color: #3b82f6; border-color: rgba(59,130,246,0.3); background: rgba(59,130,246,0.1);">
      ⏳ SCRIPT LISTO PARA APROBACIÓN
    </div>
    <h2>Gemini generó un script de prueba</h2>
    <p>Un nuevo script está esperando tu revisión y aprobación antes de ejecutarse.</p>

    <div class="meta-grid">
      <div class="meta-item">
        <div class="meta-label">JOB ID</div>
        <div class="meta-value">${job.id.slice(0, 8).toUpperCase()}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">TIPO DE APP</div>
        <div class="meta-value">${appTypeLabels[job.app_type] || job.app_type || '—'}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">FUENTE</div>
        <div class="meta-value">${srcLabels[job.source_type] || job.source_type}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">RUNNER</div>
        <div class="meta-value">${script?.runner || '—'}</div>
      </div>
      ${meta.filePath || meta.originalName ? `
      <div class="meta-item" style="grid-column: 1/-1">
        <div class="meta-label">ARCHIVO</div>
        <div class="meta-value">${meta.filePath || meta.originalName}</div>
      </div>` : ''}
      ${meta.project ? `
      <div class="meta-item">
        <div class="meta-label">PROYECTO</div>
        <div class="meta-value">${meta.project}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">RAMA</div>
        <div class="meta-value">${meta.branch || '—'}</div>
      </div>` : ''}
    </div>

    ${script ? `
    <div class="divider"></div>
    <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px; font-family: monospace;">PREVIEW DEL SCRIPT (${script.filename})</p>
    <div class="code-block">${escapeHtml(script.code?.slice(0, 600) || '')}${(script.code?.length || 0) > 600 ? '\n... (ver completo en la UI)' : ''}</div>
    ` : ''}

    <a href="${UI_URL}/jobs/${job.id}" class="cta">👀 Revisar y Aprobar →</a>
  `, '#3b82f6');
}

function templateJobPassed(job) {
  const results = job.execution_results || {};
  const summary = results.testSummary;

  return baseTemplate(`
    <div class="badge" style="color: #22c55e; border-color: rgba(34,197,94,0.3); background: rgba(34,197,94,0.1);">
      ✅ TEST EXITOSO
    </div>
    <h2>Los tests pasaron correctamente</h2>
    <p>El script aprobado se ejecutó sin errores.</p>

    <div class="meta-grid">
      <div class="meta-item">
        <div class="meta-label">JOB ID</div>
        <div class="meta-value">${job.id.slice(0, 8).toUpperCase()}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">DURACIÓN</div>
        <div class="meta-value">${formatDuration(results.duration || 0)}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">RUNNER</div>
        <div class="meta-value">${results.runner || '—'}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">EXIT CODE</div>
        <div class="meta-value" style="color: #22c55e;">0 (OK)</div>
      </div>
      ${summary ? `
      <div class="meta-item">
        <div class="meta-label">TESTS PASADOS</div>
        <div class="meta-value" style="color: #22c55e;">${summary.passed} / ${summary.total}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">FALLIDOS</div>
        <div class="meta-value" style="color: ${summary.failed > 0 ? '#ef4444' : '#6b7280'};">${summary.failed}</div>
      </div>` : ''}
    </div>

    ${results.stdout ? `
    <div class="divider"></div>
    <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px; font-family: monospace;">SALIDA</p>
    <div class="code-block">${escapeHtml(results.stdout.slice(0, 500))}${results.stdout.length > 500 ? '\n...' : ''}</div>
    ` : ''}

    <a href="${UI_URL}/jobs/${job.id}" class="cta" style="background: #16a34a;">📊 Ver Resultados →</a>
  `, '#22c55e');
}

function templateJobFailed(job) {
  const results = job.execution_results || {};
  const summary = results.testSummary;

  return baseTemplate(`
    <div class="badge" style="color: #ef4444; border-color: rgba(239,68,68,0.3); background: rgba(239,68,68,0.1);">
      ❌ TEST FALLIDO
    </div>
    <h2>El test encontró errores</h2>
    <p>El script se ejecutó pero algunos tests fallaron. Revisa los detalles para diagnosticar.</p>

    <div class="meta-grid">
      <div class="meta-item">
        <div class="meta-label">JOB ID</div>
        <div class="meta-value">${job.id.slice(0, 8).toUpperCase()}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">DURACIÓN</div>
        <div class="meta-value">${formatDuration(results.duration || 0)}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">EXIT CODE</div>
        <div class="meta-value" style="color: #ef4444;">${results.exitCode ?? '—'}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">RUNNER</div>
        <div class="meta-value">${results.runner || '—'}</div>
      </div>
      ${summary ? `
      <div class="meta-item">
        <div class="meta-label">PASADOS</div>
        <div class="meta-value" style="color: #22c55e;">${summary.passed}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">FALLIDOS</div>
        <div class="meta-value" style="color: #ef4444;">${summary.failed}</div>
      </div>` : ''}
    </div>

    ${(results.stderr || results.stdout) ? `
    <div class="divider"></div>
    <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px; font-family: monospace;">ERROR / SALIDA</p>
    <div class="code-block" style="border-color: rgba(239,68,68,0.2);">${escapeHtml((results.stderr || results.stdout || '').slice(0, 600))}${((results.stderr || results.stdout || '').length) > 600 ? '\n...' : ''}</div>
    ` : ''}

    ${job.error_message ? `
    <div class="divider"></div>
    <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px; font-family: monospace;">MENSAJE DE ERROR</p>
    <div class="code-block" style="border-color: rgba(239,68,68,0.2); color: #fca5a5;">${escapeHtml(job.error_message)}</div>
    ` : ''}

    <a href="${UI_URL}/jobs/${job.id}" class="cta" style="background: #dc2626;">🔍 Ver Detalles →</a>
  `, '#ef4444');
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatDuration(ms) {
  if (ms < 1000)  return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
}

// ─── Envío de email ───────────────────────────────────────────────────────────
async function sendEmail({ to, subject, html }) {
  const transporter = createTransporter();
  if (!transporter) return { skipped: true, reason: 'SMTP no configurado' };

  try {
    const info = await transporter.sendMail({
      from: `"TESTFORGE" <${process.env.SMTP_FROM || process.env.SMTP_USER || 'testforge@davivienda.com.sv'}>`,
      to,
      subject,
      html,
    });
    logger.info('Email enviado', { to, subject, messageId: info.messageId });
    return { ok: true, messageId: info.messageId };
  } catch (err) {
    logger.error('Error enviando email', { to, subject, error: err.message });
    throw err;
  }
}

// ─── Procesador de eventos ────────────────────────────────────────────────────
async function processNotifyJob(bullJob) {
  const { jobId, type } = bullJob.data;
  const to = process.env.NOTIFY_EMAIL;

  if (!to) {
    logger.warn('NOTIFY_EMAIL no configurado — saltando notificación', { type, jobId });
    return;
  }

  logger.info('Procesando notificación', { type, jobId, to });

  // Cargar datos del job
  const job = await db.getJob(jobId);
  if (!job) {
    logger.warn('Job no encontrado para notificar', { jobId });
    return;
  }

  // Parsear campos JSON si vienen como string
  if (typeof job.generated_scripts === 'string') {
    try { job.generated_scripts = JSON.parse(job.generated_scripts); } catch {}
  }
  if (typeof job.execution_results === 'string') {
    try { job.execution_results = JSON.parse(job.execution_results); } catch {}
  }
  if (typeof job.source_meta === 'string') {
    try { job.source_meta = JSON.parse(job.source_meta); } catch {}
  }

  let subject, html;

  switch (type) {
    case 'job_ready':
      subject = `[TESTFORGE] ⏳ Script listo para aprobar — Job ${jobId.slice(0, 8).toUpperCase()}`;
      html    = templateJobReady(job);
      break;

    case 'job_passed':
      subject = `[TESTFORGE] ✅ Test exitoso — Job ${jobId.slice(0, 8).toUpperCase()}`;
      html    = templateJobPassed(job);
      break;

    case 'job_failed':
      subject = `[TESTFORGE] ❌ Test fallido — Job ${jobId.slice(0, 8).toUpperCase()}`;
      html    = templateJobFailed(job);
      break;

    default:
      logger.warn('Tipo de notificación desconocido', { type });
      return;
  }

  const result = await sendEmail({ to, subject, html });

  // Registrar en DB
  const dbConn = await db.getDb();
  dbConn.run(
    `INSERT INTO notifications (job_id, type, sent_at, error) VALUES (?, ?, ?, ?)`,
    [jobId, type, new Date().toISOString(), result.skipped ? result.reason : null]
  );
  db.saveDb();

  logger.info('Notificación procesada', { type, jobId, skipped: result.skipped || false });
}

// ─── Arranque ─────────────────────────────────────────────────────────────────
function start() {
  const { queues } = require('../shared/queue');

  queues.notify.process(5, async (job) => {
    try {
      await processNotifyJob(job);
    } catch (err) {
      logger.error('Error en Notifier', { jobId: job.data?.jobId, error: err.message });
      // No relanzar — las notificaciones no deben bloquear el pipeline
    }
  });

  // Verificar SMTP al arrancar
  const transporter = createTransporter();
  if (transporter) {
    transporter.verify()
      .then(() => logger.info('SMTP verificado — notificaciones activas', {
        host: process.env.SMTP_HOST,
        to:   process.env.NOTIFY_EMAIL,
      }))
      .catch(err => logger.warn('SMTP no disponible — notificaciones desactivadas', { error: err.message }));
  }

  logger.info('Notifier worker activo — escuchando cola "notify"');
}

start();
module.exports = { sendEmail, templateJobReady, templateJobPassed, templateJobFailed };
