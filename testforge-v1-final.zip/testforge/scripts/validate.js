#!/usr/bin/env node
/**
 * TESTFORGE — validate.js
 * 
 * Valida que todos los componentes del sistema están funcionales.
 * Ejecutar antes del primer arranque o después de cambios.
 * 
 * Uso: node scripts/validate.js
 */

require('dotenv').config();

const fs   = require('fs');
const path = require('path');
const http = require('http');

// ─── Colores ──────────────────────────────────────────────────────────────────
const C = {
  green:  s => `\x1b[32m${s}\x1b[0m`,
  red:    s => `\x1b[31m${s}\x1b[0m`,
  yellow: s => `\x1b[33m${s}\x1b[0m`,
  cyan:   s => `\x1b[36m${s}\x1b[0m`,
  bold:   s => `\x1b[1m${s}\x1b[0m`,
  gray:   s => `\x1b[90m${s}\x1b[0m`,
};

let passed = 0;
let failed = 0;
let warned = 0;

function ok(label, detail = '') {
  passed++;
  console.log(`  ${C.green('✓')} ${label}${detail ? C.gray(' — ' + detail) : ''}`);
}

function fail(label, detail = '') {
  failed++;
  console.log(`  ${C.red('✗')} ${label}${detail ? C.gray(' — ' + detail) : ''}`);
}

function warn(label, detail = '') {
  warned++;
  console.log(`  ${C.yellow('⚠')} ${label}${detail ? C.gray(' — ' + detail) : ''}`);
}

function section(title) {
  console.log(`\n${C.bold(C.cyan(title))}`);
}

// ─── Check: HTTP health endpoint ──────────────────────────────────────────────
function checkHttp(url, timeout = 3000) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout }, (res) => {
      let body = '';
      res.on('data', d => { body += d; });
      res.on('end', () => {
        try { resolve({ ok: res.statusCode < 400, status: res.statusCode, body: JSON.parse(body) }); }
        catch { resolve({ ok: res.statusCode < 400, status: res.statusCode, body }); }
      });
    });
    req.on('error', err => resolve({ ok: false, error: err.message }));
    req.on('timeout', ()  => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
  });
}

// ─── Check: TCP port open ─────────────────────────────────────────────────────
function checkPort(host, port, timeout = 2000) {
  return new Promise((resolve) => {
    const net = require('net');
    const s   = new net.Socket();
    s.setTimeout(timeout);
    s.on('connect', () => { s.destroy(); resolve(true); });
    s.on('error',   ()  => resolve(false));
    s.on('timeout', ()  => { s.destroy(); resolve(false); });
    s.connect(port, host);
  });
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(C.bold('\n╔════════════════════════════════════════╗'));
  console.log(C.bold('║   TESTFORGE v1 — Validación del Sistema ║'));
  console.log(C.bold('╚════════════════════════════════════════╝'));

  // ── 1. Estructura de archivos ─────────────────────────────────────────────
  section('1. Estructura del Proyecto');

  const requiredFiles = [
    'collector/index.js',
    'analyzer/index.js',
    'generator/index.js',
    'executor/index.js',
    'notifier/index.js',
    'api/index.js',
    'shared/db.js',
    'shared/queue.js',
    'shared/logger.js',
    'ecosystem.config.js',
    'package.json',
    '.env',
  ];

  for (const f of requiredFiles) {
    if (fs.existsSync(path.join(process.cwd(), f))) {
      ok(f);
    } else {
      f === '.env' ? warn(f, 'Copia .env.example a .env y configura') : fail(f, 'Archivo faltante');
    }
  }

  // ── 2. Variables de entorno ───────────────────────────────────────────────
  section('2. Variables de Entorno');

  const required = ['GEMINI_API_KEY'];
  const optional = ['SMTP_HOST', 'SMTP_USER', 'NOTIFY_EMAIL', 'GITLAB_WEBHOOK_SECRET'];

  for (const v of required) {
    process.env[v] ? ok(v) : fail(v, 'REQUERIDA — sin esto Gemini no funciona');
  }
  for (const v of optional) {
    process.env[v] ? ok(v) : warn(v, 'Opcional — funcionalidad limitada sin esto');
  }

  // ── 3. Dependencias Node ──────────────────────────────────────────────────
  section('3. Dependencias Node.js');

  const deps = [
    'express', 'bull', 'redis', 'sql.js', 'chokidar',
    'multer', 'dotenv', 'winston', 'axios', 'uuid',
    'nodemailer', 'jest',
  ];

  for (const dep of deps) {
    const modPath = path.join(process.cwd(), 'node_modules', dep);
    fs.existsSync(modPath) ? ok(dep) : fail(dep, 'Ejecuta: npm install');
  }

  // ── 4. Directorios de datos ───────────────────────────────────────────────
  section('4. Directorios de Datos');

  const dirs = ['data', 'data/uploads', 'data/scripts', 'data/results', 'data/logs'];
  for (const d of dirs) {
    const full = path.join(process.cwd(), d);
    if (fs.existsSync(full)) {
      ok(d);
    } else {
      try { fs.mkdirSync(full, { recursive: true }); ok(d, 'creado ahora'); }
      catch (e) { fail(d, e.message); }
    }
  }

  // ── 5. Sintaxis de módulos ────────────────────────────────────────────────
  section('5. Sintaxis de Módulos');

  const { execSync } = require('child_process');
  const modules = [
    'shared/db.js', 'shared/queue.js', 'shared/logger.js',
    'collector/index.js', 'analyzer/index.js', 'generator/index.js',
    'executor/index.js', 'notifier/index.js', 'api/index.js',
  ];

  for (const m of modules) {
    try {
      execSync(`node --check ${m}`, { stdio: 'pipe', cwd: process.cwd() });
      ok(m);
    } catch (e) {
      fail(m, e.stderr?.toString().trim() || 'Error de sintaxis');
    }
  }

  // ── 6. Módulo de prueba (lógica sin servicios externos) ───────────────────
  section('6. Lógica Interna — Prueba sin servicios externos');

  // Test Analyzer
  try {
    const { detectAppType, extractScriptContext } = require('./analyzer/index.js');
    // analyzer arranca el worker, pero podemos importar las funciones si no hay redis
    ok('Analyzer — funciones exportadas disponibles');
  } catch (e) {
    // Normal si Redis no está disponible; la lógica de detección sí podemos testearla
    warn('Analyzer worker', 'Redis no disponible — OK para validación estática');
  }

  // Test archivo de ejemplo
  try {
    const ejemplo = require(path.join(process.cwd(), 'examples/transferencias.js'));
    const checks = [
      ejemplo.validarCuenta('DV1234567890') === true,
      ejemplo.validarCuenta('INVALIDA')     === false,
      ejemplo.validarMonto(100).valido      === true,
      ejemplo.validarMonto(-5).valido       === false,
      ejemplo.calcularComision(300)         === 0,
      ejemplo.calcularComision(1000)        === 5,
      ejemplo.calcularComision(10000)       === 100,
      ejemplo.prepararTransferencia({ origen: 'DV1234567890', destino: 'DV0987654321', monto: 500 }).ok === true,
      ejemplo.prepararTransferencia({ origen: 'DV1234567890', destino: 'DV1234567890', monto: 500 }).ok === false,
    ];
    const allPass = checks.every(Boolean);
    allPass ? ok('examples/transferencias.js — 9/9 assertions correctas') : fail('examples/transferencias.js — algunas assertions fallaron');
  } catch (e) {
    fail('examples/transferencias.js', e.message);
  }

  // ── 7. Servicios externos ─────────────────────────────────────────────────
  section('7. Servicios Externos');

  // Redis
  const redisHost = process.env.REDIS_HOST || '127.0.0.1';
  const redisPort = parseInt(process.env.REDIS_PORT || '6379');
  const redisOk   = await checkPort(redisHost, redisPort);
  redisOk
    ? ok(`Redis ${redisHost}:${redisPort}`)
    : fail(`Redis ${redisHost}:${redisPort}`, 'Inicia Redis: sudo systemctl start redis');

  // Collector (si está corriendo)
  const collectorPort = process.env.COLLECTOR_PORT || process.env.PORT || 3001;
  const cRes = await checkHttp(`http://localhost:${collectorPort}/health`);
  cRes.ok
    ? ok(`Collector :${collectorPort}`, cRes.body?.status)
    : warn(`Collector :${collectorPort}`, 'No está corriendo (normal si aún no arrancaste PM2)');

  // API (si está corriendo)
  const apiPort = process.env.API_PORT || 3002;
  const aRes = await checkHttp(`http://localhost:${apiPort}/health`);
  aRes.ok
    ? ok(`API :${apiPort}`, aRes.body?.status)
    : warn(`API :${apiPort}`, 'No está corriendo (normal si aún no arrancaste PM2)');

  // Gemini (ping básico si hay API key)
  if (process.env.GEMINI_API_KEY) {
    try {
      const axios   = require('axios');
      const model   = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
      const url     = `https://generativelanguage.googleapis.com/v1beta/models/${model}?key=${process.env.GEMINI_API_KEY}`;
      const res     = await axios.get(url, { timeout: 8000 });
      res.status === 200
        ? ok(`Gemini API (${model})`, 'Conectividad OK')
        : warn('Gemini API', `Status: ${res.status}`);
    } catch (e) {
      const msg = e.response?.status === 400 ? 'API Key inválida'
                : e.response?.status === 403 ? 'API Key sin permisos'
                : e.code === 'ECONNREFUSED'   ? 'Sin acceso a internet'
                : e.message;
      fail('Gemini API', msg);
    }
  } else {
    warn('Gemini API', 'GEMINI_API_KEY no configurada');
  }

  // SMTP (si está configurado)
  if (process.env.SMTP_HOST) {
    const smtpOk = await checkPort(process.env.SMTP_HOST, parseInt(process.env.SMTP_PORT || '587'));
    smtpOk
      ? ok(`SMTP ${process.env.SMTP_HOST}:${process.env.SMTP_PORT || 587}`)
      : warn(`SMTP ${process.env.SMTP_HOST}`, 'Puerto no accesible — emails desactivados');
  } else {
    warn('SMTP', 'No configurado — emails desactivados (opcional)');
  }

  // ── Resumen ───────────────────────────────────────────────────────────────
  console.log('\n' + '─'.repeat(44));
  console.log(C.bold(`  Resultado: ${C.green(passed + ' ✓')}  ${failed > 0 ? C.red(failed + ' ✗') : '0 ✗'}  ${warned > 0 ? C.yellow(warned + ' ⚠') : '0 ⚠'}`));

  if (failed === 0 && warned === 0) {
    console.log(C.green(C.bold('\n  ✅ Sistema listo. Ejecuta: pm2 start ecosystem.config.js\n')));
  } else if (failed === 0) {
    console.log(C.yellow('\n  ⚠  Sistema listo con advertencias. Revisa los ⚠ arriba.'));
    console.log(C.yellow('     Ejecuta: pm2 start ecosystem.config.js\n'));
  } else {
    console.log(C.red('\n  ✗  Hay errores que corregir antes de arrancar.'));
    console.log(C.red('     Revisa los ✗ arriba y soluciónalos.\n'));
    process.exit(1);
  }
}

main().catch(err => {
  console.error(C.red('\nError inesperado en validación:'), err.message);
  process.exit(1);
});
