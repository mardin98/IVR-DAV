#!/bin/bash
# ─── TESTFORGE v1 — Setup On-Premise ─────────────────────────────────────────
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}"
echo "╔════════════════════════════════════════╗"
echo "║       TESTFORGE v1 — Setup             ║"
echo "║  CI/CD con IA — On-Premise             ║"
echo "╚════════════════════════════════════════╝"
echo -e "${NC}"

# ─── Verificar dependencias del sistema ──────────────────────────────────────
echo -e "${YELLOW}[1/6] Verificando dependencias...${NC}"

check_cmd() {
  if ! command -v "$1" &> /dev/null; then
    echo -e "${RED}✗ $1 no encontrado. Por favor instálalo primero.${NC}"
    exit 1
  fi
  echo "  ✓ $1 encontrado"
}

check_cmd node
check_cmd npm
check_cmd redis-cli

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  echo -e "${RED}✗ Node.js 18+ requerido. Versión actual: $(node -v)${NC}"
  exit 1
fi
echo "  ✓ Node.js $(node -v)"

# ─── Verificar Redis ──────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[2/6] Verificando Redis...${NC}"
if redis-cli ping &> /dev/null; then
  echo "  ✓ Redis corriendo"
else
  echo -e "${RED}✗ Redis no responde. Inicia Redis con:${NC}"
  echo "    sudo systemctl start redis"
  echo "    # o en macOS: brew services start redis"
  exit 1
fi

# ─── Instalar dependencias Node.js ───────────────────────────────────────────
echo ""
echo -e "${YELLOW}[3/6] Instalando dependencias Node.js...${NC}"
npm install
echo "  ✓ Dependencias instaladas"

# ─── Crear estructura de directorios ─────────────────────────────────────────
echo ""
echo -e "${YELLOW}[4/6] Creando directorios...${NC}"
mkdir -p data/{uploads,scripts,results,logs}
echo "  ✓ data/uploads   — archivos subidos manualmente"
echo "  ✓ data/scripts   — scripts generados por Gemini"
echo "  ✓ data/results   — resultados de ejecución"
echo "  ✓ data/logs      — logs de todos los servicios"

# ─── Configurar .env ─────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[5/6] Configurando entorno...${NC}"
if [ ! -f .env ]; then
  cp .env.example .env
  echo -e "  ${YELLOW}⚠ .env creado desde .env.example${NC}"
  echo -e "  ${YELLOW}  IMPORTANTE: Edita .env y configura:${NC}"
  echo "    - GEMINI_API_KEY"
  echo "    - GITLAB_WEBHOOK_SECRET (si usas GitLab)"
  echo "    - SMTP_* (si quieres notificaciones por email)"
else
  echo "  ✓ .env ya existe"
fi

# ─── PM2 ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[6/6] Verificando PM2...${NC}"
if ! command -v pm2 &> /dev/null; then
  echo "  Instalando PM2 globalmente..."
  npm install -g pm2
fi
echo "  ✓ PM2 $(pm2 -v) disponible"

# ─── Resumen ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗"
echo "║   ✓ Setup completado!                  ║"
echo "╚════════════════════════════════════════╝${NC}"
echo ""
echo "Próximos pasos:"
echo ""
echo "  1. Edita .env y agrega tu GEMINI_API_KEY"
echo "     nano .env"
echo ""
echo "  2. Arranca todos los servicios:"
echo "     pm2 start ecosystem.config.js"
echo ""
echo "  3. Verifica que todo esté corriendo:"
echo "     pm2 status"
echo ""
echo "  4. Prueba el Collector:"
echo "     curl http://localhost:3001/health"
echo ""
echo "  5. Sube un archivo para probar el pipeline:"
echo "     curl -X POST http://localhost:3001/upload \\"
echo "       -F 'file=@tu-archivo.js' \\"
echo "       -F 'appType=script'"
echo ""
echo "  Puertos usados:"
echo "    3001 — Collector (webhooks + uploads)"
echo "    3002 — API (para la UI)"
echo "    3000 — UI Next.js (instalar aparte)"
echo ""
echo -e "${YELLOW}Logs en tiempo real:${NC}"
echo "  pm2 logs               — todos los servicios"
echo "  pm2 logs testforge-collector"
echo "  pm2 monit              — monitor visual"
