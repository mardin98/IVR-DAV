/**
 * TESTFORGE — Generator Service
 * 
 * Consume la cola 'generate', llama a Gemini para generar scripts de prueba,
 * y los guarda en estado 'pending_approval' para revisión humana.
 */

require('dotenv').config();

const axios  = require('axios');
const path   = require('path');
const fs     = require('fs');
const logger = require('../shared/logger').forModule('Generator');
const db     = require('../shared/db');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL   = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
const GEMINI_URL     = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;

// ─── Prompts por tipo ─────────────────────────────────────────────────────────
function buildPrompt(appType, context, rawContent) {
  const base = `Eres un experto en QA y testing de software. 
Tu tarea es generar scripts de prueba completos, listos para ejecutar, basados en el código o especificación proporcionada.

REGLAS IMPORTANTES:
- Genera código real y ejecutable, NO pseudocódigo
- Incluye imports/requires necesarios
- Cubre casos felices Y casos de error
- Los scripts deben ser auto-contenidos
- Responde ÚNICAMENTE con JSON válido, sin texto adicional, sin bloques markdown

Formato de respuesta (JSON):
{
  "scripts": [
    {
      "name": "nombre descriptivo del test",
      "description": "qué valida este script",
      "runner": "playwright|jest|pytest|node",
      "filename": "nombre-del-archivo.spec.js",
      "code": "código completo del script"
    }
  ],
  "summary": "resumen de qué se está probando y por qué estos tests",
  "coverageNotes": "qué aspectos importantes NO están cubiertos y por qué"
}`;

  const prompts = {
    api: `${base}

TIPO: API REST
CONTEXTO EXTRAÍDO:
${JSON.stringify(context, null, 2)}

CÓDIGO/SPEC ORIGINAL:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

Genera tests con axios para cada endpoint detectado. Prueba:
1. Respuestas exitosas (200/201) con datos válidos
2. Validaciones de entrada (400) con datos inválidos  
3. Casos de autenticación si aplica (401/403)
4. Casos borde (IDs inexistentes, campos vacíos, tipos incorrectos)
Usa runner "node" con axios. Estructura los tests con describe/it si usas Jest, o con funciones async si usas node puro.`,

    web: `${base}

TIPO: Interfaz Web / Frontend
CONTEXTO EXTRAÍDO:
${JSON.stringify(context, null, 2)}

CÓDIGO ORIGINAL:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

Genera tests Playwright (runner: "playwright") que:
1. Naveguen a las páginas/rutas detectadas
2. Verifiquen que los componentes principales renderizan
3. Prueben interacciones de formularios si existen
4. Verifiquen navegación entre páginas
5. Incluyan screenshot en puntos clave
Usa baseURL configurable via variable de entorno BASE_URL.`,

    banking: `${base}

TIPO: Sistema Bancario Interno
CONTEXTO EXTRAÍDO:
${JSON.stringify(context, null, 2)}

CÓDIGO ORIGINAL:
${rawContent?.substring(0, 3000) || 'No disponible'}

IMPORTANTE: Este es un sistema bancario crítico. Genera tests exhaustivos con:
1. Validaciones de montos (negativos, cero, decimales, límites)
2. Validaciones de cuentas (formato, existencia, estado)
3. Validaciones de fechas (formatos, rangos válidos)
4. Casos de error y manejo de excepciones
5. Pruebas de concurrencia básica si aplica
6. Casos borde específicos del dominio bancario
Usa runner "jest" con mocks donde sea necesario.`,

    script: `${base}

TIPO: Script / Función de Automatización
CONTEXTO EXTRAÍDO:
${JSON.stringify(context, null, 2)}

CÓDIGO ORIGINAL:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

${context.language === 'python' ? 
  'Genera tests con pytest (runner: "pytest"). Usa fixtures y parametrize donde aplique.' :
  'Genera tests con Jest (runner: "jest"). Usa describe/it/expect.'
}
Prueba cada función detectada con:
1. Inputs válidos esperados
2. Inputs inválidos o inesperados  
3. Casos borde (null, undefined, vacío, tipos incorrectos)
4. Si hay efectos secundarios, usa mocks apropiados`,
  };

  return prompts[appType] || prompts.script;
}

// ─── Llamada a Gemini ─────────────────────────────────────────────────────────
async function callGemini(prompt) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY no configurado en .env');

  const response = await axios.post(GEMINI_URL, {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.2,      // Bajo para código más determinista
      maxOutputTokens: 8192,
      topP: 0.8,
    },
  }, {
    timeout: 60000,
    headers: { 'Content-Type': 'application/json' },
  });

  const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini no retornó contenido');
  return text;
}

function parseGeminiResponse(text) {
  // Limpiar posibles bloques markdown que Gemini pueda agregar
  let clean = text.trim();
  clean = clean.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '');

  try {
    return JSON.parse(clean);
  } catch {
    // Intentar extraer JSON del texto
    const match = clean.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw new Error('No se pudo parsear la respuesta de Gemini como JSON');
  }
}

// ─── Guardar scripts en disco ─────────────────────────────────────────────────
function saveScriptsToDisk(jobId, scripts) {
  const jobDir = path.join(process.env.SCRIPTS_DIR || './data/scripts', jobId);
  fs.mkdirSync(jobDir, { recursive: true });

  return scripts.map(script => {
    const filePath = path.join(jobDir, script.filename);
    fs.writeFileSync(filePath, script.code, 'utf-8');
    return { ...script, filePath };
  });
}

// ─── Procesador principal ─────────────────────────────────────────────────────
async function processGenerateJob(job) {
  const { id, appType, context, rawContent } = job.data;
  logger.info('Generando scripts para job', { id, appType });

  const prompt = buildPrompt(appType, context, rawContent);

  // Llamar a Gemini
  let geminiRaw;
  try {
    geminiRaw = await callGemini(prompt);
    logger.info('Respuesta de Gemini recibida', { id, chars: geminiRaw.length });
  } catch (err) {
    logger.error('Error llamando a Gemini', { id, error: err.message });
    await db.updateJob(id, { status: 'error', errorMessage: `Error de Gemini: ${err.message}` });
    throw err;
  }

  // Parsear respuesta
  let parsed;
  try {
    parsed = parseGeminiResponse(geminiRaw);
  } catch (err) {
    logger.error('Error parseando respuesta de Gemini', { id, error: err.message });
    // Guardar raw para debugging
    await db.updateJob(id, {
      status: 'error',
      errorMessage: `No se pudo parsear respuesta de Gemini: ${err.message}`,
      generatedScripts: [{ name: 'raw_response', code: geminiRaw, runner: 'unknown', filename: 'raw.txt' }],
    });
    return;
  }

  if (!parsed.scripts?.length) {
    await db.updateJob(id, { status: 'error', errorMessage: 'Gemini no generó scripts' });
    return;
  }

  // Guardar scripts en disco
  const scriptsWithPaths = saveScriptsToDisk(id, parsed.scripts);
  logger.info(`${scriptsWithPaths.length} script(s) generados y guardados`, { id });

  // Actualizar job a pending_approval
  await db.updateJob(id, {
    status: 'pending_approval',
    generatedScripts: scriptsWithPaths.map(s => ({
      name: s.name,
      description: s.description,
      runner: s.runner,
      filename: s.filename,
      filePath: s.filePath,
      code: s.code,
    })),
  });

  logger.info('Job listo para aprobación', { id, scripts: scriptsWithPaths.length });

  // Notificar (encolar notificación)
  const { enqueue } = require('../shared/queue');
  await enqueue('notify', { jobId: id, type: 'job_ready', appType, scriptCount: parsed.scripts.length });
}

// ─── Arranque del worker ──────────────────────────────────────────────────────
function start() {
  const { queues } = require('../shared/queue');

  // Concurrencia 2: no saturar la API de Gemini
  queues.generate.process(2, async (job) => {
    try {
      await processGenerateJob(job);
    } catch (err) {
      logger.error('Error en Generator', { jobId: job.data?.id, error: err.message });
      try { await db.updateJob(job.data?.id, { status: 'error', errorMessage: err.message }); } catch {}
      throw err;
    }
  });

  logger.info('Generator worker activo — escuchando cola "generate"');
}

start();
module.exports = { buildPrompt, callGemini, parseGeminiResponse };
