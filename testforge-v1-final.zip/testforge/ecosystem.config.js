/**
 * TESTFORGE — PM2 Ecosystem
 * 
 * Uso:
 *   pm2 start ecosystem.config.js          — Arrancar todo
 *   pm2 stop ecosystem.config.js           — Detener todo
 *   pm2 restart ecosystem.config.js        — Reiniciar todo
 *   pm2 logs testforge-collector           — Ver logs de un servicio
 *   pm2 monit                              — Monitor visual
 */

module.exports = {
  apps: [
    {
      name: 'testforge-collector',
      script: './collector/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      env: { NODE_ENV: 'production', COLLECTOR_PORT: 3001 },
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      error_file: './data/logs/collector-error.log',
      out_file: './data/logs/collector-out.log',
    },
    {
      name: 'testforge-analyzer',
      script: './analyzer/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      env: { NODE_ENV: 'production' },
      error_file: './data/logs/analyzer-error.log',
      out_file: './data/logs/analyzer-out.log',
    },
    {
      name: 'testforge-generator',
      script: './generator/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '400M',
      env: { NODE_ENV: 'production' },
      error_file: './data/logs/generator-error.log',
      out_file: './data/logs/generator-out.log',
    },
    {
      name: 'testforge-executor',
      script: './executor/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: { NODE_ENV: 'production' },
      error_file: './data/logs/executor-error.log',
      out_file: './data/logs/executor-out.log',
    },
    {
      name: 'testforge-notifier',
      script: './notifier/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '150M',
      env: { NODE_ENV: 'production' },
      error_file: './data/logs/notifier-error.log',
      out_file: './data/logs/notifier-out.log',
    },
    {
      name: 'testforge-api',
      script: './api/index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '200M',
      env: { NODE_ENV: 'production', API_PORT: 3002 },
      error_file: './data/logs/api-error.log',
      out_file: './data/logs/api-out.log',
    },
  ],
};
