# TESTFORGE v1 — Guía de Instalación

> Plataforma CI/CD con generación de tests por IA  
> Davivienda El Salvador · Área de IA & Automatizaciones

---

## Requisitos del Sistema

| Componente | Versión mínima | Cómo verificar |
|---|---|---|
| Node.js | 18+ | `node -v` |
| npm | 8+ | `npm -v` |
| Redis | 6+ | `redis-cli ping` |
| PM2 | cualquiera | `pm2 -v` |
| Python 3 | 3.8+ (solo para pytest) | `python3 --version` |

---

## Paso 1 — Instalar dependencias del sistema

### Ubuntu / Debian (servidor on-premise)

```bash
# Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Redis
sudo apt-get install -y redis-server
sudo systemctl enable redis-server
sudo systemctl start redis-server

# PM2 (process manager)
sudo npm install -g pm2

# Verificar
node -v && redis-cli ping && pm2 -v
```

### macOS (desarrollo local)

```bash
brew install node redis
brew services start redis
sudo npm install -g pm2
```

---

## Paso 2 — Descomprimir y preparar el proyecto

```bash
# Descomprimir el zip
unzip testforge-v1-final.zip
cd testforge

# Instalar dependencias Node.js
npm install
```

---

## Paso 3 — Configurar variables de entorno

```bash
# Copiar plantilla
cp .env.example .env

# Editar con tu editor preferido
nano .env
```

**Variables que DEBES configurar:**

```bash
# Tu API key de Gemini (obtener en https://aistudio.google.com/app/apikey)
GEMINI_API_KEY=AIzaSy...tu_clave_aqui

# URL de tu servidor donde corre la UI (para links en emails)
UI_URL=http://192.168.1.100:3000
```

**Variables opcionales pero recomendadas:**

```bash
# Notificaciones por email (SMTP interno Davivienda)
SMTP_HOST=smtp.davivienda.com.sv
SMTP_PORT=587
SMTP_USER=testforge@davivienda.com.sv
SMTP_PASS=tu_password
SMTP_FROM=testforge@davivienda.com.sv
NOTIFY_EMAIL=tu-email@davivienda.com.sv

# Token secreto para webhooks de GitLab
GITLAB_WEBHOOK_SECRET=un_string_aleatorio_seguro
# Generar con: openssl rand -hex 32
```

---

## Paso 4 — Validar que todo está correcto

```bash
node scripts/validate.js
```

Salida esperada:
```
╔════════════════════════════════════════╗
║   TESTFORGE v1 — Validación del Sistema ║
╚════════════════════════════════════════╝

1. Estructura del Proyecto
  ✓ collector/index.js
  ✓ analyzer/index.js
  ...

2. Variables de Entorno
  ✓ GEMINI_API_KEY
  ⚠ SMTP_HOST — Opcional

3. Dependencias Node.js
  ✓ express
  ✓ bull
  ...

7. Servicios Externos
  ✓ Redis 127.0.0.1:6379
  ✓ Gemini API (gemini-1.5-flash) — Conectividad OK
  ⚠ SMTP — No configurado

  ✅ Sistema listo. Ejecuta: pm2 start ecosystem.config.js
```

> Si ves errores `✗`, resuélvelos antes de continuar.  
> Los warnings `⚠` son opcionales.

---

## Paso 5 — Arrancar todos los servicios

```bash
pm2 start ecosystem.config.js
```

Verificar que todos estén activos:

```bash
pm2 status
```

Deberías ver 6 procesos en `online`:

```
┌─────┬──────────────────────────┬─────────┬───────────┐
│ id  │ name                     │ status  │ memory    │
├─────┼──────────────────────────┼─────────┼───────────┤
│ 0   │ testforge-collector      │ online  │ 60mb      │
│ 1   │ testforge-analyzer       │ online  │ 45mb      │
│ 2   │ testforge-generator      │ online  │ 55mb      │
│ 3   │ testforge-executor       │ online  │ 70mb      │
│ 4   │ testforge-notifier       │ online  │ 40mb      │
│ 5   │ testforge-api            │ online  │ 50mb      │
└─────┴──────────────────────────┴─────────┴───────────┘
```

---

## Paso 6 — Instalar y arrancar la UI

```bash
# En otro directorio, descomprimir la UI
unzip testforge-ui.zip
cd testforge-ui

# Instalar dependencias
npm install

# Crear archivo de entorno
cat > .env.local << EOF
NEXT_PUBLIC_API_URL=http://localhost:3002
NEXT_PUBLIC_COLLECTOR_URL=http://localhost:3001
EOF

# Arrancar en producción
npm run build
npm start

# O para desarrollo
npm run dev
```

La UI queda disponible en: **http://localhost:3000**

---

## Paso 7 — Probar el pipeline completo

### Prueba rápida con el archivo de ejemplo

```bash
# El archivo examples/transferencias.js incluye un módulo bancario de ejemplo
curl -X POST http://localhost:3001/upload \
  -F "file=@examples/transferencias.js" \
  -F "appType=script" \
  -F "description=Módulo de transferencias - prueba de TESTFORGE"
```

Respuesta esperada:
```json
{
  "message": "Archivo recibido y encolado para análisis",
  "jobId": "abc12345-..."
}
```

Luego abre la UI en http://localhost:3000 y verás el job procesándose.

### Flujo completo

1. **Subir archivo** → UI en `/upload` o via `curl`
2. **Esperar ~20s** → Gemini genera el script de prueba
3. **Aprobar en UI** → `/jobs/{id}` → revisar código → "Aprobar y Ejecutar"
4. **Ver resultados** → tab "Resultados" con log completo
5. **Recibir email** → si configuraste SMTP

---

## Comandos útiles del día a día

```bash
# Ver estado de todos los servicios
pm2 status

# Ver logs en tiempo real (todos)
pm2 logs

# Ver logs de un servicio específico
pm2 logs testforge-collector
pm2 logs testforge-generator
pm2 logs testforge-executor

# Monitor visual con CPU/RAM
pm2 monit

# Reiniciar un servicio si falla
pm2 restart testforge-generator

# Reiniciar todo
pm2 restart ecosystem.config.js

# Detener todo
pm2 stop ecosystem.config.js

# Ver los últimos jobs via API
curl http://localhost:3002/api/jobs | python3 -m json.tool

# Ver estadísticas
curl http://localhost:3002/api/stats | python3 -m json.tool

# Health check rápido
curl http://localhost:3001/health
curl http://localhost:3002/health
```

---

## Configurar GitLab Webhook

1. En tu repositorio GitLab: **Settings → Webhooks**
2. URL: `http://TU_SERVIDOR:3001/webhook/gitlab`
3. Secret Token: el valor de `GITLAB_WEBHOOK_SECRET` en tu `.env`
4. Eventos: ✅ Push events, ✅ Merge request events
5. Click en **Add webhook**
6. Click en **Test → Push events** para verificar

---

## Configurar Folder Watcher

Para monitorear una carpeta local automáticamente:

```bash
curl -X POST http://localhost:3001/sources/folder \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Proyecto MIG C",
    "folderPath": "/ruta/al/proyecto"
  }'
```

Cualquier archivo `.js`, `.ts`, `.py`, `.json`, `.yaml` que se guarde en esa carpeta disparará el pipeline automáticamente.

---

## Hacer que PM2 arranque al reiniciar el servidor

```bash
# Guardar la lista de procesos actual
pm2 save

# Configurar arranque automático
pm2 startup

# Ejecutar el comando que PM2 indique (algo como):
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u usuario --hp /home/usuario
```

---

## Estructura de directorios generados

```
data/
├── uploads/      ← Archivos subidos manualmente
├── scripts/      ← Scripts generados por Gemini (por job ID)
├── results/      ← Resultados de ejecución (logs, jest-results.json)
│   └── {jobId}/
│       ├── exec/             ← Script aprobado que se ejecutó
│       ├── execution.log     ← Log completo de la ejecución
│       └── jest-results.json ← Resultados estructurados (si runner=jest)
└── logs/         ← Logs de PM2 por servicio
    ├── collector-out.log
    ├── generator-out.log
    └── ...
```

---

## Solución de problemas frecuentes

### "Redis connection refused"
```bash
sudo systemctl start redis-server
redis-cli ping   # Debe responder: PONG
```

### "GEMINI_API_KEY no configurado"
```bash
nano .env   # Agregar GEMINI_API_KEY=tu_clave
pm2 restart ecosystem.config.js
```

### Un servicio aparece como "errored" en PM2
```bash
pm2 logs testforge-generator --lines 50   # Ver el error
pm2 restart testforge-generator
```

### La UI no carga datos (CORS error)
Verifica que `NEXT_PUBLIC_API_URL` en `testforge-ui/.env.local` apunta al servidor correcto.

### Jobs se quedan en "analyzing" indefinidamente
Significa que el Analyzer worker no está procesando. Verifica:
```bash
pm2 logs testforge-analyzer
pm2 status   # ¿Está online?
```

---

## Puertos utilizados

| Puerto | Servicio | Descripción |
|---|---|---|
| 3000 | UI Next.js | Panel web |
| 3001 | Collector | Webhooks + uploads |
| 3002 | API | REST para la UI |
| 6379 | Redis | Colas Bull |
