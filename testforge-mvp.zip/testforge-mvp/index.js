/**
 * TESTFORGE MVP — index.js
 *
 * Un solo proceso Node.js que orquesta todo:
 *   - Collector  (Express: webhook GitLab + upload manual + folder watcher)
 *   - Analyzer   (detecta tipo de app, extrae contexto)
 *   - Generator  (llama a Gemini, genera scripts)
 *   - Executor   (corre scripts aprobados)
 *   - Notifier   (emails SMTP)
 *   - API REST   (para la UI Next.js)
 *
 * Sin Redis, sin Bull, sin PM2.
 * Arrancar con: node index.js
 */

require('dotenv').config();

const express  = require('express');
const multer   = require('multer');
const chokidar = require('chokidar');
const path     = require('path');
const fs       = require('fs');
const { v4: uuidv4 } = require('uuid');

const logger   = require('./shared/logger').forModule('Core');
const db       = require('./shared/db');
const analyzer = require('./modules/analyzer');
const generator= require('./modules/generator');
const executor = require('./modules/executor');
const notifier = require('./modules/notifier');

// ─── Dirs ──────────────────────────────────────────────────────────────────────
const UPLOAD_DIR  = process.env.UPLOAD_DIR  || path.join(process.cwd(), 'data', 'uploads');
const SCRIPTS_DIR = process.env.SCRIPTS_DIR || path.join(process.cwd(), 'data', 'scripts');
const RESULTS_DIR = process.env.RESULTS_DIR || path.join(process.cwd(), 'data', 'results');
[UPLOAD_DIR, SCRIPTS_DIR, RESULTS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ─── Cola en memoria (simple array FIFO) ──────────────────────────────────────
const queue    = [];
let processing = false;

async function enqueue(jobId) {
  queue.push(jobId);
  logger.info('Job encolado', { jobId, queueSize: queue.length });
  if (!processing) processNext();
}

async function processNext() {
  if (!queue.length) { processing = false; return; }
  processing = true;
  const jobId = queue.shift();

  try {
    await processJob(jobId);
  } catch (err) {
    logger.error('Error procesando job', { jobId, error: err.message });
    await db.updateJob(jobId, { status: 'error', errorMessage: err.message });
  }

  // Siguiente job (con pequeña pausa para no saturar)
  setTimeout(processNext, 500);
}

// ─── Pipeline principal ───────────────────────────────────────────────────────
async function processJob(jobId) {
  const job = await db.getJob(jobId);
  if (!job) { logger.warn('Job no encontrado', { jobId }); return; }

  logger.info('Procesando job', { jobId, sourceType: job.source_type });

  // ── 1. Analyze
  await db.updateJob(jobId, { status: 'analyzing' });
  const filePath   = job.source_meta?.filePath || job.source_meta?.originalName || '';
  const rawContent = job.raw_content || '';

  if (!rawContent || rawContent.trim().length < 10) {
    await db.updateJob(jobId, { status: 'error', errorMessage: 'Contenido insuficiente para analizar' });
    return;
  }

  const { appType, context } = analyzer.analyze(rawContent, filePath, job.app_type);
  context.jobId = jobId;
  await db.updateJob(jobId, { appType, context });
  logger.info('Análisis completado', { jobId, appType });

  // ── 2. Generate
  await db.updateJob(jobId, { status: 'generating' });
  let generated;
  try {
    generated = await generator.generate(appType, context, rawContent);
  } catch (err) {
    await db.updateJob(jobId, { status: 'error', errorMessage: `Error Gemini: ${err.message}` });
    return;
  }

  await db.updateJob(jobId, {
    status: 'pending_approval',
    generatedScripts: generated.scripts,
  });

  logger.info('Scripts generados, esperando aprobación', { jobId, count: generated.scripts.length });

  // Notificar "listo para aprobar"
  const updatedJob = await db.getJob(jobId);
  const notifResult = await notifier.notify(updatedJob, 'job_ready');
  await db.logNotification(jobId, 'job_ready', notifResult?.error || null);
}

// ─── App Express ──────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '10mb' }));

// CORS para la UI Next.js
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// ─── Multer ───────────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.js','.ts','.py','.json','.yaml','.yml','.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    allowed.includes(ext) ? cb(null, true) : cb(new Error(`Extensión no soportada: ${ext}`));
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// COLLECTOR: Fuente 1 — GitLab Webhook
// ─────────────────────────────────────────────────────────────────────────────
app.post('/webhook/gitlab', async (req, res) => {
  const secret = process.env.GITLAB_WEBHOOK_SECRET;
  if (secret && req.headers['x-gitlab-token'] !== secret) {
    logger.warn('Webhook rechazado — token inválido');
    return res.status(401).json({ error: 'Token inválido' });
  }

  const event   = req.headers['x-gitlab-event'];
  const payload = req.body;
  logger.info('Webhook GitLab', { event, project: payload.project?.name });

  if (!['Push Hook','Merge Request Hook'].includes(event)) {
    return res.json({ message: 'Evento ignorado', event });
  }

  const ignoredExt = ['.md','.txt','.lock','.gitignore','.env'];
  const commits    = payload.commits || [];
  const files      = [];

  for (const commit of commits) {
    for (const f of [...(commit.added||[]), ...(commit.modified||[])]) {
      if (!ignoredExt.includes(path.extname(f).toLowerCase())) {
        files.push({ path: f, action: 'modified' });
      }
    }
  }

  if (!files.length) return res.json({ message: 'Sin archivos relevantes' });

  const jobIds = [];
  for (const file of files) {
    const jobId = uuidv4();
    await db.createJob({
      id: jobId, sourceType: 'gitlab', status: 'queued',
      sourceMeta: {
        event, project: payload.project?.name,
        branch: payload.ref?.replace('refs/heads/',''),
        commit: payload.checkout_sha?.slice(0,8),
        filePath: file.path,
      },
      rawContent: null, // GitLab no envía el contenido en el webhook
    });
    // Nota: para obtener el contenido real del archivo se necesitaría
    // llamar a la GitLab API. Por ahora se registra el job con metadata.
    jobIds.push(jobId);
    logger.info('Job creado desde GitLab', { jobId, file: file.path });
  }

  res.json({ message: 'Jobs registrados', count: jobIds.length, jobIds });
});

// ─────────────────────────────────────────────────────────────────────────────
// COLLECTOR: Fuente 2 — Upload Manual
// ─────────────────────────────────────────────────────────────────────────────
app.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No se recibió archivo' });

  const jobId      = uuidv4();
  const rawContent = fs.readFileSync(req.file.path, 'utf-8');
  const { appType, description } = req.body;

  await db.createJob({
    id: jobId, sourceType: 'manual',
    appType: appType || null,
    status: 'queued',
    sourceMeta: {
      originalName: req.file.originalname,
      size:         req.file.size,
      storedPath:   req.file.path,
      description:  description || '',
    },
    rawContent,
  });

  logger.info('Job creado desde upload', { jobId, file: req.file.originalname });
  await enqueue(jobId);

  res.json({ message: 'Archivo recibido y encolado para análisis', jobId });
});

// ─────────────────────────────────────────────────────────────────────────────
// COLLECTOR: Fuente 3 — Folder Watcher
// ─────────────────────────────────────────────────────────────────────────────
const watchers   = new Map();
const debounces  = new Map();

function startWatcher(name, folderPath) {
  if (watchers.has(folderPath)) return;

  const ignoredExt = ['.md','.txt','.lock','.log','.gitignore','.env'];
  const watcher    = chokidar.watch(folderPath, {
    ignored: /(^|[/\\])\../,
    persistent: true, ignoreInitial: true,
    awaitWriteFinish: { stabilityThreshold: 1000, pollInterval: 100 },
  });

  const handle = async (filePath, action) => {
    if (ignoredExt.includes(path.extname(filePath).toLowerCase())) return;
    if (debounces.has(filePath)) clearTimeout(debounces.get(filePath));
    debounces.set(filePath, setTimeout(async () => {
      debounces.delete(filePath);
      try {
        const rawContent = fs.readFileSync(filePath, 'utf-8');
        const jobId      = uuidv4();
        await db.createJob({
          id: jobId, sourceType: 'folder', status: 'queued',
          sourceMeta: { watchSource: name, folderPath, filePath, action },
          rawContent,
        });
        logger.info('Job creado desde folder watcher', { jobId, filePath });
        await enqueue(jobId);
      } catch (err) {
        logger.error('Error en folder watcher', { error: err.message, filePath });
      }
    }, 500));
  };

  watcher.on('add',    fp => handle(fp, 'added'));
  watcher.on('change', fp => handle(fp, 'modified'));
  watchers.set(folderPath, watcher);
  logger.info('Folder watcher iniciado', { name, folderPath });
}

app.post('/sources/folder', async (req, res) => {
  const { name, folderPath } = req.body;
  if (!name || !folderPath) return res.status(400).json({ error: 'name y folderPath requeridos' });
  if (!fs.existsSync(folderPath)) return res.status(400).json({ error: `Carpeta no existe: ${folderPath}` });
  startWatcher(name, folderPath);
  res.json({ message: 'Watcher iniciado', folderPath });
});

// ─────────────────────────────────────────────────────────────────────────────
// API REST — para la UI Next.js
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/jobs
app.get('/api/jobs', async (req, res) => {
  try {
    const { status, limit } = req.query;
    const jobs = await db.listJobs({ status, limit: limit ? parseInt(limit) : 50 });
    res.json({ jobs, count: jobs.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/jobs/:id
app.get('/api/jobs/:id', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });
    res.json(job);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/jobs/:id/approve
app.post('/api/jobs/:id/approve', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job)                              return res.status(404).json({ error: 'Job no encontrado' });
    if (job.status !== 'pending_approval') return res.status(400).json({ error: `Estado actual: "${job.status}"` });

    const { approvedBy, editedScript } = req.body;
    const scripts = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];

    const scriptToRun = editedScript?.code ? editedScript : scripts[0];
    if (!scriptToRun?.code) return res.status(400).json({ error: 'Sin script para aprobar' });

    await db.updateJob(req.params.id, {
      status:         'approved',
      approvedBy:     approvedBy || 'admin',
      approvedAt:     new Date().toISOString(),
      approvedScript: scriptToRun,
    });

    logger.info('Job aprobado, ejecutando...', { jobId: req.params.id });
    res.json({ message: 'Aprobado. Ejecutando...', jobId: req.params.id });

    // Ejecutar en background (no bloquea la respuesta HTTP)
    setImmediate(() => runApproved(req.params.id));

  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/jobs/:id/reject
app.post('/api/jobs/:id/reject', async (req, res) => {
  try {
    const { reason, rejectedBy } = req.body;
    await db.updateJob(req.params.id, {
      status:         'rejected',
      rejectedReason: reason || 'Sin motivo',
      approvedBy:     rejectedBy || 'admin',
    });
    logger.info('Job rechazado', { jobId: req.params.id });
    res.json({ message: 'Job rechazado', jobId: req.params.id });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/jobs/:id/results
app.get('/api/jobs/:id/results', async (req, res) => {
  try {
    const job = await db.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job no encontrado' });
    const logFile = path.join(RESULTS_DIR, job.id, 'execution.log');
    res.json({
      jobId:            job.id,
      status:           job.status,
      executionResults: job.execution_results,
      log: fs.existsSync(logFile) ? fs.readFileSync(logFile,'utf-8').substring(0,20000) : null,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/stats
app.get('/api/stats', async (req, res) => {
  try {
    const jobs     = await db.listJobs({ limit: 500 });
    const byStatus = jobs.reduce((acc, j) => { acc[j.status]=(acc[j.status]||0)+1; return acc; }, {});
    const totalRan = (byStatus.passed||0) + (byStatus.failed||0);
    res.json({
      jobs: {
        total: jobs.length, byStatus,
        passRate: totalRan > 0 ? Math.round((byStatus.passed||0)/totalRan*100) : null,
      },
      queue: { pending: queue.length, processing },
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/sources
app.get('/api/sources', async (req, res) => {
  const sources = [...watchers.keys()].map(p => ({ type: 'folder', path: p }));
  res.json({ sources });
});

// GET /health
app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), queue: queue.length, processing });
});

// ─── Ejecutar script aprobado (background) ────────────────────────────────────
async function runApproved(jobId) {
  try {
    await db.updateJob(jobId, { status: 'running' });
    const job            = await db.getJob(jobId);
    const approvedScript = job.approved_script;

    if (!approvedScript?.code) {
      await db.updateJob(jobId, { status: 'error', errorMessage: 'Sin script aprobado' });
      return;
    }

    const results = await executor.execute(jobId, approvedScript);
    const status  = results.passed ? 'passed' : 'failed';

    await db.updateJob(jobId, { status, executionResults: results });

    // Notificar resultado
    const updated = await db.getJob(jobId);
    const type    = results.passed ? 'job_passed' : 'job_failed';
    const notif   = await notifier.notify(updated, type);
    await db.logNotification(jobId, type, notif?.error || null);

    logger.info(`Job ${status}`, { jobId, duration: results.duration });

  } catch (err) {
    logger.error('Error ejecutando job', { jobId, error: err.message });
    await db.updateJob(jobId, { status: 'error', errorMessage: err.message });
  }
}

// ─── Arranque ─────────────────────────────────────────────────────────────────
async function start() {
  // Inicializar DB
  await db.getDb();

  // Re-encolar jobs que quedaron a medias (analyzing/generating) de una sesión anterior
  const stuck = await db.listJobs();
  const toRetry = stuck.filter(j => ['analyzing','generating','queued'].includes(j.status));
  if (toRetry.length) {
    logger.info(`Re-encolando ${toRetry.length} job(s) de sesión anterior`);
    for (const j of toRetry) await enqueue(j.id);
  }

  const PORT = process.env.PORT || 3001;
  app.listen(PORT, () => {
    logger.info('═══════════════════════════════════════');
    logger.info('  TESTFORGE MVP — listo');
    logger.info('═══════════════════════════════════════');
    logger.info(`  Puerto:    ${PORT}`);
    logger.info(`  Upload:    POST http://localhost:${PORT}/upload`);
    logger.info(`  Webhook:   POST http://localhost:${PORT}/webhook/gitlab`);
    logger.info(`  API Jobs:  GET  http://localhost:${PORT}/api/jobs`);
    logger.info(`  Health:    GET  http://localhost:${PORT}/health`);
    logger.info('───────────────────────────────────────');
    logger.info('  UI Next.js: cd ui && npm run dev');
    logger.info('═══════════════════════════════════════');
  });
}

// Graceful shutdown
process.on('SIGINT', async () => {
  logger.info('Cerrando TESTFORGE MVP...');
  for (const [, w] of watchers) await w.close();
  process.exit(0);
});

start().catch(err => {
  logger.error('Error fatal al arrancar', { error: err.message });
  process.exit(1);
});
