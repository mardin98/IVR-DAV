#!/usr/bin/env node
require('dotenv').config();

const fs   = require('fs');
const path = require('path');
const http = require('http');

const G = s => `\x1b[32m${s}\x1b[0m`;
const R = s => `\x1b[31m${s}\x1b[0m`;
const Y = s => `\x1b[33m${s}\x1b[0m`;
const B = s => `\x1b[1m${s}\x1b[0m`;

let ok = 0, fail = 0, warn = 0;

const pass = (l, d='') => { ok++;   console.log(`  ${G('✓')} ${l}${d ? ` \x1b[90m— ${d}\x1b[0m` : ''}`); };
const err  = (l, d='') => { fail++; console.log(`  ${R('✗')} ${l}${d ? ` \x1b[90m— ${d}\x1b[0m` : ''}`); };
const war  = (l, d='') => { warn++; console.log(`  ${Y('⚠')} ${l}${d ? ` \x1b[90m— ${d}\x1b[0m` : ''}`); };
const sec  = t => console.log(`\n${B(t)}`);

function checkHttp(url, t=3000) {
  return new Promise(res => {
    const req = http.get(url, {timeout:t}, r => {
      let b=''; r.on('data',d=>b+=d);
      r.on('end', () => { try{res({ok:r.statusCode<400,body:JSON.parse(b)})}catch{res({ok:r.statusCode<400})} });
    });
    req.on('error', e=>res({ok:false,error:e.message}));
    req.on('timeout',()=>{req.destroy();res({ok:false,error:'timeout'})});
  });
}

async function main() {
  console.log(B('\n╔══════════════════════════════════════╗'));
  console.log(B('║  TESTFORGE MVP — Validación          ║'));
  console.log(B('╚══════════════════════════════════════╝'));

  sec('1. Archivos del proyecto');
  const files = [
    'index.js','shared/db.js','shared/logger.js',
    'modules/analyzer.js','modules/generator.js',
    'modules/executor.js','modules/notifier.js',
    'examples/transferencias.js','package.json',
  ];
  for (const f of files) {
    fs.existsSync(path.join(process.cwd(), f)) ? pass(f) : err(f, 'Faltante');
  }
  if (!fs.existsSync(path.join(process.cwd(), '.env'))) {
    war('.env', 'Copia .env.example a .env y configura GEMINI_API_KEY');
  } else {
    pass('.env');
  }

  sec('2. Variables de entorno');
  process.env.GEMINI_API_KEY ? pass('GEMINI_API_KEY') : err('GEMINI_API_KEY', 'REQUERIDA');
  process.env.SMTP_HOST      ? pass('SMTP_HOST')      : war('SMTP_HOST',      'Opcional — emails desactivados');
  process.env.NOTIFY_EMAIL   ? pass('NOTIFY_EMAIL')   : war('NOTIFY_EMAIL',   'Opcional');

  sec('3. Dependencias Node.js');
  const deps = ['express','sql.js','multer','chokidar','dotenv','winston','axios','uuid','nodemailer','jest'];
  for (const d of deps) {
    fs.existsSync(path.join(process.cwd(),'node_modules',d)) ? pass(d) : err(d,'Ejecuta: npm install');
  }

  sec('4. Directorios de datos');
  for (const d of ['data','data/uploads','data/scripts','data/results','data/logs']) {
    const full = path.join(process.cwd(), d);
    if (fs.existsSync(full)) { pass(d); }
    else { try { fs.mkdirSync(full,{recursive:true}); pass(d,'creado ahora'); } catch(e){ err(d,e.message); } }
  }

  sec('5. Sintaxis de módulos');
  const { execSync } = require('child_process');
  const mods = ['index.js','shared/db.js','shared/logger.js',
    'modules/analyzer.js','modules/generator.js','modules/executor.js','modules/notifier.js'];
  for (const m of mods) {
    try { execSync(`node --check ${m}`,{stdio:'pipe',cwd:process.cwd()}); pass(m); }
    catch(e) { err(m, e.stderr?.toString().trim()||'Error de sintaxis'); }
  }

  sec('6. Prueba de lógica interna');
  try {
    const t = require(path.join(process.cwd(),'examples/transferencias.js'));
    const checks = [
      t.validarCuenta('DV1234567890') === true,
      t.validarCuenta('INVALIDA')     === false,
      t.validarMonto(100).valido      === true,
      t.validarMonto(-5).valido       === false,
      t.calcularComision(300)         === 0,
      t.calcularComision(1000)        === 5,
      t.prepararTransferencia({origen:'DV1234567890',destino:'DV0987654321',monto:500}).ok === true,
      t.prepararTransferencia({origen:'DV1234567890',destino:'DV1234567890',monto:500}).ok === false,
    ];
    checks.every(Boolean) ? pass('examples/transferencias.js — 8/8 assertions ok') : err('examples/transferencias.js','Algunas assertions fallaron');
  } catch(e) { err('examples/transferencias.js', e.message); }

  sec('7. Gemini API');
  if (process.env.GEMINI_API_KEY) {
    try {
      const axios = require('axios');
      const model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
      const r = await axios.get(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}?key=${process.env.GEMINI_API_KEY}`,
        { timeout: 8000 }
      );
      r.status === 200 ? pass(`Gemini API (${model})`) : war('Gemini API', `Status ${r.status}`);
    } catch(e) {
      const msg = e.response?.status===400 ? 'API Key inválida'
                : e.response?.status===403 ? 'Sin permisos'
                : e.code==='ECONNREFUSED'  ? 'Sin internet'
                : e.message;
      err('Gemini API', msg);
    }
  } else {
    war('Gemini API', 'GEMINI_API_KEY no configurada');
  }

  sec('8. Servidor (si está corriendo)');
  const port = process.env.PORT || 3001;
  const res  = await checkHttp(`http://localhost:${port}/health`);
  res.ok
    ? pass(`Servidor :${port}`, res.body?.status)
    : war(`Servidor :${port}`, 'No está corriendo — normal si aún no arrancaste');

  console.log('\n' + '─'.repeat(40));
  console.log(B(`  ${G(ok+' ✓')}  ${fail>0?R(fail+' ✗'):'0 ✗'}  ${warn>0?Y(warn+' ⚠'):'0 ⚠'}`));

  if (fail === 0) {
    console.log(G(B('\n  ✅ Listo. Ejecuta: node index.js\n')));
  } else {
    console.log(R('\n  ✗ Corrige los errores antes de arrancar.\n'));
    process.exit(1);
  }
}

main().catch(e => { console.error(R('Error:'), e.message); process.exit(1); });
