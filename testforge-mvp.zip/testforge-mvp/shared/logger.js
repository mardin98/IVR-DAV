const winston = require('winston');
const path = require('path');
const fs = require('fs');

const logsDir = path.join(process.cwd(), 'data', 'logs');
fs.mkdirSync(logsDir, { recursive: true });

const fmt = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(({ timestamp, level, message, module: mod, ...meta }) => {
    const m = mod ? `[${mod}] ` : '';
    const e = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
    return `${timestamp} ${level.toUpperCase().padEnd(5)} ${m}${message}${e}`;
  })
);

const logger = winston.createLogger({
  level: 'info',
  format: fmt,
  transports: [
    new winston.transports.Console({ format: winston.format.combine(winston.format.colorize(), fmt) }),
    new winston.transports.File({ filename: path.join(logsDir, 'testforge.log') }),
  ],
});

logger.forModule = (mod) => logger.child({ module: mod });
module.exports = logger;
