/**
 * TESTFORGE MVP — Database (sql.js / SQLite)
 */
const initSqlJs = require('sql.js');
const fs   = require('fs');
const path = require('path');
const logger = require('./logger').forModule('DB');

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(), 'data', 'testforge.db');

let _db = null;

async function getDb() {
  if (_db) return _db;
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    _db = new SQL.Database(fs.readFileSync(DB_PATH));
    logger.info('DB cargada', { path: DB_PATH });
  } else {
    _db = new SQL.Database();
    logger.info('DB nueva', { path: DB_PATH });
  }
  _db.run(`
    CREATE TABLE IF NOT EXISTS jobs (
      id                TEXT PRIMARY KEY,
      source_type       TEXT NOT NULL,
      app_type          TEXT,
      status            TEXT NOT NULL DEFAULT 'analyzing',
      source_meta       TEXT,
      raw_content       TEXT,
      context           TEXT,
      generated_scripts TEXT,
      approved_script   TEXT,
      approved_by       TEXT,
      approved_at       TEXT,
      rejected_reason   TEXT,
      execution_results TEXT,
      error_message     TEXT,
      created_at        TEXT NOT NULL,
      updated_at        TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id      INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id  TEXT NOT NULL,
      type    TEXT NOT NULL,
      sent_at TEXT,
      error   TEXT
    );
  `);
  save();
  return _db;
}

function save() {
  if (!_db) return;
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(DB_PATH, Buffer.from(_db.export()));
}

function toSnake(k) { return k.replace(/([A-Z])/g, '_$1').toLowerCase(); }

const JSON_FIELDS = ['source_meta','context','generated_scripts','execution_results','approved_script'];

function rowToJob(cols, vals) {
  const obj = {};
  cols.forEach((c, i) => { obj[c] = vals[i]; });
  for (const f of JSON_FIELDS) {
    if (obj[f] && typeof obj[f] === 'string') {
      try { obj[f] = JSON.parse(obj[f]); } catch {}
    }
  }
  return obj;
}

async function createJob(job) {
  const db  = await getDb();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO jobs (id,source_type,app_type,status,source_meta,raw_content,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?,?)`,
    [job.id, job.sourceType, job.appType||null, job.status||'analyzing',
     JSON.stringify(job.sourceMeta||{}), job.rawContent||null, now, now]
  );
  save();
  return getJob(job.id);
}

async function updateJob(id, fields) {
  const db  = await getDb();
  const now = new Date().toISOString();
  const ALLOWED = new Set([
    'status','app_type','context','generated_scripts','approved_script',
    'approved_by','approved_at','rejected_reason','execution_results','error_message'
  ]);
  const sets = [], vals = [];
  for (const [k, v] of Object.entries(fields)) {
    const col = toSnake(k);
    if (!ALLOWED.has(col)) continue;
    sets.push(`${col} = ?`);
    vals.push(v !== null && typeof v === 'object' ? JSON.stringify(v) : v);
  }
  if (!sets.length) return getJob(id);
  sets.push('updated_at = ?');
  vals.push(now, id);
  db.run(`UPDATE jobs SET ${sets.join(', ')} WHERE id = ?`, vals);
  save();
  return getJob(id);
}

async function getJob(id) {
  const db = await getDb();
  const r  = db.exec('SELECT * FROM jobs WHERE id = ?', [id]);
  if (!r.length || !r[0].values.length) return null;
  return rowToJob(r[0].columns, r[0].values[0]);
}

async function listJobs(filters = {}) {
  const db = await getDb();
  let q = 'SELECT * FROM jobs', p = [], c = [];
  if (filters.status)     { c.push('status = ?');      p.push(filters.status); }
  if (filters.sourceType) { c.push('source_type = ?'); p.push(filters.sourceType); }
  if (c.length) q += ' WHERE ' + c.join(' AND ');
  q += ' ORDER BY created_at DESC';
  if (filters.limit) { q += ' LIMIT ?'; p.push(filters.limit); }
  const r = db.exec(q, p);
  if (!r.length) return [];
  return r[0].values.map(row => rowToJob(r[0].columns, row));
}

async function logNotification(jobId, type, error = null) {
  const db = await getDb();
  db.run(
    `INSERT INTO notifications (job_id,type,sent_at,error) VALUES (?,?,?,?)`,
    [jobId, type, new Date().toISOString(), error]
  );
  save();
}

module.exports = { getDb, save, createJob, updateJob, getJob, listJobs, logNotification };
