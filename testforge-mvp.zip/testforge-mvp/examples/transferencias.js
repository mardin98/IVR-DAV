/**
 * transferencias.js — Archivo de prueba para TESTFORGE MVP
 * Sube este archivo desde la UI para ver el pipeline completo.
 */

function validarCuenta(cuenta) {
  if (!cuenta || typeof cuenta !== 'string') return false;
  return /^[A-Z]{2}\d{10}$/.test(cuenta.trim().toUpperCase());
}

function validarMonto(monto) {
  if (monto === null || monto === undefined) return { valido: false, error: 'Monto requerido' };
  if (typeof monto !== 'number' || isNaN(monto)) return { valido: false, error: 'Monto debe ser número' };
  if (monto <= 0)    return { valido: false, error: 'Monto debe ser mayor a 0' };
  if (monto > 50000) return { valido: false, error: 'Monto supera límite de $50,000' };
  return { valido: true };
}

function calcularComision(monto) {
  if (typeof monto !== 'number' || monto <= 0) return 0;
  if (monto <= 500)  return 0;
  if (monto <= 5000) return Math.round(monto * 0.005 * 100) / 100;
  return Math.round(monto * 0.01 * 100) / 100;
}

function formatearMonto(monto) {
  if (typeof monto !== 'number') return '$0.00';
  return `$${monto.toFixed(2)}`;
}

function prepararTransferencia({ origen, destino, monto, descripcion }) {
  if (!validarCuenta(origen))  return { ok: false, error: 'Cuenta origen inválida' };
  if (!validarCuenta(destino)) return { ok: false, error: 'Cuenta destino inválida' };
  if (origen === destino)      return { ok: false, error: 'Origen y destino no pueden ser iguales' };
  const vm = validarMonto(monto);
  if (!vm.valido) return { ok: false, error: vm.error };
  const comision = calcularComision(monto);
  return {
    ok: true,
    detalle: {
      origen, destino, monto, comision,
      totalDebito: Math.round((monto + comision) * 100) / 100,
      descripcion: descripcion || 'Transferencia',
      timestamp: new Date().toISOString(),
    },
  };
}

module.exports = { validarCuenta, validarMonto, calcularComision, formatearMonto, prepararTransferencia };
