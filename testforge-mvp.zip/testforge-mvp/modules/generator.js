/**
 * TESTFORGE MVP — Generator
 * Llama a Gemini y genera scripts de prueba.
 */
const axios  = require('axios');
const path   = require('path');
const fs     = require('fs');
const logger = require('../shared/logger').forModule('Generator');

const GEMINI_URL = () => {
  const model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
  return `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`;
};

function buildPrompt(appType, context, rawContent) {
  const base = `Eres un experto en QA y testing de software.
Genera scripts de prueba completos y ejecutables basados en el código proporcionado.

REGLAS:
- Código real y ejecutable, NO pseudocódigo
- Incluye todos los imports necesarios
- Cubre casos felices Y casos de error
- Responde ÚNICAMENTE con JSON válido, sin texto adicional ni markdown

Formato de respuesta:
{
  "scripts": [
    {
      "name": "nombre descriptivo",
      "description": "qué valida este script",
      "runner": "jest|node|pytest|playwright",
      "filename": "nombre-archivo.test.js",
      "code": "código completo ejecutable"
    }
  ],
  "summary": "resumen de qué se prueba",
  "coverageNotes": "qué aspectos no están cubiertos"
}`;

  const prompts = {
    api: `${base}

TIPO: API REST
CONTEXTO: ${JSON.stringify(context, null, 2)}
CÓDIGO:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

Genera tests con axios (runner: "node"). Prueba:
1. Respuestas exitosas con datos válidos
2. Validaciones de entrada con datos inválidos
3. Casos borde (IDs inexistentes, campos vacíos)`,

    web: `${base}

TIPO: Web / Frontend
CONTEXTO: ${JSON.stringify(context, null, 2)}
CÓDIGO:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

Genera tests Playwright (runner: "playwright"). Prueba:
1. Que las páginas cargan correctamente
2. Interacciones de formularios
3. Navegación entre rutas
Usa BASE_URL desde variable de entorno.`,

    banking: `${base}

TIPO: Sistema Bancario Interno
CONTEXTO: ${JSON.stringify(context, null, 2)}
CÓDIGO:
${rawContent?.substring(0, 3000) || 'No disponible'}

Genera tests Jest (runner: "jest"). Prueba exhaustivamente:
1. Validaciones de montos (negativos, cero, decimales, límites)
2. Validaciones de cuentas y formatos
3. Casos borde críticos del dominio bancario
4. Manejo de errores y excepciones`,

    script: `${base}

TIPO: Script / Automatización
CONTEXTO: ${JSON.stringify(context, null, 2)}
CÓDIGO:
\`\`\`
${rawContent?.substring(0, 3000) || 'No disponible'}
\`\`\`

${context.language === 'python'
  ? 'Genera tests pytest (runner: "pytest").'
  : 'Genera tests Jest (runner: "jest").'}
Prueba cada función con:
1. Inputs válidos esperados
2. Inputs inválidos
3. Casos borde (null, undefined, vacío, tipos incorrectos)`,
  };

  return prompts[appType] || prompts.script;
}

async function generate(appType, context, rawContent) {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY no configurada en .env');
  }

  const prompt = buildPrompt(appType, context, rawContent);

  logger.info('Llamando a Gemini...', { appType });

  const response = await axios.post(GEMINI_URL(), {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 8192, topP: 0.8 },
  }, {
    timeout: 60000,
    headers: { 'Content-Type': 'application/json' },
  });

  const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini no retornó contenido');

  // Limpiar posibles bloques markdown
  let clean = text.trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '');

  let parsed;
  try {
    parsed = JSON.parse(clean);
  } catch {
    const match = clean.match(/\{[\s\S]*\}/);
    if (match) parsed = JSON.parse(match[0]);
    else throw new Error('No se pudo parsear la respuesta de Gemini como JSON');
  }

  if (!parsed.scripts?.length) throw new Error('Gemini no generó scripts');

  // Guardar scripts en disco
  const SCRIPTS_DIR = process.env.SCRIPTS_DIR || path.join(process.cwd(), 'data', 'scripts');
  const jobDir = path.join(SCRIPTS_DIR, context.jobId || 'unknown');
  fs.mkdirSync(jobDir, { recursive: true });

  const scripts = parsed.scripts.map(s => {
    const filePath = path.join(jobDir, s.filename);
    fs.writeFileSync(filePath, s.code, 'utf-8');
    return { ...s, filePath };
  });

  logger.info(`${scripts.length} script(s) generados`, { appType });

  return {
    scripts,
    summary: parsed.summary,
    coverageNotes: parsed.coverageNotes,
  };
}

module.exports = { generate };
