/**
 * TESTFORGE MVP — Executor
 * Corre scripts aprobados y guarda resultados.
 */
const { execFile } = require('child_process');
const path   = require('path');
const fs     = require('fs');
const logger = require('../shared/logger').forModule('Executor');

const RESULTS_DIR = () => process.env.RESULTS_DIR || path.join(process.cwd(), 'data', 'results');

function runProcess(cmd, args, jobId, timeout = 60000) {
  return new Promise((resolve) => {
    const logsDir = path.join(RESULTS_DIR(), jobId);
    fs.mkdirSync(logsDir, { recursive: true });

    const logFile   = path.join(logsDir, 'execution.log');
    const logStream = fs.createWriteStream(logFile, { flags: 'a' });
    const startTime = Date.now();

    logStream.write(`=== TESTFORGE Execution ===\n`);
    logStream.write(`Command: ${cmd} ${args.join(' ')}\n`);
    logStream.write(`Started: ${new Date().toISOString()}\n\n`);

    execFile(cmd, args, {
      timeout,
      maxBuffer: 10 * 1024 * 1024,
      cwd: process.cwd(),
      env: { ...process.env, FORCE_COLOR: '0' },
    }, (error, stdout, stderr) => {
      const duration = Date.now() - startTime;
      logStream.write(`\n--- STDOUT ---\n${stdout}`);
      if (stderr) logStream.write(`\n--- STDERR ---\n${stderr}`);
      logStream.write(`\n--- Finished in ${duration}ms | exit: ${error?.code ?? 0} ---\n`);
      logStream.end();

      resolve({
        passed:   !error || error.code === 0,
        exitCode: error?.code ?? 0,
        stdout:   stdout.substring(0, 5000),
        stderr:   stderr.substring(0, 2000),
        duration,
        logFile,
      });
    });
  });
}

async function execute(jobId, approvedScript) {
  const { code, runner, filename } = approvedScript;

  // Guardar el script aprobado
  const execDir    = path.join(RESULTS_DIR(), jobId, 'exec');
  fs.mkdirSync(execDir, { recursive: true });
  const scriptPath = path.join(execDir, filename || 'test.js');
  fs.writeFileSync(scriptPath, code, 'utf-8');

  logger.info('Ejecutando script', { jobId, runner, scriptPath });

  let result;

  switch (runner) {
    case 'jest': {
      const jestBin    = path.join(process.cwd(), 'node_modules', '.bin', 'jest');
      const outputFile = path.join(RESULTS_DIR(), jobId, 'jest-results.json');
      result = await runProcess(jestBin, [
        scriptPath, '--json', `--outputFile=${outputFile}`,
        '--no-coverage', '--forceExit', '--testTimeout=30000',
      ], jobId, 120000);

      // Leer resumen Jest
      if (fs.existsSync(outputFile)) {
        try {
          const jd = JSON.parse(fs.readFileSync(outputFile, 'utf-8'));
          result.testSummary = {
            total:   jd.numTotalTests,
            passed:  jd.numPassedTests,
            failed:  jd.numFailedTests,
            skipped: jd.numPendingTests,
          };
        } catch {}
      }
      break;
    }

    case 'pytest':
      result = await runProcess('python3', [
        '-m', 'pytest', scriptPath, '-v', '--tb=short',
      ], jobId, 120000);
      break;

    case 'playwright': {
      const pw = path.join(process.cwd(), 'node_modules', '.bin', 'playwright');
      result = await runProcess(pw, [
        'test', scriptPath, '--reporter=line',
      ], jobId, 180000);
      break;
    }

    case 'node':
    default:
      result = await runProcess('node', [scriptPath], jobId, 60000);
      break;
  }

  logger.info(`Ejecución ${result.passed ? 'exitosa' : 'fallida'}`, {
    jobId, duration: result.duration, exitCode: result.exitCode,
  });

  return {
    passed:      result.passed,
    exitCode:    result.exitCode,
    duration:    result.duration,
    stdout:      result.stdout,
    stderr:      result.stderr,
    logFile:     result.logFile,
    runner,
    executedAt:  new Date().toISOString(),
    scriptPath,
    testSummary: result.testSummary || null,
  };
}

module.exports = { execute };
