/**
 * TESTFORGE MVP — Notifier
 * Envía emails via SMTP.
 */
const nodemailer = require('nodemailer');
const logger     = require('../shared/logger').forModule('Notifier');

const UI_URL = () => process.env.UI_URL || 'http://localhost:3000';

function createTransporter() {
  if (!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host:   process.env.SMTP_HOST,
    port:   parseInt(process.env.SMTP_PORT || '587'),
    secure: parseInt(process.env.SMTP_PORT || '587') === 465,
    auth:   process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    tls:    { rejectUnauthorized: false },
  });
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function fmt(ms) {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms/1000).toFixed(1)}s`;
  return `${Math.floor(ms/60000)}m ${Math.floor((ms%60000)/1000)}s`;
}

function base(content, accent = '#3b82f6') {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body{margin:0;padding:0;background:#0a0c10;font-family:Arial,sans-serif}
  .w{max-width:580px;margin:0 auto;padding:24px 12px}
  .card{background:#0f1117;border:1px solid #1e2330;border-radius:10px;overflow:hidden}
  .hdr{padding:16px 24px;border-bottom:1px solid #1e2330;display:flex;align-items:center;gap:10px}
  .logo{background:linear-gradient(135deg,${accent},#1d4ed8);width:32px;height:32px;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;font-size:16px}
  .lt{font-family:monospace;font-weight:700;font-size:14px;color:#e8ecf0;letter-spacing:1px}
  .ls{font-size:10px;color:#6b7280}
  .body{padding:24px}
  .badge{display:inline-block;padding:3px 10px;border-radius:99px;font-size:11px;font-family:monospace;border:1px solid;margin-bottom:14px}
  h2{color:#e8ecf0;font-size:18px;margin:0 0 6px}
  p{color:#9ca3af;font-size:13px;line-height:1.6;margin:0 0 12px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:16px 0}
  .meta{background:#141720;border:1px solid #1e2330;border-radius:7px;padding:10px 12px}
  .ml{font-size:9px;font-family:monospace;color:#6b7280;letter-spacing:.5px;margin-bottom:3px}
  .mv{font-size:12px;color:#e8ecf0;font-family:monospace;word-break:break-all}
  .pre{background:#050709;border:1px solid #1e2330;border-radius:7px;padding:12px;font-family:monospace;font-size:11px;color:#e8ecf0;line-height:1.6;margin:12px 0;white-space:pre-wrap;word-break:break-all;max-height:180px;overflow:hidden}
  .cta{display:inline-block;padding:10px 22px;border-radius:7px;background:${accent};color:#fff;text-decoration:none;font-size:13px;font-weight:600;margin-top:6px}
  .ftr{padding:12px 24px;border-top:1px solid #1e2330;font-size:10px;color:#4b5563;text-align:center}
</style></head><body><div class="w"><div class="card">
<div class="hdr"><div class="logo">⚡</div><div><div class="lt">TESTFORGE</div><div class="ls">Davivienda El Salvador · IA &amp; Automatizaciones</div></div></div>
<div class="body">${content}</div>
<div class="ftr">Mensaje automático de TESTFORGE v1 MVP</div>
</div></div></body></html>`;
}

function templateReady(job) {
  const scripts = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];
  const s       = scripts[0];
  const meta    = job.source_meta || {};
  const types   = { api:'API REST', web:'Web/UI', banking:'Sistema Bancario', script:'Script' };
  const srcs    = { gitlab:'🦊 GitLab', folder:'📁 Carpeta', manual:'⬆️ Manual' };

  return base(`
    <div class="badge" style="color:#3b82f6;border-color:rgba(59,130,246,.3);background:rgba(59,130,246,.1)">⏳ SCRIPT LISTO PARA APROBACIÓN</div>
    <h2>Gemini generó un script de prueba</h2>
    <p>Un nuevo script está esperando tu revisión antes de ejecutarse.</p>
    <div class="grid">
      <div class="meta"><div class="ml">JOB ID</div><div class="mv">${job.id.slice(0,8).toUpperCase()}</div></div>
      <div class="meta"><div class="ml">TIPO</div><div class="mv">${types[job.app_type]||job.app_type||'—'}</div></div>
      <div class="meta"><div class="ml">FUENTE</div><div class="mv">${srcs[job.source_type]||job.source_type}</div></div>
      <div class="meta"><div class="ml">RUNNER</div><div class="mv">${s?.runner||'—'}</div></div>
      ${meta.originalName||meta.filePath ? `<div class="meta" style="grid-column:1/-1"><div class="ml">ARCHIVO</div><div class="mv">${esc(meta.originalName||meta.filePath)}</div></div>` : ''}
    </div>
    ${s ? `<div style="font-size:11px;color:#6b7280;font-family:monospace;margin-bottom:6px">PREVIEW (${esc(s.filename)})</div>
    <div class="pre">${esc((s.code||'').slice(0,500))}${(s.code||'').length>500?'\n...(ver completo en la UI)':''}</div>` : ''}
    <a href="${UI_URL()}/jobs/${job.id}" class="cta">👀 Revisar y Aprobar →</a>
  `);
}

function templatePassed(job) {
  const r = job.execution_results || {};
  const s = r.testSummary;
  return base(`
    <div class="badge" style="color:#22c55e;border-color:rgba(34,197,94,.3);background:rgba(34,197,94,.1)">✅ TEST EXITOSO</div>
    <h2>Los tests pasaron correctamente</h2>
    <p>El script aprobado se ejecutó sin errores.</p>
    <div class="grid">
      <div class="meta"><div class="ml">JOB ID</div><div class="mv">${job.id.slice(0,8).toUpperCase()}</div></div>
      <div class="meta"><div class="ml">DURACIÓN</div><div class="mv">${fmt(r.duration||0)}</div></div>
      <div class="meta"><div class="ml">RUNNER</div><div class="mv">${r.runner||'—'}</div></div>
      <div class="meta"><div class="ml">EXIT CODE</div><div class="mv" style="color:#22c55e">0 (OK)</div></div>
      ${s ? `<div class="meta"><div class="ml">PASADOS</div><div class="mv" style="color:#22c55e">${s.passed}/${s.total}</div></div>
      <div class="meta"><div class="ml">FALLIDOS</div><div class="mv" style="color:${s.failed>0?'#ef4444':'#6b7280'}">${s.failed}</div></div>` : ''}
    </div>
    ${r.stdout ? `<div class="pre">${esc(r.stdout.slice(0,400))}</div>` : ''}
    <a href="${UI_URL()}/jobs/${job.id}" class="cta" style="background:#16a34a">📊 Ver Resultados →</a>
  `, '#22c55e');
}

function templateFailed(job) {
  const r = job.execution_results || {};
  const s = r.testSummary;
  return base(`
    <div class="badge" style="color:#ef4444;border-color:rgba(239,68,68,.3);background:rgba(239,68,68,.1)">❌ TEST FALLIDO</div>
    <h2>El test encontró errores</h2>
    <p>El script se ejecutó pero algunos tests fallaron.</p>
    <div class="grid">
      <div class="meta"><div class="ml">JOB ID</div><div class="mv">${job.id.slice(0,8).toUpperCase()}</div></div>
      <div class="meta"><div class="ml">DURACIÓN</div><div class="mv">${fmt(r.duration||0)}</div></div>
      <div class="meta"><div class="ml">EXIT CODE</div><div class="mv" style="color:#ef4444">${r.exitCode??'—'}</div></div>
      <div class="meta"><div class="ml">RUNNER</div><div class="mv">${r.runner||'—'}</div></div>
      ${s ? `<div class="meta"><div class="ml">PASADOS</div><div class="mv" style="color:#22c55e">${s.passed}</div></div>
      <div class="meta"><div class="ml">FALLIDOS</div><div class="mv" style="color:#ef4444">${s.failed}</div></div>` : ''}
    </div>
    ${(r.stderr||r.stdout) ? `<div class="pre" style="border-color:rgba(239,68,68,.2)">${esc((r.stderr||r.stdout||'').slice(0,500))}</div>` : ''}
    <a href="${UI_URL()}/jobs/${job.id}" class="cta" style="background:#dc2626">🔍 Ver Detalles →</a>
  `, '#ef4444');
}

async function notify(job, type) {
  const to = process.env.NOTIFY_EMAIL;
  if (!to || !process.env.SMTP_HOST) {
    logger.info('Email desactivado (SMTP no configurado)', { type, jobId: job.id });
    return { skipped: true };
  }

  const transporter = createTransporter();

  const templates = {
    job_ready:  { subject: `[TESTFORGE] ⏳ Script listo para aprobar — ${job.id.slice(0,8).toUpperCase()}`, html: templateReady(job) },
    job_passed: { subject: `[TESTFORGE] ✅ Test exitoso — ${job.id.slice(0,8).toUpperCase()}`,             html: templatePassed(job) },
    job_failed: { subject: `[TESTFORGE] ❌ Test fallido — ${job.id.slice(0,8).toUpperCase()}`,             html: templateFailed(job) },
  };

  const { subject, html } = templates[type] || {};
  if (!subject) return;

  try {
    const info = await transporter.sendMail({
      from: `"TESTFORGE" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
      to, subject, html,
    });
    logger.info('Email enviado', { to, subject, messageId: info.messageId });
    return { ok: true };
  } catch (err) {
    logger.error('Error enviando email', { error: err.message });
    return { error: err.message };
  }
}

module.exports = { notify };
