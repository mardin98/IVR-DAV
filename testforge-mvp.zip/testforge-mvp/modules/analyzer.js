/**
 * TESTFORGE MVP — Analyzer
 * Detecta tipo de app y extrae contexto del código.
 */
const path = require('path');

const PATTERNS = {
  api: [
    /app\.(get|post|put|delete|patch)\s*\(/i,
    /router\.(get|post|put|delete|patch)\s*\(/i,
    /"openapi"\s*:/i,
    /"swagger"\s*:/i,
    /fastify\.(get|post|put|delete)\s*\(/i,
    /collection.*postman/i,
  ],
  web: [
    /import\s+React/i,
    /from\s+['"]react['"]/i,
    /export\s+default\s+function\s+\w+\s*\(/,
    /getServerSideProps|getStaticProps/,
    /<html|<!DOCTYPE html/i,
  ],
  banking: [
    /MIG|CORE\s*BANKING|CBS/i,
    /cuenta|saldo|transacci[oó]n|transferencia/i,
    /monto|debito|credito|extracto/i,
    /AS400|IBM\s*i|RPG/i,
  ],
  script: [
    /def\s+\w+\s*\(/,
    /function\s+\w+\s*\(/,
    /const\s+\w+\s*=\s*(?:async\s*)?\(/,
    /require\s*\(\s*['"][^'"]+['"]\s*\)/,
    /ScriptApp|SpreadsheetApp/,
  ],
};

function detectAppType(content, filePath = '') {
  const ext = path.extname(filePath).toLowerCase();
  if (['.yaml','.yml','.json'].includes(ext) && /"openapi"|"swagger"/.test(content)) return 'api';
  if (['.html','.htm'].includes(ext)) return 'web';
  if (ext === '.py') return 'script';

  const scores = { api: 0, web: 0, banking: 0, script: 0 };
  for (const [type, patterns] of Object.entries(PATTERNS)) {
    for (const pat of patterns) if (pat.test(content)) scores[type]++;
  }
  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  return best[1] > 0 ? best[0] : 'script';
}

function analyze(content, filePath, hintAppType) {
  const appType = hintAppType || detectAppType(content, filePath);

  const context = { type: appType, filePath };

  // Endpoints API
  if (appType === 'api') {
    context.endpoints = [];
    const rr = /(?:app|router)\.(get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]/gi;
    let m;
    while ((m = rr.exec(content)) !== null) {
      context.endpoints.push({ method: m[1].toUpperCase(), path: m[2] });
    }
    try {
      const parsed = JSON.parse(content);
      if (parsed.openapi || parsed.swagger) {
        context.spec = 'openapi';
        context.title = parsed.info?.title;
        context.endpoints = [];
        for (const [p, methods] of Object.entries(parsed.paths || {})) {
          for (const [method, op] of Object.entries(methods)) {
            if (['get','post','put','delete','patch'].includes(method)) {
              context.endpoints.push({ method: method.toUpperCase(), path: p, summary: op.summary });
            }
          }
        }
      }
    } catch {}
  }

  // Funciones (script / banking)
  if (['script','banking'].includes(appType)) {
    context.functions = [];
    const fr = /(?:function\s+(\w+)|const\s+(\w+)\s*=\s*(?:async\s*)?\(|def\s+(\w+)\s*\()/g;
    let m;
    while ((m = fr.exec(content)) !== null) {
      const name = m[1] || m[2] || m[3];
      if (name) context.functions.push(name);
    }
    const ext = path.extname(filePath).toLowerCase();
    context.language = ext === '.py' ? 'python' : 'javascript';
  }

  // Componentes web
  if (appType === 'web') {
    context.components = [];
    const cr = /(?:function|const)\s+([A-Z]\w+)\s*(?:=\s*(?:async\s*)?\(|\()/g;
    let m;
    while ((m = cr.exec(content)) !== null) context.components.push(m[1]);
  }

  return { appType, context };
}

module.exports = { analyze, detectAppType };
