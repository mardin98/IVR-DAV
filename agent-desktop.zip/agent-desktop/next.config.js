/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',  // Para deploy on-prem con Node directo
  experimental: {
    serverActions: {
      allowedOrigins: ['localhost:3000', 'callmanager.davivienda.local']
    }
  }
};

module.exports = nextConfig;
