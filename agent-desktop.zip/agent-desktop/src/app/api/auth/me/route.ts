// app/api/auth/me/route.ts — Obtener datos del agente logueado (incluye sipPassword)
import { NextResponse } from 'next/server';
import { getCurrentAgent } from '@/lib/auth';

export async function GET() {
  const agent = await getCurrentAgent();
  if (!agent) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  }

  // Solo enviar al browser lo que necesita para JsSIP
  return NextResponse.json({
    id:          agent.id,
    username:    agent.username,
    fullName:    agent.fullName,
    email:       agent.email,
    extension:   agent.extension,
    sipPassword: agent.sipPassword,  // Necesario para que el browser registre JsSIP
    role:        agent.role,
  });
}
