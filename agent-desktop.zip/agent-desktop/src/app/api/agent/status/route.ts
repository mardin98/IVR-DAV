// app/api/agent/status/route.ts — Cambiar estado disponible/ocupado/pausa
import { NextRequest, NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, AGENTS_COL } from '@/lib/firestore';
import type { AgentStatus } from '@/types';

const VALID_STATUSES: AgentStatus[] = ['available', 'busy', 'oncall', 'paused', 'offline'];

export async function POST(req: NextRequest) {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const { status } = await req.json();
  if (!VALID_STATUSES.includes(status)) {
    return NextResponse.json({ error: 'Estado inválido' }, { status: 400 });
  }

  const db = getDb();
  await db.collection(AGENTS_COL).doc(session.agentId).update({
    status,
    statusUpdatedAt: new Date().toISOString(),
  });

  return NextResponse.json({ ok: true, status });
}
