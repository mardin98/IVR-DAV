// app/api/calls/queue/route.ts — Lista de llamadas escaladas esperando agente
import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, SESSIONS_COL } from '@/lib/firestore';
import type { CallSession } from '@/types';

export async function GET() {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const db   = getDb();
  const snap = await db.collection(SESSIONS_COL)
    .where('status', '==', 'escalated')
    .orderBy('startedAt', 'asc')
    .limit(50)
    .get();

  const calls = snap.docs.map(doc => ({
    callId: doc.id,
    ...doc.data(),
  })) as CallSession[];

  return NextResponse.json({ calls });
}
