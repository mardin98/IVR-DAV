// app/api/calls/[callId]/accept/route.ts — Aceptar llamada escalada
import { NextRequest, NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, SESSIONS_COL } from '@/lib/firestore';

export async function POST(
  _req: NextRequest,
  { params }: { params: { callId: string } }
) {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const { callId } = params;
  const db = getDb();

  // Verificar que la llamada esté escalada
  const docRef = db.collection(SESSIONS_COL).doc(callId);
  const doc    = await docRef.get();
  if (!doc.exists) {
    return NextResponse.json({ error: 'Llamada no encontrada' }, { status: 404 });
  }

  const callData = doc.data() as any;
  if (callData.status !== 'escalated') {
    return NextResponse.json(
      { error: `Llamada ya está en estado: ${callData.status}` },
      { status: 409 }
    );
  }

  // Reservar la llamada para este agente (atomicidad básica)
  await docRef.update({
    status:         'with_agent',
    agentId:        session.agentId,
    agentExtension: session.extension,
    acceptedAt:     new Date().toISOString(),
  });

  // Llamar al Orchestrator para que haga el bridge ARI
  // El Orchestrator tiene la lógica de tomar el canal del cliente
  // (que está en AudioSocket con Sofía) y bridgearlo con el agente
  try {
    const orchestratorRes = await fetch(
      `${process.env.ORCHESTRATOR_URL}/session/${callId}/accept`,
      {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          agentExtension: session.extension,
          agentId:        session.agentId,
        }),
      }
    );

    if (!orchestratorRes.ok) {
      // Rollback en Firestore
      await docRef.update({ status: 'escalated', agentId: null, agentExtension: null });
      const errText = await orchestratorRes.text();
      return NextResponse.json(
        { error: `Orchestrator: ${errText}` },
        { status: 500 }
      );
    }
  } catch (e: any) {
    await docRef.update({ status: 'escalated', agentId: null, agentExtension: null });
    return NextResponse.json({ error: e.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, callId });
}
