// app/api/calls/[callId]/route.ts — Detalle de una llamada
import { NextRequest, NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, SESSIONS_COL } from '@/lib/firestore';

export async function GET(
  _req: NextRequest,
  { params }: { params: { callId: string } }
) {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const db  = getDb();
  const doc = await db.collection(SESSIONS_COL).doc(params.callId).get();
  if (!doc.exists) return NextResponse.json({ error: 'No encontrada' }, { status: 404 });

  return NextResponse.json({ callId: doc.id, ...doc.data() });
}
