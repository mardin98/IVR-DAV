// app/dashboard/page.tsx — Server component que verifica sesión
import { redirect } from 'next/navigation';
import { getCurrentSession } from '@/lib/auth';
import { DashboardClient } from '@/components/DashboardClient';

export default async function DashboardPage() {
  const session = await getCurrentSession();
  if (!session) redirect('/login');

  return <DashboardClient session={session} />;
}
