import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title:       'Call Manager — Davivienda',
  description: 'Panel de agentes de Call Center con IA',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
