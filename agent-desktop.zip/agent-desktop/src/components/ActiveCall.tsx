// components/ActiveCall.tsx — Vista detallada de llamada activa
'use client';

import { useState } from 'react';
import { useAgentStore } from '@/store/agentStore';
import {
  PhoneOff, Mic, MicOff, User, Clock, Brain,
  ArrowUpRight, Sparkles, Bot
} from 'lucide-react';
import clsx from 'clsx';
import type { CallSession } from '@/types';

interface Props {
  call: CallSession;
}

export function ActiveCall({ call }: Props) {
  const setActiveCall = useAgentStore((s) => s.setActiveCall);
  const setStatus     = useAgentStore((s) => s.setStatus);
  const incoming      = useAgentStore((s) => s.incomingCall);
  const [muted, setMuted] = useState(false);

  function handleHangup() {
    if (incoming?.session) incoming.session.terminate();
    setActiveCall(null);
    setStatus('available');
  }

  function handleMute() {
    if (!incoming?.session) return;
    const tracks = incoming.session.connection
      .getSenders()
      .map((s: any) => s.track)
      .filter((t: any) => t?.kind === 'audio');
    tracks.forEach((t: any) => { t.enabled = !t.enabled; });
    setMuted(!muted);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Panel izquierdo: cliente + controles */}
      <div className="lg:col-span-1 space-y-4">
        {/* Card del cliente */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-davivienda-red/10 flex items-center justify-center">
              <User className="w-6 h-6 text-davivienda-red" />
            </div>
            <div>
              <p className="text-xs text-davivienda-gray-500 uppercase tracking-wide font-medium">
                Cliente
              </p>
              <p className="font-semibold text-davivienda-gray-900">
                {call.callerNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-davivienda-gray-600">
            <Clock className="w-4 h-4" />
            <CallTimer startedAt={call.startedAt} />
          </div>
        </div>

        {/* Controles de llamada */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-4">
          <p className="text-xs font-medium text-davivienda-gray-500 uppercase tracking-wide mb-3">
            Controles
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={handleMute}
              className={clsx(
                'w-12 h-12 rounded-full flex items-center justify-center transition',
                muted
                  ? 'bg-amber-500 hover:bg-amber-600 text-white'
                  : 'bg-davivienda-gray-100 hover:bg-davivienda-gray-200 text-davivienda-gray-700'
              )}
              title={muted ? 'Quitar mute' : 'Mute'}
            >
              {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <button
              onClick={handleHangup}
              className="w-12 h-12 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition"
              title="Colgar"
            >
              <PhoneOff className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Panel derecho: Brief de IA + transcripción */}
      <div className="lg:col-span-2 space-y-4">
        {/* Brief de IA */}
        {call.summary && (
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-200 p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold text-blue-900">
                  Resumen de Sofía
                </p>
                <p className="text-xs text-blue-700">
                  Contexto generado por IA antes de transferir
                </p>
              </div>
            </div>
            <p className="text-sm text-davivienda-gray-800 leading-relaxed">
              {call.summary}
            </p>
            {call.escalationReason && (
              <div className="mt-3 pt-3 border-t border-blue-200">
                <p className="text-xs font-medium text-blue-800 mb-1">
                  Motivo del escalamiento
                </p>
                <p className="text-sm text-davivienda-gray-700">
                  {call.escalationReason}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Transcripción de la conversación */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-5">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-davivienda-gray-500" />
            <h3 className="font-semibold text-davivienda-gray-900">
              Conversación previa con Sofía
            </h3>
          </div>

          {call.messages && call.messages.length > 0 ? (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {call.messages.map((msg, i) => (
                <div
                  key={i}
                  className={clsx(
                    'flex gap-2',
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  )}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Bot className="w-3.5 h-3.5 text-blue-600" />
                    </div>
                  )}
                  <div className={clsx(
                    'max-w-[80%] rounded-2xl px-3 py-2 text-sm',
                    msg.role === 'user'
                      ? 'bg-davivienda-red text-white'
                      : 'bg-davivienda-gray-100 text-davivienda-gray-900'
                  )}>
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-davivienda-gray-500 text-center py-6">
              No hay transcripción disponible
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function CallTimer({ startedAt }: { startedAt: string }) {
  // Calcular tiempo transcurrido cada segundo
  const [elapsed, setElapsed] = useState(() =>
    Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000)
  );

  // Actualizar cada segundo
  if (typeof window !== 'undefined') {
    setTimeout(() => setElapsed(Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000)), 1000);
  }

  const m = Math.floor(elapsed / 60);
  const s = elapsed % 60;

  return (
    <span className="font-mono tabular-nums">
      {String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}
    </span>
  );
}
