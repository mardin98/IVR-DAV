// components/IncomingCallModal.tsx — Modal cuando llega llamada SIP por JsSIP
'use client';

import { Phone, PhoneOff } from 'lucide-react';
import { useAgentStore } from '@/store/agentStore';

export function IncomingCallModal() {
  const incoming = useAgentStore((s) => s.incomingCall);
  const setStatus = useAgentStore((s) => s.setStatus);

  if (!incoming) return null;

  function answer() {
    if (!incoming) return;
    incoming.session.answer({
      mediaConstraints: { audio: true, video: false },
    });
    setStatus('oncall');
  }

  function reject() {
    if (!incoming) return;
    incoming.session.terminate();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full mx-4 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500 mb-4 animate-ringing">
          <Phone className="w-10 h-10 text-white" />
        </div>

        <p className="text-sm text-davivienda-gray-500 mb-1">Llamada entrante</p>
        <p className="text-2xl font-bold text-davivienda-gray-900 mb-6">
          {incoming.fromNumber}
        </p>

        <div className="flex items-center justify-center gap-4">
          <button
            onClick={reject}
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition"
            title="Rechazar"
          >
            <PhoneOff className="w-7 h-7" />
          </button>

          <button
            onClick={answer}
            className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 text-white flex items-center justify-center transition"
            title="Atender"
          >
            <Phone className="w-7 h-7" />
          </button>
        </div>
      </div>
    </div>
  );
}
