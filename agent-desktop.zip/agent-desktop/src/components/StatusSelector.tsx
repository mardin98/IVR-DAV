// components/StatusSelector.tsx — Cambiar estado del agente
'use client';

import { useState } from 'react';
import { useAgentStore } from '@/store/agentStore';
import { ChevronDown, Circle } from 'lucide-react';
import clsx from 'clsx';
import type { AgentStatus } from '@/types';

const STATUS_OPTIONS: Array<{ value: AgentStatus; label: string; color: string }> = [
  { value: 'available', label: 'Disponible', color: 'bg-status-available' },
  { value: 'busy',      label: 'Ocupado',    color: 'bg-status-busy' },
  { value: 'paused',    label: 'En pausa',   color: 'bg-status-paused' },
];

export function StatusSelector() {
  const status     = useAgentStore((s) => s.status);
  const setStatus  = useAgentStore((s) => s.setStatus);
  const [open, setOpen] = useState(false);

  const current = STATUS_OPTIONS.find(s => s.value === status) || STATUS_OPTIONS[0];

  async function changeStatus(newStatus: AgentStatus) {
    setOpen(false);
    setStatus(newStatus);
    try {
      await fetch('/api/agent/status', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ status: newStatus }),
      });
    } catch (e) {
      console.error('Error cambiando estado:', e);
    }
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        disabled={status === 'oncall'}
        className={clsx(
          'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium border transition',
          'bg-white border-davivienda-gray-200 hover:border-davivienda-gray-300',
          status === 'oncall' && 'opacity-60 cursor-not-allowed'
        )}
      >
        <div className={clsx('w-2 h-2 rounded-full', current.color)} />
        <span>{status === 'oncall' ? 'En llamada' : current.label}</span>
        <ChevronDown className="w-3 h-3 text-davivienda-gray-400" />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-44 bg-white rounded-lg shadow-lg border border-davivienda-gray-200 z-40 py-1">
            {STATUS_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => changeStatus(opt.value)}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-davivienda-gray-50"
              >
                <div className={clsx('w-2 h-2 rounded-full', opt.color)} />
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
