// components/CallQueue.tsx — Lista de llamadas en cola esperando agente
'use client';

import { useState } from 'react';
import { useAgentStore } from '@/store/agentStore';
import { PhoneIncoming, Clock, MessageSquare, Users, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import clsx from 'clsx';
import type { CallSession } from '@/types';

export function CallQueue() {
  const queuedCalls = useAgentStore((s) => s.queuedCalls);
  const agentStatus = useAgentStore((s) => s.status);
  const setActiveCall = useAgentStore((s) => s.setActiveCall);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);

  const canAccept = agentStatus === 'available';

  async function handleAccept(call: CallSession) {
    setAcceptingId(call.callId);
    try {
      const res = await fetch(`/api/calls/${call.callId}/accept`, {
        method: 'POST',
      });
      if (!res.ok) {
        const err = await res.json();
        alert(`Error: ${err.error}`);
        return;
      }
      setActiveCall(call);
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    } finally {
      setAcceptingId(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-davivienda-gray-900">
            Cola de llamadas
          </h1>
          <p className="text-sm text-davivienda-gray-500 mt-0.5">
            {queuedCalls.length === 0
              ? 'No hay llamadas en espera'
              : `${queuedCalls.length} llamada${queuedCalls.length === 1 ? '' : 's'} esperando agente`}
          </p>
        </div>

        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-davivienda-gray-100 text-davivienda-gray-700 text-sm">
          <Users className="w-4 h-4" />
          <span>{queuedCalls.length} en cola</span>
        </div>
      </div>

      {queuedCalls.length === 0 ? (
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-davivienda-gray-100 mb-4">
            <PhoneIncoming className="w-8 h-8 text-davivienda-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-davivienda-gray-900">
            Todo tranquilo
          </h3>
          <p className="text-sm text-davivienda-gray-500 mt-1">
            Cuando haya llamadas que necesiten un agente, aparecerán aquí
          </p>
        </div>
      ) : (
        <div className="grid gap-3">
          {queuedCalls.map((call) => (
            <CallCard
              key={call.callId}
              call={call}
              onAccept={() => handleAccept(call)}
              accepting={acceptingId === call.callId}
              canAccept={canAccept}
            />
          ))}
        </div>
      )}

      {!canAccept && queuedCalls.length > 0 && (
        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800">
          Cambiá tu estado a "Disponible" para poder aceptar llamadas
        </div>
      )}
    </div>
  );
}

function CallCard({
  call,
  onAccept,
  accepting,
  canAccept,
}: {
  call:      CallSession;
  onAccept:  () => void;
  accepting: boolean;
  canAccept: boolean;
}) {
  const waitingMinutes = Math.floor(
    (Date.now() - new Date(call.startedAt).getTime()) / 60000
  );
  const isUrgent = waitingMinutes >= 2;

  return (
    <div className={clsx(
      'bg-white rounded-xl border p-4 transition',
      isUrgent
        ? 'border-amber-300 ring-1 ring-amber-200'
        : 'border-davivienda-gray-200'
    )}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <div className={clsx(
              'w-10 h-10 rounded-full flex items-center justify-center',
              isUrgent ? 'bg-amber-100' : 'bg-blue-100'
            )}>
              <PhoneIncoming className={clsx(
                'w-5 h-5',
                isUrgent ? 'text-amber-600' : 'text-blue-600'
              )} />
            </div>
            <div>
              <p className="font-semibold text-davivienda-gray-900">
                {call.callerNumber}
              </p>
              <div className="flex items-center gap-1 text-xs text-davivienda-gray-500">
                <Clock className="w-3 h-3" />
                <span>
                  Esperando hace {formatDistanceToNow(new Date(call.startedAt), { locale: es })}
                </span>
              </div>
            </div>
          </div>

          {call.summary && (
            <div className="mt-3 p-3 bg-davivienda-gray-50 rounded-lg">
              <div className="flex items-start gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-davivienda-gray-400 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-davivienda-gray-700 leading-relaxed">
                  {call.summary}
                </p>
              </div>
            </div>
          )}

          {call.escalationReason && (
            <p className="mt-2 text-xs text-davivienda-gray-500">
              <span className="font-medium">Motivo:</span> {call.escalationReason}
            </p>
          )}
        </div>

        <button
          onClick={onAccept}
          disabled={!canAccept || accepting}
          className={clsx(
            'flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition',
            'bg-davivienda-red hover:bg-davivienda-dark text-white',
            'disabled:bg-davivienda-gray-300 disabled:cursor-not-allowed',
            'flex items-center gap-1.5'
          )}
        >
          {accepting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Conectando...
            </>
          ) : (
            'Atender'
          )}
        </button>
      </div>
    </div>
  );
}
