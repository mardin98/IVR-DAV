// store/agentStore.ts — Estado global del Agent Desktop
'use client';

import { create } from 'zustand';
import type { AgentSession, AgentStatus, CallSession, SipStatus } from '@/types';

interface AgentState {
  // Sesión del agente logueado
  session: AgentSession | null;
  setSession: (s: AgentSession | null) => void;

  // Estado del agente (available/busy/etc)
  status: AgentStatus;
  setStatus: (s: AgentStatus) => void;

  // Estado del softphone SIP
  sipStatus: SipStatus;
  setSipStatus: (s: SipStatus) => void;

  // Llamada activa actual
  activeCall: CallSession | null;
  setActiveCall: (c: CallSession | null) => void;

  // Cola de llamadas escaladas
  queuedCalls: CallSession[];
  setQueuedCalls: (calls: CallSession[]) => void;

  // Llamada SIP entrante (la que viene por JsSIP)
  incomingCall: {
    session: any;        // JsSIP.RTCSession
    fromNumber: string;
    callId?: string;
  } | null;
  setIncomingCall: (c: AgentState['incomingCall']) => void;

  // Reset al logout
  reset: () => void;
}

export const useAgentStore = create<AgentState>((set) => ({
  session: null,
  setSession: (s) => set({ session: s }),

  status: 'offline',
  setStatus: (s) => set({ status: s }),

  sipStatus: 'disconnected',
  setSipStatus: (s) => set({ sipStatus: s }),

  activeCall: null,
  setActiveCall: (c) => set({ activeCall: c }),

  queuedCalls: [],
  setQueuedCalls: (calls) => set({ queuedCalls: calls }),

  incomingCall: null,
  setIncomingCall: (c) => set({ incomingCall: c }),

  reset: () => set({
    session:      null,
    status:       'offline',
    sipStatus:    'disconnected',
    activeCall:   null,
    queuedCalls:  [],
    incomingCall: null,
  }),
}));
