// hooks/useSoftphone.ts — Softphone WebRTC con JsSIP
'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useAgentStore } from '@/store/agentStore';

// JsSIP solo carga en el browser
let JsSIP: any = null;
if (typeof window !== 'undefined') {
  JsSIP = require('jssip');
}

interface SoftphoneCredentials {
  extension:   string;
  password:    string;
  domain:      string;
  wssUrl:      string;
}

export function useSoftphone(creds: SoftphoneCredentials | null) {
  const uaRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const setSipStatus    = useAgentStore((s) => s.setSipStatus);
  const setIncomingCall = useAgentStore((s) => s.setIncomingCall);

  // ── Inicializar User Agent ─────────────────────────────────────────────────
  useEffect(() => {
    if (!creds || !JsSIP) return;

    // Elemento <audio> oculto para reproducir el audio remoto
    if (!audioRef.current) {
      const audio = document.createElement('audio');
      audio.id = 'sip-remote-audio';
      audio.autoplay = true;
      audio.style.display = 'none';
      document.body.appendChild(audio);
      audioRef.current = audio;
    }

    const socket = new JsSIP.WebSocketInterface(creds.wssUrl);
    const config = {
      sockets:        [socket],
      uri:            `sip:${creds.extension}@${creds.domain}`,
      password:       creds.password,
      register:       true,
      session_timers: false,
      user_agent:     'CallManagerAgent/1.0',
    };

    const ua = new JsSIP.UA(config);

    // ── Eventos de registro ───────────────────────────────────────────────
    ua.on('connecting',      () => setSipStatus('connecting'));
    ua.on('connected',       () => setSipStatus('connecting'));
    ua.on('registered',      () => setSipStatus('registered'));
    ua.on('unregistered',    () => setSipStatus('unregistered'));
    ua.on('registrationFailed', (e: any) => {
      console.error('[SIP] Registro fallido:', e.cause);
      setSipStatus('error');
    });
    ua.on('disconnected',    () => setSipStatus('disconnected'));

    // ── Llamada entrante ──────────────────────────────────────────────────
    ua.on('newRTCSession', (data: any) => {
      const session = data.session;

      if (session.direction !== 'incoming') {
        // Llamadas salientes — manejarlas aparte
        return;
      }

      const fromNumber = session.remote_identity.uri.user;
      const callId     = session.request.getHeader('X-Session-Id');

      console.log(`[SIP] Llamada entrante de ${fromNumber}, callId: ${callId}`);

      setIncomingCall({ session, fromNumber, callId });

      // Manejar audio remoto
      session.on('peerconnection', (e: any) => {
        const pc = e.peerconnection;

        pc.addEventListener('track', (ev: RTCTrackEvent) => {
          if (ev.streams && ev.streams[0] && audioRef.current) {
            audioRef.current.srcObject = ev.streams[0];
          }
        });
      });

      session.on('ended',     () => setIncomingCall(null));
      session.on('failed',    () => setIncomingCall(null));
      session.on('terminated', () => setIncomingCall(null));
    });

    ua.start();
    uaRef.current = ua;

    return () => {
      ua.stop();
      uaRef.current = null;
    };
  }, [creds, setSipStatus, setIncomingCall]);

  // ── Atender llamada entrante ──────────────────────────────────────────────
  const answerCall = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (!incoming) return;

    incoming.session.answer({
      mediaConstraints: { audio: true, video: false },
    });

    useAgentStore.getState().setStatus('oncall');
  }, []);

  // ── Colgar llamada ────────────────────────────────────────────────────────
  const hangupCall = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (incoming?.session) {
      incoming.session.terminate();
    }
    setIncomingCall(null);
    useAgentStore.getState().setStatus('available');
    useAgentStore.getState().setActiveCall(null);
  }, [setIncomingCall]);

  // ── Mute / Unmute ────────────────────────────────────────────────────────
  const toggleMute = useCallback(() => {
    const incoming = useAgentStore.getState().incomingCall;
    if (!incoming?.session) return;

    const audioTracks = incoming.session.connection
      .getSenders()
      .map((s: any) => s.track)
      .filter((t: any) => t && t.kind === 'audio');

    audioTracks.forEach((t: any) => { t.enabled = !t.enabled; });

    return audioTracks[0]?.enabled === false;
  }, []);

  return { answerCall, hangupCall, toggleMute };
}
