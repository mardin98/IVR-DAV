// hooks/useCallQueue.ts — Cola de llamadas escaladas (polling cada 3s)
'use client';

import { useEffect } from 'react';
import { useAgentStore } from '@/store/agentStore';
import type { CallSession } from '@/types';

export function useCallQueue() {
  const setQueuedCalls = useAgentStore((s) => s.setQueuedCalls);

  useEffect(() => {
    let cancelled = false;

    async function fetchQueue() {
      try {
        const res = await fetch('/api/calls/queue', { cache: 'no-store' });
        if (!res.ok) return;
        const data: { calls: CallSession[] } = await res.json();
        if (!cancelled) setQueuedCalls(data.calls);
      } catch (e) {
        console.error('[Queue] Error:', e);
      }
    }

    // Fetch inicial
    fetchQueue();

    // Polling cada 3 segundos
    const interval = setInterval(fetchQueue, 3000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [setQueuedCalls]);
}
