// lib/firestore.ts — Cliente Firestore (server-side)
import { Firestore } from '@google-cloud/firestore';

let _db: Firestore | null = null;

export function getDb(): Firestore {
  if (!_db) {
    _db = new Firestore({
      projectId: process.env.GCP_PROJECT_ID,
    });
  }
  return _db;
}

// Colecciones
export const AGENTS_COL   = 'agents';
export const SESSIONS_COL = 'call_sessions';
export const STATS_COL    = 'agent_stats';
