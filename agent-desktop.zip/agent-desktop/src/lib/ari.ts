// lib/ari.ts — Cliente Asterisk REST Interface (server-side)
// Usado para transferir llamadas, originar, etc.

const ARI_BASE = process.env.ASTERISK_ARI_URL  || 'http://localhost:8088/ari';
const ARI_USER = process.env.ASTERISK_ARI_USER || 'orchestrator';
const ARI_PASS = process.env.ASTERISK_ARI_PASSWORD || '';

function authHeader() {
  const cred = Buffer.from(`${ARI_USER}:${ARI_PASS}`).toString('base64');
  return { 'Authorization': `Basic ${cred}` };
}

export const Ari = {
  /** Listar canales activos */
  async listChannels() {
    const res = await fetch(`${ARI_BASE}/channels`, { headers: authHeader() });
    if (!res.ok) throw new Error(`ARI listChannels failed: ${res.status}`);
    return res.json();
  },

  /** Crear bridge para conectar dos canales */
  async createBridge(type = 'mixing'): Promise<{ id: string }> {
    const res = await fetch(`${ARI_BASE}/bridges`, {
      method:  'POST',
      headers: { ...authHeader(), 'Content-Type': 'application/json' },
      body:    JSON.stringify({ type }),
    });
    if (!res.ok) throw new Error(`ARI createBridge failed: ${res.status}`);
    return res.json();
  },

  /** Agregar canal a un bridge */
  async addToBridge(bridgeId: string, channelIds: string[]) {
    const params = new URLSearchParams({ channel: channelIds.join(',') });
    const res = await fetch(`${ARI_BASE}/bridges/${bridgeId}/addChannel?${params}`, {
      method:  'POST',
      headers: authHeader(),
    });
    if (!res.ok) throw new Error(`ARI addToBridge failed: ${res.status}`);
  },

  /** Originar llamada a una extensión */
  async originate(opts: {
    endpoint:  string;  // ej: 'PJSIP/8000'
    extension: string;
    context:   string;
    callerId?: string;
    variables?: Record<string, string>;
  }) {
    const params = new URLSearchParams({
      endpoint:  opts.endpoint,
      extension: opts.extension,
      context:   opts.context,
      priority:  '1',
      callerId:  opts.callerId || 'CallManager',
    });
    const body = opts.variables
      ? JSON.stringify({ variables: opts.variables })
      : undefined;

    const res = await fetch(`${ARI_BASE}/channels?${params}`, {
      method:  'POST',
      headers: { ...authHeader(), 'Content-Type': 'application/json' },
      body,
    });
    if (!res.ok) throw new Error(`ARI originate failed: ${res.status}`);
    return res.json();
  },

  /** Colgar un canal */
  async hangup(channelId: string) {
    const res = await fetch(`${ARI_BASE}/channels/${channelId}`, {
      method:  'DELETE',
      headers: authHeader(),
    });
    if (!res.ok && res.status !== 404) {
      throw new Error(`ARI hangup failed: ${res.status}`);
    }
  },
};
