// lib/auth.ts — Autenticación JWT local
import bcrypt from 'bcryptjs';
import jwt    from 'jsonwebtoken';
import { cookies } from 'next/headers';
import { getDb, AGENTS_COL } from './firestore';
import type { Agent, AgentSession } from '@/types';

const JWT_SECRET     = process.env.JWT_SECRET || 'cambiar-en-produccion';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';
const COOKIE_NAME    = 'cm_session';

/** Hashear password (al crear agente) */
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

/** Validar password (al login) */
export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/** Generar JWT */
export function generateToken(agent: Agent): string {
  return jwt.sign(
    {
      agentId:   agent.id,
      username:  agent.username,
      fullName:  agent.fullName,
      extension: agent.extension,
      role:      agent.role,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

/** Verificar JWT */
export function verifyToken(token: string): AgentSession | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AgentSession;
  } catch {
    return null;
  }
}

/** Login (Server Action o API Route) */
export async function loginAgent(
  username: string,
  password: string
): Promise<{ ok: true; token: string; agent: Omit<Agent, 'sipPassword'> } | { ok: false; error: string }> {
  const db   = getDb();
  const snap = await db.collection(AGENTS_COL)
    .where('username', '==', username)
    .limit(1)
    .get();

  if (snap.empty) {
    return { ok: false, error: 'Usuario o contraseña incorrectos' };
  }

  const doc   = snap.docs[0];
  const agent = { id: doc.id, ...doc.data() } as Agent & { passwordHash: string };

  const valid = await verifyPassword(password, agent.passwordHash);
  if (!valid) {
    return { ok: false, error: 'Usuario o contraseña incorrectos' };
  }

  // Actualizar lastLogin
  await doc.ref.update({ lastLoginAt: new Date().toISOString() });

  const token = generateToken(agent);
  const { passwordHash, sipPassword, ...safe } = agent as any;

  return { ok: true, token, agent: safe };
}

/** Leer sesión actual desde la cookie */
export async function getCurrentSession(): Promise<AgentSession | null> {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

/** Obtener datos completos del agente actual (incluye sipPassword) */
export async function getCurrentAgent(): Promise<Agent | null> {
  const session = await getCurrentSession();
  if (!session) return null;

  const db  = getDb();
  const doc = await db.collection(AGENTS_COL).doc(session.agentId).get();
  if (!doc.exists) return null;

  return { id: doc.id, ...doc.data() } as Agent;
}

export { COOKIE_NAME };
