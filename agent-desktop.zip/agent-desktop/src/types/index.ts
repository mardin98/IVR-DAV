// types.ts — Tipos compartidos del Agent Desktop

export type AgentStatus = 'available' | 'busy' | 'oncall' | 'paused' | 'offline';

export interface Agent {
  id:           string;
  username:     string;
  fullName:     string;
  email:        string;
  extension:    string;          // ej: "8000", "8001"
  sipPassword:  string;          // Para conectarse a Asterisk via JsSIP
  status:       AgentStatus;
  role:         'agent' | 'supervisor' | 'admin';
  createdAt:    string;
  lastLoginAt?: string;
}

export interface AgentSession {
  agentId:   string;
  username:  string;
  fullName:  string;
  extension: string;
  role:      Agent['role'];
  iat:       number;
  exp:       number;
}

export type CallStatus =
  | 'active_ai'     // Bot Sofía maneja la llamada
  | 'escalated'     // Llamada esperando agente
  | 'with_agent'    // Agente atendiendo
  | 'ended';        // Terminada

export interface CallMessage {
  role:    'user' | 'assistant';
  content: string;
  ts:      string;
}

export interface CallSession {
  callId:           string;
  callerNumber:     string;
  startedAt:        string;
  endedAt?:         string;
  status:           CallStatus;
  messages:         CallMessage[];
  escalationReason?: string;
  agentId?:         string;
  agentExtension?:  string;
  summary?:         string;       // Brief generado por Gemini
}

export interface CallEvent {
  type:      'incoming' | 'answered' | 'ended' | 'transferred';
  callId:    string;
  timestamp: string;
  data?:     any;
}

// JsSIP UA states
export type SipStatus =
  | 'disconnected'
  | 'connecting'
  | 'registered'
  | 'unregistered'
  | 'error';
