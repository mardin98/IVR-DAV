import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Design system Davivienda
        davivienda: {
          red:    '#ED1C27',     // Rojo corporativo
          dark:   '#B91924',     // Rojo oscuro
          gray: {
            50:  '#F9FAFB',
            100: '#F3F4F6',
            200: '#E5E7EB',
            300: '#D1D5DB',
            400: '#9CA3AF',
            500: '#6B7280',
            600: '#4B5563',
            700: '#374151',
            800: '#1F2937',
            900: '#111827',
          }
        },
        // Estados del agente
        status: {
          available: '#10B981',
          busy:      '#F59E0B',
          oncall:    '#3B82F6',
          paused:    '#6B7280',
          offline:   '#EF4444',
        }
      },
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['DM Mono', 'ui-monospace', 'monospace'],
      },
      animation: {
        'pulse-slow':  'pulse 3s ease-in-out infinite',
        'ringing':     'ringing 1s ease-in-out infinite',
      },
      keyframes: {
        ringing: {
          '0%, 100%': { transform: 'rotate(-5deg)' },
          '50%':      { transform: 'rotate(5deg)' },
        }
      }
    },
  },
  plugins: [],
};

export default config;
