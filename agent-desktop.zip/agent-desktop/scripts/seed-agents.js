// seed-agents.js — Crear los 15 agentes iniciales en Firestore
// Uso: node seed-agents.js

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { Firestore } = require('@google-cloud/firestore');

const db = new Firestore({ projectId: process.env.GCP_PROJECT_ID });

// ── Lista de agentes a crear ─────────────────────────────────────────────────
// Editar esta lista con los datos reales
const AGENTS = [
  { username: 'agente001', fullName: 'Agente Uno',    email: 'agente001@davivienda.com', extension: '8000' },
  { username: 'agente002', fullName: 'Agente Dos',    email: 'agente002@davivienda.com', extension: '8001' },
  { username: 'agente003', fullName: 'Agente Tres',   email: 'agente003@davivienda.com', extension: '8002' },
  { username: 'agente004', fullName: 'Agente Cuatro', email: 'agente004@davivienda.com', extension: '8003' },
  { username: 'agente005', fullName: 'Agente Cinco',  email: 'agente005@davivienda.com', extension: '8004' },
  { username: 'agente006', fullName: 'Agente Seis',   email: 'agente006@davivienda.com', extension: '8005' },
  { username: 'agente007', fullName: 'Agente Siete',  email: 'agente007@davivienda.com', extension: '8006' },
  { username: 'agente008', fullName: 'Agente Ocho',   email: 'agente008@davivienda.com', extension: '8007' },
  { username: 'agente009', fullName: 'Agente Nueve',  email: 'agente009@davivienda.com', extension: '8008' },
  { username: 'agente010', fullName: 'Agente Diez',   email: 'agente010@davivienda.com', extension: '8009' },
  { username: 'agente011', fullName: 'Agente Once',   email: 'agente011@davivienda.com', extension: '8010' },
  { username: 'agente012', fullName: 'Agente Doce',   email: 'agente012@davivienda.com', extension: '8011' },
  { username: 'agente013', fullName: 'Agente Trece',  email: 'agente013@davivienda.com', extension: '8012' },
  { username: 'agente014', fullName: 'Agente Catorce',email: 'agente014@davivienda.com', extension: '8013' },
  { username: 'agente015', fullName: 'Agente Quince', email: 'agente015@davivienda.com', extension: '8014' },
];

// Generar password aleatorio
function randomPassword(length = 12) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  let pw = '';
  for (let i = 0; i < length; i++) {
    pw += chars[Math.floor(Math.random() * chars.length)];
  }
  return pw;
}

(async () => {
  console.log('Creando agentes iniciales...\n');

  const credentials = [];

  for (const data of AGENTS) {
    // Verificar si ya existe
    const existing = await db.collection('agents')
      .where('username', '==', data.username)
      .limit(1)
      .get();

    if (!existing.empty) {
      console.log(`⚠️  ${data.username} ya existe, omitiendo`);
      continue;
    }

    // Password aleatoria
    const password     = randomPassword(10);
    const passwordHash = await bcrypt.hash(password, 10);
    // SIP password (debe coincidir con pjsip.conf)
    const sipPassword  = `Agente${data.extension}Davivienda!`;

    const agent = {
      username:     data.username,
      fullName:     data.fullName,
      email:        data.email,
      extension:    data.extension,
      passwordHash,
      sipPassword,
      status:       'offline',
      role:         'agent',
      createdAt:    new Date().toISOString(),
    };

    await db.collection('agents').add(agent);
    credentials.push({ username: data.username, password, extension: data.extension });
    console.log(`✓ ${data.username} (ext. ${data.extension}) creado`);
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('CREDENCIALES DE ACCESO (guardar de forma segura):');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  credentials.forEach(c => {
    console.log(`Usuario: ${c.username.padEnd(15)} Password: ${c.password.padEnd(15)} Ext: ${c.extension}`);
  });
  console.log('\n⚠️  Las passwords son aleatorias y NO se pueden recuperar.');
  console.log('   Anotalas ahora o cambialas desde el admin después.\n');

  process.exit(0);
})();
