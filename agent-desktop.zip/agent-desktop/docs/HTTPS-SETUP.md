# HTTPS Setup — Agent Desktop con certificado Davivienda

## Por qué HTTPS es obligatorio

JsSIP usa WebRTC en el browser. **WebRTC requiere HTTPS** para acceder al micrófono. Sin HTTPS, los agentes no podrán hablar.

## Arquitectura

```
Agentes (browser)
    │ HTTPS (cert Davivienda)
    ▼
Nginx (puerto 443)
    │ HTTP (interno)
    ▼
Next.js (puerto 3000)
```

Además necesitamos que Asterisk también acepte WebSocket sobre TLS (WSS) en puerto 8089.

---

## Paso 1 — Pedir certificado al área de seguridad de Davivienda

Necesitás un certificado para el hostname:
```
callmanager.davivienda.local
```

(o el dominio interno que use Davivienda)

Tu área de seguridad te debe dar:
- Certificado: `callmanager.crt`
- Clave privada: `callmanager.key`
- Cadena CA (si aplica): `ca-bundle.crt`

---

## Paso 2 — Instalar certificado en la VM

```bash
sudo mkdir -p /etc/pki/davivienda
sudo cp callmanager.crt /etc/pki/davivienda/
sudo cp callmanager.key /etc/pki/davivienda/
sudo cp ca-bundle.crt   /etc/pki/davivienda/
sudo chmod 600 /etc/pki/davivienda/callmanager.key
sudo chmod 644 /etc/pki/davivienda/callmanager.crt
sudo chmod 644 /etc/pki/davivienda/ca-bundle.crt
```

---

## Paso 3 — Instalar y configurar Nginx

```bash
sudo dnf install -y nginx
sudo systemctl enable nginx
```

Crear configuración:

```bash
sudo nano /etc/nginx/conf.d/callmanager.conf
```

Pegar:

```nginx
# Redirect HTTP → HTTPS
server {
  listen 80;
  server_name callmanager.davivienda.local;
  return 301 https://$server_name$request_uri;
}

# HTTPS server
server {
  listen 443 ssl http2;
  server_name callmanager.davivienda.local;

  ssl_certificate     /etc/pki/davivienda/callmanager.crt;
  ssl_certificate_key /etc/pki/davivienda/callmanager.key;
  ssl_protocols       TLSv1.2 TLSv1.3;
  ssl_ciphers         HIGH:!aNULL:!MD5;

  # Headers de seguridad
  add_header Strict-Transport-Security "max-age=63072000; includeSubDomains" always;
  add_header X-Frame-Options "SAMEORIGIN" always;
  add_header X-Content-Type-Options "nosniff" always;

  # Tamaño máximo de request
  client_max_body_size 10M;

  # Proxy a Next.js
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;
    proxy_read_timeout 60s;
  }
}
```

Verificar configuración y arrancar:

```bash
sudo nginx -t
sudo systemctl start nginx
```

---

## Paso 4 — Firewall

```bash
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --reload
```

---

## Paso 5 — Configurar Asterisk para WSS (puerto 8089)

Editar `/etc/asterisk/http.conf`:

```ini
[general]
enabled    = yes
bindaddr   = 0.0.0.0
bindport   = 8088
tlsenable  = yes
tlsbindaddr = 0.0.0.0:8089
tlscertfile = /etc/pki/davivienda/callmanager.crt
tlsprivatekey = /etc/pki/davivienda/callmanager.key
```

**Importante:** Asterisk necesita permisos para leer el cert:

```bash
sudo chown asterisk:asterisk /etc/pki/davivienda/callmanager.key
sudo chmod 640 /etc/pki/davivienda/callmanager.key
```

Editar `/etc/asterisk/pjsip.conf` y agregar el transport WSS:

```ini
[transport-wss]
type=transport
protocol=wss
bind=0.0.0.0:8089
cert_file=/etc/pki/davivienda/callmanager.crt
priv_key_file=/etc/pki/davivienda/callmanager.key
```

Recargar Asterisk:

```bash
sudo asterisk -rx "core reload"
sudo asterisk -rx "pjsip reload"
```

Verificar:

```bash
sudo ss -tlnp | grep 8089
# Debe mostrar Asterisk escuchando en 8089
```

---

## Paso 6 — Configurar el Agent Desktop

Editar `/etc/callmanager/agent-desktop.env`:

```bash
NEXT_PUBLIC_ASTERISK_WSS_URL=wss://callmanager.davivienda.local:8089/ws
NEXT_PUBLIC_ASTERISK_DOMAIN=callmanager.davivienda.local
NEXT_PUBLIC_ORCHESTRATOR_URL=https://callmanager.davivienda.local
```

Reiniciar:

```bash
sudo systemctl restart callmanager-agent-desktop
```

---

## Paso 7 — Probar desde un browser

1. Abrir Chrome/Edge en una PC dentro de la red Davivienda (o por VPN)
2. Navegar a: `https://callmanager.davivienda.local`
3. Login con un agente
4. **Permitir acceso al micrófono** cuando lo pida el browser
5. Verificar en el header "Conectado" (verde)
6. Hacer una llamada al 7000 desde Zoiper y escalar
7. Debería aparecer en la cola del agente
8. Click en "Atender" → modal de llamada entrante → atender

---

## Troubleshooting

### "Mixed Content" en consola del browser
Significa que algo aún está en HTTP. Verificar que `NEXT_PUBLIC_ASTERISK_WSS_URL` empieza con `wss://`.

### "WebSocket handshake failed"
Asterisk no acepta WSS. Verificar:
```bash
sudo ss -tlnp | grep 8089
sudo asterisk -rx "http show status"
```

### "Microphone access denied"
El browser bloqueó el mic. Hacer click en el ícono de candado → permisos → permitir micrófono.

### Certificado no confiable
Si el navegador dice "no seguro", el cert no está en la cadena CA del PC del agente. Hablar con seguridad del banco para distribuir el CA root a los equipos.

### JsSIP no registra
```bash
# Ver intentos de registro en Asterisk
sudo asterisk -rvvv
# Marcar dialog filter en *CLI*
core set verbose 5
# Después abrir el Agent Desktop y ver los logs
```
