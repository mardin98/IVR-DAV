#!/bin/bash
# =============================================================================
# install.sh — Agent Desktop (Next.js 14) en RHEL 9
# Call Manager AI Davivienda
# =============================================================================

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && error "Ejecutar como root: sudo bash install.sh"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   Agent Desktop — Call Manager Davivienda       ║"
echo "║   Next.js 14 + JsSIP                            ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── 1. Node.js 20 ────────────────────────────────────────────────────────────
echo "[1/6] Verificando Node.js 20..."
if ! command -v node &>/dev/null || [ "$(node -v | cut -c2-3)" -lt 20 ]; then
  curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
  dnf install -y -q nodejs
fi
info "Node: $(node -v)"

# ── 2. Usuario callmanager ───────────────────────────────────────────────────
echo "[2/6] Usuario callmanager..."
if ! id callmanager &>/dev/null; then
  useradd -r -s /sbin/nologin -d /opt/callmanager callmanager
fi
info "Usuario callmanager OK"

# ── 3. Copiar archivos ───────────────────────────────────────────────────────
echo "[3/6] Copiando archivos..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p /opt/callmanager/agent-desktop
cp -r "$SCRIPT_DIR"/{src,public,package.json,tsconfig.json,next.config.js,tailwind.config.ts,postcss.config.js} \
  /opt/callmanager/agent-desktop/ 2>/dev/null || true

# Configuración
mkdir -p /etc/callmanager
if [ ! -f /etc/callmanager/agent-desktop.env ]; then
  cp "$SCRIPT_DIR/.env.example" /etc/callmanager/agent-desktop.env
  # Generar JWT_SECRET aleatorio
  JWT_SECRET=$(openssl rand -base64 64 | tr -d '\n')
  sed -i "s|JWT_SECRET=.*|JWT_SECRET=$JWT_SECRET|" /etc/callmanager/agent-desktop.env
  chmod 600 /etc/callmanager/agent-desktop.env
  warn "Editar /etc/callmanager/agent-desktop.env con configuración real"
fi

chown -R callmanager:callmanager /opt/callmanager /etc/callmanager
info "Archivos copiados"

# ── 4. Instalar dependencias y build ─────────────────────────────────────────
echo "[4/6] Instalando dependencias y compilando (5-10 min)..."
cd /opt/callmanager/agent-desktop
sudo -u callmanager npm install --no-audit --no-fund
sudo -u callmanager npm run build
info "Build completado"

# ── 5. systemd service ───────────────────────────────────────────────────────
echo "[5/6] Instalando service..."
cp "$SCRIPT_DIR/callmanager-agent-desktop.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable callmanager-agent-desktop
info "Service habilitado"

# ── 6. Firewall (puerto 3000) ────────────────────────────────────────────────
echo "[6/6] Configurando firewall..."
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-port=3000/tcp
  firewall-cmd --reload
fi
info "Firewall OK"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  ✅  Agent Desktop instalado                     ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "PRÓXIMOS PASOS:"
echo ""
echo "1. Configurar variables:"
echo "   sudo nano /etc/callmanager/agent-desktop.env"
echo ""
echo "2. Subir GCP service account (mismo que el orchestrator):"
echo "   sudo cp ~/gcp-sa.json /etc/callmanager/gcp-service-account.json"
echo ""
echo "3. Crear agentes iniciales (15):"
echo "   cd /opt/callmanager/agent-desktop"
echo "   sudo -u callmanager node scripts/seed-agents.js"
echo "   ⚠️  ANOTAR las passwords que se generan"
echo ""
echo "4. Iniciar servicio:"
echo "   sudo systemctl start callmanager-agent-desktop"
echo ""
echo "5. Verificar:"
echo "   curl http://localhost:3000"
echo "   sudo journalctl -u callmanager-agent-desktop -f"
echo ""
echo "6. Configurar reverse proxy HTTPS (siguiente paso):"
echo "   ver docs/GUIA-COMPLETA.md sección 'HTTPS con certificado Davivienda'"
echo ""
