# Tono de llamada

Reemplazar este archivo por un MP3 de tono de llamada llamado `ringtone.mp3`.
Recomendado: 2-5 segundos en loop, suave para no irritar al agente.
