# Agent Desktop — Call Manager AI Davivienda

Panel web para los 15 agentes humanos del Call Center.

## Stack

- **Frontend:** Next.js 14 (App Router) + Tailwind + TypeScript
- **Softphone:** JsSIP (WebRTC SIP)
- **Auth:** JWT local con bcrypt
- **DB:** Firestore (compartido con Orchestrator)
- **Estado:** Zustand
- **Iconos:** Lucide React

## Funcionalidades

✅ Login con usuario/password local
✅ Estados del agente: Disponible / Ocupado / En pausa / En llamada
✅ Cola de llamadas escaladas en tiempo real
✅ Vista de llamada activa con:
  - Datos del cliente
  - **Brief de IA** (resumen de Sofía)
  - Transcripción completa de la conversación previa
  - Controles: Mute, Colgar
✅ Softphone WebRTC integrado (JsSIP)
✅ Modal de llamada entrante con tono
✅ Indicador de estado de conexión SIP

## Instalación (RHEL 9 — junto a Asterisk)

```bash
# 1. Subir archivos a la VM
scp -r agent-desktop/ mardin@IP-VM:~/

# 2. SSH y ejecutar instalador
ssh mardin@IP-VM
cd agent-desktop
sudo bash install.sh

# 3. Configurar .env
sudo nano /etc/callmanager/agent-desktop.env

# 4. Crear agentes
cd /opt/callmanager/agent-desktop
sudo -u callmanager node scripts/seed-agents.js
# ⚠️  ANOTAR las passwords que aparecen

# 5. Iniciar
sudo systemctl start callmanager-agent-desktop
```

## HTTPS con certificado Davivienda

Para que JsSIP funcione (WebRTC requiere HTTPS), necesitás:

1. **Certificado del CA interno de Davivienda** para `callmanager.davivienda.local`
2. **Reverse proxy con Nginx** delante de Next.js (puerto 3000)
3. **Asterisk WebSocket con TLS** (puerto 8089)

Ver `docs/HTTPS-SETUP.md` para detalles.

## Estructura

```
src/
├── app/
│   ├── login/              Login del agente
│   ├── dashboard/          Vista principal
│   ├── api/
│   │   ├── auth/           Login, logout, me
│   │   ├── calls/          Cola, accept, detalle
│   │   └── agent/          Cambiar estado
│   └── layout.tsx
├── components/
│   ├── DashboardClient.tsx Vista principal del agente
│   ├── AgentHeader.tsx     Barra superior
│   ├── StatusSelector.tsx  Cambiar estado
│   ├── CallQueue.tsx       Lista de llamadas en cola
│   ├── ActiveCall.tsx      Vista de llamada activa con brief IA
│   └── IncomingCallModal.tsx
├── hooks/
│   ├── useSoftphone.ts     JsSIP WebRTC
│   └── useCallQueue.ts     Polling de llamadas
├── store/
│   └── agentStore.ts       Zustand
├── lib/
│   ├── auth.ts             JWT, bcrypt
│   ├── firestore.ts        Cliente Firestore
│   └── ari.ts              Cliente Asterisk ARI
└── types/
    └── index.ts            Tipos TypeScript

scripts/
└── seed-agents.js          Crear 15 agentes iniciales
```

## Variables de entorno

Ver `.env.example` para la lista completa.

Críticas:
- `JWT_SECRET` — generar con `openssl rand -base64 64`
- `NEXT_PUBLIC_ASTERISK_WSS_URL` — `wss://callmanager.davivienda.local:8089/ws`
- `ORCHESTRATOR_URL` — `http://localhost:8080`
- `GCP_PROJECT_ID` — tu proyecto GCP
- `GOOGLE_APPLICATION_CREDENTIALS` — path al service account JSON
