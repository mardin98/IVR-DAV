"use client";

// ─── GOOGLE DRIVE ─────────────────────────────────────────────────────────────
// These functions call Cloud Functions that handle the actual Google API calls
// using a service account with domain-wide delegation.

import { httpsCallable } from "firebase/functions";
import { functions } from "@/lib/firebase";

export interface DriveFolder {
  id: string;
  webViewLink: string;
  name: string;
}

export interface CalendarEvent {
  id: string;
  htmlLink: string;
}

/**
 * Creates a Google Drive folder for an initiative.
 * Cloud Function: createDriveFolder
 */
export async function createDriveFolder(initiativeId: string, initiativeCode: string, title: string): Promise<DriveFolder> {
  const fn = httpsCallable<{ initiativeId: string; code: string; title: string }, DriveFolder>(
    functions, "createDriveFolder"
  );
  const result = await fn({ initiativeId, code: initiativeCode, title });
  return result.data;
}

/**
 * Creates a Google Calendar event for the initiative deadline.
 * Cloud Function: createCalendarEvent
 */
export async function createCalendarEvent(
  initiativeId: string,
  title: string,
  dueDate: string,
  leaderEmail: string
): Promise<CalendarEvent> {
  const fn = httpsCallable<
    { initiativeId: string; title: string; dueDate: string; leaderEmail: string },
    CalendarEvent
  >(functions, "createCalendarEvent");
  const result = await fn({ initiativeId, title, dueDate, leaderEmail });
  return result.data;
}

/**
 * Generates a PDF report and saves it to Drive.
 * Cloud Function: generateReportPDF
 */
export async function generateReportPDF(filters: {
  status?: string[];
  category?: string[];
  leaderId?: string;
}): Promise<{ driveFileId: string; webViewLink: string }> {
  const fn = httpsCallable<typeof filters, { driveFileId: string; webViewLink: string }>(
    functions, "generateReportPDF"
  );
  const result = await fn(filters);
  return result.data;
}
