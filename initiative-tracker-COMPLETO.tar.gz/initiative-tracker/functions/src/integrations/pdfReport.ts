import * as PDFDocument from "pdfkit";
import { google } from "googleapis";
import * as admin from "firebase-admin";
import { Readable } from "stream";

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface InitiativeData {
  id: string;
  code: string;
  title: string;
  status: string;
  priority: string;
  category: string;
  progress: number;
  budget: number;
  budgetSpent: number;
  leaderId: string;
  dueDate?: admin.firestore.Timestamp;
  startDate?: admin.firestore.Timestamp;
}

interface ReportFilters {
  status?: string[];
  category?: string[];
  leaderId?: string;
}

// ─── COLOR MAP ────────────────────────────────────────────────────────────────

const STATUS_COLORS: Record<string, string> = {
  active: "#22d3ee", draft: "#64748b", on_hold: "#f59e0b",
  completed: "#4ade80", cancelled: "#f87171",
};

const STATUS_LABELS: Record<string, string> = {
  active: "Activa", draft: "Borrador", on_hold: "En pausa",
  completed: "Completada", cancelled: "Cancelada",
};

const PRIORITY_LABELS: Record<string, string> = {
  critical: "Crítica", high: "Alta", medium: "Media", low: "Baja",
};

const CATEGORY_LABELS: Record<string, string> = {
  ai: "IA", automation: "Automatización", infra: "Infraestructura", process: "Proceso",
};

// ─── PDF GENERATOR ────────────────────────────────────────────────────────────

export async function generateInitiativeReportPDF(
  filters: ReportFilters,
  generatedBy: string
): Promise<Buffer> {
  // Fetch initiatives from Firestore
  const db = admin.firestore();
  let q: admin.firestore.Query = db.collection("initiatives");

  if (filters.status?.length) q = q.where("status", "in", filters.status);
  if (filters.leaderId) q = q.where("leaderId", "==", filters.leaderId);
  if (filters.category?.length) q = q.where("category", "in", filters.category);

  const snap = await q.orderBy("createdAt", "desc").get();
  const initiatives = snap.docs.map(d => ({ id: d.id, ...d.data() } as InitiativeData));

  // Fetch user names
  const leaderIds = [...new Set(initiatives.map(i => i.leaderId))];
  const userMap: Record<string, string> = {};
  for (const uid of leaderIds) {
    const userDoc = await db.collection("users").doc(uid).get();
    if (userDoc.exists) userMap[uid] = (userDoc.data() as { name: string }).name;
  }

  // Stats
  const active = initiatives.filter(i => i.status === "active");
  const completed = initiatives.filter(i => i.status === "completed");
  const avgProgress = active.length
    ? Math.round(active.reduce((s, i) => s + i.progress, 0) / active.length) : 0;
  const totalBudget = initiatives.reduce((s, i) => s + (i.budget || 0), 0);
  const totalSpent = initiatives.reduce((s, i) => s + (i.budgetSpent || 0), 0);

  const now = new Date();
  const dateStr = now.toLocaleDateString("es-SV", { day: "2-digit", month: "long", year: "numeric" });

  return new Promise((resolve, reject) => {
    const doc = new (PDFDocument as any)({ size: "A4", margin: 40, info: {
      Title: "Reporte de Iniciativas — Davivienda AI & Automations",
      Author: "Initiative Tracker",
    }});

    const buffers: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => buffers.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(buffers)));
    doc.on("error", reject);

    const W = 515; // usable width
    const DARK = "#0d1628";
    const ACCENT = "#22d3ee";
    const GRAY = "#64748b";
    const LIGHT = "#e2e8f0";

    // ── HEADER ──────────────────────────────────────────────────────────────
    doc.rect(0, 0, 595, 80).fill(DARK);
    doc.fontSize(22).fillColor(LIGHT).font("Helvetica-Bold")
      .text("Initiative Tracker", 40, 22);
    doc.fontSize(10).fillColor(GRAY).font("Helvetica")
      .text("Davivienda El Salvador · AI & Automations", 40, 50);
    doc.fontSize(9).fillColor(ACCENT)
      .text(`Generado el ${dateStr}`, 40, 62);

    doc.moveDown(2);

    // ── TITLE ───────────────────────────────────────────────────────────────
    doc.fontSize(16).fillColor(DARK).font("Helvetica-Bold")
      .text("Reporte de Iniciativas", 40, 100);
    doc.fontSize(10).fillColor(GRAY).font("Helvetica")
      .text(`Generado por ${generatedBy || "Sistema"} · ${initiatives.length} iniciativas`, 40, 120);

    // ── KPI BOXES ───────────────────────────────────────────────────────────
    const kpis = [
      { label: "Total", value: String(initiatives.length), color: DARK },
      { label: "Activas", value: String(active.length), color: "#0e7490" },
      { label: "Completadas", value: String(completed.length), color: "#16a34a" },
      { label: "Avance promedio", value: `${avgProgress}%`, color: "#7c3aed" },
    ];

    const boxW = 115, boxH = 50, boxY = 140, gap = 10;
    kpis.forEach((k, i) => {
      const x = 40 + i * (boxW + gap);
      doc.roundedRect(x, boxY, boxW, boxH, 6).fillAndStroke("#f8fafc", "#e2e8f0");
      doc.fontSize(9).fillColor(GRAY).font("Helvetica")
        .text(k.label.toUpperCase(), x + 10, boxY + 10);
      doc.fontSize(20).fillColor(k.color).font("Helvetica-Bold")
        .text(k.value, x + 10, boxY + 22);
    });

    // ── BUDGET BAR ──────────────────────────────────────────────────────────
    const budgetY = 205;
    const budgetPct = totalBudget > 0 ? Math.min(totalSpent / totalBudget, 1) : 0;
    const barColor = budgetPct > 0.85 ? "#dc2626" : budgetPct > 0.6 ? "#d97706" : "#0e7490";

    doc.fontSize(9).fillColor(GRAY).font("Helvetica")
      .text("EJECUCIÓN PRESUPUESTARIA GLOBAL", 40, budgetY);
    doc.rect(40, budgetY + 14, W, 8).fillAndStroke("#e2e8f0", "#e2e8f0");
    doc.rect(40, budgetY + 14, W * budgetPct, 8).fill(barColor);
    doc.fontSize(9).fillColor(GRAY)
      .text(`$${(totalSpent / 1000).toFixed(1)}k ejecutado de $${(totalBudget / 1000).toFixed(1)}k · ${Math.round(budgetPct * 100)}%`, 40, budgetY + 28);

    // ── TABLE HEADER ────────────────────────────────────────────────────────
    const tableY = 250;
    const cols = { code: 40, title: 110, status: 310, priority: 375, progress: 425, budget: 470 };

    doc.rect(40, tableY, W, 22).fill(DARK);
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica-Bold");
    doc.text("CÓDIGO", cols.code, tableY + 7);
    doc.text("TÍTULO", cols.title, tableY + 7);
    doc.text("ESTADO", cols.status, tableY + 7);
    doc.text("PRIORIDAD", cols.priority, tableY + 7);
    doc.text("AVANCE", cols.progress, tableY + 7);
    doc.text("BUDGET%", cols.budget, tableY + 7);

    // ── TABLE ROWS ──────────────────────────────────────────────────────────
    let rowY = tableY + 22;
    const ROW_H = 28;

    initiatives.slice(0, 20).forEach((ini, i) => {
      const bg = i % 2 === 0 ? "#ffffff" : "#f8fafc";
      doc.rect(40, rowY, W, ROW_H).fill(bg);

      const progPct = ini.progress / 100;
      const budPct = ini.budget > 0 ? ini.budgetSpent / ini.budget : 0;
      const progColor = ini.progress >= 80 ? "#16a34a" : ini.progress >= 50 ? "#0e7490" : "#d97706";
      const bColor = budPct > 0.85 ? "#dc2626" : budPct > 0.6 ? "#d97706" : "#0e7490";
      const dueDate = ini.dueDate?.toDate?.()?.toLocaleDateString("es-SV", { day: "2-digit", month: "short" }) ?? "—";

      doc.fontSize(8).font("Helvetica-Bold").fillColor(ACCENT)
        .text(ini.code, cols.code, rowY + 5);
      doc.font("Helvetica").fillColor(DARK)
        .text(ini.title.substring(0, 28) + (ini.title.length > 28 ? "…" : ""), cols.title, rowY + 5);

      // Status chip
      const sColor = STATUS_COLORS[ini.status] || GRAY;
      doc.roundedRect(cols.status, rowY + 4, 55, 14, 7).fill(`${sColor}22`);
      doc.fontSize(7).fillColor(sColor).font("Helvetica-Bold")
        .text(STATUS_LABELS[ini.status] || ini.status, cols.status + 4, rowY + 8);

      doc.fontSize(8).fillColor(GRAY).font("Helvetica")
        .text(PRIORITY_LABELS[ini.priority] || ini.priority, cols.priority, rowY + 9);

      // Progress mini-bar
      doc.rect(cols.progress, rowY + 9, 36, 5).fill("#e2e8f0");
      doc.rect(cols.progress, rowY + 9, 36 * progPct, 5).fill(progColor);
      doc.fontSize(7).fillColor(progColor).font("Helvetica-Bold")
        .text(`${ini.progress}%`, cols.progress + 38, rowY + 8);

      // Budget
      doc.fontSize(7).fillColor(bColor).font("Helvetica-Bold")
        .text(`${Math.round(budPct * 100)}%`, cols.budget, rowY + 9);

      // Leader + due date on second line
      doc.fontSize(7).fillColor(GRAY).font("Helvetica")
        .text(`${CATEGORY_LABELS[ini.category] || ini.category} · ${userMap[ini.leaderId] || "—"} · Vence: ${dueDate}`, cols.title, rowY + 17, { width: 200 });

      rowY += ROW_H;

      if (rowY > 750) {
        doc.addPage();
        rowY = 40;
      }
    });

    if (initiatives.length > 20) {
      doc.fontSize(9).fillColor(GRAY).font("Helvetica-Oblique")
        .text(`… y ${initiatives.length - 20} iniciativas más`, 40, rowY + 8);
      rowY += 20;
    }

    // ── FOOTER ──────────────────────────────────────────────────────────────
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica")
      .text(
        `Initiative Tracker · Davivienda El Salvador · ${dateStr}`,
        40, 810, { align: "center", width: W }
      );

    doc.end();
  });
}

// ─── UPLOAD TO DRIVE ─────────────────────────────────────────────────────────

export async function uploadPDFToDrive(
  pdfBuffer: Buffer,
  fileName: string,
  parentFolderId?: string
): Promise<{ fileId: string; webViewLink: string }> {
  const auth = new google.auth.GoogleAuth({
    scopes: ["https://www.googleapis.com/auth/drive.file"],
  });
  const drive = google.drive({ version: "v3", auth: await auth.getClient() as any });

  const stream = Readable.from(pdfBuffer);
  const parents = parentFolderId ? [parentFolderId] : [];

  const res = await drive.files.create({
    requestBody: {
      name: fileName,
      mimeType: "application/pdf",
      parents,
    },
    media: { mimeType: "application/pdf", body: stream },
    fields: "id, webViewLink",
  });

  return {
    fileId: res.data.id || "",
    webViewLink: res.data.webViewLink || "",
  };
}
