import { google } from "googleapis";
import * as admin from "firebase-admin";
import { defineString } from "firebase-functions/params";

// ─── CONFIG ───────────────────────────────────────────────────────────────────
// Set via: firebase functions:config:set google.service_account_email="..."
// The service account needs:
//   - Google Drive API enabled
//   - Google Calendar API enabled
//   - Domain-wide delegation in Google Workspace Admin

const DRIVE_PARENT_FOLDER = defineString("DRIVE_PARENT_FOLDER_ID", {
  description: "Google Drive folder ID where initiative subfolders will be created",
  default: "",
});

const CALENDAR_ID = defineString("GOOGLE_CALENDAR_ID", {
  description: "Google Calendar ID for initiative deadlines",
  default: "primary",
});

const SERVICE_ACCOUNT_EMAIL = defineString("SERVICE_ACCOUNT_EMAIL", {
  description: "Service account email for impersonation",
  default: "",
});

// ─── AUTH ─────────────────────────────────────────────────────────────────────

function getAuthClient(impersonateEmail?: string) {
  // Uses Application Default Credentials (ADC) — works automatically on Cloud Run/Functions
  // The service account must have domain-wide delegation enabled
  const auth = new google.auth.GoogleAuth({
    scopes: [
      "https://www.googleapis.com/auth/drive",
      "https://www.googleapis.com/auth/calendar",
    ],
  });

  if (impersonateEmail) {
    // Impersonate a workspace user for calendar events
    return auth.fromJSON({
      type: "service_account",
      client_email: SERVICE_ACCOUNT_EMAIL.value(),
      // private_key loaded from ADC
      subject: impersonateEmail,
    } as Parameters<typeof auth.fromJSON>[0]);
  }

  return auth.getClient();
}

// ─── DRIVE ────────────────────────────────────────────────────────────────────

export interface DriveFolder {
  id: string;
  webViewLink: string;
  name: string;
}

/**
 * Creates a Google Drive folder for an initiative.
 * Structure: [DRIVE_PARENT_FOLDER] / [INI-001] Title
 */
export async function createInitiativeDriveFolder(
  initiativeId: string,
  code: string,
  title: string
): Promise<DriveFolder> {
  const auth = await getAuthClient();
  const drive = google.drive({ version: "v3", auth: auth as any });

  const folderName = `[${code}] ${title}`;
  const parents = DRIVE_PARENT_FOLDER.value() ? [DRIVE_PARENT_FOLDER.value()] : [];

  const res = await drive.files.create({
    requestBody: {
      name: folderName,
      mimeType: "application/vnd.google-apps.folder",
      parents,
    },
    fields: "id, webViewLink, name",
  });

  const folder = res.data;
  if (!folder.id) throw new Error("Drive folder creation failed");

  // Create standard subfolders
  const subfolders = ["📄 Documentos", "📊 Reportes", "🎨 Diseños", "📋 Actas"];
  await Promise.all(subfolders.map(name =>
    drive.files.create({
      requestBody: { name, mimeType: "application/vnd.google-apps.folder", parents: [folder.id!] },
    })
  ));

  // Save to Firestore
  await admin.firestore().collection("initiatives").doc(initiativeId).update({
    googleDriveFolderId: folder.id,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return {
    id: folder.id,
    webViewLink: folder.webViewLink || `https://drive.google.com/drive/folders/${folder.id}`,
    name: folder.name || folderName,
  };
}

// ─── CALENDAR ─────────────────────────────────────────────────────────────────

export interface CalendarEvent {
  id: string;
  htmlLink: string;
}

/**
 * Creates a Google Calendar event for the initiative deadline.
 * Adds leader + all members as attendees.
 */
export async function createInitiativeCalendarEvent(
  initiativeId: string,
  title: string,
  dueDate: string, // ISO date string YYYY-MM-DD
  leaderEmail: string,
  memberEmails: string[] = []
): Promise<CalendarEvent> {
  const auth = await getAuthClient(leaderEmail);
  const calendar = google.calendar({ version: "v3", auth: auth as any });

  const allAttendees = [...new Set([leaderEmail, ...memberEmails])].map(email => ({ email }));

  const res = await calendar.events.insert({
    calendarId: CALENDAR_ID.value() || "primary",
    sendUpdates: "all",
    requestBody: {
      summary: `📋 Vence: [${title}]`,
      description: `Fecha de vencimiento de la iniciativa.\n\nVer en Initiative Tracker: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard/initiatives/${initiativeId}`,
      start: { date: dueDate },
      end: { date: dueDate },
      attendees: allAttendees,
      reminders: {
        useDefault: false,
        overrides: [
          { method: "email", minutes: 24 * 60 * 7 }, // 7 days before
          { method: "email", minutes: 24 * 60 * 3 }, // 3 days before
          { method: "popup", minutes: 24 * 60 },      // 1 day before
        ],
      },
      colorId: "11", // Tomato red
    },
  });

  const event = res.data;
  if (!event.id) throw new Error("Calendar event creation failed");

  // Save to Firestore
  await admin.firestore().collection("initiatives").doc(initiativeId).update({
    googleCalendarEventId: event.id,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { id: event.id, htmlLink: event.htmlLink || "" };
}

/**
 * Updates a calendar event when the initiative dueDate changes.
 */
export async function updateInitiativeCalendarEvent(
  eventId: string,
  newDueDate: string,
  leaderEmail: string
): Promise<void> {
  const auth = await getAuthClient(leaderEmail);
  const calendar = google.calendar({ version: "v3", auth: auth as any });

  await calendar.events.patch({
    calendarId: CALENDAR_ID.value() || "primary",
    eventId,
    requestBody: {
      start: { date: newDueDate },
      end: { date: newDueDate },
    },
  });
}

/**
 * Deletes a calendar event when the initiative is cancelled or deleted.
 */
export async function deleteInitiativeCalendarEvent(
  eventId: string,
  leaderEmail: string
): Promise<void> {
  const auth = await getAuthClient(leaderEmail);
  const calendar = google.calendar({ version: "v3", auth: auth as any });

  await calendar.events.delete({
    calendarId: CALENDAR_ID.value() || "primary",
    eventId,
  });
}
