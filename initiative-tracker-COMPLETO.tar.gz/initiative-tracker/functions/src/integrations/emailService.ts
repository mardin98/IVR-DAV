import * as nodemailer from "nodemailer";
import { defineString, defineSecret } from "firebase-functions/params";

// ─── CONFIG (set via: firebase functions:secrets:set SMTP_PASSWORD) ──────────
const SMTP_HOST = defineString("SMTP_HOST", { default: "smtp.gmail.com" });
const SMTP_PORT = defineString("SMTP_PORT", { default: "587" });
const SMTP_USER = defineString("SMTP_USER", { default: "noreply@davivienda.com.sv" });
const SMTP_PASS = defineSecret("SMTP_PASSWORD");
const FROM_NAME = "Initiative Tracker · Davivienda";

function createTransport() {
  return nodemailer.createTransport({
    host: SMTP_HOST.value(),
    port: parseInt(SMTP_PORT.value()),
    secure: false, // STARTTLS
    auth: {
      user: SMTP_USER.value(),
      pass: SMTP_PASS.value(),
    },
    tls: { rejectUnauthorized: false },
  });
}

// ─── BASE HTML TEMPLATE ───────────────────────────────────────────────────────

function baseTemplate(content: string, preheader = ""): string {
  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Initiative Tracker</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#060b14; font-family:'Segoe UI',Arial,sans-serif; color:#f1f5f9; }
  .wrapper { max-width:600px; margin:0 auto; padding:32px 16px; }
  .header { display:flex; align-items:center; gap:12px; margin-bottom:32px; padding-bottom:20px; border-bottom:1px solid rgba(255,255,255,0.08); }
  .logo { width:40px; height:40px; border-radius:10px; background:linear-gradient(135deg,#22d3ee,#a78bfa); display:flex; align-items:center; justify-content:center; font-size:20px; }
  .logo-text { font-size:16px; font-weight:800; color:#f1f5f9; line-height:1; }
  .logo-sub { font-size:10px; color:#334155; letter-spacing:0.1em; text-transform:uppercase; }
  .card { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:28px; margin-bottom:20px; }
  .badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700; }
  .badge-active { color:#22d3ee; background:rgba(34,211,238,0.12); border:1px solid rgba(34,211,238,0.3); }
  .badge-warning { color:#f59e0b; background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.3); }
  .badge-success { color:#4ade80; background:rgba(74,222,128,0.12); border:1px solid rgba(74,222,128,0.3); }
  .badge-danger { color:#f87171; background:rgba(248,113,113,0.12); border:1px solid rgba(248,113,113,0.3); }
  .progress-bar-bg { background:rgba(255,255,255,0.07); border-radius:4px; height:6px; margin:8px 0; }
  .btn { display:inline-block; padding:12px 24px; border-radius:10px; font-size:14px; font-weight:700; text-decoration:none; color:#060b14; background:linear-gradient(135deg,#22d3ee,#0e7490); }
  .meta-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05); font-size:13px; }
  .meta-label { color:#64748b; }
  .meta-value { color:#e2e8f0; font-weight:600; }
  .footer { text-align:center; font-size:11px; color:#1e3a5f; margin-top:32px; }
  h1 { font-size:22px; font-weight:800; color:#f1f5f9; margin-bottom:6px; }
  h2 { font-size:16px; font-weight:700; color:#e2e8f0; margin-bottom:12px; }
  p { font-size:14px; color:#94a3b8; line-height:1.7; margin-bottom:12px; }
  .mono { font-family:'Courier New',monospace; color:#22d3ee; font-weight:700; }
</style>
</head>
<body>
${preheader ? `<div style="display:none;max-height:0;overflow:hidden;">${preheader}</div>` : ""}
<div class="wrapper">
  <div class="header">
    <div class="logo">◈</div>
    <div>
      <div class="logo-text">Initiative Tracker</div>
      <div class="logo-sub">Davivienda AI & Automations</div>
    </div>
  </div>
  ${content}
  <div class="footer">
    Este mensaje fue generado automáticamente · Initiative Tracker · Davivienda El Salvador<br>
    No responder a este correo
  </div>
</div>
</body>
</html>`;
}

// ─── EMAIL TYPES ──────────────────────────────────────────────────────────────

export interface TaskAssignedEmail {
  to: string;
  userName: string;
  taskTitle: string;
  initiativeCode: string;
  initiativeTitle: string;
  assignedBy: string;
  dueDate?: string;
  initiativeUrl: string;
}

export interface OverdueTaskEmail {
  to: string;
  userName: string;
  tasks: { title: string; initiativeCode: string; dueDate: string; }[];
  appUrl: string;
}

export interface WeeklyReportEmail {
  to: string;
  userName: string;
  stats: {
    activeCount: number;
    completedCount: number;
    avgProgress: number;
    overdueTasksCount: number;
    totalBudget: number;
    totalSpent: number;
  };
  topInitiatives: {
    code: string;
    title: string;
    progress: number;
    status: string;
    daysLeft: number;
  }[];
  appUrl: string;
}

export interface StatusChangedEmail {
  to: string[];
  userName: string; // who changed it
  initiativeCode: string;
  initiativeTitle: string;
  oldStatus: string;
  newStatus: string;
  initiativeUrl: string;
}

export interface BudgetAlertEmail {
  to: string;
  initiativeCode: string;
  initiativeTitle: string;
  budgetPct: number;
  spent: number;
  total: number;
  initiativeUrl: string;
}

// ─── SEND FUNCTIONS ───────────────────────────────────────────────────────────

export async function sendTaskAssigned(data: TaskAssignedEmail): Promise<void> {
  const transport = createTransport();
  const html = baseTemplate(`
    <div class="card">
      <p style="margin-bottom:16px;">Hola <strong>${data.userName}</strong>,</p>
      <h1>Nueva tarea asignada</h1>
      <p>Se te asignó una tarea en <span class="mono">${data.initiativeCode}</span></p>

      <div style="background:rgba(34,211,238,0.06);border:1px solid rgba(34,211,238,0.2);border-radius:12px;padding:16px;margin:20px 0;">
        <div style="font-size:16px;font-weight:700;color:#f1f5f9;margin-bottom:8px;">${data.taskTitle}</div>
        <div style="font-size:13px;color:#64748b;">${data.initiativeCode} — ${data.initiativeTitle}</div>
        ${data.dueDate ? `<div style="font-size:12px;color:#f59e0b;margin-top:6px;">📅 Vence el ${data.dueDate}</div>` : ""}
      </div>

      <div class="meta-row"><span class="meta-label">Asignado por</span><span class="meta-value">${data.assignedBy}</span></div>

      <div style="margin-top:24px;">
        <a href="${data.initiativeUrl}" class="btn">Ver iniciativa →</a>
      </div>
    </div>
  `, `Nueva tarea: ${data.taskTitle}`);

  await transport.sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: data.to,
    subject: `📋 Nueva tarea asignada: ${data.taskTitle}`,
    html,
  });
}

export async function sendOverdueTasks(data: OverdueTaskEmail): Promise<void> {
  const transport = createTransport();
  const taskRows = data.tasks.map(t => `
    <div style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
      <span class="mono">${t.initiativeCode}</span>
      <span style="font-size:13px;color:#e2e8f0;margin-left:10px;">${t.title}</span>
      <span style="font-size:12px;color:#f87171;margin-left:10px;">Venció ${t.dueDate}</span>
    </div>
  `).join("");

  const html = baseTemplate(`
    <div class="card">
      <span class="badge badge-warning" style="margin-bottom:16px;">⚠ Alerta de vencimiento</span>
      <h1 style="margin-top:12px;">Tienes ${data.tasks.length} tarea${data.tasks.length > 1 ? "s" : ""} vencida${data.tasks.length > 1 ? "s" : ""}</h1>
      <p>Hola <strong>${data.userName}</strong>, las siguientes tareas asignadas a ti han superado su fecha límite:</p>
      <div style="margin:20px 0;">${taskRows}</div>
      <div style="margin-top:20px;">
        <a href="${data.appUrl}" class="btn">Ir al sistema →</a>
      </div>
    </div>
  `, `${data.tasks.length} tareas vencidas pendientes`);

  await transport.sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: data.to,
    subject: `⚠ ${data.tasks.length} tarea${data.tasks.length > 1 ? "s" : ""} vencida${data.tasks.length > 1 ? "s" : ""} — Initiative Tracker`,
    html,
  });
}

export async function sendWeeklyReport(data: WeeklyReportEmail): Promise<void> {
  const transport = createTransport();
  const budgetPct = data.stats.totalBudget > 0
    ? Math.round((data.stats.totalSpent / data.stats.totalBudget) * 100) : 0;

  const iniRows = data.topInitiatives.map(i => {
    const barWidth = i.progress;
    const barColor = i.progress >= 80 ? "#4ade80" : i.progress >= 50 ? "#22d3ee" : "#f59e0b";
    const dlColor = i.daysLeft < 0 ? "#f87171" : i.daysLeft < 7 ? "#f59e0b" : "#64748b";
    return `
      <div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
          <div>
            <span class="mono" style="font-size:11px;">${i.code}</span>
            <span style="font-size:13px;font-weight:600;color:#e2e8f0;margin-left:8px;">${i.title}</span>
          </div>
          <span style="font-size:12px;color:${dlColor};">
            ${i.daysLeft < 0 ? `Venció hace ${Math.abs(i.daysLeft)}d` : `${i.daysLeft}d restantes`}
          </span>
        </div>
        <div class="progress-bar-bg">
          <div style="height:6px;border-radius:4px;width:${barWidth}%;background:${barColor};"></div>
        </div>
        <div style="font-size:11px;color:#64748b;text-align:right;">${i.progress}%</div>
      </div>
    `;
  }).join("");

  const html = baseTemplate(`
    <div class="card">
      <span class="badge badge-active" style="margin-bottom:16px;">📊 Reporte semanal</span>
      <h1 style="margin-top:12px;">Resumen de la semana</h1>
      <p>Hola <strong>${data.userName}</strong>, aquí está el resumen del área de AI & Automations:</p>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:24px 0;">
        ${[
          { label: "Activas", value: data.stats.activeCount, color: "#22d3ee" },
          { label: "Completadas", value: data.stats.completedCount, color: "#4ade80" },
          { label: "Avance promedio", value: `${data.stats.avgProgress}%`, color: "#a78bfa" },
          { label: "Tareas vencidas", value: data.stats.overdueTasksCount, color: data.stats.overdueTasksCount > 0 ? "#f87171" : "#4ade80" },
        ].map(k => `
          <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:14px;">
            <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">${k.label}</div>
            <div style="font-size:26px;font-weight:800;color:${k.color};font-family:'Courier New',monospace;">${k.value}</div>
          </div>
        `).join("")}
      </div>

      <div style="margin-bottom:16px;">
        <div style="font-size:12px;color:#64748b;margin-bottom:6px;">PRESUPUESTO GLOBAL — ${budgetPct}% ejecutado</div>
        <div class="progress-bar-bg">
          <div style="height:6px;border-radius:4px;width:${budgetPct}%;background:${budgetPct > 85 ? "#f87171" : budgetPct > 60 ? "#f59e0b" : "#22d3ee"};"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:#475569;margin-top:4px;">
          <span>Ejecutado: $${(data.stats.totalSpent / 1000).toFixed(1)}k</span>
          <span>Total: $${(data.stats.totalBudget / 1000).toFixed(1)}k</span>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>Iniciativas activas</h2>
      ${iniRows}
      <div style="margin-top:20px;">
        <a href="${data.appUrl}" class="btn">Ver dashboard completo →</a>
      </div>
    </div>
  `, `${data.stats.activeCount} activas · ${data.stats.avgProgress}% avance promedio`);

  await transport.sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: data.to,
    subject: `📊 Resumen semanal — ${data.stats.activeCount} iniciativas activas`,
    html,
  });
}

export async function sendStatusChanged(data: StatusChangedEmail): Promise<void> {
  const transport = createTransport();
  const statusLabels: Record<string, string> = {
    active: "Activa", on_hold: "En pausa", completed: "Completada",
    cancelled: "Cancelada", draft: "Borrador",
  };
  const statusColors: Record<string, string> = {
    active: "badge-active", on_hold: "badge-warning",
    completed: "badge-success", cancelled: "badge-danger", draft: "",
  };

  const html = baseTemplate(`
    <div class="card">
      <p>Hola,</p>
      <h1>Iniciativa actualizada</h1>
      <p><strong>${data.userName}</strong> actualizó el estado de la iniciativa <span class="mono">${data.initiativeCode}</span></p>

      <div style="display:flex;align-items:center;gap:16px;margin:20px 0;padding:16px;background:rgba(255,255,255,0.03);border-radius:10px;">
        <span class="badge ${statusColors[data.oldStatus] || ""}">${statusLabels[data.oldStatus] || data.oldStatus}</span>
        <span style="color:#475569;font-size:18px;">→</span>
        <span class="badge ${statusColors[data.newStatus] || ""}">${statusLabels[data.newStatus] || data.newStatus}</span>
      </div>

      <div style="font-size:15px;font-weight:600;color:#f1f5f9;margin-bottom:4px;">${data.initiativeTitle}</div>

      <div style="margin-top:24px;">
        <a href="${data.initiativeUrl}" class="btn">Ver iniciativa →</a>
      </div>
    </div>
  `, `${data.initiativeCode} cambió a ${statusLabels[data.newStatus] || data.newStatus}`);

  await transport.sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: data.to.join(","),
    subject: `🔄 ${data.initiativeCode} — Estado actualizado: ${statusLabels[data.newStatus] || data.newStatus}`,
    html,
  });
}

export async function sendBudgetAlert(data: BudgetAlertEmail): Promise<void> {
  const transport = createTransport();
  const html = baseTemplate(`
    <div class="card">
      <span class="badge badge-warning" style="margin-bottom:16px;">💰 Alerta de presupuesto</span>
      <h1 style="margin-top:12px;">${data.initiativeCode} al ${data.budgetPct}% del presupuesto</h1>
      <p>La iniciativa <strong>${data.initiativeTitle}</strong> ha consumido el <strong style="color:#f59e0b;">${data.budgetPct}%</strong> de su presupuesto asignado.</p>

      <div style="margin:20px 0;">
        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:8px;">
          <span style="color:#64748b;">Ejecutado</span>
          <span style="color:#f59e0b;font-weight:700;">$${data.spent.toLocaleString()}</span>
        </div>
        <div class="progress-bar-bg">
          <div style="height:8px;border-radius:4px;width:${Math.min(data.budgetPct, 100)}%;background:${data.budgetPct > 95 ? "#f87171" : "#f59e0b"};"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#475569;margin-top:4px;">
          <span>${data.budgetPct}% ejecutado</span>
          <span>Total: $${data.total.toLocaleString()}</span>
        </div>
      </div>

      <a href="${data.initiativeUrl}" class="btn">Revisar iniciativa →</a>
    </div>
  `, `${data.initiativeCode} al ${data.budgetPct}% del presupuesto`);

  await transport.sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: data.to,
    subject: `💰 Alerta: ${data.initiativeCode} al ${data.budgetPct}% del presupuesto`,
    html,
  });
}
