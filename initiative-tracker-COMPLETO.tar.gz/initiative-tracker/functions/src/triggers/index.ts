import * as functions from "firebase-functions/v2/firestore";
import * as admin from "firebase-admin";
import {
  sendTaskAssigned,
  sendStatusChanged,
  sendBudgetAlert,
} from "../integrations/emailService";

const db = admin.firestore();
const APP_URL = process.env.APP_URL || "https://initiative-tracker.web.app";

// ─── TASK WRITE: Recalc progress + notify assignee ───────────────────────────

export const onTaskWrite = functions.onDocumentWritten(
  "initiatives/{initiativeId}/tasks/{taskId}",
  async (event) => {
    const initiativeId = event.params.initiativeId;
    const before = event.data?.before?.data();
    const after = event.data?.after?.data();

    // 1. Recalculate initiative progress from root tasks
    const rootTasksSnap = await db
      .collection("initiatives").doc(initiativeId)
      .collection("tasks")
      .get();

    const rootTasks = rootTasksSnap.docs.filter(d => !d.data().parentTaskId);

    if (rootTasks.length > 0) {
      const avg = rootTasks.reduce((s, d) => s + (d.data().progress || 0), 0) / rootTasks.length;
      await db.collection("initiatives").doc(initiativeId).update({
        progress: Math.round(avg),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }

    // 2. Notify new assignee if assigneeId changed
    if (!after || before?.assigneeId === after.assigneeId) return;
    const assigneeId = after.assigneeId as string;
    if (!assigneeId) return;

    const [assigneeDoc, iniDoc] = await Promise.all([
      db.collection("users").doc(assigneeId).get(),
      db.collection("initiatives").doc(initiativeId).get(),
    ]);

    if (!assigneeDoc.exists || !iniDoc.exists) return;

    const assignee = assigneeDoc.data() as { name: string; email: string };
    const ini = iniDoc.data() as { code: string; title: string };

    // In-app notification
    await db.collection("notifications").doc(assigneeId).collection("items").add({
      type: "info",
      title: "Nueva tarea asignada",
      body: `Se te asignó: "${after.title}" en ${ini.code}`,
      entityType: "task",
      entityId: event.params.taskId,
      read: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Email notification
    try {
      let assignedByName = "Sistema";
      if (before?.assigneeId) {
        const prevDoc = await db.collection("users").doc(before.assigneeId).get();
        if (prevDoc.exists) assignedByName = (prevDoc.data() as { name: string }).name;
      }

      await sendTaskAssigned({
        to: assignee.email,
        userName: assignee.name,
        taskTitle: after.title as string,
        initiativeCode: ini.code,
        initiativeTitle: ini.title,
        assignedBy: assignedByName,
        dueDate: after.dueDate ? (after.dueDate as admin.firestore.Timestamp).toDate().toLocaleDateString("es-SV") : undefined,
        initiativeUrl: `${APP_URL}/dashboard/initiatives/${initiativeId}`,
      });
    } catch (err) {
      console.warn("Email send failed (task assigned):", err);
    }
  }
);

// ─── INITIATIVE WRITE: Notify on status change ───────────────────────────────

export const onInitiativeWrite = functions.onDocumentWritten(
  "initiatives/{initiativeId}",
  async (event) => {
    const before = event.data?.before?.data();
    const after = event.data?.after?.data();
    if (!after || !before) return;

    // Status changed
    if (before.status !== after.status) {
      const members: string[] = after.members || [];
      const statusLabels: Record<string, string> = {
        active: "Activa", on_hold: "En pausa", completed: "Completada",
        cancelled: "Cancelada", draft: "Borrador",
      };

      // In-app notifications (batch)
      const batch = db.batch();
      for (const uid of members) {
        const ref = db.collection("notifications").doc(uid).collection("items").doc();
        batch.set(ref, {
          type: after.status === "completed" ? "success" : after.status === "cancelled" ? "error" : "info",
          title: "Estado de iniciativa actualizado",
          body: `${after.code} — ${after.title}: ${statusLabels[before.status]} → ${statusLabels[after.status]}`,
          entityType: "initiative",
          entityId: event.params.initiativeId,
          read: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();

      // Email to members
      try {
        const memberEmails: string[] = [];
        for (const uid of members) {
          const userDoc = await db.collection("users").doc(uid).get();
          if (userDoc.exists) memberEmails.push((userDoc.data() as { email: string }).email);
        }

        const changedByDoc = await db.collection("users").doc(after.createdBy as string).get();
        const changedBy = changedByDoc.exists ? (changedByDoc.data() as { name: string }).name : "Sistema";

        await sendStatusChanged({
          to: memberEmails,
          userName: changedBy,
          initiativeCode: after.code as string,
          initiativeTitle: after.title as string,
          oldStatus: before.status as string,
          newStatus: after.status as string,
          initiativeUrl: `${APP_URL}/dashboard/initiatives/${event.params.initiativeId}`,
        });
      } catch (err) {
        console.warn("Email send failed (status changed):", err);
      }
    }

    // Budget alert: crossed 85% threshold
    const budgetBefore = before.budget > 0 ? (before.budgetSpent / before.budget) : 0;
    const budgetAfter = after.budget > 0 ? (after.budgetSpent / after.budget) : 0;
    if (budgetBefore < 0.85 && budgetAfter >= 0.85 && after.status === "active") {
      // In-app
      await db.collection("notifications").doc(after.leaderId as string).collection("items").add({
        type: "warning",
        title: "Alerta de presupuesto",
        body: `${after.code} ha consumido el ${Math.round(budgetAfter * 100)}% del presupuesto`,
        entityType: "initiative",
        entityId: event.params.initiativeId,
        read: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // Email
      try {
        const leaderDoc = await db.collection("users").doc(after.leaderId as string).get();
        if (leaderDoc.exists) {
          const leader = leaderDoc.data() as { email: string };
          await sendBudgetAlert({
            to: leader.email,
            initiativeCode: after.code as string,
            initiativeTitle: after.title as string,
            budgetPct: Math.round(budgetAfter * 100),
            spent: after.budgetSpent as number,
            total: after.budget as number,
            initiativeUrl: `${APP_URL}/dashboard/initiatives/${event.params.initiativeId}`,
          });
        }
      } catch (err) {
        console.warn("Email send failed (budget alert):", err);
      }
    }
  }
);
