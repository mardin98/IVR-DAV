import * as admin from "firebase-admin";
if (!admin.apps.length) admin.initializeApp();

export { onTaskWrite, onInitiativeWrite } from "./triggers";
export { cronDailyOverdueCheck, cronWeeklyReport, cronMonthlyBudgetReport } from "./scheduled";

import * as https from "firebase-functions/v2/https";
import { defineSecret, defineString } from "firebase-functions/params";
import {
  createInitiativeDriveFolder,
  createInitiativeCalendarEvent,
  updateInitiativeCalendarEvent,
  deleteInitiativeCalendarEvent,
} from "./integrations/googleWorkspace";
import { generateInitiativeReportPDF, uploadPDFToDrive } from "./integrations/pdfReport";

const SMTP_PASSWORD = defineSecret("SMTP_PASSWORD");
const DRIVE_PARENT_FOLDER = defineString("DRIVE_PARENT_FOLDER_ID", { default: "" });

export const createDriveFolder = https.onCall(
  { secrets: [SMTP_PASSWORD], memory: "256MiB" },
  async (request) => {
    if (!request.auth) throw new https.HttpsError("unauthenticated", "Login required");
    const { initiativeId, code, title } = request.data as { initiativeId: string; code: string; title: string; };
    try {
      return await createInitiativeDriveFolder(initiativeId, code, title);
    } catch (err: unknown) {
      throw new https.HttpsError("internal", err instanceof Error ? err.message : "Drive error");
    }
  }
);

export const createCalendarEvent = https.onCall(
  { memory: "256MiB" },
  async (request) => {
    if (!request.auth) throw new https.HttpsError("unauthenticated", "Login required");
    const { initiativeId, title, dueDate, leaderEmail, memberEmails } = request.data as {
      initiativeId: string; title: string; dueDate: string; leaderEmail: string; memberEmails?: string[];
    };
    try {
      return await createInitiativeCalendarEvent(initiativeId, title, dueDate, leaderEmail, memberEmails ?? []);
    } catch (err: unknown) {
      throw new https.HttpsError("internal", err instanceof Error ? err.message : "Calendar error");
    }
  }
);

export const updateCalendarEvent = https.onCall(
  { memory: "256MiB" },
  async (request) => {
    if (!request.auth) throw new https.HttpsError("unauthenticated", "Login required");
    const { eventId, newDueDate, leaderEmail } = request.data as { eventId: string; newDueDate: string; leaderEmail: string; };
    try {
      await updateInitiativeCalendarEvent(eventId, newDueDate, leaderEmail);
      return { success: true };
    } catch (err: unknown) {
      throw new https.HttpsError("internal", err instanceof Error ? err.message : "Calendar update error");
    }
  }
);

export const deleteCalendarEvent = https.onCall(
  { memory: "256MiB" },
  async (request) => {
    if (!request.auth) throw new https.HttpsError("unauthenticated", "Login required");
    const { eventId, leaderEmail } = request.data as { eventId: string; leaderEmail: string; };
    try {
      await deleteInitiativeCalendarEvent(eventId, leaderEmail);
      return { success: true };
    } catch (err: unknown) {
      throw new https.HttpsError("internal", err instanceof Error ? err.message : "Calendar delete error");
    }
  }
);

export const generateReportPDF = https.onCall(
  { memory: "512MiB", timeoutSeconds: 120 },
  async (request) => {
    if (!request.auth) throw new https.HttpsError("unauthenticated", "Login required");
    const { filters, saveToDrive } = request.data as {
      filters?: { status?: string[]; category?: string[]; leaderId?: string; };
      saveToDrive?: boolean;
    };
    const db = admin.firestore();
    const userDoc = await db.collection("users").doc(request.auth.uid).get();
    const generatedBy = userDoc.exists ? (userDoc.data() as { name: string }).name : request.auth.uid;
    try {
      const pdfBuffer = await generateInitiativeReportPDF(filters ?? {}, generatedBy);
      if (!saveToDrive) {
        return {
          base64: pdfBuffer.toString("base64"),
          fileName: `reporte-iniciativas-${new Date().toISOString().split("T")[0]}.pdf`,
        };
      }
      const fileName = `Reporte Iniciativas ${new Date().toLocaleDateString("es-SV")}.pdf`;
      const { fileId, webViewLink } = await uploadPDFToDrive(pdfBuffer, fileName, DRIVE_PARENT_FOLDER.value() || undefined);
      return { driveFileId: fileId, webViewLink };
    } catch (err: unknown) {
      throw new https.HttpsError("internal", err instanceof Error ? err.message : "PDF error");
    }
  }
);
