import * as scheduler from "firebase-functions/v2/scheduler";
import * as admin from "firebase-admin";
import { sendOverdueTasks, sendWeeklyReport } from "../integrations/emailService";
import { differenceInDays } from "date-fns";

const db = admin.firestore();
const APP_URL = process.env.APP_URL || "https://initiative-tracker.web.app";
const TZ = "America/El_Salvador";

// ─── DAILY: 8:00 AM — Overdue tasks + budget alerts ─────────────────────────

export const cronDailyOverdueCheck = scheduler.onSchedule(
  { schedule: "0 8 * * *", timeZone: TZ, memory: "256MiB" },
  async () => {
    const now = admin.firestore.Timestamp.now();
    console.log("[cron:daily] Starting overdue check");

    // Find all overdue incomplete tasks
    const tasksSnap = await db.collectionGroup("tasks")
      .where("status", "in", ["todo", "in_progress", "blocked"])
      .where("dueDate", "<", now)
      .get();

    // Group by assignee
    const byAssignee: Record<string, { title: string; initiativeCode: string; dueDate: string }[]> = {};

    for (const taskDoc of tasksSnap.docs) {
      const task = taskDoc.data();
      const initiativeId = taskDoc.ref.parent.parent?.id;
      if (!initiativeId || !task.assigneeId) continue;

      const iniDoc = await db.collection("initiatives").doc(initiativeId).get();
      if (!iniDoc.exists) continue;
      const ini = iniDoc.data()!;
      if (ini.status === "completed" || ini.status === "cancelled") continue;

      const assigneeId = task.assigneeId as string;
      if (!byAssignee[assigneeId]) byAssignee[assigneeId] = [];

      byAssignee[assigneeId].push({
        title: task.title as string,
        initiativeCode: ini.code as string,
        dueDate: (task.dueDate as admin.firestore.Timestamp).toDate().toLocaleDateString("es-SV"),
      });

      // In-app notification
      await db.collection("notifications").doc(assigneeId).collection("items").add({
        type: "warning",
        title: "Tarea vencida",
        body: `${ini.code} › "${task.title}" sigue pendiente`,
        entityType: "task",
        entityId: taskDoc.id,
        read: false,
        createdAt: now,
      });
    }

    // Send one consolidated email per assignee
    for (const [uid, tasks] of Object.entries(byAssignee)) {
      const userDoc = await db.collection("users").doc(uid).get();
      if (!userDoc.exists) continue;
      const user = userDoc.data() as { name: string; email: string };
      try {
        await sendOverdueTasks({
          to: user.email,
          userName: user.name,
          tasks,
          appUrl: APP_URL,
        });
      } catch (err) {
        console.warn(`Email failed for ${user.email}:`, err);
      }
    }

    console.log(`[cron:daily] Processed ${tasksSnap.size} overdue tasks across ${Object.keys(byAssignee).length} users`);
  }
);

// ─── WEEKLY: Monday 7:00 AM — Executive summary ──────────────────────────────

export const cronWeeklyReport = scheduler.onSchedule(
  { schedule: "0 7 * * 1", timeZone: TZ, memory: "256MiB" },
  async () => {
    console.log("[cron:weekly] Generating weekly report");

    const [iniSnap, usersSnap] = await Promise.all([
      db.collection("initiatives").get(),
      db.collection("users")
        .where("globalRole", "in", ["admin", "leader"])
        .where("active", "==", true)
        .get(),
    ]);

    const all = iniSnap.docs.map(d => ({ id: d.id, ...d.data() })) as any[];
    const active = all.filter((i: any) => i.status === "active");

    // Count overdue tasks
    const now = admin.firestore.Timestamp.now();
    const overdueSnap = await db.collectionGroup("tasks")
      .where("status", "in", ["todo", "in_progress", "blocked"])
      .where("dueDate", "<", now).get();

    const stats = {
      activeCount: active.length,
      completedCount: all.filter((i: any) => i.status === "completed").length,
      avgProgress: active.length
        ? Math.round(active.reduce((s: number, i: any) => s + (i.progress || 0), 0) / active.length)
        : 0,
      overdueTasksCount: overdueSnap.size,
      totalBudget: all.reduce((s: number, i: any) => s + (i.budget || 0), 0),
      totalSpent: all.reduce((s: number, i: any) => s + (i.budgetSpent || 0), 0),
    };

    const topInitiatives = active
      .sort((a: any, b: any) => {
        const pa = { critical: 0, high: 1, medium: 2, low: 3 };
        return (pa[a.priority as keyof typeof pa] || 2) - (pa[b.priority as keyof typeof pa] || 2);
      })
      .slice(0, 6)
      .map((i: any) => ({
        code: i.code,
        title: i.title,
        progress: i.progress || 0,
        status: i.status,
        daysLeft: i.dueDate
          ? differenceInDays(i.dueDate.toDate(), new Date())
          : 999,
      }));

    // Send to each admin/leader
    for (const userDoc of usersSnap.docs) {
      const user = userDoc.data() as { name: string; email: string };
      try {
        await sendWeeklyReport({
          to: user.email,
          userName: user.name,
          stats,
          topInitiatives,
          appUrl: APP_URL,
        });

        // In-app notification too
        await db.collection("notifications").doc(userDoc.id).collection("items").add({
          type: "info",
          title: "Resumen semanal disponible",
          body: `${active.length} activas · ${stats.avgProgress}% avance promedio · ${overdueSnap.size} tareas vencidas`,
          read: false,
          createdAt: now,
        });
      } catch (err) {
        console.warn(`Weekly report email failed for ${user.email}:`, err);
      }
    }

    console.log(`[cron:weekly] Sent to ${usersSnap.size} recipients`);
  }
);

// ─── MONTHLY: 1st of month 9:00 AM — Budget report ──────────────────────────

export const cronMonthlyBudgetReport = scheduler.onSchedule(
  { schedule: "0 9 1 * *", timeZone: TZ, memory: "256MiB" },
  async () => {
    console.log("[cron:monthly] Budget report");
    const now = admin.firestore.Timestamp.now();

    const activeSnap = await db.collection("initiatives")
      .where("status", "==", "active").get();

    const adminsSnap = await db.collection("users")
      .where("globalRole", "==", "admin")
      .where("active", "==", true).get();

    // Notify admins about high-budget initiatives
    const highBudget = activeSnap.docs
      .map(d => ({ id: d.id, ...d.data() }) as any)
      .filter((i: any) => i.budget > 0 && (i.budgetSpent / i.budget) > 0.7);

    for (const adminDoc of adminsSnap.docs) {
      await db.collection("notifications").doc(adminDoc.id).collection("items").add({
        type: highBudget.length > 0 ? "warning" : "info",
        title: "Reporte mensual de presupuesto",
        body: `${highBudget.length} iniciativa${highBudget.length !== 1 ? "s" : ""} con más del 70% del presupuesto ejecutado`,
        read: false,
        createdAt: now,
      });
    }

    console.log(`[cron:monthly] ${highBudget.length} high-budget initiatives flagged`);
  }
);
