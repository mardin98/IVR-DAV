"use client";

import { useState } from "react";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import { generateReportPDF } from "@/lib/integrations/googleWorkspace";
import {
  INITIATIVE_STATUS, CATEGORY_CONFIG, PRIORITY_CONFIG,
  budgetPct, budgetColor, progressColor, fmtDate,
} from "@/lib/utils";
import { InitiativeStatus, InitiativeCategory } from "@/types";
import { Button, Spinner, SectionTitle, Card } from "@/components/ui";
import toast from "react-hot-toast";

export default function ReportsPage() {
  const { initiatives, loading } = useInitiatives();
  const { isLeader } = useAuth();
  const [generating, setGenerating] = useState(false);

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300 }}>
      <Spinner size={28} />
    </div>
  );

  const active = initiatives.filter(i => i.status === "active");
  const completed = initiatives.filter(i => i.status === "completed");
  const totalBudget = initiatives.reduce((s, i) => s + (i.budget || 0), 0);
  const totalSpent = initiatives.reduce((s, i) => s + (i.budgetSpent || 0), 0);

  // By status
  const byStatus = Object.entries(
    initiatives.reduce((a: Record<string, number>, i) => { a[i.status] = (a[i.status] || 0) + 1; return a; }, {})
  );

  // By category
  const byCategory = Object.entries(
    initiatives.reduce((a: Record<string, number>, i) => { a[i.category] = (a[i.category] || 0) + 1; return a; }, {})
  );

  // By priority
  const byPriority = Object.entries(
    initiatives.filter(i => i.status === "active").reduce((a: Record<string, number>, i) => {
      a[i.priority] = (a[i.priority] || 0) + 1; return a;
    }, {})
  );

  const handleGeneratePDF = async () => {
    setGenerating(true);
    try {
      const result = await generateReportPDF({});
      toast.success("📄 Reporte generado en Drive");
      window.open(result.webViewLink, "_blank");
    } catch {
      toast.error("Error generando reporte — verifica la integración Drive");
    } finally {
      setGenerating(false);
    }
  };

  const BarChart = ({ data, colors }: { data: [string, number][]; colors: Record<string, string> }) => {
    const max = Math.max(...data.map(([, v]) => v), 1);
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {data.map(([k, v]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 12, color: colors[k] || "#64748b", minWidth: 8, flexShrink: 0 }}>●</span>
            <span style={{ fontSize: 12, color: "#94a3b8", width: 110, flexShrink: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {INITIATIVE_STATUS[k as InitiativeStatus]?.label || CATEGORY_CONFIG[k as InitiativeCategory]?.label || PRIORITY_CONFIG[k as keyof typeof PRIORITY_CONFIG]?.label || k}
            </span>
            <div style={{ flex: 1, height: 8, background: "rgba(255,255,255,0.06)", borderRadius: 4 }}>
              <div style={{ height: "100%", width: `${(v / max) * 100}%`, borderRadius: 4, background: colors[k] || "#64748b", transition: "width 0.6s" }} />
            </div>
            <span style={{ fontSize: 12, color: "#475569", minWidth: 20, textAlign: "right" }}>{v}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 12, color: "#334155", marginBottom: 4 }}>AI & Automations › <span style={{ color: "#22d3ee" }}>Reportes</span></div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: "#f1f5f9" }}>Reportes & Analytics</h1>
        </div>
        {isLeader && (
          <Button variant="primary" onClick={handleGeneratePDF} disabled={generating}>
            {generating ? "Generando…" : "📄 Exportar PDF a Drive"}
          </Button>
        )}
      </div>

      {/* KPI Summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 14 }}>
        {[
          { label: "Total iniciativas", value: initiatives.length, color: "#f1f5f9" },
          { label: "Activas", value: active.length, color: "#22d3ee" },
          { label: "Completadas", value: completed.length, color: "#4ade80" },
          { label: "Avance promedio", value: `${active.length ? Math.round(active.reduce((s, i) => s + i.progress, 0) / active.length) : 0}%`, color: "#a78bfa" },
        ].map((k, i) => (
          <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "16px 20px" }}>
            <div style={{ fontSize: 11, color: "#475569", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontSize: 30, fontWeight: 800, color: k.color, fontFamily: "var(--font-space-mono, monospace)" }}>{k.value}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "18px 20px" }}>
          <SectionTitle>Por estado</SectionTitle>
          <BarChart data={byStatus}
            colors={{ active: "#22d3ee", draft: "#64748b", on_hold: "#f59e0b", completed: "#4ade80", cancelled: "#f87171" }} />
        </div>
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "18px 20px" }}>
          <SectionTitle>Por categoría</SectionTitle>
          <BarChart data={byCategory}
            colors={{ ai: "#a78bfa", automation: "#22d3ee", infra: "#4ade80", process: "#f59e0b" }} />
        </div>
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "18px 20px" }}>
          <SectionTitle>Prioridad (activas)</SectionTitle>
          <BarChart data={byPriority}
            colors={{ critical: "#f87171", high: "#fb923c", medium: "#facc15", low: "#4ade80" }} />
        </div>
      </div>

      {/* Budget breakdown */}
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "20px 22px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <SectionTitle>Ejecución presupuestaria</SectionTitle>
          <div style={{ display: "flex", gap: 20, fontSize: 13 }}>
            <span style={{ color: "#475569" }}>Total: <span style={{ color: "#f1f5f9", fontWeight: 700, fontFamily: "var(--font-space-mono, monospace)" }}>${(totalBudget / 1000).toFixed(1)}k</span></span>
            <span style={{ color: "#475569" }}>Ejecutado: <span style={{ color: "#f59e0b", fontWeight: 700, fontFamily: "var(--font-space-mono, monospace)" }}>${(totalSpent / 1000).toFixed(1)}k</span></span>
            <span style={{ color: "#475569" }}>Disponible: <span style={{ color: "#4ade80", fontWeight: 700, fontFamily: "var(--font-space-mono, monospace)" }}>${((totalBudget - totalSpent) / 1000).toFixed(1)}k</span></span>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {initiatives.filter(i => i.status !== "completed" && i.budget > 0).map(ini => {
            const bp = budgetPct(ini.budgetSpent, ini.budget);
            const bc = budgetColor(ini.budgetSpent, ini.budget);
            return (
              <div key={ini.id} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: 11, color: "#22d3ee", fontFamily: "var(--font-space-mono, monospace)", width: 60, flexShrink: 0 }}>{ini.code}</span>
                <span style={{ fontSize: 12, color: "#64748b", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ini.title}</span>
                <div style={{ width: 140, height: 5, background: "rgba(255,255,255,0.06)", borderRadius: 4, flexShrink: 0 }}>
                  <div style={{ height: "100%", width: `${bp}%`, borderRadius: 4, background: bc, transition: "width 0.5s" }} />
                </div>
                <span style={{ fontSize: 12, color: bc, minWidth: 36, textAlign: "right", fontWeight: 600 }}>{bp}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Progress overview */}
      <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "20px 22px" }}>
        <SectionTitle>Avance por iniciativa (activas)</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {active.sort((a, b) => b.progress - a.progress).map(ini => {
            const pc = progressColor(ini.progress);
            return (
              <div key={ini.id} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: 11, color: "#22d3ee", fontFamily: "var(--font-space-mono, monospace)", width: 60, flexShrink: 0 }}>{ini.code}</span>
                <span style={{ fontSize: 12, color: "#64748b", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ini.title}</span>
                <div style={{ width: 200, height: 6, background: "rgba(255,255,255,0.06)", borderRadius: 4, flexShrink: 0 }}>
                  <div style={{ height: "100%", width: `${ini.progress}%`, borderRadius: 4, background: pc, transition: "width 0.5s" }} />
                </div>
                <span style={{ fontSize: 12, color: pc, minWidth: 36, textAlign: "right", fontWeight: 700 }}>{ini.progress}%</span>
                <span style={{ fontSize: 11, color: "#334155", minWidth: 80, textAlign: "right" }}>Vence {fmtDate(ini.dueDate)}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scheduled reports */}
      {isLeader && (
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "20px 22px" }}>
          <SectionTitle>Reportes programados</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {[
              { name: "Resumen ejecutivo semanal", freq: "Lunes 7:00 AM", to: "liderazgo@davivienda.com.sv", active: true },
              { name: "Alertas de tareas vencidas", freq: "Diario 8:00 AM", to: "líderes de iniciativa", active: true },
              { name: "Reporte de presupuesto mensual", freq: "1° de cada mes", to: "admin@davivienda.com.sv", active: false },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0",
                borderBottom: i < 2 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: r.active ? "#4ade80" : "#334155", flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "#e2e8f0" }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: "#475569" }}>{r.freq} · {r.to}</div>
                </div>
                <Button size="sm" variant="ghost">Editar</Button>
              </div>
            ))}
          </div>
          <button style={{ marginTop: 12, padding: "8px 16px", background: "rgba(34,211,238,0.06)",
            border: "1px dashed rgba(34,211,238,0.3)", borderRadius: 10, color: "#22d3ee",
            fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>
            + Nuevo reporte programado
          </button>
        </div>
      )}
    </div>
  );
}
