"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import {
  INITIATIVE_STATUS, PRIORITY_CONFIG, CATEGORY_CONFIG,
  progressColor, budgetPct, budgetColor, fmtDate, daysLeftLabel,
} from "@/lib/utils";
import { Initiative, InitiativeStatus, InitiativePriority, InitiativeCategory } from "@/types";
import { StatusBadge, PriorityBadge, CategoryChip, ProgressRing, Button, Spinner, EmptyState } from "@/components/ui";
import toast from "react-hot-toast";

type SortKey = "priority" | "progress" | "due" | "created";

const PRIORITY_ORDER: Record<InitiativePriority, number> = { critical: 0, high: 1, medium: 2, low: 3 };

export default function InitiativesPage() {
  const { isLeader } = useAuth();
  const { initiatives, loading, changeStatus } = useInitiatives();
  const router = useRouter();
  const [filterStatus, setFilterStatus] = useState<InitiativeStatus | "all">("all");
  const [filterCat, setFilterCat] = useState<InitiativeCategory | "all">("all");
  const [sort, setSort] = useState<SortKey>("priority");
  const [search, setSearch] = useState("");

  const filtered = initiatives
    .filter(i => filterStatus === "all" || i.status === filterStatus)
    .filter(i => filterCat === "all" || i.category === filterCat)
    .filter(i => !search || i.title.toLowerCase().includes(search.toLowerCase()) || i.code.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === "priority") return PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
      if (sort === "progress") return b.progress - a.progress;
      if (sort === "due") return (a.dueDate?.seconds ?? 0) - (b.dueDate?.seconds ?? 0);
      return (b.createdAt?.seconds ?? 0) - (a.createdAt?.seconds ?? 0);
    });

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300 }}>
      <Spinner size={28} />
    </div>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 12, color: "#334155", marginBottom: 4 }}>AI & Automations › <span style={{ color: "#22d3ee" }}>Iniciativas</span></div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: "#f1f5f9" }}>Iniciativas</h1>
        </div>
        {isLeader && (
          <Button variant="primary" onClick={() => router.push("/dashboard/initiatives/new")}>
            + Nueva iniciativa
          </Button>
        )}
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        {/* Search */}
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Buscar por código o título…"
          style={{ width: 240, padding: "7px 12px", fontSize: 13 }} />

        {/* Status filter */}
        <div style={{ display: "flex", gap: 2, background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: 3 }}>
          {([["all", "Todas"], ["active", "Activas"], ["on_hold", "Pausa"], ["completed", "Completadas"], ["draft", "Borrador"]] as [string, string][]).map(([k, v]) => (
            <button key={k} onClick={() => setFilterStatus(k as InitiativeStatus | "all")} style={{
              padding: "5px 12px", borderRadius: 8, border: "none", cursor: "pointer",
              background: filterStatus === k ? "rgba(34,211,238,0.15)" : "none",
              color: filterStatus === k ? "#22d3ee" : "#475569",
              fontSize: 12, fontWeight: filterStatus === k ? 700 : 500, fontFamily: "inherit",
            }}>{v}</button>
          ))}
        </div>

        {/* Category filter */}
        <select value={filterCat} onChange={e => setFilterCat(e.target.value as InitiativeCategory | "all")}
          style={{ width: "auto", padding: "7px 12px" }}>
          <option value="all">Todas las categorías</option>
          {Object.entries(CATEGORY_CONFIG).map(([k, v]) => (
            <option key={k} value={k}>{v.icon} {v.label}</option>
          ))}
        </select>

        {/* Sort */}
        <select value={sort} onChange={e => setSort(e.target.value as SortKey)}
          style={{ width: "auto", padding: "7px 12px", marginLeft: "auto" }}>
          <option value="priority">Prioridad</option>
          <option value="progress">Avance</option>
          <option value="due">Vencimiento</option>
          <option value="created">Más recientes</option>
        </select>
      </div>

      {/* Count */}
      <div style={{ fontSize: 12, color: "#334155" }}>
        {filtered.length} iniciativa{filtered.length !== 1 ? "s" : ""}
        {filterStatus !== "all" && ` · ${INITIATIVE_STATUS[filterStatus as InitiativeStatus]?.label}`}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <EmptyState icon="◈" title="Sin iniciativas"
          sub={search ? "Intenta con otro término de búsqueda" : "Aún no hay iniciativas en esta categoría"}
          action={isLeader ? (
            <Button variant="primary" onClick={() => router.push("/dashboard/initiatives/new")}>
              + Crear primera iniciativa
            </Button>
          ) : undefined} />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {filtered.map(ini => (
            <InitiativeCard key={ini.id} ini={ini} />
          ))}
        </div>
      )}
    </div>
  );
}

function InitiativeCard({ ini }: { ini: Initiative }) {
  const dl = daysLeftLabel(ini.dueDate);
  const bp = budgetPct(ini.budgetSpent, ini.budget);
  const bc = budgetColor(ini.budgetSpent, ini.budget);
  const doneTasks = 0; // Would need tasks count — simplified here
  const progColor = progressColor(ini.progress);

  return (
    <Link href={`/dashboard/initiatives/${ini.id}`} style={{ textDecoration: "none" }}>
      <div style={{
        background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)",
        borderRadius: 14, padding: "18px 22px", cursor: "pointer", transition: "all 0.15s",
      }}
        onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "#22d3ee33"; (e.currentTarget as HTMLDivElement).style.background = "rgba(34,211,238,0.04)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(255,255,255,0.07)"; (e.currentTarget as HTMLDivElement).style.background = "rgba(255,255,255,0.025)"; }}
      >
        <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, flexWrap: "wrap" }}>
              <span style={{ fontSize: 11, color: "#22d3ee", fontFamily: "var(--font-space-mono, monospace)", fontWeight: 700 }}>{ini.code}</span>
              <span style={{ fontSize: 15, fontWeight: 700, color: "#f1f5f9" }}>{ini.title}</span>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
              <StatusBadge status={ini.status} />
              <PriorityBadge priority={ini.priority} />
              <CategoryChip category={ini.category} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, maxWidth: 320 }}>
              <div style={{ flex: 1, height: 5, background: "rgba(255,255,255,0.07)", borderRadius: 4 }}>
                <div style={{ height: "100%", width: `${ini.progress}%`, borderRadius: 4, background: progColor, transition: "width 0.5s" }} />
              </div>
              <span style={{ fontSize: 12, color: "#64748b" }}>{ini.progress}%</span>
            </div>
            <div style={{ display: "flex", gap: 16, fontSize: 12, color: "#475569", flexWrap: "wrap" }}>
              <span style={{ color: dl.color }}>{dl.label}</span>
              <span>Vence {fmtDate(ini.dueDate)}</span>
              {ini.budget > 0 && <span style={{ color: bc }}>💰 {bp}% budget</span>}
            </div>
          </div>
          <ProgressRing pct={ini.progress} size={56} />
        </div>
      </div>
    </Link>
  );
}
