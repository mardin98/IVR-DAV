"use client";

import { useState, useEffect } from "react";
import { getAllUsers } from "@/lib/firestore/users";
import { User, TaskFormData, TaskStatus, InitiativePriority } from "@/types";
import { Button } from "@/components/ui";

interface Props {
  initiativeMembers: string[];
  parentTaskId?: string;
  initial?: Partial<TaskFormData>;
  onSubmit: (data: TaskFormData) => Promise<void>;
  onCancel: () => void;
  submitLabel?: string;
}

const STATUSES: { value: TaskStatus; label: string }[] = [
  { value: "todo", label: "Pendiente" },
  { value: "in_progress", label: "En progreso" },
  { value: "blocked", label: "Bloqueada" },
  { value: "review", label: "En revisión" },
  { value: "done", label: "Completada" },
];

const PRIORITIES: { value: InitiativePriority; label: string }[] = [
  { value: "critical", label: "Crítica" },
  { value: "high", label: "Alta" },
  { value: "medium", label: "Media" },
  { value: "low", label: "Baja" },
];

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label>{label}</label>{children}</div>;
}

export default function TaskForm({ initiativeMembers, parentTaskId, initial, onSubmit, onCancel, submitLabel = "Crear tarea" }: Props) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<TaskFormData>({
    title: initial?.title ?? "",
    description: initial?.description ?? "",
    assigneeId: initial?.assigneeId ?? "",
    status: initial?.status ?? "todo",
    priority: initial?.priority ?? "medium",
    progress: initial?.progress ?? 0,
    estimatedHours: initial?.estimatedHours ?? 0,
    dueDate: initial?.dueDate ?? "",
    parentTaskId: parentTaskId ?? initial?.parentTaskId,
  });

  useEffect(() => {
    getAllUsers().then(all => setUsers(all.filter(u => initiativeMembers.includes(u.id))));
  }, [initiativeMembers]);

  const set = (key: keyof TaskFormData, val: unknown) => setForm(p => ({ ...p, [key]: val }));

  const handleSubmit = async () => {
    if (!form.title || !form.assigneeId) return;
    setLoading(true);
    try { await onSubmit(form); } finally { setLoading(false); }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Field label={parentTaskId ? "Título de subtarea *" : "Título de tarea *"}>
        <input value={form.title} onChange={e => set("title", e.target.value)}
          placeholder={parentTaskId ? "Ej: Configurar webhook ESL" : "Ej: Integrar Gemini API"} />
      </Field>

      <Field label="Descripción">
        <textarea value={form.description ?? ""} onChange={e => set("description", e.target.value)}
          placeholder="Detalle adicional..." rows={2} style={{ resize: "vertical" }} />
      </Field>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Responsable *">
          <select value={form.assigneeId} onChange={e => set("assigneeId", e.target.value)}>
            <option value="">Seleccionar…</option>
            {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </Field>
        <Field label="Estado">
          <select value={form.status} onChange={e => set("status", e.target.value as TaskStatus)}>
            {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </Field>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Prioridad">
          <select value={form.priority} onChange={e => set("priority", e.target.value as InitiativePriority)}>
            {PRIORITIES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
          </select>
        </Field>
        <Field label="Horas estimadas">
          <input type="number" value={form.estimatedHours} onChange={e => set("estimatedHours", Number(e.target.value))} min="0" />
        </Field>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Fecha límite">
          <input type="date" value={form.dueDate ?? ""} onChange={e => set("dueDate", e.target.value)} />
        </Field>
        <Field label={`Avance: ${form.progress}%`}>
          <input type="range" value={form.progress} onChange={e => set("progress", Number(e.target.value))}
            min="0" max="100" step="5"
            style={{ background: "transparent", border: "none", padding: "8px 0", cursor: "pointer" }} />
        </Field>
      </div>

      <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 4,
        paddingTop: 14, borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <Button variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button variant="primary" onClick={handleSubmit} disabled={loading || !form.title || !form.assigneeId}>
          {loading ? "Guardando…" : submitLabel}
        </Button>
      </div>
    </div>
  );
}
