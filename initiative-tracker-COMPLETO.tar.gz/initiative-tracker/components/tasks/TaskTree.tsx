"use client";

import { useState } from "react";
import { Task, TaskStatus, User } from "@/types";
import { TASK_STATUS, PRIORITY_CONFIG, fmtDate, daysLeftLabel } from "@/lib/utils";
import { Avatar, TaskStatusBadge, ProgressBar, Button } from "@/components/ui";

interface Props {
  taskTree: Task[];
  users: User[];
  canEdit: boolean;
  onAddSubtask: (parentId: string) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onChangeStatus: (taskId: string, status: TaskStatus) => void;
  onChangeProgress: (taskId: string, progress: number) => void;
  onLogHours: (taskId: string) => void;
}

const NEXT_STATUS: Partial<Record<TaskStatus, TaskStatus>> = {
  todo: "in_progress",
  in_progress: "review",
  review: "done",
};

function TaskRow({ task, users, depth = 0, canEdit, onAddSubtask, onEditTask, onDeleteTask, onChangeStatus, onChangeProgress, onLogHours }: {
  task: Task; users: User[]; depth?: number; canEdit: boolean;
  onAddSubtask: (id: string) => void; onEditTask: (t: Task) => void;
  onDeleteTask: (id: string) => void; onChangeStatus: (id: string, s: TaskStatus) => void;
  onChangeProgress: (id: string, p: number) => void; onLogHours: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const [showActions, setShowActions] = useState(false);
  const assignee = users.find(u => u.id === task.assigneeId);
  const cfg = TASK_STATUS[task.status];
  const dl = daysLeftLabel(task.dueDate);
  const hasSubtasks = (task.subtasks?.length ?? 0) > 0;

  return (
    <div>
      <div
        style={{
          paddingLeft: depth * 24 + 12, paddingRight: 12, paddingTop: 12, paddingBottom: 12,
          borderBottom: "1px solid rgba(255,255,255,0.04)",
          background: depth > 0 ? "rgba(0,0,0,0.15)" : "transparent",
          transition: "background 0.1s",
        }}
        onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = depth > 0 ? "rgba(0,0,0,0.25)" : "rgba(255,255,255,0.02)"; setShowActions(true); }}
        onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = depth > 0 ? "rgba(0,0,0,0.15)" : "transparent"; setShowActions(false); }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {/* Expand toggle */}
          <button onClick={() => setExpanded(p => !p)} style={{
            width: 16, height: 16, background: "none", border: "none", cursor: "pointer",
            color: "#475569", fontSize: 9, padding: 0, flexShrink: 0,
            opacity: hasSubtasks ? 1 : 0, transition: "transform 0.2s",
            transform: expanded ? "rotate(90deg)" : "none",
          }}>▶</button>

          {/* Status dot */}
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: cfg?.color, flexShrink: 0,
            border: task.status === "done" ? "none" : `1.5px solid ${cfg?.color}`,
            boxShadow: task.status === "done" ? `0 0 6px ${cfg?.color}66` : "none",
          }} />

          {/* Title */}
          <span style={{
            flex: 1, fontSize: depth > 0 ? 13 : 14,
            color: task.status === "done" ? "#475569" : "#e2e8f0",
            fontWeight: depth > 0 ? 500 : 600,
            textDecoration: task.status === "done" ? "line-through" : "none",
          }}>{task.title}</span>

          {/* Meta */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
            {task.status !== "done" && canEdit && NEXT_STATUS[task.status] && showActions && (
              <Button size="sm" variant="ghost" onClick={() => onChangeStatus(task.id, NEXT_STATUS[task.status]!)}>
                → {TASK_STATUS[NEXT_STATUS[task.status]!]?.label}
              </Button>
            )}
            <TaskStatusBadge status={task.status} />
            {assignee && <Avatar name={assignee.name} size={22} photoURL={assignee.photoURL} />}
            {task.dueDate && (
              <span style={{ fontSize: 11, color: dl.color, minWidth: 80, textAlign: "right" }}>
                {fmtDate(task.dueDate)}
              </span>
            )}
            {task.estimatedHours > 0 && (
              <span style={{ fontSize: 11, color: "#475569", minWidth: 64, textAlign: "right" }}>
                {task.loggedHours}h/{task.estimatedHours}h
              </span>
            )}

            {/* Action menu */}
            {canEdit && showActions && (
              <div style={{ display: "flex", gap: 4 }}>
                {depth === 0 && (
                  <Button size="sm" variant="ghost" onClick={() => onAddSubtask(task.id)}>+ Sub</Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => onLogHours(task.id)}>⏱</Button>
                <Button size="sm" variant="ghost" onClick={() => onEditTask(task)}>✎</Button>
                <Button size="sm" variant="danger" onClick={() => onDeleteTask(task.id)}>✕</Button>
              </div>
            )}
          </div>
        </div>

        {/* Progress bar for root tasks */}
        {depth === 0 && task.estimatedHours > 0 && (
          <div style={{ paddingLeft: 34, marginTop: 8 }}>
            <ProgressBar pct={task.progress} height={3} maxWidth={200} />
          </div>
        )}
      </div>

      {/* Subtasks */}
      {expanded && hasSubtasks && task.subtasks!.map(st => (
        <TaskRow key={st.id} task={st} users={users} depth={depth + 1}
          canEdit={canEdit} onAddSubtask={onAddSubtask} onEditTask={onEditTask}
          onDeleteTask={onDeleteTask} onChangeStatus={onChangeStatus}
          onChangeProgress={onChangeProgress} onLogHours={onLogHours} />
      ))}
    </div>
  );
}

export default function TaskTree(props: Props) {
  if (props.taskTree.length === 0) return null;
  return (
    <div style={{ border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, overflow: "hidden" }}>
      {/* Header */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", padding: "10px 12px 10px 56px",
        borderBottom: "1px solid rgba(255,255,255,0.07)",
        fontSize: 11, color: "#334155", fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" }}>
        <span>Tarea</span>
        <div style={{ display: "flex", gap: 10, paddingRight: 4 }}>
          <span style={{ minWidth: 80, textAlign: "right" }}>Estado</span>
          <span style={{ minWidth: 22 }} />
          <span style={{ minWidth: 80, textAlign: "right" }}>Vence</span>
          <span style={{ minWidth: 64, textAlign: "right" }}>Horas</span>
        </div>
      </div>
      {props.taskTree.map(task => (
        <TaskRow key={task.id} task={task} {...props} depth={0} />
      ))}
    </div>
  );
}
