"use client";

import { useState, useEffect } from "react";
import { getAllUsers } from "@/lib/firestore/users";
import { User, InitiativeFormData, InitiativeStatus, InitiativePriority, InitiativeCategory } from "@/types";
import { Button } from "@/components/ui";
import { useAuth } from "@/lib/hooks/useAuth";

interface Props {
  initial?: Partial<InitiativeFormData>;
  onSubmit: (data: InitiativeFormData) => Promise<void>;
  onCancel: () => void;
  submitLabel?: string;
}

const STATUSES: { value: InitiativeStatus; label: string }[] = [
  { value: "draft", label: "Borrador" },
  { value: "active", label: "Activa" },
  { value: "on_hold", label: "En pausa" },
  { value: "completed", label: "Completada" },
  { value: "cancelled", label: "Cancelada" },
];

const PRIORITIES: { value: InitiativePriority; label: string }[] = [
  { value: "critical", label: "Crítica" },
  { value: "high", label: "Alta" },
  { value: "medium", label: "Media" },
  { value: "low", label: "Baja" },
];

const CATEGORIES: { value: InitiativeCategory; label: string; icon: string }[] = [
  { value: "ai", label: "Inteligencia Artificial", icon: "◈" },
  { value: "automation", label: "Automatización", icon: "⚙" },
  { value: "infra", label: "Infraestructura", icon: "⬡" },
  { value: "process", label: "Proceso", icon: "◎" },
];

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label>{label}</label>
      {children}
    </div>
  );
}

export default function InitiativeForm({ initial, onSubmit, onCancel, submitLabel = "Crear iniciativa" }: Props) {
  const { user, isAdmin, isLeader } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState<InitiativeFormData>({
    title: initial?.title ?? "",
    description: initial?.description ?? "",
    status: initial?.status ?? "draft",
    priority: initial?.priority ?? "medium",
    category: initial?.category ?? "automation",
    leaderId: initial?.leaderId ?? user?.id ?? "",
    startDate: initial?.startDate ?? new Date().toISOString().split("T")[0],
    dueDate: initial?.dueDate ?? "",
    budget: initial?.budget ?? 0,
  });

  useEffect(() => {
    getAllUsers().then(setUsers);
  }, []);

  const set = (key: keyof InitiativeFormData, val: unknown) =>
    setForm(p => ({ ...p, [key]: val }));

  const handleSubmit = async () => {
    if (!form.title || !form.dueDate || !form.leaderId) return;
    setLoading(true);
    try {
      await onSubmit(form);
    } finally {
      setLoading(false);
    }
  };

  const leaders = users.filter(u => u.globalRole === "admin" || u.globalRole === "leader");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <Field label="Título *">
        <input value={form.title} onChange={e => set("title", e.target.value)}
          placeholder="Ej: Call Manager AI — Módulo 4" />
      </Field>

      <Field label="Descripción">
        <textarea value={form.description} onChange={e => set("description", e.target.value)}
          placeholder="Describe el objetivo y alcance de la iniciativa..."
          rows={3} style={{ resize: "vertical" }} />
      </Field>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Estado">
          <select value={form.status} onChange={e => set("status", e.target.value as InitiativeStatus)}>
            {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </Field>
        <Field label="Prioridad">
          <select value={form.priority} onChange={e => set("priority", e.target.value as InitiativePriority)}>
            {PRIORITIES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
          </select>
        </Field>
      </div>

      <Field label="Categoría">
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {CATEGORIES.map(c => (
            <button key={c.value} onClick={() => set("category", c.value)} style={{
              padding: "8px 14px", borderRadius: 10, cursor: "pointer", fontFamily: "inherit",
              background: form.category === c.value ? "rgba(34,211,238,0.15)" : "rgba(255,255,255,0.04)",
              border: form.category === c.value ? "1px solid rgba(34,211,238,0.4)" : "1px solid rgba(255,255,255,0.08)",
              color: form.category === c.value ? "#22d3ee" : "#64748b",
              fontSize: 13, fontWeight: form.category === c.value ? 700 : 500, transition: "all 0.15s",
            }}>
              {c.icon} {c.label}
            </button>
          ))}
        </div>
      </Field>

      {(isAdmin || isLeader) && (
        <Field label="Líder *">
          <select value={form.leaderId} onChange={e => set("leaderId", e.target.value)}>
            <option value="">Seleccionar líder…</option>
            {leaders.map(u => (
              <option key={u.id} value={u.id}>{u.name} ({u.globalRole})</option>
            ))}
          </select>
        </Field>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Fecha de inicio *">
          <input type="date" value={form.startDate} onChange={e => set("startDate", e.target.value)} />
        </Field>
        <Field label="Fecha de vencimiento *">
          <input type="date" value={form.dueDate} onChange={e => set("dueDate", e.target.value)} />
        </Field>
      </div>

      <Field label="Presupuesto (USD)">
        <input type="number" value={form.budget} onChange={e => set("budget", Number(e.target.value))}
          placeholder="0" min="0" />
      </Field>

      <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8, paddingTop: 16,
        borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <Button variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button variant="primary" onClick={handleSubmit} disabled={loading || !form.title || !form.dueDate}>
          {loading ? "Guardando…" : submitLabel}
        </Button>
      </div>
    </div>
  );
}
