#!/usr/bin/env bash
#
# Arranque del repositorio de verificación biométrica.
#
# Crea la estructura del monorepo y coloca los archivos de contexto. Después
# de correrlo, abrí Claude Code en la raíz y empezá por la tarea 0.1 de
# docs/plan.md.
#
# Uso:
#   1. Copiá aquí: CLAUDE.md, plan.md, .spectral.yaml,
#      noBusinessVocabulary.js, openapi-verificacion-biometrica.yaml,
#      VerificacionBiometrica.jsx, diseno-biometria-reutilizable.md
#   2. bash bootstrap.sh identidad-biometrica

set -euo pipefail

REPO="${1:-identidad-biometrica}"
ORIGEN="$(pwd)"

echo "Creando $REPO"
mkdir -p "$REPO"
cd "$REPO"

# ── Estructura ───────────────────────────────────────────────────────────────

mkdir -p docs
mkdir -p packages/contracts/spectral-functions

mkdir -p packages/orchestrator/src/{api,domain,policy,ports,tokens,persistence/migrations,observability,config}
mkdir -p packages/orchestrator/src/adapters/{facephi,rnpn}
mkdir -p packages/orchestrator/test/{unit,contract,integration}

mkdir -p packages/biometria-web/src/{components,hooks,i18n}
mkdir -p packages/hosted/src

mkdir -p tools/rnpn-simulator

# ── Archivos de contexto ─────────────────────────────────────────────────────

copiar() {
  if [ -f "$ORIGEN/$1" ]; then
    cp "$ORIGEN/$1" "$2"
    echo "  ✓ $2"
  else
    echo "  ! falta $1 — copialo manualmente a $2"
  fi
}

echo "Colocando archivos de contexto"
copiar "CLAUDE.md" "CLAUDE.md"
copiar "plan.md" "docs/plan.md"
copiar "diseno-biometria-reutilizable.md" "docs/diseno.md"
copiar "openapi-verificacion-biometrica.yaml" "packages/contracts/openapi.yaml"
copiar ".spectral.yaml" "packages/contracts/.spectral.yaml"
copiar "noBusinessVocabulary.js" "packages/contracts/spectral-functions/noBusinessVocabulary.js"
copiar "VerificacionBiometrica.jsx" "packages/biometria-web/src/components/VerificacionBiometrica.jsx"

# ── Workspace ────────────────────────────────────────────────────────────────

cat > pnpm-workspace.yaml <<'EOF'
packages:
  - 'packages/*'
  - 'tools/*'
EOF

cat > package.json <<'EOF'
{
  "name": "identidad-biometrica",
  "private": true,
  "type": "module",
  "engines": { "node": ">=22" },
  "scripts": {
    "build": "pnpm -r build",
    "test": "pnpm -r test",
    "lint": "eslint . && pnpm lint:contract",
    "lint:contract": "spectral lint packages/contracts/openapi.yaml --ruleset packages/contracts/.spectral.yaml",
    "types:generate": "openapi-typescript packages/contracts/openapi.yaml -o packages/orchestrator/src/api/generated.ts",
    "dev": "pnpm --filter orchestrator dev"
  },
  "devDependencies": {
    "@stoplight/spectral-cli": "^6",
    "openapi-typescript": "^7",
    "typescript": "^5.6",
    "vitest": "^2",
    "eslint": "^9"
  }
}
EOF

cat > tsconfig.base.json <<'EOF'
{
  "compilerOptions": {
    "target": "ES2023",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "noImplicitOverride": true,
    "noFallthroughCasesInSwitch": true,
    "verbatimModuleSyntax": true,
    "skipLibCheck": true,
    "declaration": true,
    "sourceMap": true
  }
}
EOF

# ── Documento de supuestos del RNPN ──────────────────────────────────────────

cat > packages/orchestrator/src/adapters/rnpn/ASSUMPTIONS.md <<'EOF'
# Supuestos del adaptador RNPN

Este adaptador se construye contra supuestos mientras no tengamos la
especificación técnica del RNPN. Cada supuesto lleva el punto del código que
lo consume, para que ajustarlo sea localizable.

Al recibir la especificación real: confirmar o corregir cada línea, y actualizar
únicamente `mapper.ts`. Si el cambio obliga a tocar otro archivo, el aislamiento
del adaptador está mal hecho.

| # | Supuesto | Confirmado | Consumido en |
|---|---|---|---|
| 1 | Servicio sincrónico, respuesta en menos de 10 s | ☐ | `client.ts` |
| 2 | Autenticación por certificado cliente (mTLS) | ☐ | `client.ts` |
| 3 | Imagen JPEG, base64, sin cabecera MIME | ☐ | `mapper.ts` |
| 4 | Resolución mínima 480×640 | ☐ | `mapper.ts` |
| 5 | Se envía el DUI junto con la imagen | ☐ | `mapper.ts` |
| 6 | Devuelve booleano de coincidencia, no score | ☐ | `mapper.ts` |
| 7 | El umbral lo fija el RNPN, no es configurable | ☐ | `mapper.ts` |
| 8 | Distingue "no coincide" de "DUI no encontrado" | ☐ | `mapper.ts` |
| 9 | Tarifado por consulta, sin cargo si falla | ☐ | métricas de costo |
| 10 | Sin límite de tasa documentado | ☐ | `client.ts` |

## Preguntas para el RNPN

1. ¿Devuelve score de similitud o solo veredicto? Si es score, ¿podemos fijar umbral propio?
2. ¿Cómo se distingue "no coincide" de "DUI no existe" de "sin fotografía en el registro"?
3. ¿Qué pasa con fotografías antiguas en el registro? ¿Hay política de vigencia?
4. ¿Ambiente de certificación disponible? ¿Con qué datos de prueba?
5. ¿SLA de disponibilidad y de tiempo de respuesta?
6. ¿Límite de consultas por minuto o por día?
7. ¿Requisitos de conservación o de reporte de las consultas realizadas?
EOF

# ── Registro de decisiones ───────────────────────────────────────────────────

cat > docs/decisiones.md <<'EOF'
# Registro de decisiones

Una entrada por decisión que sea costosa de revertir. Formato corto a propósito:
contexto, decisión, consecuencia.

---

## D-001 — El servicio no conoce el proceso que lo invoca

**Contexto.** La biometría se necesita en apertura de cuenta, alta de SaaS,
reposición de clave y actualización de datos.

**Decisión.** El contrato no admite vocabulario de negocio. Lo único que
distingue un proceso de otro es `policyId`. La correlación con la transacción
del consumidor se hace con `clientReference`, opaco para este servicio.

**Consecuencia.** Agregar un proceso es agregar una política. A cambio, este
servicio nunca podrá resolver por sí solo un flujo completo de apertura: el
consumidor tiene que orquestar. Es el precio de la reutilización y lo pagamos
conscientemente.

---

## D-002 — El resultado se entrega como token firmado de un solo uso

**Contexto.** Varios procesos consumen el mismo servicio. Un resultado emitido
para uno no puede servir a otro.

**Decisión.** VRT con `azp` atado al `client_id` que abrió la sesión, `exp` de
15 minutos y `jti` de un solo uso.

**Consecuencia.** El consumidor debe canjear el resultado servidor a servidor y
validar la firma. No puede confiar en lo que le diga el frontend.

---

## D-003 — El registro civil tiene precedencia sobre el match documental

**Contexto.** FacePhi compara contra la foto del DUI; el RNPN contra el registro
civil. Pueden discrepar.

**Decisión.** RNPN negativo con documento positivo: rechazo. RNPN positivo con
documento negativo: revisión manual, no rechazo automático — es señal de
documento alterado, no de suplantación.

**Consecuencia.** Necesitamos cola de revisión manual desde v1. No es opcional.

---

## D-004 — (pendiente) Comportamiento con RNPN no disponible

**Contexto.** Si el RNPN cae, ¿qué hacemos con las verificaciones en curso?

**Opciones.** Rechazar / encolar y resolver después / aprobar con nivel
`SUBSTANTIAL` y revisión posterior.

**Estado.** Pendiente de decisión de negocio. Las tres rutas están implementadas
detrás de configuración; ninguna es default silencioso.
EOF

# ── .gitignore ───────────────────────────────────────────────────────────────

cat > .gitignore <<'EOF'
node_modules/
dist/
coverage/
*.log
.env
.env.*
!.env.example
.DS_Store
EOF

cat > .env.example <<'EOF'
# Nunca commitear valores reales.
NODE_ENV=development
PORT=8080

DATABASE_URL=postgresql://localhost:5432/identidad

# FacePhi — obtener del contrato, no de la documentación pública
FACEPHI_BASE_URL=
FACEPHI_API_KEY=

# RNPN — pendiente de especificación técnica
RNPN_BASE_URL=http://localhost:9090
RNPN_CLIENT_CERT_PATH=
RNPN_MODE=simulator

# Firma de VRT
VRT_ISSUER=https://identidad.banco.sv
VRT_SIGNING_KEY_ID=
VRT_TTL_SECONDS=900
EOF

echo ""
echo "Listo. Siguiente paso:"
echo ""
echo "  cd $REPO"
echo "  git init && git add -A && git commit -m 'Estructura inicial'"
echo "  claude"
echo ""
echo "Primer prompt sugerido:"
echo ""
echo "  Leé CLAUDE.md y docs/plan.md. Empezá por la tarea 0.1."
echo "  Antes de escribir código, mostrame el plan de la tarea y esperá aprobación."
echo ""
