# Registro de decisiones

Una entrada por decisión que sea costosa de revertir. Formato corto a propósito:
contexto, decisión, consecuencia.

---

## D-001 — El servicio no conoce el proceso que lo invoca

**Contexto.** La biometría se necesita en apertura de cuenta, alta de SaaS,
reposición de clave y actualización de datos.

**Decisión.** El contrato no admite vocabulario de negocio. Lo único que
distingue un proceso de otro es `policyId`. La correlación con la transacción
del consumidor se hace con `clientReference`, opaco para este servicio.

**Consecuencia.** Agregar un proceso es agregar una política. A cambio, este
servicio nunca podrá resolver por sí solo un flujo completo de apertura: el
consumidor tiene que orquestar. Es el precio de la reutilización y lo pagamos
conscientemente.

---

## D-002 — El resultado se entrega como token firmado de un solo uso

**Contexto.** Varios procesos consumen el mismo servicio. Un resultado emitido
para uno no puede servir a otro.

**Decisión.** VRT con `azp` atado al `client_id` que abrió la sesión, `exp` de
15 minutos y `jti` de un solo uso.

**Consecuencia.** El consumidor debe canjear el resultado servidor a servidor y
validar la firma. No puede confiar en lo que le diga el frontend.

---

## D-003 — El registro civil tiene precedencia sobre el match documental

**Contexto.** FacePhi compara contra la foto del DUI; el RNPN contra el registro
civil. Pueden discrepar.

**Decisión.** RNPN negativo con documento positivo: rechazo. RNPN positivo con
documento negativo: revisión manual, no rechazo automático — es señal de
documento alterado, no de suplantación.

**Consecuencia.** Necesitamos cola de revisión manual desde v1. No es opcional.

---

## D-004 — (pendiente) Comportamiento con RNPN no disponible

**Contexto.** Si el RNPN cae, ¿qué hacemos con las verificaciones en curso?

**Opciones.** Rechazar / encolar y resolver después / aprobar con nivel
`SUBSTANTIAL` y revisión posterior.

**Estado.** Pendiente de decisión de negocio. Las tres rutas están implementadas
detrás de configuración; ninguna es default silencioso.
