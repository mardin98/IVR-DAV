# Servicio de Verificación de Identidad Biométrica
## Diseño para reutilización entre procesos de negocio

---

## 1. La decisión central

El error que hace que un onboarding biométrico no se pueda reciclar es diseñarlo como **un paso dentro de la apertura de cuenta**. Cuando eso pasa, la API termina recibiendo `numeroCuenta`, `tipoProducto`, `agencia`, y ya no sirve para el SaaS.

La decisión aquí es la contraria: el servicio de biometría no sabe nada del proceso que lo invoca. Su contrato de entrada es *"verificá que esta persona es quien dice ser, con esta política"* y su contrato de salida es *"aquí está una identidad verificada firmada"*. Nada más.

El artefacto que hace esto posible es el **VRT (Verification Result Token)**: un JWT firmado por el servicio que declara qué se verificó, con qué nivel, y para quién. El proceso consumidor lo valida y sigue con su lógica de negocio.

```
Apertura de cuenta ─┐
Alta SaaS ──────────┤
Reposición de clave ─┼──► POST /verification-sessions ──► VRT ──► cada proceso sigue lo suyo
Actualización datos ─┤        (misma API, política distinta)
Firma de contrato ──┘
```

Lo único que cambia entre procesos es el `policyId`. No el código, no el endpoint, no el frontend.

---

## 2. Modelo de dominio

### Sesión de verificación

Es el objeto de primera clase. Tiene ciclo de vida propio, independiente de la transacción de negocio.

```
CREATED ──► CAPTURING ──► PROCESSING ──► VERIFIED
                │              │              
                │              ├──────────► REJECTED   (no pasó la política)
                │              └──────────► FAILED     (error técnico)
                └─────────────────────────► EXPIRED    (TTL vencido)
                └─────────────────────────► ABANDONED  (usuario canceló)
```

Campos que **sí** lleva la sesión:
- `policyId` — qué se le exige a esta verificación
- `clientId` — qué sistema la creó (del token OAuth)
- `clientReference` — el ID que el consumidor quiera correlacionar (opaco para nosotros)
- `subjectHint` — DUI declarado, si el proceso ya lo conoce (opcional)

Campos que **no** lleva: nada de producto, cuenta, monto, canal de venta. Si un consumidor necesita guardar eso, lo guarda de su lado y correlaciona por `clientReference`.

### Política de verificación

Configuración versionada, no código. Vive en base de datos o en un repo de configuración con su propio pipeline.

| policyId | Pasos | Umbral facial | RNPN | Nivel resultante |
|---|---|---|---|---|
| `apertura-cuenta-v1` | liveness + OCR DUI + match doc + cotejo RNPN | 0.85 | obligatorio | `HIGH` |
| `alta-saas-v1` | liveness + OCR DUI + match doc | 0.80 | no | `SUBSTANTIAL` |
| `step-up-v1` | liveness + 1:1 contra template enrolado | 0.85 | no | `SUBSTANTIAL` |
| `actualizacion-datos-v1` | liveness + cotejo RNPN | — | obligatorio | `HIGH` |

Agregar un proceso nuevo = agregar una fila. Ese es el criterio de éxito del diseño.

### VRT — Verification Result Token

```json
{
  "iss": "https://identidad.banco.sv",
  "aud": "apertura-cuenta-api",
  "azp": "apertura-cuenta-api",
  "sub": "vs_01HQZX8K3N4M5P6R7S8T9V",
  "iat": 1756512000,
  "exp": 1756512900,
  "jti": "vrt_01HQZX9M2P3Q4R5S6T7U8W",
  "verification": {
    "status": "VERIFIED",
    "level": "HIGH",
    "policyId": "apertura-cuenta-v1",
    "documentType": "DUI",
    "documentNumber": "01234567-8",
    "fullName": "NOMBRE APELLIDO",
    "dateOfBirth": "1990-05-14",
    "evidence": {
      "liveness": { "result": "LIVE", "provider": "facephi" },
      "documentMatch": { "result": "POSITIVE", "similarity": 0.9921 },
      "civilRegistryMatch": { "result": "POSITIVE", "provider": "rnpn" },
      "documentAuthenticity": { "result": "PASSED" }
    },
    "completedAt": "2026-08-30T14:22:03Z"
  }
}
```

Tres propiedades que lo hacen seguro de reciclar:

- **`azp` ata el resultado a quien abrió la sesión.** El proceso SaaS no puede tomar un VRT emitido para apertura de cuenta y presentarlo como propio.
- **`exp` corto (15 min).** Un VRT no es una credencial de larga vida; es la evidencia de que la verificación acaba de ocurrir.
- **`jti` de un solo uso.** El consumidor lo canjea una vez; el segundo intento se rechaza. Evita que una verificación abra dos cuentas.

Esto encaja con FAPI 2.0: el VRT se entrega sobre un canal *sender-constrained* (mTLS o DPoP), y la llamada servidor-a-servidor que lo obtiene usa la misma restricción.

---

## 3. Arquitectura

```
┌──────────────────────────────────────────────────────────────────┐
│  CONSUMIDORES (cada uno con su client_id)                        │
│  API Apertura Cuenta   API SaaS   Portal Web   App Móvil         │
└────────────┬─────────────────────────────────────────────────────┘
             │ 1. POST /verification-sessions  (OAuth, mTLS)
             │ 6. GET  /verification-sessions/{id}/result  ──► VRT
             ▼
┌──────────────────────────────────────────────────────────────────┐
│  APIGEE  ·  policy FAPI 2.0, rate limit, schema validation       │
└────────────┬─────────────────────────────────────────────────────┘
             ▼
┌──────────────────────────────────────────────────────────────────┐
│  ORQUESTADOR DE VERIFICACIÓN                                     │
│                                                                  │
│  ┌────────────┐  ┌─────────────┐  ┌──────────┐  ┌────────────┐   │
│  │  Sesiones  │  │   Motor de  │  │  Emisor  │  │  Custodia  │   │
│  │  (estado)  │  │   política  │  │   VRT    │  │ documental │   │
│  └────────────┘  └─────────────┘  └──────────┘  └────────────┘   │
│                                                                  │
│  ┌─────────────── Adaptadores (puertos de salida) ────────────┐  │
│  │  FacePhiAdapter          RnpnAdapter                       │  │
│  │  ports: LivenessProvider · DocumentProvider · MatchProvider│  │
│  └────────────────────────────────────────────────────────────┘  │
└──────┬───────────────────────────────────────┬───────────────────┘
       │ solo salida (política de red)         │ solo salida
       ▼                                       ▼
  FacePhi Identity API                    RNPN cotejo facial
```

**Puertos, no llamadas directas.** El motor de política habla contra interfaces (`LivenessProvider`, `FacialMatchProvider`, `CivilRegistryProvider`). FacePhi y el RNPN son implementaciones. Si mañana el banco cambia de proveedor de liveness, o el RNPN publica una v2, se cambia un adaptador y no se toca el orquestador ni el frontend.

**Restricción de red (solo conexiones salientes).** Ni FacePhi ni el RNPN pueden llamarte con un webhook. Todo lo externo se resuelve con polling desde el orquestador. Los webhooks que sí funcionan son los tuyos hacia los consumidores, porque viven dentro de la red.

Esto importa para el módulo de validación morfológica de documento (`Document validation Start` / `Status` / `Data`), que en FacePhi es asíncrono con polling — encaja bien con la restricción, pero mete latencia. Sugerencia: ejecutarlo en paralelo con el cotejo RNPN, no en serie.

---

## 4. Flujo detallado

```
Consumidor        Orquestador          Frontend           FacePhi        RNPN
    │                  │                   │                 │             │
    │─ POST session ──►│                   │                 │             │
    │                  │─ crea sesión      │                 │             │
    │◄─ sessionId +────│                   │                 │             │
    │   sessionToken   │                   │                 │             │
    │                  │                   │                 │             │
    │── pasa token ───────────────────────►│                 │             │
    │                  │                   │                 │             │
    │                  │◄─ GET /config ────│                 │             │
    │                  │─ sdkConfig ──────►│                 │             │
    │                  │                   │─ monta widget ─►│             │
    │                  │                   │◄─ bestImageToken│             │
    │                  │                   │   + docImages   │             │
    │                  │◄─ POST /captures ─│                 │             │
    │                  │                                     │             │
    │                  │─ /onboarding/v2/identity ───────────►│            │
    │                  │◄─ liveness + similarity ────────────│             │
    │                  │─ OCR extract ──────────────────────►│             │
    │                  │◄─ datos DUI ────────────────────────│             │
    │                  │─ cotejo facial (selfie + DUI) ────────────────────►│
    │                  │◄─ POSITIVE / NEGATIVE ─────────────────────────────│
    │                  │                                     │             │
    │                  │─ evalúa política                    │             │
    │                  │─ emite VRT                          │             │
    │                  │                   │                 │             │
    │                  │─ notifica ───────►│─ onComplete ───►│             │
    │◄─ GET /result ───│                                     │             │
    │   (VRT)          │                                     │             │
```

### Puntos donde hay que decidir

**El selfie que va al RNPN.** FacePhi devuelve `bestImageToken` (imagen tokenizada, cifrada). El RNPN va a querer una imagen abierta. Necesitás el endpoint `Detokenize Image` de FacePhi para obtener el JPEG, y esa imagen no debe tocar disco: memoria, envío al RNPN, descarte. Esto hay que dejarlo explícito en el diseño de seguridad porque es el punto donde el dato biométrico crudo existe en claro.

**Orden de las validaciones.** Liveness primero, siempre. Si el liveness falla no gastás una consulta al RNPN, que probablemente sea tarifada por transacción. El orden por costo creciente:

1. Liveness (local a FacePhi, barato, filtra la mayoría de intentos fraudulentos burdos)
2. OCR + match contra la foto del DUI (FacePhi, `method: "3"` o `"5"`)
3. Cotejo RNPN (autoritativo, caro, último)

**Qué manda si discrepan.** Si FacePhi da match contra la foto del DUI pero el RNPN dice NEGATIVE, el RNPN manda: `REJECTED`. El caso inverso (RNPN positivo, DUI negativo) es señal de documento alterado y debería ir a revisión manual, no a rechazo automático.

---

## 5. El frontend

Dos modalidades de consumo, porque no todos tus procesos son React.

### Modo embebido — `@davivienda/biometria-web`

Componente React que encapsula el SDK Web de FacePhi. La app consumidora no ve FacePhi nunca; ve un componente con tres props.

```jsx
<VerificacionBiometrica
  sessionToken={token}
  onComplete={(sessionId) => avanzarAperturaCuenta(sessionId)}
  onError={(error) => manejarFallo(error)}
/>
```

El componente resuelve internamente: carga del SDK, orden de pasos según la política, reintentos, manejo de los 18 códigos de liveness de FacePhi traducidos a mensajes que un usuario entiende, y envío de capturas al orquestador.

### Modo alojado — redirect

Para procesos que no pueden embeber nada: un core legacy, un canal de terceros, una app nativa vieja.

```
https://identidad.banco.sv/v/{sessionToken}?redirect_uri=...
```

El usuario va, se verifica, y vuelve a `redirect_uri?session_id=vs_...&status=verified`. El consumidor canjea el `session_id` por el VRT servidor a servidor.

Esta modalidad es la que realmente garantiza reciclabilidad universal. El componente React sirve para la mayoría; el modo alojado sirve para todo lo demás. Es el mismo patrón de Stripe Identity y Persona, y funciona por la misma razón: el proceso consumidor no necesita saber nada de biometría, solo redirigir y validar un token al volver.

### Traducción de errores

FacePhi devuelve códigos técnicos. El usuario necesita instrucciones accionables. Esta tabla vive en el componente, no en cada app:

| Código FacePhi | Mensaje al usuario | Acción |
|---|---|---|
| `NoneBecauseBadQuality` (4) | Buscá un lugar con más luz | reintentar |
| `NoneBecauseFaceTooSmall` (7) | Acercá el teléfono a tu cara | reintentar |
| `NoneBecauseFaceOccluded` (16) | Quitate lentes, gorra o mascarilla | reintentar |
| `NoneBecauseEyesClosed` (18) | Mantené los ojos abiertos | reintentar |
| `NoLive` (17) | No pudimos completar la verificación | sin reintento, a revisión |
| `NoneBecauseLicenseError` (15) | Servicio no disponible | alerta a operaciones |

Nótese la distinción: `NoLive` (17) es un posible intento de fraude y no debe ofrecer reintento infinito. Los `NoneBecause*` son problemas de captura y sí. Meter todo en un genérico "intentá de nuevo" es regalarle intentos a un atacante.

---

## 6. Seguridad y datos

**Retención.** La sesión y sus artefactos se borran a los 30 días o cuando el consumidor confirma el consumo del VRT, lo que ocurra primero. Las imágenes crudas nunca se persisten; solo los tokens de FacePhi y el resultado. Para lo que sí requiere conservación legal (evidencia del onboarding), usar el módulo de custodia documental de FacePhi en lugar de guardar los blobs vos mismo.

**Consentimiento.** La captura de datos biométricos requiere consentimiento explícito registrado con timestamp, versión del texto e IP. Se guarda a nivel de sesión y viaja como claim en el VRT si el consumidor lo necesita para su expediente.

**Idempotencia.** `POST /verification-sessions` acepta `Idempotency-Key`. Un reintento de red no debe crear dos sesiones ni consumir dos transacciones RNPN.

**Auditoría.** Cada sesión deja traza inmutable: quién la creó, qué política, qué proveedores respondieron qué, cuánto tardó cada uno, quién canjeó el VRT y cuándo. Sin esto no pasás una auditoría de la Superintendencia.

---

## 7. Qué falta definir

Estos puntos no se pueden cerrar sin información que no está en la documentación pública:

1. **Contrato técnico del RNPN.** Formato y resolución de imagen aceptada, esquema de autenticación, si devuelve score o solo booleano, umbral configurable o fijo, SLA de respuesta, y si es sincrónico. Todo el `RnpnAdapter` depende de esto.
2. **Alcance de licenciamiento FacePhi.** Si el contrato incluye Identity API en la nube de FacePhi o el Backend SDK on-premise. Cambia la arquitectura de red por completo.
3. **Umbral de similitud institucional.** El 0.85 de la tabla es un punto de partida razonable de la industria, no una recomendación calibrada. Hay que fijarlo con datos propios y con riesgo operativo.
4. **Política de revisión manual.** Qué pasa con los casos ambiguos, quién los ve, en qué herramienta, y con qué SLA.
