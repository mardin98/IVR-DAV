# Plan de trabajo

Backlog ordenado por dependencia. Cada tarea es una unidad de trabajo para una sesión de Claude Code: alcance acotado, criterio de aceptación explícito.

Marcá `[x]` al completar. No saltes fases: el orden refleja dependencias reales, no preferencia.

---

## Fase 0 — Fundaciones

Sin esto nada más compila. Debería tomar una sesión larga o dos.

- [ ] **0.1 Monorepo**
  pnpm workspaces con los paquetes `orchestrator`, `biometria-web`, `hosted`, `contracts`. TypeScript estricto compartido, ESLint, Prettier, Vitest.
  *Aceptación:* `pnpm build` y `pnpm test` pasan en verde con los paquetes vacíos.

- [ ] **0.2 Regla de dependencias**
  ESLint que bloquea imports desde `policy/` hacia `adapters/`, y desde `domain/` hacia cualquier capa con I/O.
  *Aceptación:* un import prohibido falla el lint en CI.

- [ ] **0.3 Serializador de redacción**
  `observability/redact.ts`. Elimina de logs: imágenes base64, tokens de imagen, plantillas biométricas, números de documento, nombres, fechas de nacimiento.
  *Aceptación:* test que pasa un objeto con los seis tipos de dato y verifica que ninguno aparece en la salida.

- [ ] **0.4 Pipeline GitLab**
  Etapas: lint, test, contract-lint (Spectral), build, scan de dependencias, publicación de imagen.
  *Aceptación:* pipeline verde en un MR de prueba.

---

## Fase 1 — Contrato

El contrato manda sobre el código. Esta fase va antes de la implementación.

- [ ] **1.1 OpenAPI base**
  Trasladar `openapi-verificacion-biometrica.yaml` a `packages/contracts/openapi.yaml`.
  *Aceptación:* valida como OpenAPI 3.1.

- [ ] **1.2 Reglas Spectral**
  Ruleset propio en `packages/contracts/.spectral.yaml`. Incluye la regla de gobierno que prohíbe vocabulario de negocio en el contrato (ver Fase 1.3).
  *Aceptación:* `spectral lint` en verde, y falla si se introduce un campo prohibido.

- [ ] **1.3 Regla anti-acoplamiento**
  Regla Spectral que rechaza los términos `account`, `cuenta`, `product`, `producto`, `amount`, `monto`, `branch`, `agencia`, `channel`, `canal` en nombres de propiedad o path.
  *Aceptación:* agregar `numeroCuenta` al esquema hace fallar el lint.

- [ ] **1.4 Tipos desde el contrato**
  Generar tipos TypeScript y esquemas Zod desde el OpenAPI. Automatizado, no a mano.
  *Aceptación:* cambiar el contrato y regenerar produce un diff coherente en los tipos.

---

## Fase 2 — Núcleo del dominio

Todo sin I/O. Es la parte más fácil de probar y la que más rinde tenerla sólida.

- [ ] **2.1 Máquina de estados**
  `domain/session-state.ts`. Transiciones válidas, estados terminales, función pura de transición que rechaza saltos ilegales.
  *Aceptación:* test que recorre toda transición válida y toda inválida.

- [ ] **2.2 Modelo de sesión**
  Entidad, invariantes, expiración, conteo de intentos.
  *Aceptación:* no se puede construir una sesión sin `policyId` ni `clientId`.

- [ ] **2.3 Puertos de proveedor**
  `LivenessProvider`, `DocumentProvider`, `FacialMatchProvider`, `CivilRegistryProvider`. Tipos de resultado normalizados, independientes del proveedor.
  *Aceptación:* ningún tipo del puerto menciona FacePhi ni RNPN.

- [ ] **2.4 Motor de política**
  Evalúa una política contra los puertos. Orden por costo creciente, corte temprano en fallo de liveness, precedencia del registro civil sobre el match documental.
  *Aceptación:* casos de test para cada `rejectionReason` del contrato, más el caso de discrepancia RNPN positivo / documento negativo que debe ir a revisión y no a rechazo.

- [ ] **2.5 Catálogo de políticas**
  Configuración versionada, no código. Las cuatro políticas iniciales.
  *Aceptación:* agregar una política nueva no requiere tocar `policy/engine.ts`.

---

## Fase 3 — Emisión de VRT

- [ ] **3.1 Emisor**
  Firma con claims `iss`, `aud`, `azp`, `sub`, `jti`, `exp` de 15 minutos, y el bloque `verification`.
  *Aceptación:* el token valida contra el JWKS publicado.

- [ ] **3.2 Un solo uso**
  Registro de `jti` canjeados. Segundo canje devuelve 409.
  *Aceptación:* test de doble canje.

- [ ] **3.3 Aislamiento por cliente**
  Un `client_id` distinto al que creó la sesión recibe 403 aunque conozca el `sessionId`.
  *Aceptación:* test de acceso cruzado.

- [ ] **3.4 JWKS y rotación**
  Endpoint de llaves públicas, dos llaves activas durante la ventana de rotación.
  *Aceptación:* tokens firmados con la llave anterior siguen validando durante la ventana.

---

## Fase 4 — Adaptador FacePhi

Antes de cada tarea, leé la página de documentación correspondiente en `docs.facephi.com`.

- [ ] **4.1 Cliente HTTP base**
  Timeouts, reintentos con backoff, circuit breaker, headers `x-api-key` y `family`.
  *Aceptación:* el breaker abre tras N fallos y se recupera.

- [ ] **4.2 Liveness**
  `POST /services/evaluatePassiveLiveness`. Mapeo de los 18 códigos de `serviceLivenessResult` al resultado normalizado del puerto, distinguiendo `NoLive` (17, resultado negativo) de los `NoneBecause*` (fallo de captura).
  *Aceptación:* test parametrizado sobre los 18 códigos.

- [ ] **4.3 Validación de identidad**
  `POST /onboarding/v2/identity`. Métodos `"3"` (imagen abierta) y `"5"` (tokenFaceImage). Devuelve liveness y similitud en una llamada.
  *Aceptación:* ambos métodos cubiertos con respuestas grabadas.

- [ ] **4.4 OCR de documento**
  Extracción de datos del DUI. Validación cruzada contra `subjectHint` si vino.
  *Aceptación:* discrepancia entre DUI declarado y leído produce `SUBJECT_HINT_MISMATCH`.

- [ ] **4.5 Autenticidad documental**
  Morphology / document validation. Es asíncrono con polling: presupuesto de tiempo acotado, y debe correr **en paralelo** con el cotejo RNPN, no en serie.
  *Aceptación:* el tiempo total no es la suma de ambos.

- [ ] **4.6 Detokenización**
  Obtener imagen abierta para el RNPN. En memoria, descartada en el mismo scope, nunca a disco ni a log.
  *Aceptación:* revisión explícita de que el buffer no escapa del scope. Documentar el punto en el registro de seguridad.

---

## Fase 5 — Adaptador RNPN

Bloqueado por la especificación técnica. Se construye contra supuestos hasta que llegue.

- [ ] **5.1 Documento de supuestos**
  `adapters/rnpn/ASSUMPTIONS.md`: cada suposición sobre formato, autenticación, umbral y sincronía, marcada como pendiente de confirmar.
  *Aceptación:* cada supuesto tiene el punto del código que lo consume.

- [ ] **5.2 Implementación contra supuestos**
  El adaptador completo, con el mapeo aislado en un módulo para que ajustarlo no toque la lógica.
  *Aceptación:* cambiar el formato de respuesta supuesto toca un solo archivo.

- [ ] **5.3 Simulador**
  Servicio local que emula el RNPN según los supuestos, con modos: positivo, negativo, lento, caído.
  *Aceptación:* el flujo completo corre de punta a punta sin acceso al RNPN real.

- [ ] **5.4 Degradación**
  Las tres rutas de RNPN no disponible (rechazar, encolar, aprobar con nivel reducido) detrás de configuración. Decisión de negocio pendiente.
  *Aceptación:* las tres rutas probadas; ninguna cableada como default silencioso.

---

## Fase 6 — API HTTP

- [ ] **6.1 Crear sesión**
  Con idempotencia real: misma `Idempotency-Key` devuelve la sesión original sin consumir transacciones de proveedor.
  *Aceptación:* dos llamadas idénticas producen una sola sesión.

- [ ] **6.2 Configuración de sesión**
  `GET /config` autenticado con `sessionToken`. Emite licencia de widget de alcance y vigencia limitados a la sesión.
  *Aceptación:* la licencia no sirve para otra sesión.

- [ ] **6.3 Recepción de capturas**
  `POST /captures`. Valida contra los pasos de la política, exige consentimiento, dispara evaluación asíncrona.
  *Aceptación:* captura sin consentimiento se rechaza; captura con pasos incompletos se rechaza.

- [ ] **6.4 Estado y resultado**
  Los dos endpoints de lectura, con las reglas de aislamiento de la Fase 3.

- [ ] **6.5 Webhook a consumidores**
  Notificación de estado terminal, con reintentos y firma. No transporta el resultado: el consumidor lo canjea.
  *Aceptación:* la notificación no contiene datos personales.

- [ ] **6.6 Persistencia**
  Esquema PostgreSQL, migraciones, y el job de retención que purga a los 30 días o al canje del VRT.
  *Aceptación:* el job corre y deja traza de auditoría de lo purgado.

---

## Fase 7 — Frontend

- [ ] **7.1 Componente base**
  `VerificacionBiometrica.jsx` como punto de partida. Máquina de estados, carga de configuración, envío de capturas.
  *Aceptación:* funciona contra el orquestador local con el simulador RNPN.

- [ ] **7.2 Pantalla de consentimiento**
  Texto versionado, registro con timestamp.
  *Aceptación:* la versión aceptada llega al backend y queda en la traza.

- [ ] **7.3 Mensajería de error**
  La tabla de traducción de los 18 diagnósticos. Reintento solo en los códigos que lo admiten, con tope.
  *Aceptación:* `NoLive` no ofrece reintento.

- [ ] **7.4 Accesibilidad**
  Foco visible, `aria-live` en cambios de estado, contraste, movimiento reducido respetado.
  *Aceptación:* navegable solo con teclado y anunciado correctamente por lector de pantalla.

- [ ] **7.5 Modo alojado**
  Página propia, redirect de vuelta con `session_id` y `status`. Validación de `redirect_uri` contra lista pre-registrada por cliente.
  *Aceptación:* un `redirect_uri` no registrado se rechaza.

- [ ] **7.6 Publicación**
  Paquete interno versionado en el registry de GitLab.

---

## Fase 8 — Operación

- [ ] **8.1 Métricas**
  Tasa de completitud, abandono por paso, distribución de similitud, latencia por proveedor, costo por transacción atribuido a política y consumidor.
  *Aceptación:* tablero que responde "qué proceso está quemando el presupuesto RNPN".

- [ ] **8.2 Auditoría**
  Traza inmutable: quién creó la sesión, qué política, qué respondió cada proveedor, quién canjeó el VRT.
  *Aceptación:* reconstruir una verificación completa desde la traza, sin datos biométricos.

- [ ] **8.3 Backoffice de revisión manual**
  Cola de casos ambiguos, decisión con doble control, registro de quién resolvió qué.
  *Aceptación:* un caso no puede resolverse por una sola persona.

- [ ] **8.4 Alertas**
  Proveedor caído, tasa de rechazo anómala, agotamiento de licencia, latencia degradada.

- [ ] **8.5 Límites antifraude**
  Tope de intentos por documento y por dispositivo, en ventana de tiempo.
  *Aceptación:* el mismo DUI no puede intentar indefinidamente.

---

## Fase 9 — Antifraude avanzado

Fuera del alcance inicial. El diseño debe admitirlos como pasos de política sin refactor.

- [ ] **9.1 IAD** — detección de inyección de cámara virtual. Es el vector real en web.
- [ ] **9.2 Detección 1:N** — mismo rostro con documentos distintos. El control que más fraude atrapa.
- [ ] **9.3 Señales de dispositivo** — huella, emulador, root.

---

## Trabajo en paralelo, fuera del repo

Estas colas mandan el calendario. Arrancalas ya; no dependen del código.

- Ambiente de certificación del RNPN y ventanas de prueba
- Licenciamiento definitivo de FacePhi y decisión nube/on-premise
- Pentest agendado
- Revisión de cumplimiento: normativa de protección de datos y requisitos de la SSF sobre onboarding no presencial
- Comité de riesgo
- Definición de canal alterno presencial para quien no complete el flujo digital
