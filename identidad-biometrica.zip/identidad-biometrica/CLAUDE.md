# CLAUDE.md

Contexto operativo para trabajar en este repositorio. Leé esto completo antes de tocar código.

---

## Qué estamos construyendo

Un servicio de verificación de identidad biométrica **reutilizable entre procesos de negocio**. Apertura de cuenta, alta de SaaS, reposición de clave y actualización de datos consumen el mismo servicio; lo único que los distingue es un `policyId`.

Proveedores externos: **FacePhi** (captura, prueba de vida, OCR, cotejo facial contra documento) y **RNPN** (cotejo facial contra el registro civil de El Salvador).

La documentación pública de FacePhi está en `https://docs.facephi.com`. Las páginas tienen versión Markdown agregando `.md` a la URL, y el índice completo está en `https://docs.facephi.com/llms.txt`. Consultala en lugar de asumir firmas de endpoints.

---

## Invariantes

Estas reglas no se negocian. Si una tarea parece requerir violarlas, la tarea está mal planteada: pará y preguntá.

**1. El servicio no conoce el proceso que lo invoca.**
Ningún tipo, columna, endpoint o parámetro puede referirse a cuentas, productos, montos, agencias o canales. Si aparece un campo así en un requerimiento, va del lado del consumidor correlacionado por `clientReference`. Este es el invariante que hace el servicio reutilizable; romperlo lo convierte en un módulo de apertura de cuenta.

**2. Nunca se persiste imagen biométrica cruda.**
Se almacenan tokens del proveedor y resultados. La detokenización ocurre en memoria, solo cuando un proveedor externo exige imagen abierta (el RNPN), y el buffer se descarta en el mismo scope. Nada de escribir a disco, a un bucket, ni a un campo de base de datos.

**3. Ningún dato biométrico ni personal entra a logs.**
Ni imágenes, ni tokens de imagen, ni plantillas, ni números de documento, ni nombres. Los logs llevan `sessionId`, `policyId`, `clientId`, estado, latencias y códigos de resultado. Existe un serializador de redacción en `packages/orchestrator/src/observability/redact.ts`: usalo siempre, no armes objetos de log a mano.

**4. Las llamadas salientes son la única forma de hablar con el exterior.**
La política de red del banco permite solo conexiones de salida. No diseñes nada que dependa de que FacePhi o el RNPN nos llamen. Lo asíncrono de proveedor se resuelve con polling desde el orquestador. Los webhooks hacia consumidores sí existen, porque son internos.

**5. El motor de política habla contra puertos, no contra proveedores.**
`LivenessProvider`, `DocumentProvider`, `FacialMatchProvider`, `CivilRegistryProvider`. Nada en `src/policy/` puede importar de `src/adapters/`. Hay una regla de ESLint que lo bloquea; si te estorba, el diseño está mal, no la regla.

**6. El VRT es la única fuente de verdad del resultado.**
El frontend nunca decide si alguien quedó verificado, ni recibe el resultado de la verificación. Reporta que la captura terminó. El consumidor canjea el resultado servidor a servidor.

---

## Arquitectura

```
packages/
  orchestrator/          Servicio principal (Fastify + TypeScript)
    src/
      api/               Rutas HTTP. Delgadas: validan, delegan, mapean respuesta.
      domain/            Entidades, máquina de estados, tipos. Sin I/O.
      policy/            Motor de evaluación. Habla contra puertos. Sin I/O directo.
      ports/             Interfaces de proveedores biométricos.
      adapters/
        facephi/         Implementación FacePhi de los puertos.
        rnpn/            Implementación RNPN.
      tokens/            Emisión y verificación de VRT, JWKS, rotación.
      persistence/       Repositorios. PostgreSQL.
      observability/     Logs, métricas, trazas, redacción.
  biometria-web/         Componente React publicable como paquete interno.
  hosted/                Experiencia alojada (modo redirect).
  contracts/             OpenAPI + reglas Spectral. Fuente de verdad del contrato.
```

**Dirección de dependencias:** `api → policy → ports ← adapters`. `domain` no depende de nada. Si una capa importa hacia afuera de esa dirección, está mal.

---

## Máquina de estados

```
CREATED → CAPTURING → PROCESSING → VERIFIED | REJECTED | FAILED
   ↓          ↓            ↓
EXPIRED    EXPIRED      FAILED
   ↓          ↓
ABANDONED  ABANDONED
```

`VERIFIED` y `REJECTED` son resultados de negocio y son terminales. `FAILED` es error técnico y admite reintento con sesión nueva. Las transiciones viven en `domain/session-state.ts` y se validan ahí; ningún otro módulo puede mutar el estado directamente.

---

## Orden de evaluación

Costo creciente. No lo reordenes por conveniencia:

1. **Liveness** — barato, filtra la mayoría de intentos burdos
2. **OCR + match contra la foto del documento** — FacePhi
3. **Cotejo RNPN** — autoritativo y tarifado por transacción, va al final

Si el liveness falla, no se consulta el RNPN. Si FacePhi da match positivo contra el documento pero el RNPN dice NEGATIVE, **manda el RNPN**: `REJECTED`. El caso inverso (RNPN positivo, documento negativo) es señal de documento alterado y va a revisión manual, nunca a rechazo automático.

---

## Convenciones de código

- TypeScript estricto. `strict: true`, sin `any`, sin `!` de aserción no nula. Si necesitás uno, replanteá el tipo.
- Validación de entrada con Zod, derivada del OpenAPI. El contrato manda sobre el código.
- Errores HTTP en formato RFC 9457 (`application/problem+json`). Hay un helper en `api/problem.ts`.
- Nada de `console.log`. Logger estructurado, siempre con el serializador de redacción.
- Toda llamada externa lleva timeout explícito, reintentos con backoff, y circuit breaker. Ningún `fetch` desnudo.
- Nombres de dominio en español cuando corresponden al negocio salvadoreño (`consentimiento`, `cotejo`), en inglés cuando son técnicos (`session`, `token`). No mezcles dentro de un mismo concepto.

---

## Pruebas

- **Unitarias** del motor de política con puertos falsos. Es el corazón del servicio: cada política declarada necesita casos de aprobación, rechazo por cada motivo posible, y proveedor caído.
- **Contrato** contra el OpenAPI. Toda respuesta que emita el servicio debe validar contra el esquema.
- **Integración** de adaptadores contra grabaciones de respuestas reales (nock o similar), no contra los servicios en vivo.
- No escribas tests que dependan de credenciales de proveedor.

Un PR que agrega una política sin sus casos de rechazo no está completo.

---

## Cómo trabajar en este repo

- El backlog está en `docs/plan.md`, organizado por fases. Trabajá una tarea a la vez y marcala al terminar.
- **El contrato primero.** Si una tarea cambia la API, actualizá `packages/contracts/openapi.yaml` y pasá Spectral antes de escribir implementación.
- Antes de escribir un adaptador, leé la página de documentación del proveedor correspondiente. No infieras firmas.
- Si una decisión de negocio no está resuelta (ver "Decisiones pendientes"), no la inventes: dejá un `TODO(decisión)` con la pregunta concreta y seguí con lo que sí está definido.

---

## Decisiones pendientes

No las resuelvas por tu cuenta. Si una tarea las toca, implementá detrás de una interfaz y dejá el punto marcado.

1. **Especificación técnica del RNPN.** Formato y resolución de imagen, autenticación, si devuelve score o booleano, umbral configurable, SLA, sincronía. El `RnpnAdapter` se construye contra supuestos documentados en `adapters/rnpn/ASSUMPTIONS.md` hasta que llegue.
2. **Modalidad de licenciamiento FacePhi.** Identity API en su nube, o Backend SDK on-premise. Cambia la topología de red completa.
3. **Umbral de similitud institucional.** El 0.85 en las políticas es un valor de arranque, no una calibración. Marcado como `TODO(calibración)`.
4. **Degradación con RNPN caído.** ¿Rechazar, encolar, o aprobar con nivel `SUBSTANTIAL` y revisión posterior? Decisión de negocio pendiente. Implementá las tres rutas detrás de configuración.
5. **Alcance de antifraude en v1.** IAD (detección de inyección de cámara) y 1:N (mismo rostro con documentos distintos) están fuera del alcance inicial pero el diseño debe admitirlos como pasos de política adicionales sin refactor.

---

## Fuera de alcance

No agregues esto al servicio aunque parezca natural:

- **Listas PEP, OFAC, listas restrictivas.** Pertenecen al proceso de apertura de cuenta, no a la verificación de identidad. Meterlas aquí rompe la reutilización para el SaaS.
- **Scoring crediticio o de riesgo.**
- **Persistencia de datos del cliente más allá de la sesión.** El expediente lo arma el consumidor.
