# Verificación de Identidad Biométrica

Servicio de verificación de identidad reutilizable entre procesos de negocio.
Apertura de cuenta, alta de SaaS, reposición de clave y actualización de datos
consumen el mismo servicio; lo único que los distingue es un `policyId`.

Proveedores: **FacePhi** (captura, prueba de vida, OCR, cotejo documental) y
**RNPN** (cotejo facial contra el registro civil de El Salvador).

## Por dónde empezar

1. Leé `CLAUDE.md` — invariantes y arquitectura. Es el contrato de trabajo.
2. Leé `docs/diseno.md` — el razonamiento detrás de las decisiones.
3. Abrí `docs/plan.md` y empezá por la tarea 0.1.

## Estructura

```
CLAUDE.md                      Contexto e invariantes para Claude Code
docs/
  plan.md                      Backlog por fases
  diseno.md                    Documento de arquitectura
  decisiones.md                Registro de decisiones
packages/
  contracts/                   OpenAPI + reglas Spectral. Fuente de verdad.
  orchestrator/                Servicio principal
  biometria-web/               Componente React
  hosted/                      Experiencia alojada (modo redirect)
tools/
  rnpn-simulator/              Emulador del RNPN para desarrollo local
```

## Comandos

```bash
pnpm install
pnpm lint:contract     # Spectral sobre el OpenAPI
pnpm types:generate    # Tipos desde el contrato
pnpm test
pnpm dev
```

## Estado

Fase 0 pendiente. El monorepo está estructurado pero los paquetes están vacíos:
la implementación arranca con la tarea 0.1 del plan.

El adaptador RNPN está bloqueado por la especificación técnica del registro.
Se construye contra los supuestos documentados en
`packages/orchestrator/src/adapters/rnpn/ASSUMPTIONS.md`, que incluye las
preguntas pendientes para el RNPN.
