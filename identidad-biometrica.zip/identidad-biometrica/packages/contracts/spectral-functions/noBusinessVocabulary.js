/**
 * Función Spectral: noBusinessVocabulary
 *
 * Rechaza vocabulario de negocio en el contrato de la API de verificación.
 *
 * El razonamiento: si el contrato menciona cuentas, productos o montos, el
 * servicio dejó de ser reutilizable — quedó atado al proceso que introdujo
 * ese término. Un consumidor que necesita correlacionar con su propia
 * transacción usa clientReference, que es opaco para este servicio.
 *
 * Colocar en:  packages/contracts/spectral-functions/noBusinessVocabulary.js
 */

const TERMINOS_PROHIBIDOS = [
  // Producto y cuenta
  'account', 'cuenta', 'product', 'producto', 'plan', 'tarifa',
  // Dinero
  'amount', 'monto', 'balance', 'saldo', 'currency', 'moneda',
  'price', 'precio', 'fee', 'comision',
  // Organización
  'branch', 'agencia', 'sucursal', 'channel', 'canal',
  'agent', 'ejecutivo', 'asesor',
  // Proceso ajeno
  'loan', 'prestamo', 'credit', 'credito', 'card', 'tarjeta',
  'contract', 'contrato', 'subscription', 'suscripcion',
  // Riesgo y cumplimiento — pertenecen al consumidor
  'pep', 'ofac', 'aml', 'score', 'risk', 'riesgo', 'blacklist',
];

// Términos que contienen una subcadena prohibida pero son legítimos aquí.
const EXCEPCIONES = new Set([
  'clientReference',   // opaco por diseño
  'clientId',
  'creditRegistry',    // no aplica hoy, reservado
]);

export default function noBusinessVocabulary(input, options, context) {
  if (typeof input !== 'string') return;
  if (EXCEPCIONES.has(input)) return;

  const normalizado = input
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();

  const encontrado = TERMINOS_PROHIBIDOS.find((termino) => {
    // Coincidencia por palabra dentro de camelCase, kebab-case o snake_case,
    // no por subcadena suelta: "documentType" no debe disparar por "type".
    const patron = new RegExp(`(^|[^a-z])${termino}([^a-z]|$)`, 'i');
    const separado = normalizado.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[-_]/g, ' ');
    return patron.test(` ${separado} `);
  });

  if (!encontrado) return;

  return [
    {
      message:
        `"${input}" introduce vocabulario de negocio ("${encontrado}") en el contrato. ` +
        `El servicio de verificación no debe conocer el proceso que lo invoca. ` +
        `Si necesitás correlacionar con una transacción propia, usá clientReference. ` +
        `Si el término es legítimo, agregalo a EXCEPCIONES con justificación.`,
      path: context.path,
    },
  ];
}
