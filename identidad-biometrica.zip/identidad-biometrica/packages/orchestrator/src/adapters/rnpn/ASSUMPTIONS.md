# Supuestos del adaptador RNPN

Este adaptador se construye contra supuestos mientras no tengamos la
especificación técnica del RNPN. Cada supuesto lleva el punto del código que
lo consume, para que ajustarlo sea localizable.

Al recibir la especificación real: confirmar o corregir cada línea, y actualizar
únicamente `mapper.ts`. Si el cambio obliga a tocar otro archivo, el aislamiento
del adaptador está mal hecho.

| # | Supuesto | Confirmado | Consumido en |
|---|---|---|---|
| 1 | Servicio sincrónico, respuesta en menos de 10 s | ☐ | `client.ts` |
| 2 | Autenticación por certificado cliente (mTLS) | ☐ | `client.ts` |
| 3 | Imagen JPEG, base64, sin cabecera MIME | ☐ | `mapper.ts` |
| 4 | Resolución mínima 480×640 | ☐ | `mapper.ts` |
| 5 | Se envía el DUI junto con la imagen | ☐ | `mapper.ts` |
| 6 | Devuelve booleano de coincidencia, no score | ☐ | `mapper.ts` |
| 7 | El umbral lo fija el RNPN, no es configurable | ☐ | `mapper.ts` |
| 8 | Distingue "no coincide" de "DUI no encontrado" | ☐ | `mapper.ts` |
| 9 | Tarifado por consulta, sin cargo si falla | ☐ | métricas de costo |
| 10 | Sin límite de tasa documentado | ☐ | `client.ts` |

## Preguntas para el RNPN

1. ¿Devuelve score de similitud o solo veredicto? Si es score, ¿podemos fijar umbral propio?
2. ¿Cómo se distingue "no coincide" de "DUI no existe" de "sin fotografía en el registro"?
3. ¿Qué pasa con fotografías antiguas en el registro? ¿Hay política de vigencia?
4. ¿Ambiente de certificación disponible? ¿Con qué datos de prueba?
5. ¿SLA de disponibilidad y de tiempo de respuesta?
6. ¿Límite de consultas por minuto o por día?
7. ¿Requisitos de conservación o de reporte de las consultas realizadas?
