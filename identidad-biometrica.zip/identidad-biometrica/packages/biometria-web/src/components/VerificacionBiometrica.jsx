/**
 * @davivienda/biometria-web
 *
 * Componente único de verificación biométrica. Cualquier proceso lo monta con
 * un sessionToken y recibe un sessionId al terminar. La app consumidora no
 * conoce FacePhi, ni el RNPN, ni los pasos de la política.
 *
 * Uso:
 *
 *   <VerificacionBiometrica
 *     sessionToken={token}
 *     onComplete={({ sessionId }) => continuarProceso(sessionId)}
 *     onError={(error) => manejarFallo(error)}
 *   />
 *
 * El sessionToken lo obtiene el backend de la app consumidora llamando a
 * POST /verification-sessions. Nunca se genera en el navegador.
 */

import { useCallback, useEffect, useMemo, useReducer, useRef } from 'react';
import { SDKProvider, SelphiComponent, SelphIDComponent } from '@facephi/sdk-web-react';

// ─────────────────────────────────────────────────────────────────────────────
// Traducción de diagnósticos del proveedor a instrucciones accionables.
//
// La distinción que importa: los códigos NoneBecause* son fallos de captura y
// admiten reintento. NoLive es un resultado negativo de la prueba de vida y no
// debe ofrecer reintentos ilimitados — cada reintento es un intento gratis para
// quien esté probando una suplantación.
// ─────────────────────────────────────────────────────────────────────────────

const DIAGNOSTICOS = {
  0:  { texto: 'No pudimos evaluar la captura. Intentá otra vez.', reintentable: true },
  3:  { texto: null, reintentable: false }, // Live: caso de éxito
  4:  { texto: 'La imagen salió borrosa. Buscá un lugar con mejor luz.', reintentable: true },
  5:  { texto: 'Alejá un poco el teléfono de tu cara.', reintentable: true },
  6:  { texto: 'No detectamos tu rostro. Colocate frente a la cámara.', reintentable: true },
  7:  { texto: 'Acercá el teléfono a tu cara.', reintentable: true },
  8:  { texto: 'Mirá de frente a la cámara, sin inclinar la cabeza.', reintentable: true },
  9:  { texto: 'Hubo un problema con la imagen. Intentá otra vez.', reintentable: true },
  10: { texto: 'El servicio no está disponible en este momento.', reintentable: false },
  11: { texto: 'Hubo un problema procesando la imagen. Intentá otra vez.', reintentable: true },
  12: { texto: 'Asegurate de estar solo frente a la cámara.', reintentable: true },
  13: { texto: 'Centrá tu rostro dentro del marco.', reintentable: true },
  14: { texto: 'Tu rostro quedó cortado. Centrate en el marco.', reintentable: true },
  15: { texto: 'El servicio no está disponible en este momento.', reintentable: false },
  16: { texto: 'Quitate lentes, gorra o mascarilla y volvé a intentar.', reintentable: true },
  17: { texto: 'No pudimos completar la verificación.', reintentable: false },
  18: { texto: 'Mantené los ojos abiertos durante la captura.', reintentable: true },
};

const FALLBACK = { texto: 'No pudimos completar la verificación.', reintentable: false };

function traducirDiagnostico(codigo) {
  return DIAGNOSTICOS[codigo] ?? FALLBACK;
}

// ─────────────────────────────────────────────────────────────────────────────
// Máquina de estados. El componente refleja la máquina del backend; no inventa
// estados propios ni decide si una verificación pasó — eso lo resuelve la
// política del lado servidor.
// ─────────────────────────────────────────────────────────────────────────────

const estadoInicial = {
  fase: 'cargando',     // cargando | consentimiento | capturando | enviando | listo | error
  config: null,
  pasoActual: 0,
  capturas: {},
  intentos: 0,
  mensaje: null,
  reintentable: false,
};

function reducer(estado, accion) {
  switch (accion.type) {
    case 'CONFIG_CARGADA':
      return { ...estado, fase: 'consentimiento', config: accion.config };

    case 'CONSENTIMIENTO_OTORGADO':
      return { ...estado, fase: 'capturando', capturas: { consent: accion.consent } };

    case 'PASO_COMPLETADO': {
      const capturas = { ...estado.capturas, ...accion.datos };
      const siguiente = estado.pasoActual + 1;
      const terminado = siguiente >= estado.config.steps.length;
      return {
        ...estado,
        capturas,
        pasoActual: siguiente,
        fase: terminado ? 'enviando' : 'capturando',
        mensaje: null,
      };
    }

    case 'PASO_FALLIDO': {
      const { texto, reintentable } = traducirDiagnostico(accion.codigo);
      const intentos = estado.intentos + 1;
      const quedan = intentos < (estado.config?.maxAttempts ?? 3);
      return {
        ...estado,
        intentos,
        fase: reintentable && quedan ? 'capturando' : 'error',
        mensaje: texto,
        reintentable: reintentable && quedan,
      };
    }

    case 'ENVIO_ACEPTADO':
      return { ...estado, fase: 'listo' };

    case 'FALLO':
      return { ...estado, fase: 'error', mensaje: accion.mensaje, reintentable: false };

    case 'REINTENTAR':
      return { ...estado, fase: 'capturando', mensaje: null };

    default:
      return estado;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Cliente HTTP contra el orquestador. Aislado para poder sustituirlo en tests
// sin levantar el SDK del proveedor.
// ─────────────────────────────────────────────────────────────────────────────

function crearCliente(baseUrl, sessionToken) {
  const decodificado = JSON.parse(atob(sessionToken.split('.')[1]));
  const sessionId = decodificado.sub;

  async function pedir(ruta, opciones = {}) {
    const respuesta = await fetch(`${baseUrl}/verification-sessions/${sessionId}${ruta}`, {
      ...opciones,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${sessionToken}`,
        ...opciones.headers,
      },
    });

    if (!respuesta.ok) {
      const problema = await respuesta.json().catch(() => ({}));
      const error = new Error(problema.detail ?? `Error ${respuesta.status}`);
      error.status = respuesta.status;
      error.type = problema.type;
      throw error;
    }

    return respuesta.status === 204 ? null : respuesta.json();
  }

  return {
    sessionId,
    obtenerConfig: () => pedir('/config'),
    enviarCapturas: (capturas) =>
      pedir('/captures', { method: 'POST', body: JSON.stringify(capturas) }),
    consultarEstado: () => pedir(''),
  };
}

// ─────────────────────────────────────────────────────────────────────────────

export default function VerificacionBiometrica({
  sessionToken,
  baseUrl = '/api/identity/v1',
  onComplete,
  onError,
  onCancel,
  textoConsentimiento,
}) {
  const [estado, despachar] = useReducer(reducer, estadoInicial);
  const cliente = useMemo(() => crearCliente(baseUrl, sessionToken), [baseUrl, sessionToken]);
  const notificado = useRef(false);

  // Carga de configuración
  useEffect(() => {
    let vigente = true;

    cliente
      .obtenerConfig()
      .then((config) => vigente && despachar({ type: 'CONFIG_CARGADA', config }))
      .catch((error) => {
        if (!vigente) return;
        const mensaje =
          error.status === 410
            ? 'La sesión expiró. Volvé a iniciar el proceso.'
            : 'No pudimos iniciar la verificación.';
        despachar({ type: 'FALLO', mensaje });
      });

    return () => {
      vigente = false;
    };
  }, [cliente]);

  // Envío de capturas al completar todos los pasos
  useEffect(() => {
    if (estado.fase !== 'enviando') return;
    let vigente = true;

    cliente
      .enviarCapturas(estado.capturas)
      .then(() => vigente && despachar({ type: 'ENVIO_ACEPTADO' }))
      .catch(() => {
        if (!vigente) return;
        despachar({ type: 'FALLO', mensaje: 'No pudimos enviar la verificación.' });
      });

    return () => {
      vigente = false;
    };
  }, [estado.fase, estado.capturas, cliente]);

  // Notificación al consumidor. El componente informa que la captura terminó,
  // no si la persona quedó verificada: ese resultado lo canjea el backend del
  // consumidor por el VRT, que es la única fuente confiable.
  useEffect(() => {
    if (notificado.current) return;

    if (estado.fase === 'listo') {
      notificado.current = true;
      onComplete?.({ sessionId: cliente.sessionId });
    } else if (estado.fase === 'error' && !estado.reintentable) {
      notificado.current = true;
      onError?.({ sessionId: cliente.sessionId, message: estado.mensaje });
    }
  }, [estado.fase, estado.reintentable, estado.mensaje, cliente.sessionId, onComplete, onError]);

  const alCompletarRostro = useCallback((resultado) => {
    if (resultado.diagnostic && resultado.diagnostic !== 3) {
      despachar({ type: 'PASO_FALLIDO', codigo: resultado.diagnostic });
      return;
    }
    despachar({
      type: 'PASO_COMPLETADO',
      datos: {
        face: {
          bestImageToken: resultado.bestImageTokenized,
          templateRaw: resultado.templateRaw,
        },
        tracking: resultado.tracking,
      },
    });
  }, []);

  const alCompletarDocumento = useCallback((resultado) => {
    despachar({
      type: 'PASO_COMPLETADO',
      datos: {
        document: {
          frontImage: resultado.frontDocumentImage,
          backImage: resultado.backDocumentImage,
          tokenFaceImage: resultado.tokenFaceImage,
        },
      },
    });
  }, []);

  if (estado.fase === 'cargando') {
    return <Cargando />;
  }

  if (estado.fase === 'consentimiento') {
    return (
      <Consentimiento
        texto={textoConsentimiento}
        version={estado.config.consentVersion}
        onAceptar={(consent) => despachar({ type: 'CONSENTIMIENTO_OTORGADO', consent })}
        onRechazar={onCancel}
      />
    );
  }

  if (estado.fase === 'error') {
    return (
      <Aviso
        mensaje={estado.mensaje}
        accion={estado.reintentable ? 'Intentar de nuevo' : null}
        onAccion={() => despachar({ type: 'REINTENTAR' })}
      />
    );
  }

  if (estado.fase === 'enviando' || estado.fase === 'listo') {
    return <Procesando />;
  }

  const paso = estado.config.steps[estado.pasoActual];
  const { provider, theme, locale } = estado.config;

  return (
    <SDKProvider
      apikey={provider.widgetLicense}
      operationId={provider.operationId}
      tenantId={provider.tenantId}
      language={locale}
      theme={theme}
    >
      {paso.type === 'FACE_CAPTURE' && (
        <SelphiComponent
          {...paso.settings}
          onExtractionFinish={alCompletarRostro}
          onUserCancel={onCancel}
          onExceptionCaptured={(e) => despachar({ type: 'PASO_FALLIDO', codigo: e.code ?? 0 })}
        />
      )}

      {paso.type === 'DOCUMENT_CAPTURE' && (
        <SelphIDComponent
          {...paso.settings}
          onExtractionFinish={alCompletarDocumento}
          onUserCancel={onCancel}
          onExceptionCaptured={(e) => despachar({ type: 'PASO_FALLIDO', codigo: e.code ?? 0 })}
        />
      )}

      <Progreso actual={estado.pasoActual + 1} total={estado.config.steps.length} />
    </SDKProvider>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Vistas auxiliares. Deliberadamente sin estilos propios: heredan del tema de
// la app consumidora para que el módulo no imponga una identidad visual.
// ─────────────────────────────────────────────────────────────────────────────

function Cargando() {
  return <div role="status" aria-live="polite">Preparando la verificación</div>;
}

function Procesando() {
  return <div role="status" aria-live="polite">Verificando tu identidad</div>;
}

function Progreso({ actual, total }) {
  if (total < 2) return null;
  return (
    <div aria-live="polite">
      Paso {actual} de {total}
    </div>
  );
}

function Aviso({ mensaje, accion, onAccion }) {
  return (
    <div role="alert">
      <p>{mensaje}</p>
      {accion && (
        <button type="button" onClick={onAccion}>
          {accion}
        </button>
      )}
    </div>
  );
}

function Consentimiento({ texto, version, onAceptar, onRechazar }) {
  const aceptar = () =>
    onAceptar({
      granted: true,
      version,
      grantedAt: new Date().toISOString(),
    });

  return (
    <div>
      <h2>Verificación de identidad</h2>
      <p>{texto}</p>
      <button type="button" onClick={aceptar}>
        Autorizo la verificación
      </button>
      <button type="button" onClick={onRechazar}>
        Ahora no
      </button>
    </div>
  );
}
