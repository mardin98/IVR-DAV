# MVP — WSO2 API Manager + Micro Integrator

Stack funcional de referencia para validar el reemplazo de WildFly/WAR con WSO2 (gateway + orquestación) y microservicios propios en contenedores.

## Estructura

```
wso2-mvp/
├── docker-compose.yml          # Levanta todo el stack
├── .env.example                 # Config de LEGACY_BASE_URL (real o mock)
├── services/
│   ├── business-service/        # Microservicio de negocio (Node.js)
│   └── mock-legacy-service/     # Mock del sistema legacy (XML, Node.js)
├── integration/
│   ├── mi-artifacts/
│   │   ├── api/                 # Flujo de orquestación (Synapse)
│   │   └── endpoints/           # Endpoints hacia legacy y business-service
│   └── openapi/                 # Contrato para publicar en API Manager
└── docs/
    ├── MVP-Design-Document.md   # Documento de diseño
    ├── INSTALL-RHEL.md          # Instalación desde cero en RHEL (Docker, SELinux, firewall)
    └── README-deployment.md     # Guía de despliegue paso a paso (asume Docker ya instalado)
```

## Inicio rápido (RHEL)

Si es la primera vez que corres Docker en esta máquina RHEL, empieza por `docs/INSTALL-RHEL.md`. Ya con Docker funcionando:

```bash
cp .env.example .env
docker-compose up -d
curl http://localhost:8290/mvp/customer/12345/eligibility
```

Detalle completo en `docs/README-deployment.md`. Contexto de diseño y decisiones en `docs/MVP-Design-Document.md`.

## Estado de validación

- ✅ `business-service` y `mock-legacy-service`: código probado en vivo, flujo end-to-end confirmado
- ✅ Artefactos XML de Micro Integrator: validados sintácticamente (`xmllint`)
- ✅ `docker-compose.yml` y OpenAPI: validados sintácticamente (YAML)
- ⚠️ WSO2 API Manager + Micro Integrator corriendo juntos vía Docker: **pendiente de validar en un ambiente con Docker disponible** — este stack no se pudo levantar en el entorno donde se generó (sin Docker/Docker Hub). Sigue `docs/README-deployment.md` para correrlo y validarlo tú.
