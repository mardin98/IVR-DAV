# MVP — Arquitectura WSO2 API Manager + Micro Integrator
### Documento de diseño

## 1. Objetivo

Validar, con un caso de uso real end-to-end, el patrón de arquitectura objetivo que reemplaza el rol de WildFly/WAR: **WSO2 API Manager (gateway)** + **WSO2 Micro Integrator (orquestación/transformación)** + **microservicios de negocio propios (Node.js)**, todo en contenedores, listo para K8s.

Este MVP no migra nada existente — es una construcción desde cero (greenfield) que sirve de plantilla de referencia para los siguientes casos de uso.

## 2. Caso de uso elegido

**Consulta de elegibilidad crediticia de un cliente.**

Se eligió porque toca las tres capas de la arquitectura en un solo flujo:
- Requiere **transformación de datos** (XML legacy → JSON moderno)
- Requiere **orquestación** (dos llamadas encadenadas, no solo un passthrough)
- Requiere **lógica de negocio real** (regla de elegibilidad), aislada en un microservicio propio

## 3. Flujo end-to-end

```
Cliente/Canal
     │  GET /mvp/1.0.0/customer/{id}/eligibility  (+ token OAuth2)
     ▼
┌─────────────────────┐
│ WSO2 API Manager     │  Valida OAuth2 Client Credentials,
│ (Gateway)             │  rate limiting, enruta a MI
└──────────┬───────────┘
           ▼
┌─────────────────────┐
│ WSO2 Micro Integrator │  1. Llama al sistema legacy (XML)
│ (Orquestación)         │  2. Transforma XML → JSON
│                        │  3. Llama al business-service
│                        │  4. Compone la respuesta final
└──────┬────────────┬────┘
       ▼             ▼
┌─────────────┐  ┌──────────────────┐
│ legacy-service│  │ business-service  │
│ (real o mock) │  │ (Node.js/Express)  │
│ Datos fuente  │  │ Regla de elegibilidad│
└─────────────┘  └──────────────────┘
```

## 4. Componentes construidos

| Componente | Tecnología | Rol |
|---|---|---|
| `mock-legacy-service` | Node.js/Express | Simula el sistema legacy; responde XML (igual que un core bancario típico). Reemplazable por el endpoint real vía variable de entorno `LEGACY_BASE_URL`. |
| `business-service` | Node.js/Express | Lógica de negocio aislada (regla de elegibilidad: relación deuda/ingreso y antigüedad de cuenta). Equivalente al 30% de lógica de negocio que hoy vive en los WAR. |
| `wso2-mi` | WSO2 Micro Integrator 4.3.0 | Orquesta: llama al legacy, transforma XML→JSON, llama al business-service, compone respuesta. Equivalente al 70% de orquestación/integración que hoy vive en los WAR. |
| `wso2-am` | WSO2 API Manager 4.3.0 | Gateway externo: seguridad OAuth2, rate limiting, gobierno del contrato (OpenAPI incluido). |

## 5. Decisiones de diseño

- **Desacoplamiento del legacy real/mock:** el endpoint de MI (`LegacyEndpoint.xml`) usa una URL configurable por variable de entorno. El flujo de orquestación no cambia entre ambiente de prueba (mock) y producción (endpoint real).
- **XML como formato del legacy:** se eligió a propósito para que el MVP demuestre transformación real, no un passthrough JSON→JSON.
- **Lógica de negocio fuera de MI:** la regla de elegibilidad vive en `business-service`, no en scripts dentro del flujo Synapse. Esto es intencional: mantiene el patrón "MI orquesta, los microservicios deciden", que es la separación de responsabilidades que se busca reemplazando WildFly.
- **Manejo de errores explícito:** el flujo de MI diferencia entre falla del legacy (502), error de orquestación (500) y respuesta exitosa (200), evitando que errores aguas abajo se propaguen sin control al canal.

## 6. Qué queda fuera del MVP (alcance deliberadamente reducido)

- Alta disponibilidad / clustering de WSO2 (single node en ambos productos)
- Developer Portal público y flujo de suscripción de terceros
- Analytics avanzado de WSO2
- Pipeline CI/CD completo de 6 etapas (se usa despliegue manual vía docker-compose)
- Migración de casos de uso existentes

## 7. Criterios de éxito

1. El flujo completo responde correctamente para un cliente elegible y uno no elegible (validado — ver sección de pruebas).
2. Latencia end-to-end aceptable para uso interno (a medir una vez desplegado con WSO2 real; los microservicios individualmente responden en <50ms).
3. Un desarrollador del equipo puede modificar la regla de negocio y desplegar el cambio sin tocar WSO2 (separación de responsabilidades validada).
4. El mismo flujo de MI funciona sin cambios apuntando al endpoint legacy real (solo cambiando `LEGACY_BASE_URL`).

## 8. Pruebas realizadas antes de la entrega

Los dos microservicios (`business-service` y `mock-legacy-service`) fueron levantados y probados de extremo a extremo en este ambiente de desarrollo, confirmando:
- Health checks respondiendo correctamente
- El mock legacy devuelve XML válido para un cliente existente
- El business-service aplica correctamente la regla de negocio, tanto para un cliente elegible (deuda/ingreso 25%, antigüedad 18 meses → elegible, límite sugerido 3000) como para uno no elegible (deuda/ingreso 63%, antigüedad 3 meses → no elegible)

Los 3 artefactos XML de Micro Integrator y el `docker-compose.yml` fueron validados sintácticamente (`xmllint`, parser YAML). **La validación de WSO2 API Manager y Micro Integrator corriendo juntos vía Docker requiere un ambiente con Docker disponible** (este entorno de generación no tiene Docker ni acceso a Docker Hub) — ver guía de despliegue para los pasos de verificación que debes correr tú.

## 9. Próximos pasos sugeridos (fuera de este MVP)

1. Correr `docker-compose up` en un ambiente con Docker y validar el flujo con WSO2 real (ver `README-deployment.md`)
2. Publicar el OpenAPI en el Publisher de API Manager y probar con un token OAuth2 real
3. Medir latencia end-to-end y compararla contra el WAR equivalente en WildFly
4. Si el MVP valida bien, definir el siguiente caso de uso a construir (ya no de prueba, sino productivo) y usar esta misma estructura de repo como plantilla
