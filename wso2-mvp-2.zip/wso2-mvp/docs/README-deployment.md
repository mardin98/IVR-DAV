# Guía de despliegue — MVP WSO2

## Requisitos previos

- Docker y Docker Compose instalados
- Puertos libres: 4000, 5000, 8280, 8243, 8290, 8253, 9443, 9164
- Al menos 4GB de RAM disponibles para los contenedores de WSO2 (son pesados)

## Paso 1 — Configurar el ambiente

```bash
cd wso2-mvp
cp .env.example .env
```

Por defecto `.env` apunta al mock incluido. Si ya tienes el endpoint real disponible, edítalo:

```
LEGACY_BASE_URL=https://tu-endpoint-real.davivienda.local
```

Si usas el endpoint real, revisa que:
- Responda en el mismo formato XML que espera `LegacyEndpoint.xml` (`<customerRecord><customerId>...</customerId>...`), o ajusta el `payloadFactory` en `MVPOrchestrationAPI.xml` al formato real
- Sea alcanzable desde la red de Docker (si es interno de Davivienda, puede requerir ajustar la red de docker-compose a `host` o configurar DNS/VPN)

## Paso 2 — Levantar el stack

```bash
docker-compose up -d
```

Esto levanta 4 contenedores: `mock-legacy-service`, `business-service`, `wso2-mi`, `wso2-am`. WSO2 tarda entre 1 y 3 minutos en arrancar completamente la primera vez.

Verifica que todo esté arriba:

```bash
docker-compose ps
docker-compose logs -f wso2-mi
docker-compose logs -f wso2-am
```

## Paso 3 — Probar el flujo de Micro Integrator directamente (sin gateway)

Antes de meter la capa de API Manager, prueba que MI orquesta bien:

```bash
curl http://localhost:8290/mvp/customer/12345/eligibility
```

Respuesta esperada (cliente elegible):
```json
{
  "customerId": "12345",
  "fullName": "Juan Perez",
  "eligible": true,
  "suggestedLimit": 3000,
  "debtToIncomeRatio": 0.25,
  "sourceSystem": "MI-ORCHESTRATION-MVP",
  "processedAt": "..."
}
```

Prueba también con `67890` (no elegible) y con un ID inexistente como `99999` (debe responder 502 con `LEGACY_LOOKUP_FAILED`).

## Paso 4 — Publicar la API en WSO2 API Manager

Este paso es manual vía UI la primera vez (no se automatiza en el MVP):

1. Entra a `https://localhost:9443/publisher` (usuario/clave por defecto de la imagen: `admin`/`admin`, **cámbialo antes de cualquier ambiente compartido**)
2. Crea una API nueva → **Import OpenAPI** → sube `integration/openapi/mvp-orchestration-api.yaml`
3. En la configuración del backend/endpoint de la API, apunta a: `http://wso2-mi:8290/mvp`
4. Configura el flujo de seguridad OAuth2 (Client Credentials) en la pestaña de Runtime
5. **Deploy** y luego **Publish** la API

## Paso 5 — Obtener token OAuth2 y probar a través del gateway

1. Entra a `https://localhost:9443/devportal`, suscríbete a la API con una aplicación nueva
2. Genera las credenciales (Consumer Key/Secret)
3. Obtén un token:

```bash
curl -k -X POST https://localhost:8243/token \
  -d "grant_type=client_credentials" \
  -u "<CONSUMER_KEY>:<CONSUMER_SECRET>"
```

4. Llama a la API a través del gateway con el token:

```bash
curl -k http://localhost:8280/mvp/1.0.0/customer/12345/eligibility \
  -H "Authorization: Bearer <ACCESS_TOKEN>"
```

Si esto responde igual que el paso 3, el flujo completo (gateway → MI → business-service + legacy) está validado de punta a punta.

## Solución de problemas comunes

| Síntoma | Causa probable |
|---|---|
| `wso2-mi` no orquesta, responde 404 | Los volúmenes de `docker-compose.yml` no montaron bien los artefactos; revisa `docker-compose logs wso2-mi` |
| `LEGACY_LOOKUP_FAILED` con el mock | El contenedor `mock-legacy-service` no está healthy; `docker-compose ps` |
| Timeout llamando al endpoint real | Restricción de red saliente; revisa que el endpoint real esté en la whitelist de salida del ambiente donde corre Docker |
| API Manager no arranca | Falta de memoria asignada a Docker; sube el límite de RAM del daemon de Docker |

## Apagar el stack

```bash
docker-compose down
```
