# Instalación desde cero — Red Hat Enterprise Linux (RHEL)

Esta guía asume una instalación limpia de RHEL 8 o 9, sin Docker instalado. Ejecuta todo como usuario con privilegios `sudo`.

## 0. Verificar versión y recursos

```bash
cat /etc/redhat-release
nproc                    # núcleos disponibles (recomendado: 4+)
free -h                  # RAM disponible (recomendado: 8GB+, WSO2 AM + MI son pesados)
df -h /                  # espacio en disco (recomendado: 20GB+ libres para imágenes)
```

## 1. Nota importante: RHEL no trae Docker por defecto

RHEL viene con **Podman** preinstalado, pero el `docker-compose.yml` de este proyecto está escrito para Docker Engine + Docker Compose. Docker no es un paquete oficial de los repos de RHEL, así que se instala desde el repositorio de CentOS (es el método estándar y funciona bien en RHEL 8/9).

Si tu organización ya estandarizó en Podman en vez de Docker, dímelo y te adapto el `docker-compose.yml` a un `podman-compose.yml` — la sintaxis es casi idéntica pero hay diferencias en manejo de redes y volúmenes.

## 2. Instalar Docker Engine

```bash
# Quitar cualquier versión vieja/conflictiva
sudo dnf remove -y docker docker-client docker-client-latest docker-common \
  docker-latest docker-latest-logrotate docker-logrotate docker-engine podman-docker

# Instalar utilidades necesarias
sudo dnf install -y dnf-plugins-core

# Agregar el repositorio de Docker (usando el repo de CentOS, compatible con RHEL)
sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# Instalar Docker Engine, CLI, containerd y el plugin de Compose
sudo dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

> Si `dnf config-manager` no existe, instálalo primero con `sudo dnf install -y dnf-plugins-core` (ya está en el paso anterior) o usa `sudo yum-config-manager` como alternativa en RHEL 8.

## 3. Habilitar e iniciar el servicio

```bash
sudo systemctl enable --now docker
sudo systemctl status docker
```

Debe mostrar `active (running)`.

## 4. Permitir correr Docker sin sudo (opcional pero recomendado)

```bash
sudo usermod -aG docker $USER
newgrp docker          # aplica el grupo sin necesidad de cerrar sesión
docker ps               # debe correr sin pedir sudo ni dar error de permisos
```

## 5. Verificar Docker Compose

Este proyecto usa la sintaxis `docker-compose` (con guión). El plugin moderno se invoca como `docker compose` (sin guión). Verifica cuál tienes:

```bash
docker compose version
```

Si prefieres usar el comando con guión (`docker-compose`) para que coincida exactamente con los comandos de la guía de despliegue, crea un alias:

```bash
echo "alias docker-compose='docker compose'" >> ~/.bashrc
source ~/.bashrc
```

## 6. SELinux (importante — RHEL lo trae activo por defecto)

Verifica el modo actual:

```bash
getenforce
```

Si dice `Enforcing` (lo normal y recomendado, **no lo desactives**), ya está cubierto: el `docker-compose.yml` de este proyecto monta los volúmenes de los artefactos de MI con la etiqueta `:Z`, que le indica a SELinux que ese contenido es privado del contenedor. Sin esa etiqueta, WSO2 MI fallaría al leer los archivos montados con un error de "Permission denied" aunque los permisos Unix se vean correctos.

Si de todas formas ves errores de permisos en los volúmenes, confirma el contexto:

```bash
ls -Z integration/mi-artifacts/api
```

## 7. Firewall — abrir los puertos necesarios

```bash
sudo firewall-cmd --permanent --add-port=4000/tcp    # business-service
sudo firewall-cmd --permanent --add-port=5000/tcp    # mock-legacy-service
sudo firewall-cmd --permanent --add-port=8280/tcp    # WSO2 AM Gateway HTTP
sudo firewall-cmd --permanent --add-port=8243/tcp    # WSO2 AM Gateway HTTPS
sudo firewall-cmd --permanent --add-port=8290/tcp    # WSO2 MI HTTP
sudo firewall-cmd --permanent --add-port=8253/tcp    # WSO2 MI HTTPS
sudo firewall-cmd --permanent --add-port=9443/tcp    # WSO2 AM Consola/Publisher/DevPortal
sudo firewall-cmd --permanent --add-port=9164/tcp    # WSO2 MI gestión
sudo firewall-cmd --reload
```

Si vas a acceder solo desde `localhost` (la misma máquina donde corre Docker), este paso no es estrictamente necesario — solo lo necesitas si otra persona/equipo va a probar la API desde otra máquina en la red.

## 8. Verificar que los puertos no estén ocupados

```bash
sudo ss -tulpn | grep -E ':(4000|5000|8280|8243|8290|8253|9443|9164)\b'
```

Si no devuelve nada, todos los puertos están libres. Si algo aparece, hay un conflicto que resolver antes de levantar el stack (otro servicio usando ese puerto).

## 9. Ya con Docker listo — continuar con el despliegue del MVP

A partir de aquí sigue exactamente `README-deployment.md` (Paso 1 en adelante: `cp .env.example .env`, `docker-compose up -d`, etc.)

## Troubleshooting específico de RHEL

| Síntoma | Causa | Solución |
|---|---|---|
| `docker: permission denied` al correr sin sudo | Usuario no está en el grupo `docker` o no se aplicó la sesión nueva | Repite el paso 4, o cierra sesión y vuelve a entrar |
| `Permission denied` leyendo archivos montados en `wso2-mi` | Falta la etiqueta SELinux en el volumen | Ya está corregido en `docker-compose.yml` con `:Z`; si clonaste una versión vieja del archivo, agrégala |
| `dnf config-manager: command not found` | Falta `dnf-plugins-core` | `sudo dnf install -y dnf-plugins-core` antes del paso 2 |
| Contenedores de WSO2 se reinician en loop | Poca memoria asignada — WSO2 AM + MI necesitan varios GB entre los dos | Verifica `free -h`; considera subir la RAM de la VM/servidor |
| `firewall-cmd: command not found` | `firewalld` no está instalado o no es el gestor activo (algunas RHEL minimal usan `iptables` directo) | `sudo dnf install -y firewalld && sudo systemctl enable --now firewalld`, o ajusta reglas con la herramienta que sí tengas |
