/**
 * mock-legacy-service
 * ------------------------------------------------------------
 * Simula el sistema legacy (core bancario / mainframe / AS400)
 * SOLO para cuando no se tiene acceso al endpoint real o se
 * quiere probar el MVP de forma aislada.
 *
 * Responde en XML a propósito: así el flujo del Micro Integrator
 * demuestra una transformación real (XML legacy -> JSON moderno),
 * que es exactamente el tipo de trabajo que hoy hacen los WARs.
 *
 * Para usar el endpoint REAL en vez de este mock, simplemente
 * cambia LEGACY_ENDPOINT_URL en el .env / docker-compose apuntando
 * al endpoint real. El contrato de MI está desacoplado de esto.
 * ------------------------------------------------------------
 */
const express = require('express');
const app = express();

const PORT = process.env.PORT || 5000;

// Datos de prueba en "formato legacy" - simula 3 clientes fijos
const CUSTOMERS = {
  '12345': { monthlyIncome: 1200, existingDebt: 300, accountAgeMonths: 18, fullName: 'Juan Perez' },
  '67890': { monthlyIncome: 800, existingDebt: 500, accountAgeMonths: 3, fullName: 'Maria Lopez' },
  '11111': { monthlyIncome: 2500, existingDebt: 200, accountAgeMonths: 40, fullName: 'Carlos Gomez' }
};

app.get('/health', (req, res) => {
  res.status(200).send('<health><status>UP</status></health>');
});

/**
 * GET /legacy/customer/:id
 * Responde en XML, como lo haría un sistema legacy real.
 */
app.get('/legacy/customer/:id', (req, res) => {
  const customer = CUSTOMERS[req.params.id];

  res.set('Content-Type', 'application/xml');

  if (!customer) {
    return res.status(404).send(
      `<error><code>NOT_FOUND</code><message>Cliente ${req.params.id} no existe</message></error>`
    );
  }

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<customerRecord>
  <customerId>${req.params.id}</customerId>
  <fullName>${customer.fullName}</fullName>
  <monthlyIncome>${customer.monthlyIncome}</monthlyIncome>
  <existingDebt>${customer.existingDebt}</existingDebt>
  <accountAgeMonths>${customer.accountAgeMonths}</accountAgeMonths>
  <sourceSystem>MOCK-LEGACY-CORE</sourceSystem>
</customerRecord>`;

  res.status(200).send(xml);
});

app.listen(PORT, () => {
  console.log(`mock-legacy-service escuchando en puerto ${PORT}`);
});
