/**
 * business-service
 * ------------------------------------------------------------
 * Microservicio de LOGICA DE NEGOCIO para el MVP de arquitectura
 * WSO2 API Manager + Micro Integrator.
 *
 * Este servicio NO conoce al sistema legacy ni al canal de entrada.
 * Solo recibe datos ya transformados por el Micro Integrator y
 * aplica una regla de negocio (elegibilidad crediticia simplificada).
 *
 * WSO2 Micro Integrator lo invoca como un servicio downstream más,
 * igual que llamaría a cualquier otro microservicio del stack.
 * ------------------------------------------------------------
 */
const express = require('express');
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 4000;

// Health check - usado por docker-compose healthcheck y por MI para validar disponibilidad
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'UP', service: 'business-service' });
});

/**
 * POST /business/eligibility
 * Recibe el perfil del cliente (ya normalizado por MI) y devuelve
 * una decisión de negocio. Esta es la pieza que en el WAR legacy
 * hoy vive mezclada con la orquestación; aquí queda aislada.
 *
 * Body esperado:
 * {
 *   "customerId": "12345",
 *   "monthlyIncome": 1200,
 *   "existingDebt": 300,
 *   "accountAgeMonths": 18
 * }
 */
app.post('/business/eligibility', (req, res) => {
  const { customerId, monthlyIncome, existingDebt, accountAgeMonths } = req.body || {};

  if (!customerId || monthlyIncome === undefined) {
    return res.status(400).json({
      error: 'BAD_REQUEST',
      message: 'customerId y monthlyIncome son requeridos'
    });
  }

  // Regla de negocio simplificada (ejemplo para el MVP):
  // - Relación deuda/ingreso debe ser menor a 40%
  // - Antigüedad de cuenta mínima de 6 meses
  const debtToIncome = existingDebt ? existingDebt / monthlyIncome : 0;
  const meetsDebtRatio = debtToIncome < 0.4;
  const meetsTenure = (accountAgeMonths || 0) >= 6;
  const eligible = meetsDebtRatio && meetsTenure;

  const suggestedLimit = eligible
    ? Math.round(monthlyIncome * 2.5)
    : 0;

  return res.status(200).json({
    customerId,
    eligible,
    suggestedLimit,
    evaluatedAt: new Date().toISOString(),
    rulesApplied: {
      debtToIncomeRatio: Number(debtToIncome.toFixed(2)),
      meetsDebtRatio,
      meetsTenure
    }
  });
});

app.listen(PORT, () => {
  console.log(`business-service escuchando en puerto ${PORT}`);
});
