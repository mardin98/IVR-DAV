"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { logout } from "@/lib/firebaseClient";

export default function NavBar({ user }) {
  const pathname = usePathname();
  const router = useRouter();

  const tabs = [
    { href: "/chat", label: "Notas" },
    { href: "/documentos", label: "Documentos" },
  ];

  async function handleLogout() {
    await logout();
    router.replace("/");
  }

  return (
    <header className="border-b border-line bg-white">
      <div className="max-w-3xl mx-auto px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <span className="font-display text-lg text-ink">Bitácora</span>
          <nav className="flex gap-1">
            {tabs.map((t) => (
              <Link
                key={t.href}
                href={t.href}
                className={`text-sm px-3 py-1.5 rounded-md transition-colors ${
                  pathname === t.href
                    ? "bg-accentSoft text-accent font-medium"
                    : "text-ink/60 hover:text-ink"
                }`}
              >
                {t.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-ink/50 hidden sm:block">{user?.email}</span>
          <button
            onClick={handleLogout}
            className="text-xs text-ink/50 hover:text-warn transition-colors"
          >
            Salir
          </button>
        </div>
      </div>
    </header>
  );
}
