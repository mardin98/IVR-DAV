// instrumentation.js
// Next.js ejecuta register() UNA VEZ al levantar el servidor (cada
// instancia/contenedor). Lo usamos para asegurar que la base de
// Firestore exista antes de que lleguen requests.

export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { ensureFirestoreDatabase } = await import("./lib/ensureFirestoreDatabase");
    try {
      await ensureFirestoreDatabase();
    } catch (e) {
      console.error("No se pudo preparar Firestore al arrancar:", e.message);
    }
  }
}
