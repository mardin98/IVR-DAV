"use client";
import { useAuth } from "@/lib/useAuth";
import { loginWithGoogle } from "@/lib/firebaseClient";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user) router.replace("/chat");
  }, [user, router]);

  async function handleLogin() {
    try {
      await loginWithGoogle();
    } catch (e) {
      console.error(e);
    }
  }

  if (loading) return null;

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 bg-paper">
      <div className="max-w-sm w-full text-center">
        <p className="font-mono text-xs tracking-widest text-warn uppercase mb-3">
          Bitácora
        </p>
        <h1 className="font-display text-3xl text-ink mb-3 leading-snug">
          Tus notas de proyecto,
          <br />siempre a la mano.
        </h1>
        <p className="text-sm text-ink/60 mb-10">
          Registra avances y tickets en el momento. Cuando llegue el pase a
          producción, la bitácora recuerda por ti.
        </p>
        <button
          onClick={handleLogin}
          className="w-full border border-line bg-white hover:border-accent hover:bg-accentSoft transition-colors rounded-md py-3 text-sm font-medium text-ink flex items-center justify-center gap-2"
        >
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62z"/>
            <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.81.54-1.85.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.95v2.33A9 9 0 0 0 9 18z"/>
            <path fill="#FBBC05" d="M3.97 10.72A5.4 5.4 0 0 1 3.68 9c0-.6.1-1.18.29-1.72V4.95H.95A9 9 0 0 0 0 9c0 1.45.35 2.83.95 4.05l3.02-2.33z"/>
            <path fill="#EA4335" d="M9 3.58c1.32 0 2.51.45 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .95 4.95l3.02 2.33C4.68 5.16 6.66 3.58 9 3.58z"/>
          </svg>
          Continuar con Google
        </button>
      </div>
    </main>
  );
}
