import "./globals.css";

export const metadata = {
  title: "Bitácora — segundo cerebro",
  description: "Notas de proyectos con recuperación semántica",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
