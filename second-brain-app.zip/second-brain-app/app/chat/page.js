"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import NavBar from "@/components/NavBar";

const MODOS = [
  { id: "nota", label: "Guardar nota" },
  { id: "buscar", label: "Preguntar / resumir" },
];

export default function ChatPage() {
  const { user, loading, apiFetch } = useAuth();
  const router = useRouter();
  const [modo, setModo] = useState("nota");
  const [clasificacionManual, setClasificacionManual] = useState(false);
  const [proyectoManual, setProyectoManual] = useState("");
  const [tagsManual, setTagsManual] = useState("");
  const [proyectoFiltro, setProyectoFiltro] = useState("");
  const [texto, setTexto] = useState("");
  const [mensajes, setMensajes] = useState([]);
  const [enviando, setEnviando] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/");
  }, [user, loading, router]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [mensajes]);

  async function handleSend() {
    if (!texto.trim() || enviando) return;
    const textoEnviado = texto;
    setTexto("");
    setMensajes((m) => [...m, { rol: "usuario", texto: textoEnviado }]);
    setEnviando(true);

    try {
      if (modo === "nota") {
        const body = { texto: textoEnviado };
        if (clasificacionManual && proyectoManual.trim()) {
          body.proyecto = proyectoManual.trim();
          body.tags = tagsManual
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean);
        }
        const data = await apiFetch("/api/notes", {
          method: "POST",
          body: JSON.stringify(body),
        });
        setMensajes((m) => [
          ...m,
          {
            rol: "sistema",
            texto: `Nota guardada en “${data.proyecto}”${
              data.tags?.length ? ` · ${data.tags.join(", ")}` : ""
            } (${data.clasificacion === "manual" ? "clasificación manual" : "clasificación automática"})`,
          },
        ]);
      } else {
        const data = await apiFetch("/api/notes/search", {
          method: "POST",
          body: JSON.stringify({
            pregunta: textoEnviado,
            proyecto: proyectoFiltro || undefined,
          }),
        });
        setMensajes((m) => [
          ...m,
          { rol: "sistema", texto: data.respuesta, notas: data.notas },
        ]);
      }
    } catch (e) {
      setMensajes((m) => [...m, { rol: "error", texto: e.message }]);
    } finally {
      setEnviando(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  if (loading || !user) return null;

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <NavBar user={user} />

      <div className="max-w-3xl mx-auto w-full px-5 pt-4 flex items-center gap-2">
        {MODOS.map((m) => (
          <button
            key={m.id}
            onClick={() => setModo(m.id)}
            className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
              modo === m.id
                ? "border-accent bg-accentSoft text-accent font-medium"
                : "border-line text-ink/60 hover:border-ink/30"
            }`}
          >
            {m.label}
          </button>
        ))}
        {modo === "buscar" && (
          <input
            value={proyectoFiltro}
            onChange={(e) => setProyectoFiltro(e.target.value)}
            placeholder="Filtrar por proyecto (opcional)"
            className="text-xs px-3 py-1.5 rounded-full border border-line bg-white ml-auto w-52 focus:border-accent outline-none"
          />
        )}

        {modo === "nota" && (
          <label className="ml-auto flex items-center gap-1.5 text-xs text-ink/60 cursor-pointer">
            <input
              type="checkbox"
              checked={clasificacionManual}
              onChange={(e) => setClasificacionManual(e.target.checked)}
              className="accent-accent"
            />
            Clasificar manualmente
          </label>
        )}
      </div>

      {modo === "nota" && clasificacionManual && (
        <div className="max-w-3xl mx-auto w-full px-5 pt-2 flex gap-2">
          <input
            value={proyectoManual}
            onChange={(e) => setProyectoManual(e.target.value)}
            placeholder="Proyecto (ej: MIG C)"
            className="text-xs px-3 py-1.5 rounded-md border border-line bg-white flex-1 focus:border-accent outline-none"
          />
          <input
            value={tagsManual}
            onChange={(e) => setTagsManual(e.target.value)}
            placeholder="Tags separados por coma (opcional)"
            className="text-xs px-3 py-1.5 rounded-md border border-line bg-white flex-1 focus:border-accent outline-none"
          />
        </div>
      )}

      <div ref={scrollRef} className="flex-1 overflow-y-auto max-w-3xl mx-auto w-full px-5 py-6 space-y-4">
        {mensajes.length === 0 && (
          <div className="text-center text-ink/40 text-sm mt-20">
            {modo === "nota"
              ? "Escribe lo que acabas de hacer, un ticket o una decisión tomada."
              : "Pregunta por ejemplo: “dame las notas para el pase a producción de MIG C”."}
          </div>
        )}

        {mensajes.map((m, i) => (
          <div key={i} className={`flex ${m.rol === "usuario" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-lg px-4 py-2.5 text-sm whitespace-pre-wrap ${
                m.rol === "usuario"
                  ? "bg-accent text-white"
                  : m.rol === "error"
                  ? "bg-warn/10 text-warn border border-warn/30"
                  : "bg-white border border-line text-ink"
              }`}
            >
              {m.texto}
              {m.notas?.length > 0 && (
                <div className="mt-2 pt-2 border-t border-line/60 space-y-1">
                  {m.notas.map((n) => (
                    <div key={n.id} className="text-xs text-ink/50">
                      · [{n.proyecto}] {n.texto.slice(0, 90)}
                      {n.texto.length > 90 ? "…" : ""}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {enviando && (
          <div className="text-xs text-ink/40 font-mono">procesando…</div>
        )}
      </div>

      <div className="border-t border-line bg-white px-5 py-4">
        <div className="max-w-3xl mx-auto flex gap-2">
          <textarea
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
            placeholder={
              modo === "nota" ? "Escribe tu nota…" : "Escribe tu pregunta…"
            }
            className="flex-1 resize-none border border-line rounded-md px-3 py-2.5 text-sm focus:border-accent outline-none"
          />
          <button
            onClick={handleSend}
            disabled={enviando || !texto.trim()}
            className="bg-accent text-white text-sm px-4 rounded-md disabled:opacity-40"
          >
            Enviar
          </button>
        </div>
      </div>
    </div>
  );
}
