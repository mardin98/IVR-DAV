// app/api/notes/search/route.js
// POST -> búsqueda semántica sobre las notas del usuario + resumen generado con Gemini
// Body: { pregunta: string, proyecto?: string, topK?: number }

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";
import { generateEmbedding, cosineSim, generateSummary } from "@/lib/gemini";

export async function POST(req) {
  try {
    const uid = await getUserFromRequest(req);
    const { pregunta, proyecto, topK = 12 } = await req.json();

    if (!pregunta) {
      return Response.json({ error: "Falta la pregunta" }, { status: 400 });
    }

    // 1. Filtra primero por proyecto (si se indica) para no comparar contra todo
    let query = db.collection("notas").where("userId", "==", uid);
    if (proyecto) query = query.where("proyecto", "==", proyecto);
    const snap = await query.get();
    const notas = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

    if (notas.length === 0) {
      return Response.json({ respuesta: "No hay notas registradas todavía.", notas: [] });
    }

    // 2. Embedding de la pregunta y similitud coseno contra cada nota
    const preguntaEmbedding = await generateEmbedding(pregunta);
    const ranked = notas
      .map((n) => ({ ...n, score: cosineSim(preguntaEmbedding, n.embedding) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);

    // 3. Gemini arma el resumen final a partir de las notas más relevantes
    const respuesta = await generateSummary(pregunta, ranked);

    return Response.json({
      respuesta,
      notas: ranked.map((n) => ({ id: n.id, texto: n.texto, proyecto: n.proyecto, score: n.score })),
    });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
