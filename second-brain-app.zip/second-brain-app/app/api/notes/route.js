// app/api/notes/route.js
// POST -> guarda una nota nueva.
// Si el body trae "proyecto" (y opcionalmente "tags"), se usa eso tal cual
// (clasificación MANUAL). Si no vienen, Gemini clasifica automáticamente.

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";
import { classifyNote, generateEmbedding } from "@/lib/gemini";

export async function POST(req) {
  try {
    const uid = await getUserFromRequest(req);
    const { texto, proyecto: proyectoManual, tags: tagsManual } = await req.json();

    if (!texto || texto.trim().length === 0) {
      return Response.json({ error: "Texto vacío" }, { status: 400 });
    }

    const esManual = !!proyectoManual;

    // Si el usuario ya indicó el proyecto a mano, nos saltamos la
    // clasificación de Gemini y solo generamos el embedding.
    const [clasificacion, embedding] = await Promise.all([
      esManual
        ? Promise.resolve({
            proyecto: proyectoManual,
            tags: tagsManual || [],
            resumen_corto: texto.slice(0, 80),
          })
        : classifyNote(texto),
      generateEmbedding(texto),
    ]);

    const docRef = await db.collection("notas").add({
      texto,
      proyecto: clasificacion.proyecto,
      tags: clasificacion.tags,
      resumenCorto: clasificacion.resumen_corto,
      clasificacion: esManual ? "manual" : "automatica",
      embedding,
      userId: uid,
      createdAt: new Date(),
    });

    return Response.json({
      id: docRef.id,
      proyecto: clasificacion.proyecto,
      tags: clasificacion.tags,
      clasificacion: esManual ? "manual" : "automatica",
    });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}

// GET -> lista notas del usuario (opcional: ?proyecto=X)
export async function GET(req) {
  try {
    const uid = await getUserFromRequest(req);
    const { searchParams } = new URL(req.url);
    const proyecto = searchParams.get("proyecto");

    let query = db.collection("notas").where("userId", "==", uid);
    if (proyecto) query = query.where("proyecto", "==", proyecto);

    const snap = await query.orderBy("createdAt", "desc").limit(200).get();
    const notas = snap.docs.map((d) => ({ id: d.id, ...d.data(), embedding: undefined }));

    return Response.json({ notas });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
