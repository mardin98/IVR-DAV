// app/api/notes/[id]/route.js
// PATCH -> corrige manualmente el proyecto/tags de una nota existente
// (por si la clasificación automática se equivocó).
// Body: { proyecto?, tags? }

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";

export async function PATCH(req, { params }) {
  try {
    const uid = await getUserFromRequest(req);
    const { id } = params;
    const { proyecto, tags } = await req.json();

    const ref = db.collection("notas").doc(id);
    const snap = await ref.get();

    if (!snap.exists || snap.data().userId !== uid) {
      return Response.json({ error: "Nota no encontrada" }, { status: 404 });
    }

    const cambios = { clasificacion: "manual" };
    if (proyecto) cambios.proyecto = proyecto;
    if (tags) cambios.tags = tags;

    await ref.update(cambios);
    return Response.json({ ok: true, ...cambios });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}

export async function DELETE(req, { params }) {
  try {
    const uid = await getUserFromRequest(req);
    const { id } = params;
    const ref = db.collection("notas").doc(id);
    const snap = await ref.get();

    if (!snap.exists || snap.data().userId !== uid) {
      return Response.json({ error: "Nota no encontrada" }, { status: 404 });
    }

    await ref.delete();
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
