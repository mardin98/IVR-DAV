// app/api/documents/compare/route.js
// POST -> compara las notas de un proyecto contra los chunks de un documento
// Body: { proyecto, documentoId }

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";
import { compareAgainstDocument } from "@/lib/gemini";

export async function POST(req) {
  try {
    const uid = await getUserFromRequest(req);
    const { proyecto, documentoId } = await req.json();

    if (!proyecto || !documentoId) {
      return Response.json({ error: "Falta proyecto o documentoId" }, { status: 400 });
    }

    const notasSnap = await db
      .collection("notas")
      .where("userId", "==", uid)
      .where("proyecto", "==", proyecto)
      .get();
    const notas = notasSnap.docs.map((d) => d.data());

    const chunksSnap = await db
      .collection("documentos")
      .doc(documentoId)
      .collection("chunks")
      .get();
    const chunks = chunksSnap.docs.map((d) => d.data());

    if (notas.length === 0 || chunks.length === 0) {
      return Response.json({ error: "No hay notas o documento suficiente para comparar" }, { status: 400 });
    }

    const analisis = await compareAgainstDocument(notas, chunks);
    return Response.json({ analisis });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
