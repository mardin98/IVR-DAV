// app/api/documents/upload/route.js
// POST -> recibe el ARCHIVO (multipart/form-data), extrae el texto,
// lo trocea y guarda embeddings por chunk.
// FormData: file (PDF/DOCX/TXT), proyecto (string)

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";
import { generateEmbedding, chunkText } from "@/lib/gemini";
import { extractText } from "@/lib/extractText";

export async function POST(req) {
  try {
    const uid = await getUserFromRequest(req);
    const formData = await req.formData();
    const file = formData.get("file");
    const proyecto = formData.get("proyecto") || "Sin proyecto";

    if (!file) {
      return Response.json({ error: "Falta el archivo" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const textoCompleto = await extractText(buffer, file.type);

    if (!textoCompleto || textoCompleto.trim().length < 20) {
      return Response.json({ error: "No se pudo extraer texto del archivo" }, { status: 400 });
    }

    const docRef = await db.collection("documentos").add({
      nombreArchivo: file.name,
      proyecto,
      userId: uid,
      uploadedAt: new Date(),
    });

    const chunks = chunkText(textoCompleto);
    const batch = db.batch();

    for (const [i, texto] of chunks.entries()) {
      const embedding = await generateEmbedding(texto);
      const chunkRef = docRef.collection("chunks").doc(`chunk_${i}`);
      batch.set(chunkRef, { texto, embedding, orden: i });
    }
    await batch.commit();

    return Response.json({ id: docRef.id, chunksGuardados: chunks.length, proyecto });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
