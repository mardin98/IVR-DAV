// app/api/documents/route.js
// GET -> lista documentos subidos por el usuario (opcional ?proyecto=X)

import { db, getUserFromRequest } from "@/lib/firebaseAdmin";

export async function GET(req) {
  try {
    const uid = await getUserFromRequest(req);
    const { searchParams } = new URL(req.url);
    const proyecto = searchParams.get("proyecto");

    let query = db.collection("documentos").where("userId", "==", uid);
    if (proyecto) query = query.where("proyecto", "==", proyecto);

    const snap = await query.orderBy("uploadedAt", "desc").get();
    const documentos = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

    return Response.json({ documentos });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 401 });
  }
}
