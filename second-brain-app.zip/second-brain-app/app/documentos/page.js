"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
import NavBar from "@/components/NavBar";

export default function DocumentosPage() {
  const { user, loading, apiFetch } = useAuth();
  const router = useRouter();

  const [proyecto, setProyecto] = useState("");
  const [archivo, setArchivo] = useState(null);
  const [subiendo, setSubiendo] = useState(false);
  const [documentos, setDocumentos] = useState([]);
  const [docSeleccionado, setDocSeleccionado] = useState("");
  const [proyectoComparar, setProyectoComparar] = useState("");
  const [analisis, setAnalisis] = useState("");
  const [comparando, setComparando] = useState(false);
  const [mensaje, setMensaje] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/");
  }, [user, loading, router]);

  useEffect(() => {
    if (user) cargarDocumentos();
  }, [user]);

  async function cargarDocumentos() {
    try {
      const data = await apiFetch("/api/documents");
      setDocumentos(data.documentos || []);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleUpload() {
    if (!archivo) return;
    setSubiendo(true);
    setMensaje("");
    try {
      const token = await user.getIdToken();
      const formData = new FormData();
      formData.append("file", archivo);
      formData.append("proyecto", proyecto || "Sin proyecto");

      const res = await fetch("/api/documents/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setMensaje(`“${archivo.name}” guardado (${data.chunksGuardados} secciones indexadas).`);
      setArchivo(null);
      cargarDocumentos();
    } catch (e) {
      setMensaje(`Error: ${e.message}`);
    } finally {
      setSubiendo(false);
    }
  }

  async function handleComparar() {
    if (!docSeleccionado || !proyectoComparar) return;
    setComparando(true);
    setAnalisis("");
    try {
      const data = await apiFetch("/api/documents/compare", {
        method: "POST",
        body: JSON.stringify({ proyecto: proyectoComparar, documentoId: docSeleccionado }),
      });
      setAnalisis(data.analisis);
    } catch (e) {
      setAnalisis(`Error: ${e.message}`);
    } finally {
      setComparando(false);
    }
  }

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-paper">
      <NavBar user={user} />

      <main className="max-w-3xl mx-auto px-5 py-8 space-y-10">
        {/* Subir documento */}
        <section>
          <h2 className="font-display text-xl text-ink mb-1">Base de conocimiento</h2>
          <p className="text-sm text-ink/50 mb-4">
            Sube checklists, manuales o guías de referencia. Se indexan por secciones
            para poder cruzarlos luego contra tus notas.
          </p>
          <div className="bg-white border border-line rounded-lg p-5 space-y-3">
            <input
              value={proyecto}
              onChange={(e) => setProyecto(e.target.value)}
              placeholder="Proyecto asociado (ej: MIG C)"
              className="w-full border border-line rounded-md px-3 py-2 text-sm focus:border-accent outline-none"
            />
            <input
              type="file"
              accept=".pdf,.docx,.txt"
              onChange={(e) => setArchivo(e.target.files[0])}
              className="w-full text-sm"
            />
            <button
              onClick={handleUpload}
              disabled={!archivo || subiendo}
              className="bg-accent text-white text-sm px-4 py-2 rounded-md disabled:opacity-40"
            >
              {subiendo ? "Procesando…" : "Subir e indexar"}
            </button>
            {mensaje && <p className="text-xs text-ink/60">{mensaje}</p>}
          </div>

          {documentos.length > 0 && (
            <div className="mt-3 space-y-1">
              {documentos.map((d) => (
                <div key={d.id} className="text-xs text-ink/50 font-mono">
                  · {d.nombreArchivo} — {d.proyecto}
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Comparar */}
        <section>
          <h2 className="font-display text-xl text-ink mb-1">Verificar cobertura</h2>
          <p className="text-sm text-ink/50 mb-4">
            Compara las notas de un proyecto contra un documento para ver qué falta
            antes del pase a producción o presentación.
          </p>
          <div className="bg-white border border-line rounded-lg p-5 space-y-3">
            <input
              value={proyectoComparar}
              onChange={(e) => setProyectoComparar(e.target.value)}
              placeholder="Proyecto a verificar (ej: MIG C)"
              className="w-full border border-line rounded-md px-3 py-2 text-sm focus:border-accent outline-none"
            />
            <select
              value={docSeleccionado}
              onChange={(e) => setDocSeleccionado(e.target.value)}
              className="w-full border border-line rounded-md px-3 py-2 text-sm focus:border-accent outline-none bg-white"
            >
              <option value="">Selecciona un documento…</option>
              {documentos.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.nombreArchivo} ({d.proyecto})
                </option>
              ))}
            </select>
            <button
              onClick={handleComparar}
              disabled={!docSeleccionado || !proyectoComparar || comparando}
              className="bg-accent text-white text-sm px-4 py-2 rounded-md disabled:opacity-40"
            >
              {comparando ? "Analizando…" : "Comparar"}
            </button>
          </div>

          {analisis && (
            <div className="mt-4 bg-white border border-line rounded-lg p-5 text-sm whitespace-pre-wrap text-ink">
              {analisis}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
