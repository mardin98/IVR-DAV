/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#1C1E21",
        paper: "#FAFAF9",
        line: "#E4E4E2",
        accent: "#2F5D50",
        accentSoft: "#E7EFEC",
        warn: "#B5482A",
      },
      fontFamily: {
        display: ["'IBM Plex Serif'", "serif"],
        body: ["'IBM Plex Sans'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
