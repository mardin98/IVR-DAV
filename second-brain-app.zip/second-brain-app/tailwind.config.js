/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#1C1E21",
        paper: "#FFFFFF",
        line: "#E6E6E6",
        accent: "#EC1C24",
        accentSoft: "#FDEBEC",
        warn: "#B5482A",
      },
      fontFamily: {
        display: ["'IBM Plex Serif'", "serif"],
        body: ["'IBM Plex Sans'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
