/** @type {import('next').NextConfig} */
const nextConfig = {
  serverExternalPackages: ["pdf-parse", "mammoth", "@google-cloud/firestore"],
  experimental: {
    instrumentationHook: true,
  },
};

module.exports = nextConfig;
