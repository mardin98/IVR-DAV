# Bitácora — Second Brain App

App para registrar notas de proyectos/tickets por chat, con clasificación
automática, búsqueda semántica y comparación contra documentos de
referencia (checklists, manuales de pase a producción, etc.).

Stack: Next.js 14 · Firebase Auth (Google) · Firestore · Gemini 1.5 Flash.
Multiusuario: cada quien solo ve sus propias notas y documentos.

---

## 1. Crear el proyecto en Firebase

1. Ve a https://console.firebase.google.com → **Crear proyecto**.
2. Dentro del proyecto:
   - **Build → Authentication → Sign-in method** → habilita **Google**.
   - **Build → Firestore Database** → **Crear base de datos** (modo producción,
     la región más cercana, ej. `us-central1`).
3. Registra una app web: ⚙️ **Configuración del proyecto → General →
   Tus apps → Web (</>)**. Copia el objeto `firebaseConfig` que te da,
   ahí están los valores de `NEXT_PUBLIC_FIREBASE_*`.
4. Genera credenciales de servidor: ⚙️ **Configuración del proyecto →
   Cuentas de servicio → Generar nueva clave privada**. Descarga el JSON,
   ese es tu `FIREBASE_SERVICE_ACCOUNT_JSON`.

## 2. Conseguir la API key de Gemini

1. Ve a https://aistudio.google.com/apikey y genera una key.
2. Guárdala como `GEMINI_API_KEY`.

## 3. La base de Firestore se crea sola (NO usa la "(default)")

No hace falta ningún paso manual: la app trae `lib/ensureFirestoreDatabase.js`,
que corre automáticamente una vez al arrancar el servidor (vía
`instrumentation.js` de Next.js). Verifica si existe una base con nombre
`bitacora-db` (configurable con `FIRESTORE_DATABASE_ID`) y, si no existe,
la crea usando el cliente Admin de Firestore — así nunca se usa la base
`(default)` que Firebase crea sola.

Lo único que necesitas es que la **service account tenga el rol correcto**
para poder crear bases, no solo leer/escribir datos:

**Google Cloud Console → IAM → busca tu service account → Editar →
agregar rol "Cloud Datastore Owner" (`roles/datastore.owner`)**
(o "Editor" si prefieres algo más amplio para desarrollo).

Sin ese rol, el arranque del servidor mostrará en los logs que no pudo
crear la base — con "Cloud Datastore Owner" queda resuelto.

## 4. Configurar variables de entorno

Copia esto a un archivo `.env.local` en la raíz del proyecto:

```
NEXT_PUBLIC_FIREBASE_API_KEY=AIza...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=tu-proyecto.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=tu-proyecto
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=tu-proyecto.appspot.com
NEXT_PUBLIC_FIREBASE_APP_ID=1:xxxx:web:xxxx

FIREBASE_SERVICE_ACCOUNT_JSON={"type":"service_account","project_id":"...", ...todo el JSON en una sola línea...}

GEMINI_API_KEY=AIza...

FIRESTORE_DATABASE_ID=bitacora-db
FIRESTORE_LOCATION=us-central1
```

> Nota sobre índices: las consultas combinadas (`where userId ==` +
> `where proyecto ==` + `orderBy createdAt`) requieren un índice compuesto.
> Firestore te lo pide crear la primera vez que corras esa consulta y te
> da un link directo en el error de la consola/logs — un clic y listo.

> Truco para meter el JSON en una línea:
> `cat service-account.json | jq -c . ` (con `jq` instalado) o simplemente
> pega el archivo completo respetando que quede entre comillas simples en
> el `.env.local` si tu gestor de variables lo permite.

## 5. Instalar y correr en local (esto también crea la base de Firestore)

```bash
npm install
npm run dev
```

Al arrancar, verás en la consola algo como
`[firestore] Base "bitacora-db" no existe. Creando...` seguido de
`creada correctamente`. Ese primer arranque ya deja la base lista —
por eso conviene correr `npm run dev` una vez antes de desplegar reglas
o hacer el deploy a producción.

Abre `http://localhost:3000`, entra con Google, y ya puedes:
- Escribir notas en **Notas** (se auto-clasifican por proyecto/tags con Gemini).
- Activar "Clasificar manualmente" para indicar tú mismo el proyecto/tags
  en vez de dejar que Gemini decida — útil cuando ya sabes exactamente
  dónde va la nota o quieres forzar un nombre de proyecto consistente.
- Corregir después una nota mal clasificada con `PATCH /api/notes/{id}`
  (queda marcada como `clasificacion: "manual"` para no perder el ajuste).
- Pedir resúmenes: "dame las notas para el pase a producción de MIG C".
- Subir documentos en **Documentos** y comparar cobertura contra tus notas.

## 6. Desplegar las reglas de seguridad de Firestore

Instala Firebase CLI si no la tienes:

```bash
npm install -g firebase-tools
firebase login
firebase init firestore   # selecciona tu proyecto, acepta el firestore.rules existente
firebase deploy --only firestore:rules --database=bitacora-db
```

Si el CLI no te deja pasar `--database` en el deploy, ajusta el bloque
`firestore` en `firebase.json` agregando `"database": "bitacora-db"`
junto a `"rules": "firestore.rules"`.

Esto asegura que nadie pueda leer/escribir notas o documentos que no
sean suyos, aunque intente llamar a Firestore directamente.

---

## 7. Despliegue en producción — Cloud Run (recomendado, dado tu stack en GCP)

### a) Dockerfile

Ya viene incluido en la raíz del proyecto (`Dockerfile`), listo para
usar tal cual — no necesitas crear nada.

### b) Build y despliegue

```bash
# Autenticado con gcloud y con el proyecto seleccionado
gcloud builds submit --tag gcr.io/TU_PROYECTO_GCP/bitacora-app

gcloud run deploy bitacora-app \
  --image gcr.io/TU_PROYECTO_GCP/bitacora-app \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars NEXT_PUBLIC_FIREBASE_API_KEY=...,NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=...,NEXT_PUBLIC_FIREBASE_PROJECT_ID=...,NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=...,NEXT_PUBLIC_FIREBASE_APP_ID=...,GEMINI_API_KEY=...,FIRESTORE_DATABASE_ID=bitacora-db,FIRESTORE_LOCATION=us-central1
```

Para `FIREBASE_SERVICE_ACCOUNT_JSON` (es largo y sensible), mejor usa
**Secret Manager** en vez de pasarlo como variable de entorno plana:

```bash
gcloud secrets create firebase-service-account --data-file=service-account.json

gcloud run deploy bitacora-app \
  --image gcr.io/TU_PROYECTO_GCP/bitacora-app \
  --update-secrets=FIREBASE_SERVICE_ACCOUNT_JSON=firebase-service-account:latest \
  ...(resto de flags igual que arriba)
```

### c) Autorizar el dominio en Firebase Auth

Una vez desplegado, Cloud Run te da una URL tipo
`https://bitacora-app-xxxx-uc.a.run.app`. Agrégala en:

**Firebase Console → Authentication → Settings → Authorized domains**
→ **Add domain**.

Sin este paso, el login con Google fallará en producción con
`auth/unauthorized-domain`.

---

## 8. Estructura final del proyecto

```
app/
  page.js                    -> login
  chat/page.js                -> notas + búsqueda/resumen
  documentos/page.js          -> subir y comparar documentos
  layout.js, globals.css
  api/
    notes/route.js                    -> POST guardar (auto o manual) | GET listar
    notes/[id]/route.js               -> PATCH corregir clasificación | DELETE borrar
    notes/search/route.js             -> POST búsqueda semántica + resumen
    documents/route.js                -> GET listar documentos
    documents/upload/route.js         -> POST subir archivo (extrae+trocea+embeddings)
    documents/compare/route.js        -> POST comparar notas vs documento

components/NavBar.js

lib/
  firebaseClient.js         -> Auth en navegador
  firebaseAdmin.js          -> Firestore (datos) + verificación de tokens (servidor)
  ensureFirestoreDatabase.js -> crea la base "bitacora-db" si no existe (plano de control)
  useAuth.js                 -> hook de sesión + fetch autenticado
  gemini.js                  -> clasificar, embeddings, resumen, comparación
  extractText.js              -> PDF/DOCX/TXT -> texto plano

instrumentation.js   -> corre ensureFirestoreDatabase() una vez al arrancar
firestore.rules
Dockerfile            -> ya incluido, listo para build/deploy
public/               -> estáticos (vacía por ahora)
```

## 9. Costos esperados (uso personal / equipo pequeño)

- Firestore + Auth + Hosting: dentro del free tier, **$0**.
- Gemini Flash (clasificación, embeddings, resúmenes): **$1–5/mes**.
- Cloud Run: factura por uso; con tráfico bajo/moderado normalmente
  cae dentro del free tier mensual (2M requests) o cuesta centavos.
- **Total estimado: $0–10/mes.**

## 10. Próximos pasos opcionales

- Botón "editar proyecto" en una nota si Gemini clasificó mal.
- Exportar el resumen generado directo a PDF o Google Doc.
- Notificación (correo/Slack) cuando se detecta un "FALTANTE" al comparar
  contra el checklist.
