/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: ['better-sqlite3', '@stoplight/spectral-core', 'openapi-to-postmanv2', 'archiver', 'docx']
  }
};
export default nextConfig;
