# API Design Copilot — API Factory Davivienda

Herramienta **100% local** para transformar reglas de negocio en contratos OpenAPI certificables,
con documentación completa para el equipo de desarrollo y paquete de gobernanza.

La única conexión externa es la API de Gemini (Google AI Studio). No usa GitLab, GCP ni Firestore.
Cumple la restricción de red del banco: solo conexiones salientes.

## Qué genera por cada diseño

- `contrato/openapi.yaml` — OpenAPI 3.0.3 validado con Spectral (rulesets Davivienda + BIAN + FAPI 2.0 condicional)
- `documentacion/traduccion-reglas-negocio.md` — comportamiento exacto por regla, para el dev
- `documentacion/documento-control.docx` — ficha técnica, matriz de cumplimiento (con citas al manual), matriz de trazabilidad y checklist FAPI 2.0
- `documentacion/diagrama-orquestacion.mmd` — si la capa proceso requiere composición
- `pruebas/postman-collection.json` — generada determinísticamente del contrato
- `validacion/reporte-spectral.json`

## Instalación

```bash
npm install
cp .env.example .env      # y coloca tu GEMINI_API_KEY de https://aistudio.google.com/apikey
npm run dev               # http://localhost:3000
```

Para producción local: `npm run build && npm start`.

## Flujo de uso

1. **Base de conocimiento** — carga el manual técnico interno (se indexa con RAG y se cita por sección
   en la matriz de cumplimiento) y 2–3 contratos gold standard (se usan como ejemplos few-shot).
   Sin esto la app funciona en "modo genérico" y lo avisa.
2. **Catálogo existente** — registra las APIs ya certificadas. El motor de recomendación las usa
   para sugerir reutilización y bloquear duplicados.
3. **Nuevo diseño** — wizard de 4 pasos. Las reglas de negocio siguen la plantilla obligatoria
   Actor + Acción + Condición + Excepción (la excepción define los códigos de error del contrato).
   El perfil de seguridad (FAPI 2.0 / OAuth2 interno / mTLS) se calcula solo según capa y exposición.
4. **Generar** — solo se habilita sin bloqueantes. Pipeline: heurísticas de composición → RAG →
   prompt de 4 capas → Gemini → validación Spectral → segundo pase de corrección si hay errores →
   versión persistida con changelog.
5. **Descargar ZIP** — el paquete completo por versión.

## Arquitectura

```
src/lib/
  db.js           SQLite (better-sqlite3): apis, versiones, changelog, catálogo, conocimiento
  completitud.js  Score 0-100% + validaciones bloqueantes (anti-GIGO)
  seguridad.js    Matriz capa×exposición → perfil (FAPI 2.0 / OAuth2 / mTLS) + checklist FAPI
  recomendador.js Heurísticas determinísticas de composición (etapa 1)
  rag.js          Chunking por secciones + embeddings (text-embedding-004) + top-K coseno
  gemini.js       Prompt de 4 capas (system fijo → RAG → few-shot → formulario) + segundo pase
  spectral.js     Rulesets: davivienda (siempre), bian (siempre), fapi (si perfil FAPI 2.0)
  exportar.js     Postman determinístico + documento-control.docx + ZIP
```

La base de datos se crea sola en `data/copilot.db` al primer arranque.

## Notas operativas

- **Regeneración**: pide motivo y queda en el changelog. Cada versión conserva el prompt usado (auditoría).
- **Modelo**: `gemini-1.5-flash` por defecto; cámbialo en `.env` (p. ej. `gemini-1.5-pro` para diseños complejos).
- **Manual en Word/PDF**: exporta a Markdown/texto antes de cargarlo, conservando los números de sección — son los que se citan en la matriz de cumplimiento.
