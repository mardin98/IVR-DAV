'use client';
import { useEffect, useState } from 'react';
import GlifoCapas from '@/components/GlifoCapas';

const NUEVO = { nombre: '', capa: 'sistema', dominio_bian: '', operaciones: '', estado: 'certificada' };

export default function Catalogo() {
  const [items, setItems] = useState(null);
  const [form, setForm] = useState(NUEVO);
  const [mostrarForm, setMostrarForm] = useState(false);

  const cargar = () => fetch('/api/catalogo').then((r) => r.json()).then(setItems);
  useEffect(() => { cargar(); }, []);

  async function agregar() {
    const operaciones = form.operaciones
      .split('\n').map((l) => l.trim()).filter(Boolean)
      .map((l) => { const [metodo, ...resto] = l.split(/\s+/); return { metodo, path: resto.join(' ') }; });
    await fetch('/api/catalogo', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, operaciones }),
    });
    setForm(NUEVO); setMostrarForm(false); cargar();
  }

  async function quitar(id) {
    if (!confirm('¿Quitar esta API del catálogo?')) return;
    await fetch('/api/catalogo', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    cargar();
  }

  return (
    <>
      <div className="eyebrow">Inventario</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1>Catálogo de APIs existentes</h1>
          <p className="descripcion">
            El motor de recomendación usa este catálogo para sugerir reutilización y detectar duplicados.
            Mantenerlo al día es lo que evita crear APIs que ya existen.
          </p>
        </div>
        <button className="primario" onClick={() => setMostrarForm(!mostrarForm)}>{mostrarForm ? 'Cancelar' : 'Registrar API'}</button>
      </div>

      {mostrarForm && (
        <div className="panel">
          <div className="fila-3">
            <label className="campo">Nombre
              <input type="text" value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} placeholder="API Sistema Consulta Cuentas" />
            </label>
            <label className="campo">Capa
              <select value={form.capa} onChange={(e) => setForm({ ...form, capa: e.target.value })}>
                <option value="sistema">Sistema</option><option value="proceso">Proceso</option><option value="experiencia">Experiencia</option>
              </select>
            </label>
            <label className="campo">Dominio BIAN
              <input type="text" value={form.dominio_bian} onChange={(e) => setForm({ ...form, dominio_bian: e.target.value })} placeholder="Current Account" />
            </label>
          </div>
          <label className="campo">Operaciones (una por línea: MÉTODO /path)
            <textarea className="mono" value={form.operaciones} onChange={(e) => setForm({ ...form, operaciones: e.target.value })} placeholder={'GET /v1/accounts/{id}\nGET /v1/accounts/{id}/balance'} />
          </label>
          <label className="campo">Estado
            <select value={form.estado} onChange={(e) => setForm({ ...form, estado: e.target.value })}>
              <option value="certificada">Certificada</option><option value="en_desarrollo">En desarrollo</option><option value="deprecada">Deprecada</option>
            </select>
          </label>
          <div style={{ marginTop: 14 }}><button className="primario" onClick={agregar} disabled={!form.nombre || !form.dominio_bian}>Guardar en catálogo</button></div>
        </div>
      )}

      {items?.length === 0 && <div className="panel"><p className="descripcion">Catálogo vacío. Registra las APIs certificadas que ya existen en el API Factory.</p></div>}

      {items?.map((c) => (
        <div key={c.id} className="tarjeta-api">
          <GlifoCapas capa={c.capa} conLeyenda />
          <div>
            <strong>{c.nombre}</strong>
            <div className="descripcion">{c.dominio_bian} · {JSON.parse(c.operaciones_json || '[]').length} operaciones</div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span className={`chip ${c.estado === 'certificada' ? 'validado' : c.estado === 'deprecada' ? '' : 'generado'}`}>{c.estado.replace('_', ' ')}</span>
            <button className="fantasma" onClick={() => quitar(c.id)}>Quitar</button>
          </div>
        </div>
      ))}
    </>
  );
}
