import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { indexarDocumento } from '@/lib/rag';

export async function GET() {
  const docs = getDb()
    .prepare(`SELECT d.id, d.nombre_archivo, d.tipo, d.version, d.fecha_carga,
              (SELECT COUNT(*) FROM chunks_conocimiento c WHERE c.documento_id = d.id) AS chunks
              FROM documentos_conocimiento d ORDER BY d.fecha_carga DESC`)
    .all();
  return NextResponse.json(docs);
}

export async function POST(req) {
  const { nombre_archivo, tipo, contenido, version } = await req.json();
  if (!contenido?.trim()) return NextResponse.json({ error: 'Contenido vacío' }, { status: 400 });
  const db = getDb();
  const info = db
    .prepare('INSERT INTO documentos_conocimiento (nombre_archivo, tipo, contenido_completo, version) VALUES (?, ?, ?, ?)')
    .run(nombre_archivo, tipo, contenido, version || null);

  let chunks = 0;
  if (tipo !== 'gold_standard_openapi') {
    // Los gold standards se usan completos (few-shot), no se trocean
    chunks = await indexarDocumento(info.lastInsertRowid, contenido, nombre_archivo);
  }
  return NextResponse.json({ id: info.lastInsertRowid, chunks });
}

export async function DELETE(req) {
  const { id } = await req.json();
  getDb().prepare('DELETE FROM documentos_conocimiento WHERE id = ?').run(id);
  return NextResponse.json({ ok: true });
}
