import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET() {
  return NextResponse.json(getDb().prepare('SELECT * FROM catalogo_apis ORDER BY id DESC').all());
}

export async function POST(req) {
  const b = await req.json();
  const info = getDb()
    .prepare(`INSERT INTO catalogo_apis (nombre, capa, dominio_bian, operaciones_json, estado, contrato_openapi, fecha_certificacion)
              VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(b.nombre, b.capa, b.dominio_bian, JSON.stringify(b.operaciones || []), b.estado || 'certificada', b.contrato_openapi || null, b.fecha_certificacion || null);
  return NextResponse.json({ id: info.lastInsertRowid });
}

export async function DELETE(req) {
  const { id } = await req.json();
  getDb().prepare('DELETE FROM catalogo_apis WHERE id = ?').run(id);
  return NextResponse.json({ ok: true });
}
