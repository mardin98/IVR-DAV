import { NextResponse } from 'next/server';
import { getDb, siguienteVersion } from '@/lib/db';
import { evaluarCompletitud } from '@/lib/completitud';
import { analizarComposicion } from '@/lib/recomendador';
import { recuperarContexto, obtenerGoldStandards } from '@/lib/rag';
import { generarContrato, corregirContrato } from '@/lib/gemini';
import { validarContrato } from '@/lib/spectral';

export const maxDuration = 300;

export async function POST(req, { params }) {
  const db = getDb();
  const api = db.prepare('SELECT * FROM apis WHERE id = ?').get(params.id);
  if (!api) return NextResponse.json({ error: 'API no encontrada' }, { status: 404 });

  const { motivo } = await req.json().catch(() => ({}));
  const formulario = JSON.parse(api.formulario_json);

  // 1. Validaciones bloqueantes (anti-GIGO): sin contexto suficiente no se gasta la llamada
  const completitud = evaluarCompletitud(formulario);
  if (!completitud.puede_generar) {
    return NextResponse.json(
      { error: 'El formulario tiene campos bloqueantes sin completar', completitud },
      { status: 422 }
    );
  }

  try {
    // 2. Etapa 1 de recomendación: heurísticas determinísticas
    const recomendacion = analizarComposicion(formulario);

    // 3. RAG: recuperar secciones relevantes del manual interno
    const queryRag = `${formulario.capa_api} ${formulario.dominio_bian} ${formulario.exposicion} ${formulario.descripcion_negocio}`;
    const contextoRag = await recuperarContexto(queryRag, 6);

    // 4. Few-shot: gold standards certificados
    const goldStandards = obtenerGoldStandards(2);

    // 5. Generación con Gemini (prompt de 4 capas)
    const contexto = { formulario, perfil: api.perfil_seguridad, recomendacion, contextoRag, goldStandards };
    let { respuesta, prompt } = await generarContrato(contexto);

    // 6. Validación Spectral
    let spectralRes = await validarContrato(respuesta.openapi_yaml, api.perfil_seguridad);

    // 7. Segundo pase si hay errores de gobernanza
    let segundoPase = false;
    if (!spectralRes.limpio) {
      segundoPase = true;
      const errores = spectralRes.violaciones.filter((v) => v.severidad === 'error');
      const correccion = await corregirContrato(contexto, respuesta.openapi_yaml, errores);
      respuesta = correccion.respuesta;
      prompt = correccion.prompt;
      spectralRes = await validarContrato(respuesta.openapi_yaml, api.perfil_seguridad);
    }

    // 8. Persistir versión + changelog
    const numeroVersion = siguienteVersion(api.id);
    const info = db
      .prepare(
        `INSERT INTO versiones_api
         (api_id, numero_version, openapi_yaml, documento_control_json, traduccion_reglas_json, recomendacion_json, resultado_spectral_json, prompt_usado, modelo_usado)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        api.id,
        numeroVersion,
        respuesta.openapi_yaml,
        JSON.stringify(respuesta.documento_control || {}),
        JSON.stringify(respuesta.traduccion_reglas || []),
        JSON.stringify(respuesta.recomendaciones_composicion || recomendacion),
        JSON.stringify(spectralRes),
        prompt,
        process.env.GEMINI_MODEL || 'gemini-1.5-flash'
      );

    db.prepare(
      'INSERT INTO changelog (api_id, version_anterior, version_nueva, cambios_detectados, motivo) VALUES (?, ?, ?, ?, ?)'
    ).run(
      api.id,
      numeroVersion > 1 ? numeroVersion - 1 : null,
      numeroVersion,
      segundoPase ? 'Generación con segundo pase de corrección Spectral' : 'Generación limpia en primer pase',
      motivo || (numeroVersion === 1 ? 'Primera generación' : 'Regeneración')
    );

    db.prepare(
      `UPDATE apis SET estado = ?, actualizado_en = datetime('now') WHERE id = ?`
    ).run(spectralRes.limpio ? 'validado' : 'generado', api.id);

    return NextResponse.json({
      version_id: info.lastInsertRowid,
      numero_version: numeroVersion,
      spectral: spectralRes,
      segundo_pase: segundoPase,
      sugerencias_mejora: respuesta.sugerencias_mejora || [],
      recomendaciones_composicion: respuesta.recomendaciones_composicion || recomendacion,
      contexto_usado: {
        chunks_manual: contextoRag.length,
        gold_standards: goldStandards.length,
        senales_composicion: recomendacion.senales?.length || 0,
      },
    });
  } catch (e) {
    console.error('Error en generación:', e);
    return NextResponse.json({ error: `Fallo en la generación: ${e.message}` }, { status: 500 });
  }
}
