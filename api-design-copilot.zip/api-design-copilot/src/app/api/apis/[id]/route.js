import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { calcularPerfilSeguridad } from '@/lib/seguridad';
import { evaluarCompletitud } from '@/lib/completitud';

export async function GET(_req, { params }) {
  const db = getDb();
  const api = db.prepare('SELECT * FROM apis WHERE id = ?').get(params.id);
  if (!api) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
  const versiones = db
    .prepare('SELECT id, numero_version, creado_en, resultado_spectral_json FROM versiones_api WHERE api_id = ? ORDER BY numero_version DESC')
    .all(params.id);
  const ultima = db
    .prepare('SELECT * FROM versiones_api WHERE api_id = ? ORDER BY numero_version DESC LIMIT 1')
    .get(params.id);
  const changelog = db.prepare('SELECT * FROM changelog WHERE api_id = ? ORDER BY id DESC').all(params.id);
  const formulario = JSON.parse(api.formulario_json);
  return NextResponse.json({ api, formulario, versiones, ultima, changelog, completitud: evaluarCompletitud(formulario) });
}

export async function PUT(req, { params }) {
  const formulario = await req.json();
  const perfil = calcularPerfilSeguridad(formulario.capa_api, formulario.exposicion);
  getDb()
    .prepare(`UPDATE apis SET nombre=?, capa=?, exposicion=?, dominio_bian=?, perfil_seguridad=?, formulario_json=?, actualizado_en=datetime('now') WHERE id=?`)
    .run(formulario.nombre_api, formulario.capa_api, formulario.exposicion, formulario.dominio_bian, perfil, JSON.stringify(formulario), params.id);
  return NextResponse.json({ ok: true, perfil_seguridad: perfil, completitud: evaluarCompletitud(formulario) });
}

export async function DELETE(_req, { params }) {
  getDb().prepare('DELETE FROM apis WHERE id = ?').run(params.id);
  return NextResponse.json({ ok: true });
}
