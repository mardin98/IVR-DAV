import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { generarZip } from '@/lib/exportar';

export const maxDuration = 120;

export async function GET(req, { params }) {
  const db = getDb();
  const api = db.prepare('SELECT * FROM apis WHERE id = ?').get(params.id);
  if (!api) return NextResponse.json({ error: 'API no encontrada' }, { status: 404 });

  const url = new URL(req.url);
  const versionParam = url.searchParams.get('version');
  const version = versionParam
    ? db.prepare('SELECT * FROM versiones_api WHERE api_id = ? AND numero_version = ?').get(params.id, versionParam)
    : db.prepare('SELECT * FROM versiones_api WHERE api_id = ? ORDER BY numero_version DESC LIMIT 1').get(params.id);

  if (!version) return NextResponse.json({ error: 'Aún no hay versiones generadas' }, { status: 404 });

  const { buffer, nombre } = await generarZip({ api, version });
  return new NextResponse(buffer, {
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${nombre}"`,
    },
  });
}
