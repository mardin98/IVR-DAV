import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { calcularPerfilSeguridad } from '@/lib/seguridad';
import { evaluarCompletitud } from '@/lib/completitud';

export async function GET() {
  const apis = getDb()
    .prepare(`SELECT a.*, (SELECT MAX(numero_version) FROM versiones_api v WHERE v.api_id = a.id) AS ultima_version
              FROM apis a ORDER BY a.actualizado_en DESC`)
    .all();
  return NextResponse.json(apis);
}

export async function POST(req) {
  const formulario = await req.json();
  const perfil = calcularPerfilSeguridad(formulario.capa_api, formulario.exposicion);
  const completitud = evaluarCompletitud(formulario);
  try {
    const info = getDb()
      .prepare(`INSERT INTO apis (nombre, codigo_interno, capa, exposicion, dominio_bian, perfil_seguridad, formulario_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .run(
        formulario.nombre_api, formulario.codigo_interno, formulario.capa_api,
        formulario.exposicion, formulario.dominio_bian, perfil, JSON.stringify(formulario)
      );
    return NextResponse.json({ id: info.lastInsertRowid, perfil_seguridad: perfil, completitud });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) {
      return NextResponse.json({ error: 'Ya existe un API con ese código interno' }, { status: 409 });
    }
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
