'use client';
import { useEffect, useRef, useState } from 'react';

const TIPOS = {
  manual_interno: 'Manual técnico interno',
  norma_sib: 'Norma regulatoria (SIB)',
  estandar_bian: 'Estándar BIAN',
  gold_standard_openapi: 'Contrato gold standard (OpenAPI)',
};

export default function Conocimiento() {
  const [docs, setDocs] = useState(null);
  const [form, setForm] = useState({ nombre_archivo: '', tipo: 'manual_interno', contenido: '', version: '' });
  const [subiendo, setSubiendo] = useState(false);
  const [aviso, setAviso] = useState(null);
  const fileRef = useRef();

  const cargar = () => fetch('/api/conocimiento').then((r) => r.json()).then(setDocs);
  useEffect(() => { cargar(); }, []);

  function leerArchivo(e) {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    const lector = new FileReader();
    lector.onload = () => setForm((f) => ({ ...f, nombre_archivo: f.nombre_archivo || archivo.name, contenido: String(lector.result) }));
    lector.readAsText(archivo);
  }

  async function subir() {
    setSubiendo(true); setAviso(null);
    const res = await fetch('/api/conocimiento', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
    });
    const data = await res.json();
    setSubiendo(false);
    if (!res.ok) return setAviso({ tipo: 'error', texto: data.error });
    setAviso({ tipo: 'ok', texto: form.tipo === 'gold_standard_openapi' ? 'Gold standard guardado (se usa completo como ejemplo few-shot).' : `Documento indexado en ${data.chunks} secciones para RAG.` });
    setForm({ nombre_archivo: '', tipo: form.tipo, contenido: '', version: '' });
    if (fileRef.current) fileRef.current.value = '';
    cargar();
  }

  async function quitar(id) {
    if (!confirm('¿Eliminar este documento y sus chunks?')) return;
    await fetch('/api/conocimiento', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    cargar();
  }

  const tieneManual = docs?.some((d) => d.tipo === 'manual_interno');
  const goldCount = docs?.filter((d) => d.tipo === 'gold_standard_openapi').length ?? 0;

  return (
    <>
      <div className="eyebrow">Contexto de gobernanza</div>
      <h1>Base de conocimiento</h1>
      <p className="descripcion">
        Lo que cargues aquí es lo que la IA consulta al generar cada contrato: el manual interno se indexa
        para RAG (con citas por sección) y los gold standards se usan completos como ejemplos de estilo.
      </p>

      {docs && (!tieneManual || goldCount < 2) && (
        <div className="aviso">
          <strong>Modo genérico activo.</strong> Para resultados alineados a tu gobernanza:
          {!tieneManual && ' carga el manual técnico interno'}{!tieneManual && goldCount < 2 && ' y'}
          {goldCount < 2 && ` carga ${2 - goldCount} contrato(s) gold standard más`}.
        </div>
      )}

      <div className="panel">
        <h2>Cargar documento</h2>
        <div className="fila-3">
          <label className="campo">Tipo
            <select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })}>
              {Object.entries(TIPOS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </label>
          <label className="campo">Nombre
            <input type="text" value={form.nombre_archivo} onChange={(e) => setForm({ ...form, nombre_archivo: e.target.value })} placeholder="manual-diseno-apis-v3.md" />
          </label>
          <label className="campo">Versión (opcional)
            <input type="text" value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} placeholder="v3.1" />
          </label>
        </div>
        <label className="campo">Archivo (.md, .txt, .yaml) — o pega el contenido abajo
          <span className="ayuda">Si tu manual está en Word/PDF, expórtalo a texto o Markdown primero (conserva los números de sección: son los que se citan en la matriz de cumplimiento).</span>
          <input type="file" ref={fileRef} accept=".md,.txt,.yaml,.yml,.json" onChange={leerArchivo} />
        </label>
        <label className="campo">Contenido
          <textarea className="mono" style={{ minHeight: 160 }} value={form.contenido} onChange={(e) => setForm({ ...form, contenido: e.target.value })} placeholder="# 4. Estándares de diseño&#10;## 4.2 Manejo de errores&#10;### 4.2.1 Formato uniforme…" />
        </label>
        {aviso && <div className={`aviso ${aviso.tipo === 'ok' ? 'ok' : 'error'}`}>{aviso.texto}</div>}
        <div style={{ marginTop: 14 }}>
          <button className="primario" onClick={subir} disabled={subiendo || !form.contenido || !form.nombre_archivo}>
            {subiendo ? 'Indexando…' : 'Cargar e indexar'}
          </button>
        </div>
      </div>

      {docs?.length > 0 && (
        <div className="panel">
          <h2>Documentos cargados</h2>
          <table className="datos">
            <thead><tr><th>Documento</th><th>Tipo</th><th>Secciones RAG</th><th>Cargado</th><th></th></tr></thead>
            <tbody>
              {docs.map((d) => (
                <tr key={d.id}>
                  <td className="mono">{d.nombre_archivo}{d.version ? ` · ${d.version}` : ''}</td>
                  <td>{TIPOS[d.tipo]}</td>
                  <td>{d.tipo === 'gold_standard_openapi' ? 'completo (few-shot)' : d.chunks}</td>
                  <td>{d.fecha_carga}</td>
                  <td><button className="fantasma" onClick={() => quitar(d.id)}>Eliminar</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
