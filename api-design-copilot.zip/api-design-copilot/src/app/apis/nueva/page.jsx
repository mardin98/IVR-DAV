'use client';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Suspense } from 'react';
import FormularioApi from '@/components/FormularioApi';

function Contenido() {
  const params = useSearchParams();
  const id = params.get('id');
  const [inicial, setInicial] = useState(undefined);

  useEffect(() => {
    if (!id) return setInicial(null);
    fetch(`/api/apis/${id}`).then((r) => r.json()).then((d) => setInicial(d.formulario));
  }, [id]);

  if (inicial === undefined) return <div className="panel">Cargando…</div>;
  return <FormularioApi apiId={id} formularioInicial={inicial} />;
}

export default function NuevaApi() {
  return (
    <Suspense fallback={<div className="panel">Cargando…</div>}>
      <Contenido />
    </Suspense>
  );
}
