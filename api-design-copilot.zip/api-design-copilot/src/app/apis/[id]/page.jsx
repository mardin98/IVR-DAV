'use client';
import { useCallback, useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import GlifoCapas from '@/components/GlifoCapas';

export default function DetalleApi() {
  const { id } = useParams();
  const router = useRouter();
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('contrato');
  const [generando, setGenerando] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [errorGen, setErrorGen] = useState(null);

  const cargar = useCallback(() => {
    fetch(`/api/apis/${id}`).then((r) => r.json()).then(setData);
  }, [id]);

  useEffect(() => { cargar(); }, [cargar]);

  async function generar() {
    setGenerando(true);
    setErrorGen(null);
    setResultado(null);
    const motivo = data?.ultima ? prompt('Motivo de la regeneración (queda en el changelog):') : 'Primera generación';
    const res = await fetch(`/api/apis/${id}/generar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ motivo }),
    });
    const body = await res.json();
    setGenerando(false);
    if (!res.ok) {
      setErrorGen(body.error || 'Error en la generación');
      if (body.completitud) setResultado({ completitud: body.completitud });
      return;
    }
    setResultado(body);
    cargar();
  }

  async function eliminar() {
    if (!confirm('¿Eliminar este diseño y todas sus versiones?')) return;
    await fetch(`/api/apis/${id}`, { method: 'DELETE' });
    router.push('/');
  }

  if (!data) return <div className="panel">Cargando…</div>;
  const { api, formulario, ultima, versiones, changelog, completitud } = data;
  const control = ultima ? JSON.parse(ultima.documento_control_json || '{}') : null;
  const traduccion = ultima ? JSON.parse(ultima.traduccion_reglas_json || '[]') : [];
  const spectral = ultima?.resultado_spectral_json ? JSON.parse(ultima.resultado_spectral_json) : null;
  const recomendacion = ultima?.recomendacion_json ? JSON.parse(ultima.recomendacion_json) : null;

  return (
    <>
      <div className="eyebrow">{api.dominio_bian} · {api.perfil_seguridad === 'fapi_2_0' ? 'FAPI 2.0' : api.perfil_seguridad.replace('_', ' ')}</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 20 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <GlifoCapas capa={api.capa} conLeyenda />
          <div>
            <h1>{api.nombre}</h1>
            <p className="descripcion mono">{api.codigo_interno} · {api.exposicion === 'externa_apigee' ? 'Externa vía Apigee' : 'Interna'} · <span className={`chip ${api.estado}`}>{api.estado}</span></p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Link href={`/apis/nueva?id=${api.id}`}><button>Editar formulario</button></Link>
          {ultima && <a href={`/api/apis/${api.id}/exportar`}><button>Descargar ZIP</button></a>}
          <button className="primario" onClick={generar} disabled={generando || !completitud.puede_generar}>
            {generando ? 'Generando…' : ultima ? `Regenerar (v${ultima.numero_version + 1})` : 'Generar contrato'}
          </button>
        </div>
      </div>

      {!completitud.puede_generar && (
        <div className="aviso error">
          <strong>El formulario tiene {completitud.bloqueantes.length} bloqueante(s).</strong> Complétalos en
          {' '}<Link href={`/apis/nueva?id=${api.id}`} style={{ textDecoration: 'underline' }}>Editar formulario</Link> para habilitar la generación.
          <ul className="lista-problemas bloqueantes">{completitud.bloqueantes.slice(0, 6).map((b, i) => <li key={i}>{b}</li>)}</ul>
        </div>
      )}
      {completitud.puede_generar && completitud.score < 80 && (
        <div className="aviso">Completitud al {completitud.score}%. Puedes generar, pero con menos de 80% el contrato puede salir con vacíos.</div>
      )}

      {errorGen && <div className="aviso error">{errorGen}</div>}

      {resultado?.spectral && (
        <div className={`aviso ${resultado.spectral.limpio ? 'ok' : ''}`}>
          <strong>
            {resultado.spectral.limpio
              ? `Contrato v${resultado.numero_version} generado y validado sin errores de gobernanza`
              : `Contrato v${resultado.numero_version} generado con ${resultado.spectral.total_errores} error(es) pendientes tras el segundo pase`}
          </strong>
          <div className="descripcion">
            {resultado.segundo_pase ? 'Requirió segundo pase de corrección con Spectral. ' : 'Limpio en primer pase. '}
            Contexto usado: {resultado.contexto_usado.chunks_manual} secciones del manual · {resultado.contexto_usado.gold_standards} gold standards · {resultado.contexto_usado.senales_composicion} señales de composición.
          </div>
          {resultado.sugerencias_mejora?.length > 0 && (
            <ul className="lista-problemas advertencias">
              {resultado.sugerencias_mejora.map((s, i) => <li key={i}><strong>{s.campo_formulario}:</strong> {s.problema} — {s.sugerencia}</li>)}
            </ul>
          )}
        </div>
      )}

      {!ultima && <div className="panel"><h2>Sin versiones aún</h2><p className="descripcion">Genera el primer contrato para ver aquí el YAML, la traducción de reglas y el documento de control.</p></div>}

      {ultima && (
        <>
          <div className="tabs" role="tablist">
            {[
              ['contrato', `Contrato v${ultima.numero_version}`],
              ['traduccion', 'Traducción para devs'],
              ['control', 'Documento de control'],
              ['composicion', 'Composición'],
              ['spectral', `Spectral (${spectral?.total_errores ?? 0}E/${spectral?.total_advertencias ?? 0}W)`],
              ['historial', 'Historial'],
            ].map(([k, t]) => (
              <button key={k} className={tab === k ? 'actual' : ''} onClick={() => setTab(k)}>{t}</button>
            ))}
          </div>

          {tab === 'contrato' && <pre className="codigo">{ultima.openapi_yaml}</pre>}

          {tab === 'traduccion' && (
            <div className="panel">
              {traduccion.map((t, i) => (
                <div key={i} className="bloque">
                  <h3 className="mono">{t.regla_id} → {t.endpoint}</h3>
                  <p style={{ marginTop: 8 }}>{t.comportamiento}</p>
                  <table className="datos">
                    <thead><tr><th>HTTP</th><th>Código</th><th>Cuándo</th></tr></thead>
                    <tbody>
                      {(t.casos_error || []).map((e, j) => (
                        <tr key={j}><td className="mono">{e.http}</td><td className="mono">{e.code}</td><td>{e.cuando}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
          )}

          {tab === 'control' && control && (
            <div className="panel">
              <h2>Ficha técnica</h2>
              <table className="datos"><tbody>
                {Object.entries(control.ficha_tecnica || {}).map(([k, v]) => (
                  <tr key={k}><td style={{ fontWeight: 600, width: 220 }}>{k.replaceAll('_', ' ')}</td><td>{Array.isArray(v) ? v.join(', ') : String(v)}</td></tr>
                ))}
              </tbody></table>

              <h2 style={{ marginTop: 24 }}>Matriz de cumplimiento</h2>
              <table className="datos">
                <thead><tr><th>Control</th><th>Cumple</th><th>Referencia</th><th>Observación</th></tr></thead>
                <tbody>
                  {(control.matriz_cumplimiento || []).map((c, i) => (
                    <tr key={i}><td>{c.control}</td><td style={{ color: c.cumple ? 'var(--ok)' : 'var(--error)', fontWeight: 700 }}>{c.cumple ? 'Sí' : 'No'}</td><td>{c.referencia_manual}</td><td>{c.observacion || '—'}</td></tr>
                  ))}
                </tbody>
              </table>

              <h2 style={{ marginTop: 24 }}>Trazabilidad regla → endpoint → control</h2>
              <table className="datos">
                <thead><tr><th>Regla</th><th>Endpoint</th><th>Control técnico</th></tr></thead>
                <tbody>
                  {(control.matriz_trazabilidad || []).map((t, i) => (
                    <tr key={i}><td className="mono">{t.regla}</td><td className="mono">{t.endpoint}</td><td>{t.control_tecnico}</td></tr>
                  ))}
                </tbody>
              </table>

              {control.seguridad?.checklist_fapi?.length > 0 && (
                <>
                  <h2 style={{ marginTop: 24 }}>Checklist FAPI 2.0</h2>
                  <table className="datos">
                    <thead><tr><th>Requisito</th><th>Cumple</th><th>Detalle</th></tr></thead>
                    <tbody>
                      {control.seguridad.checklist_fapi.map((r, i) => (
                        <tr key={i}><td>{r.req}</td><td style={{ color: r.cumple ? 'var(--ok)' : 'var(--error)', fontWeight: 700 }}>{r.cumple ? 'Sí' : 'No'}</td><td>{r.mecanismo || r.justificacion || '—'}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </>
              )}
            </div>
          )}

          {tab === 'composicion' && (
            <div className="panel">
              {recomendacion?.requiere_composicion === false && <div className="aviso ok">No requiere composición: puede resolverse con una sola API.</div>}
              {recomendacion?.justificacion && <p style={{ marginTop: 10 }}>{recomendacion.justificacion}</p>}
              {(recomendacion?.apis_a_reutilizar || []).length > 0 && (
                <>
                  <h2 style={{ marginTop: 16 }}>APIs a reutilizar</h2>
                  <table className="datos">
                    <thead><tr><th>API</th><th>Endpoint</th></tr></thead>
                    <tbody>{recomendacion.apis_a_reutilizar.map((a, i) => <tr key={i}><td>{a.nombre}</td><td className="mono">{a.endpoint}</td></tr>)}</tbody>
                  </table>
                </>
              )}
              {(recomendacion?.anti_patrones_detectados || []).length > 0 && (
                <div className="aviso"><strong>Anti-patrones detectados:</strong>
                  <ul className="lista-problemas advertencias">{recomendacion.anti_patrones_detectados.map((a, i) => <li key={i}>{a}</li>)}</ul>
                </div>
              )}
              {recomendacion?.orquestacion_mermaid && (
                <>
                  <h2 style={{ marginTop: 16 }}>Diagrama de orquestación (Mermaid)</h2>
                  <p className="descripcion">Incluido en el ZIP como .mmd — pégalo en mermaid.live o en tu documentación.</p>
                  <pre className="codigo">{recomendacion.orquestacion_mermaid}</pre>
                </>
              )}
            </div>
          )}

          {tab === 'spectral' && spectral && (
            <div className="panel">
              <div className={`aviso ${spectral.limpio ? 'ok' : 'error'}`}>
                {spectral.limpio ? 'Contrato limpio: sin errores de gobernanza.' : `${spectral.total_errores} error(es) y ${spectral.total_advertencias} advertencia(s).`}
              </div>
              <table className="datos">
                <thead><tr><th>Ruleset</th><th>Severidad</th><th>Regla</th><th>Mensaje</th><th>Ruta</th></tr></thead>
                <tbody>
                  {spectral.violaciones.map((v, i) => (
                    <tr key={i}>
                      <td className="mono">{v.ruleset}</td>
                      <td style={{ color: v.severidad === 'error' ? 'var(--error)' : 'var(--alerta)', fontWeight: 700 }}>{v.severidad}</td>
                      <td className="mono">{v.codigo}</td><td>{v.mensaje}</td><td className="mono" style={{ fontSize: 11.5 }}>{v.ruta}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === 'historial' && (
            <div className="panel">
              <h2>Versiones</h2>
              <table className="datos">
                <thead><tr><th>Versión</th><th>Fecha</th><th>Gobernanza</th><th></th></tr></thead>
                <tbody>
                  {versiones.map((v) => {
                    const s = v.resultado_spectral_json ? JSON.parse(v.resultado_spectral_json) : null;
                    return (
                      <tr key={v.id}>
                        <td className="mono">v{v.numero_version}</td>
                        <td>{v.creado_en}</td>
                        <td>{s ? (s.limpio ? 'Limpio' : `${s.total_errores} errores`) : '—'}</td>
                        <td><a href={`/api/apis/${api.id}/exportar?version=${v.numero_version}`} style={{ textDecoration: 'underline' }}>ZIP</a></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <h2 style={{ marginTop: 24 }}>Changelog</h2>
              <table className="datos">
                <thead><tr><th>Cambio</th><th>Motivo</th><th>Fecha</th></tr></thead>
                <tbody>
                  {changelog.map((c) => (
                    <tr key={c.id}>
                      <td>{c.version_anterior ? `v${c.version_anterior} → v${c.version_nueva}` : `v${c.version_nueva}`} · {c.cambios_detectados}</td>
                      <td>{c.motivo}</td><td>{c.creado_en}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      <div style={{ marginTop: 30 }}>
        <button className="fantasma" onClick={eliminar}>Eliminar diseño</button>
      </div>
    </>
  );
}
