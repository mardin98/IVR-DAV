'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import GlifoCapas from '@/components/GlifoCapas';

export default function Dashboard() {
  const [apis, setApis] = useState(null);

  useEffect(() => {
    fetch('/api/apis').then((r) => r.json()).then(setApis);
  }, []);

  return (
    <>
      <div className="eyebrow">API Factory</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 20 }}>
        <div>
          <h1>Diseños de API</h1>
          <p className="descripcion">
            De la regla de negocio al contrato OpenAPI certificable: cada diseño genera su contrato,
            la traducción para el dev y el paquete de gobernanza.
          </p>
        </div>
        <Link href="/apis/nueva"><button className="primario">Nuevo diseño</button></Link>
      </div>

      {apis === null && <div className="panel">Cargando…</div>}

      {apis?.length === 0 && (
        <div className="panel">
          <h2>Aún no hay diseños</h2>
          <p className="descripcion">
            Empieza creando tu primer diseño. Antes, te conviene cargar el manual técnico y 2–3
            contratos gold standard en <Link href="/conocimiento" style={{ textDecoration: 'underline' }}>Base de conocimiento</Link> —
            sin ellos la generación funciona en modo genérico.
          </p>
        </div>
      )}

      {apis?.map((a) => (
        <Link key={a.id} href={`/apis/${a.id}`}>
          <div className="tarjeta-api">
            <GlifoCapas capa={a.capa} conLeyenda />
            <div>
              <strong>{a.nombre}</strong>{' '}
              <span className="mono" style={{ color: 'var(--tinta-suave)', fontSize: 12.5 }}>{a.codigo_interno}</span>
              <div className="descripcion">
                {a.dominio_bian} · {a.perfil_seguridad === 'fapi_2_0' ? 'FAPI 2.0' : a.perfil_seguridad.replace('_', ' ')}
                {a.ultima_version ? ` · v${a.ultima_version}` : ' · sin generar'}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              {a.exposicion === 'externa_apigee' && <span className="chip externa">Externa · Apigee</span>}
              <span className={`chip ${a.estado}`}>{a.estado}</span>
            </div>
          </div>
        </Link>
      ))}
    </>
  );
}
