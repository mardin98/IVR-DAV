import './globals.css';
import Nav from '@/components/Nav';

export const metadata = {
  title: 'API Design Copilot — API Factory',
  description: 'Diseño de APIs contract-first con gobernanza automática',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>
        <div className="app">
          <Nav />
          <main className="contenido">{children}</main>
        </div>
      </body>
    </html>
  );
}
