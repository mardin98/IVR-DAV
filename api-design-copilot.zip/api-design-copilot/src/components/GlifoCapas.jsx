// Firma visual de la app: la pila de capas de la arquitectura API.
// Codifica información real — la capa a la que pertenece el API — no decoración.
export default function GlifoCapas({ capa, conLeyenda = false }) {
  const capas = ['experiencia', 'proceso', 'sistema']; // orden arquitectónico: arriba → abajo
  return (
    <div>
      <div className="glifo-capas" role="img" aria-label={`Capa ${capa}`}>
        {capas.map((c) => (
          <span key={c} className={c === capa ? 'activa' : ''} title={c} />
        ))}
      </div>
      {conLeyenda && <div className="glifo-leyenda">{capa}</div>}
    </div>
  );
}
