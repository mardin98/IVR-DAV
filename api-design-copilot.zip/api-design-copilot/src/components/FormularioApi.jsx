'use client';
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { evaluarCompletitud } from '@/lib/completitud';
import { calcularPerfilSeguridad, descripcionPerfil } from '@/lib/seguridad';
import GlifoCapas from '@/components/GlifoCapas';

const DOMINIOS_BIAN = [
  'Current Account', 'Savings Account', 'Payment Order', 'Payment Execution',
  'Party Authentication', 'Party Reference Data Directory', 'Customer Offer',
  'Consumer Loan', 'Card Authorization', 'Customer Position', 'Fraud Detection',
  'Session Dialogue', 'Product Directory', 'Consent Management',
];

const actorVacio = () => ({ nombre: '', tipo: 'canal_interno', scope_asignado: '', data_isolation: false, campos_visibles: [] });
const campoVacio = () => ({ nombre: '', tipo: 'string', formato: '', es_pii: false, requiere_masking: false, obligatorio: true, ejemplo: '', origen_sistema: 'manual' });
const reglaVacia = (n) => ({ id: `RN-${String(n).padStart(3, '0')}`, actor: '', accion: '', condicion: '', excepcion: '', referencia_normativa: '', fuente: '' });
const operacionVacia = () => ({ metodo: 'GET', nombre_operacion: '', descripcion: '', idempotente: true, campos_entrada: [], campos_salida: [campoVacio()], reglas_negocio: [reglaVacia(1)], sla_esperado_ms: '' });

const FORM_INICIAL = {
  nombre_api: '', codigo_interno: '', descripcion_negocio: '', dominio_bian: '',
  capa_api: 'proceso', exposicion: 'interna', canal_consumidor: [], version_inicial: 'v1',
  owner_tecnico: '', requiere_consentimiento: null, actores: [actorVacio()], operaciones: [operacionVacia()],
};

export default function FormularioApi({ apiId = null, formularioInicial = null }) {
  const router = useRouter();
  const [paso, setPaso] = useState(0);
  const [form, setForm] = useState(formularioInicial || FORM_INICIAL);
  const [guardando, setGuardando] = useState(false);
  const [errorApi, setErrorApi] = useState(null);

  const completitud = useMemo(() => evaluarCompletitud(form), [form]);
  const perfil = calcularPerfilSeguridad(form.capa_api, form.exposicion);

  const set = (campo, valor) => setForm((f) => ({ ...f, [campo]: valor }));
  const setOp = (i, campo, valor) =>
    setForm((f) => {
      const ops = [...f.operaciones];
      ops[i] = { ...ops[i], [campo]: valor };
      return { ...f, operaciones: ops };
    });

  async function guardar() {
    setGuardando(true);
    setErrorApi(null);
    const res = await fetch(apiId ? `/api/apis/${apiId}` : '/api/apis', {
      method: apiId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setGuardando(false);
    if (!res.ok) return setErrorApi(data.error || 'Error al guardar');
    router.push(`/apis/${apiId || data.id}`);
  }

  const pasos = ['Identificación', 'Actores y seguridad', 'Operaciones y reglas', 'Revisión'];

  return (
    <>
      <div className="eyebrow">{apiId ? 'Editar diseño' : 'Nuevo diseño'}</div>
      <h1>{form.nombre_api || 'Diseño de API'}</h1>

      <div className="pasos" role="tablist">
        {pasos.map((p, i) => (
          <button key={p} role="tab" aria-selected={paso === i} className={`fantasma paso ${paso === i ? 'actual' : i < paso ? 'completo' : ''}`} onClick={() => setPaso(i)}>
            {p}
          </button>
        ))}
      </div>

      {/* ============ PASO 1: IDENTIFICACIÓN ============ */}
      {paso === 0 && (
        <div className="panel">
          <div className="fila">
            <label className="campo">Nombre del API
              <span className="ayuda">Nombre del producto, en lenguaje de negocio</span>
              <input type="text" value={form.nombre_api} onChange={(e) => set('nombre_api', e.target.value)} placeholder="Consulta de Saldos para Terceros" />
            </label>
            <label className="campo">Código interno
              <span className="ayuda">Según nomenclatura del banco. No se puede repetir.</span>
              <input type="text" value={form.codigo_interno} onChange={(e) => set('codigo_interno', e.target.value)} placeholder="OB-CTAS-001" />
            </label>
          </div>

          <label className="campo">Descripción de negocio
            <span className="ayuda">Qué problema resuelve y para quién. Si esto queda pobre, el contrato saldrá genérico.</span>
            <textarea value={form.descripcion_negocio} onChange={(e) => set('descripcion_negocio', e.target.value)} placeholder="Permite a terceros autorizados (TPP) consultar el saldo de cuentas corrientes de clientes que otorgaron consentimiento…" />
          </label>

          <div className="fila-3">
            <label className="campo">Dominio BIAN
              <select value={form.dominio_bian} onChange={(e) => set('dominio_bian', e.target.value)}>
                <option value="">— Selecciona —</option>
                {DOMINIOS_BIAN.map((d) => <option key={d}>{d}</option>)}
              </select>
            </label>
            <label className="campo">Capa arquitectónica
              <select value={form.capa_api} onChange={(e) => set('capa_api', e.target.value)}>
                <option value="sistema">Sistema (1:1 al core)</option>
                <option value="proceso">Proceso / Servicio (orquestación)</option>
                <option value="experiencia">Experiencia (canal)</option>
              </select>
            </label>
            <label className="campo">Exposición
              <select value={form.exposicion} onChange={(e) => set('exposicion', e.target.value)}>
                <option value="interna">Interna</option>
                <option value="externa_apigee">Externa vía Apigee</option>
              </select>
            </label>
          </div>

          <div className="aviso ok" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <GlifoCapas capa={form.capa_api} />
            <div>
              <strong>Perfil de seguridad calculado: {perfil === 'fapi_2_0' ? 'FAPI 2.0' : perfil.replace('_', ' ')}</strong>
              <div className="descripcion">{descripcionPerfil(perfil)}</div>
            </div>
          </div>

          {form.capa_api === 'experiencia' && (
            <label className="campo">Canales consumidores
              <span className="ayuda">Marca todos los que aplican</span>
              <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
                {['app_movil', 'web', 'terceros_tpp', 'sucursal'].map((c) => (
                  <span key={c} className="check-inline">
                    <input type="checkbox" id={`canal-${c}`} checked={form.canal_consumidor.includes(c)}
                      onChange={(e) => set('canal_consumidor', e.target.checked ? [...form.canal_consumidor, c] : form.canal_consumidor.filter((x) => x !== c))} />
                    <label htmlFor={`canal-${c}`}>{c.replace('_', ' ')}</label>
                  </span>
                ))}
              </div>
            </label>
          )}

          {form.exposicion === 'externa_apigee' && (
            <label className="campo">¿Requiere consentimiento explícito del cliente? (Open Banking)
              <select value={form.requiere_consentimiento === null ? '' : String(form.requiere_consentimiento)} onChange={(e) => set('requiere_consentimiento', e.target.value === '' ? null : e.target.value === 'true')}>
                <option value="">— Responde obligatoriamente —</option>
                <option value="true">Sí, con gestión de consentimiento</option>
                <option value="false">No aplica</option>
              </select>
            </label>
          )}

          <div className="fila">
            <label className="campo">Owner técnico
              <input type="text" value={form.owner_tecnico} onChange={(e) => set('owner_tecnico', e.target.value)} placeholder="Mardin Turcios" />
            </label>
            <label className="campo">Versión inicial
              <input type="text" value={form.version_inicial} onChange={(e) => set('version_inicial', e.target.value)} />
            </label>
          </div>
        </div>
      )}

      {/* ============ PASO 2: ACTORES ============ */}
      {paso === 1 && (
        <div className="panel">
          <h2>Actores y consumidores</h2>
          <p className="descripcion">Quién llama al API, con qué permisos, y si sus datos deben aislarse por consumidor.</p>
          {form.actores.map((a, i) => (
            <div className="bloque" key={i}>
              <div className="cabecera">
                <h3>Actor {i + 1}</h3>
                {form.actores.length > 1 && <button className="fantasma" onClick={() => set('actores', form.actores.filter((_, j) => j !== i))}>Quitar</button>}
              </div>
              <div className="fila-3">
                <label className="campo">Nombre
                  <input type="text" value={a.nombre} onChange={(e) => set('actores', form.actores.map((x, j) => j === i ? { ...x, nombre: e.target.value } : x))} placeholder="TPP Agregador Financiero" />
                </label>
                <label className="campo">Tipo
                  <select value={a.tipo} onChange={(e) => set('actores', form.actores.map((x, j) => j === i ? { ...x, tipo: e.target.value } : x))}>
                    <option value="tercero_externo">Tercero externo (TPP)</option>
                    <option value="canal_interno">Canal interno</option>
                    <option value="sistema_interno">Sistema interno</option>
                  </select>
                </label>
                <label className="campo">Scope OAuth2
                  <span className="ayuda">Sin scope, el dev adivinará los permisos</span>
                  <input type="text" className="mono" value={a.scope_asignado} onChange={(e) => set('actores', form.actores.map((x, j) => j === i ? { ...x, scope_asignado: e.target.value } : x))} placeholder="accounts:read" />
                </label>
              </div>
              <span className="check-inline">
                <input type="checkbox" id={`iso-${i}`} checked={a.data_isolation} onChange={(e) => set('actores', form.actores.map((x, j) => j === i ? { ...x, data_isolation: e.target.checked } : x))} />
                <label htmlFor={`iso-${i}`}>Aislamiento de datos por consumidor (modelo sandbox)</label>
              </span>
            </div>
          ))}
          <div style={{ marginTop: 14 }}>
            <button onClick={() => set('actores', [...form.actores, actorVacio()])}>Agregar actor</button>
          </div>
        </div>
      )}

      {/* ============ PASO 3: OPERACIONES ============ */}
      {paso === 2 && (
        <div className="panel">
          <h2>Operaciones y reglas de negocio</h2>
          <p className="descripcion">Cada regla sigue la plantilla Actor + Acción + Condición + Excepción. La excepción define los códigos de error del contrato.</p>

          {form.operaciones.map((op, i) => (
            <div className="bloque" key={i}>
              <div className="cabecera">
                <h3 className="mono">{op.metodo} · {op.nombre_operacion || `Operación ${i + 1}`}</h3>
                {form.operaciones.length > 1 && <button className="fantasma" onClick={() => set('operaciones', form.operaciones.filter((_, j) => j !== i))}>Quitar</button>}
              </div>

              <div className="fila-3">
                <label className="campo">Método
                  <select value={op.metodo} onChange={(e) => setOp(i, 'metodo', e.target.value)}>
                    {['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((m) => <option key={m}>{m}</option>)}
                  </select>
                </label>
                <label className="campo">Nombre de la operación
                  <input type="text" value={op.nombre_operacion} onChange={(e) => setOp(i, 'nombre_operacion', e.target.value)} placeholder="Consultar saldo de cuenta" />
                </label>
                <label className="campo">¿Idempotente?
                  <span className="ayuda">Crítico en POST de pagos</span>
                  <select value={String(op.idempotente)} onChange={(e) => setOp(i, 'idempotente', e.target.value === 'true')}>
                    <option value="true">Sí</option>
                    <option value="false">No</option>
                  </select>
                </label>
              </div>

              <label className="campo">Descripción
                <textarea value={op.descripcion} onChange={(e) => setOp(i, 'descripcion', e.target.value)} placeholder="Qué hace, para quién y cuándo se usa…" style={{ minHeight: 60 }} />
              </label>

              {/* Campos */}
              {['campos_entrada', 'campos_salida'].map((tipoCampos) => (
                <div key={tipoCampos} style={{ marginTop: 14 }}>
                  <strong style={{ fontSize: 13 }}>{tipoCampos === 'campos_entrada' ? 'Campos de entrada' : 'Campos de salida'}</strong>
                  {op[tipoCampos].map((c, k) => (
                    <div className="bloque" key={k}>
                      <div className="fila-3">
                        <label className="campo">Nombre
                          <input type="text" className="mono" value={c.nombre} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, nombre: e.target.value } : x))} placeholder="numeroCuenta" />
                        </label>
                        <label className="campo">Tipo
                          <select value={c.tipo} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, tipo: e.target.value } : x))}>
                            {['string', 'number', 'boolean', 'date', 'object', 'array'].map((t) => <option key={t}>{t}</option>)}
                          </select>
                        </label>
                        <label className="campo">Origen (sistema)
                          <input type="text" className="mono" value={c.origen_sistema} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, origen_sistema: e.target.value } : x))} placeholder="AS400-CTAS / T24 / manual" />
                        </label>
                      </div>
                      <div className="fila-3">
                        <label className="campo">Formato / ejemplo
                          <input type="text" className="mono" value={c.ejemplo} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, ejemplo: e.target.value } : x))} placeholder="ISO 8601 · CR05-0152…" />
                        </label>
                        <span className="check-inline" style={{ marginTop: 30 }}>
                          <input type="checkbox" id={`pii-${i}-${tipoCampos}-${k}`} checked={c.es_pii} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, es_pii: e.target.checked } : x))} />
                          <label htmlFor={`pii-${i}-${tipoCampos}-${k}`}>PII</label>
                        </span>
                        {c.es_pii && (
                          <label className="campo">¿Requiere masking?
                            <select value={String(c.requiere_masking)} onChange={(e) => setOp(i, tipoCampos, op[tipoCampos].map((x, m) => m === k ? { ...x, requiere_masking: e.target.value === 'true' } : x))}>
                              <option value="true">Sí (****2840)</option>
                              <option value="false">No</option>
                            </select>
                          </label>
                        )}
                      </div>
                      <button className="fantasma" onClick={() => setOp(i, tipoCampos, op[tipoCampos].filter((_, m) => m !== k))}>Quitar campo</button>
                    </div>
                  ))}
                  <div style={{ marginTop: 8 }}>
                    <button onClick={() => setOp(i, tipoCampos, [...op[tipoCampos], campoVacio()])}>Agregar campo</button>
                  </div>
                </div>
              ))}

              {/* Reglas de negocio */}
              <div style={{ marginTop: 16 }}>
                <strong style={{ fontSize: 13 }}>Reglas de negocio</strong>
                {op.reglas_negocio.map((r, k) => (
                  <div className="bloque" key={k}>
                    <div className="cabecera">
                      <h3 className="mono">{r.id}</h3>
                      {op.reglas_negocio.length > 1 && <button className="fantasma" onClick={() => setOp(i, 'reglas_negocio', op.reglas_negocio.filter((_, m) => m !== k))}>Quitar</button>}
                    </div>
                    <div className="fila">
                      <label className="campo">Actor — ¿quién puede hacer esto?
                        <input type="text" value={r.actor} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, actor: e.target.value } : x))} placeholder="Tercero autorizado (TPP)" />
                      </label>
                      <label className="campo">Acción
                        <input type="text" value={r.accion} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, accion: e.target.value } : x))} placeholder="Consultar el saldo de una cuenta corriente" />
                      </label>
                    </div>
                    <label className="campo">Condición — ¿bajo qué circunstancias?
                      <textarea value={r.condicion} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, condicion: e.target.value } : x))} placeholder="El cliente otorgó consentimiento activo hace menos de 90 días Y la cuenta está activa" style={{ minHeight: 56 }} />
                    </label>
                    <label className="campo">Excepción — ¿qué pasa si falla?
                      <span className="ayuda">Define aquí los códigos de error. Si lo dejas vacío, el dev los inventará.</span>
                      <textarea value={r.excepcion} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, excepcion: e.target.value } : x))} placeholder="Consentimiento expirado → 403 CONSENT_EXPIRED; cuenta bloqueada → 403 ACCOUNT_BLOCKED" style={{ minHeight: 56 }} />
                    </label>
                    <div className="fila">
                      <label className="campo">Referencia normativa
                        <input type="text" value={r.referencia_normativa} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, referencia_normativa: e.target.value } : x))} placeholder="Manual Interno §4.2.1 / SIB NRP-XX" />
                      </label>
                      <label className="campo">Fuente
                        <input type="text" value={r.fuente} onChange={(e) => setOp(i, 'reglas_negocio', op.reglas_negocio.map((x, m) => m === k ? { ...x, fuente: e.target.value } : x))} placeholder="Reunión con negocio 2026-07-15" />
                      </label>
                    </div>
                  </div>
                ))}
                <div style={{ marginTop: 8 }}>
                  <button onClick={() => setOp(i, 'reglas_negocio', [...op.reglas_negocio, reglaVacia(op.reglas_negocio.length + 1)])}>Agregar regla</button>
                </div>
              </div>
            </div>
          ))}
          <div style={{ marginTop: 14 }}>
            <button onClick={() => set('operaciones', [...form.operaciones, operacionVacia()])}>Agregar operación</button>
          </div>
        </div>
      )}

      {/* ============ PASO 4: REVISIÓN ============ */}
      {paso === 3 && (
        <div className="panel">
          <h2>Revisión de completitud</h2>
          <p className="descripcion">
            La generación con Gemini solo se habilita sin bloqueantes. Con menos de 80% el contrato puede salir con vacíos.
          </p>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 12 }}>
            <span style={{ fontSize: 34, fontWeight: 800, letterSpacing: '-.03em' }}>{completitud.score}%</span>
            <span className="descripcion">de contexto completo</span>
          </div>
          <div className="score-barra"><div className={completitud.score >= 80 ? 'ok' : ''} style={{ width: `${completitud.score}%` }} /></div>

          {completitud.bloqueantes.length > 0 && (
            <div className="aviso error">
              <strong>Bloqueantes — corrige antes de generar:</strong>
              <ul className="lista-problemas bloqueantes">
                {completitud.bloqueantes.map((b, i) => <li key={i}>{b}</li>)}
              </ul>
            </div>
          )}
          {completitud.advertencias.length > 0 && (
            <div className="aviso">
              <strong>Advertencias — el contrato saldrá más pobre:</strong>
              <ul className="lista-problemas advertencias">
                {completitud.advertencias.map((a, i) => <li key={i}>{a}</li>)}
              </ul>
            </div>
          )}
          {completitud.puede_generar && completitud.advertencias.length === 0 && (
            <div className="aviso ok">Todo el contexto necesario está completo. Guarda y genera el contrato.</div>
          )}
          {errorApi && <div className="aviso error">{errorApi}</div>}
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 18 }}>
        <button onClick={() => setPaso(Math.max(0, paso - 1))} disabled={paso === 0}>Anterior</button>
        {paso < 3
          ? <button className="primario" onClick={() => setPaso(paso + 1)}>Siguiente</button>
          : <button className="primario" onClick={guardar} disabled={guardando}>{guardando ? 'Guardando…' : apiId ? 'Guardar cambios' : 'Guardar diseño'}</button>}
      </div>
    </>
  );
}
