'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const enlaces = [
  { href: '/', texto: 'Diseños de API' },
  { href: '/catalogo', texto: 'Catálogo existente' },
  { href: '/conocimiento', texto: 'Base de conocimiento' },
];

export default function Nav() {
  const ruta = usePathname();
  return (
    <aside className="rail">
      <div className="rail-marca">
        <div className="titulo">API Design Copilot</div>
        <div className="sub">API Factory · Open Banking</div>
      </div>
      <nav aria-label="Navegación principal">
        {enlaces.map((e) => (
          <Link key={e.href} href={e.href} className={ruta === e.href ? 'activo' : ''}>
            {e.texto}
          </Link>
        ))}
      </nav>
      <div className="rail-pie">100% local · Gemini + Spectral</div>
    </aside>
  );
}
