"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/hooks/useAuth";
export default function Root() {
  const { user, loading } = useAuth();
  const router = useRouter();
  useEffect(() => { if (!loading) router.replace(user ? "/dashboard" : "/login"); }, [user, loading, router]);
  return <div style={{ minHeight:"100vh", background:"#060b14", display:"flex", alignItems:"center", justifyContent:"center" }}>
    <div style={{ width:32, height:32, borderRadius:8, background:"linear-gradient(135deg,#22d3ee,#a78bfa)" }} />
  </div>;
}
