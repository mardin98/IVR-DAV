"use client";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import { INIT_STATUS, CATEGORY, PRIORITY, budgetPct, budgetColor, progColor, fmtDate } from "@/lib/utils";
import { Button, Spinner, SectionTitle } from "@/components/ui";
import toast from "react-hot-toast";
import { generateReportPDF } from "@/lib/integrations/googleWorkspace";
import { useState } from "react";
export default function ReportsPage() {
  const { initiatives, loading } = useInitiatives();
  const { isLeader } = useAuth();
  const [gen,setGen] = useState(false);
  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;
  const active=initiatives.filter(i=>i.status==="active");
  const totalB=initiatives.reduce((s,i)=>s+(i.budget||0),0);
  const totalS=initiatives.reduce((s,i)=>s+(i.budgetSpent||0),0);
  const byStatus=Object.entries(initiatives.reduce((a,i)=>{a[i.status]=(a[i.status]||0)+1;return a;},{}));
  const byCat=Object.entries(initiatives.reduce((a,i)=>{a[i.category]=(a[i.category]||0)+1;return a;},{}));
  const colors={active:"#22d3ee",draft:"#64748b",on_hold:"#f59e0b",completed:"#4ade80",cancelled:"#f87171",ai:"#a78bfa",automation:"#22d3ee",infra:"#4ade80",process:"#f59e0b"};
  const Bar=({data,max})=>(<div style={{display:"flex",flexDirection:"column",gap:10}}>
    {data.map(([k,v])=><div key={k} style={{display:"flex",alignItems:"center",gap:10}}>
      <span style={{width:8,height:8,borderRadius:"50%",background:colors[k]||"#64748b",flexShrink:0}}/>
      <span style={{fontSize:12,color:"#94a3b8",width:110,flexShrink:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{INIT_STATUS[k]?.label||CATEGORY[k]?.label||k}</span>
      <div style={{flex:1,height:8,background:"rgba(255,255,255,0.06)",borderRadius:4}}>
        <div style={{height:"100%",width:`${(v/max)*100}%`,borderRadius:4,background:colors[k]||"#64748b",transition:"width 0.6s"}}/>
      </div>
      <span style={{fontSize:12,color:"#475569",minWidth:20,textAlign:"right"}}>{v}</span>
    </div>)}
  </div>);
  const maxS=Math.max(...byStatus.map(([,v])=>v),1);
  const maxC=Math.max(...byCat.map(([,v])=>v),1);
  return <div style={{display:"flex",flexDirection:"column",gap:24}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div><div style={{fontSize:12,color:"#334155",marginBottom:4}}>AI & Automations › <span style={{color:"#22d3ee"}}>Reportes</span></div><h1 style={{fontSize:22,fontWeight:800,color:"#f1f5f9"}}>Reportes & Analytics</h1></div>
      {isLeader&&<Button variant="primary" disabled={gen} onClick={async()=>{setGen(true);try{const r=await generateReportPDF({});toast.success("📄 Reporte generado en Drive");window.open(r.webViewLink,"_blank");}catch{toast.error("Error generando reporte");}finally{setGen(false);}}}>
        {gen?"Generando…":"📄 Exportar a Drive"}
      </Button>}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))",gap:14}}>
      {[{l:"Total",v:initiatives.length,c:"#f1f5f9"},{l:"Activas",v:active.length,c:"#22d3ee"},{l:"Completadas",v:initiatives.filter(i=>i.status==="completed").length,c:"#4ade80"},{l:"Avance prom.",v:`${active.length?Math.round(active.reduce((s,i)=>s+i.progress,0)/active.length):0}%`,c:"#a78bfa"}]
        .map((k,i)=><div key={i} style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px 20px"}}>
          <div style={{fontSize:11,color:"#475569",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:6}}>{k.l}</div>
          <div style={{fontSize:30,fontWeight:800,color:k.c,fontFamily:"monospace"}}>{k.v}</div>
        </div>)}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
      <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:"18px 20px"}}><SectionTitle>Por estado</SectionTitle><Bar data={byStatus} max={maxS}/></div>
      <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:"18px 20px"}}><SectionTitle>Por categoría</SectionTitle><Bar data={byCat} max={maxC}/></div>
    </div>
    <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:"20px 22px"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <SectionTitle>Ejecución presupuestaria</SectionTitle>
        <div style={{display:"flex",gap:20,fontSize:13}}>
          <span style={{color:"#475569"}}>Total: <b style={{color:"#f1f5f9",fontFamily:"monospace"}}>${(totalB/1000).toFixed(1)}k</b></span>
          <span style={{color:"#475569"}}>Ejecutado: <b style={{color:"#f59e0b",fontFamily:"monospace"}}>${(totalS/1000).toFixed(1)}k</b></span>
        </div>
      </div>
      {initiatives.filter(i=>i.status!=="completed"&&i.budget>0).map(ini=>{
        const bp=budgetPct(ini.budgetSpent,ini.budget), bc=budgetColor(ini.budgetSpent,ini.budget);
        return <div key={ini.id} style={{display:"flex",alignItems:"center",gap:12,marginBottom:8}}>
          <span style={{fontSize:11,color:"#22d3ee",fontFamily:"monospace",width:60,flexShrink:0}}>{ini.code}</span>
          <span style={{fontSize:12,color:"#64748b",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ini.title}</span>
          <div style={{width:120,height:5,background:"rgba(255,255,255,0.06)",borderRadius:4,flexShrink:0}}>
            <div style={{height:"100%",width:`${bp}%`,borderRadius:4,background:bc}}/>
          </div>
          <span style={{fontSize:12,color:bc,minWidth:36,textAlign:"right",fontWeight:600}}>{bp}%</span>
        </div>;
      })}
    </div>
  </div>;
}
