"use client";
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/hooks/useAuth";
import { useNotifications } from "@/lib/hooks/useTasks";
import { fmtRel, DV } from "@/lib/utils";
import toast from "react-hot-toast";

const NAV = [
  {href:"/dashboard",       icon:"◈", label:"Dashboard"},
  {href:"/dashboard/initiatives", icon:"▦", label:"Iniciativas"},
  {href:"/dashboard/reports",     icon:"▤", label:"Reportes"},
  {href:"/dashboard/team",        icon:"◉", label:"Equipo"},
];

function Avatar({ name, photoURL, size=30 }) {
  const i=name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  if(photoURL) return <img src={photoURL} alt={name} style={{width:size,height:size,borderRadius:"50%",objectFit:"cover"}}/>;
  return <div style={{width:size,height:size,borderRadius:"50%",background:`${DV.red}25`,border:`1.5px solid ${DV.red}50`,
    display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.36,fontWeight:700,color:DV.red}}>{i}</div>;
}

export default function Layout({ children }) {
  const { user, loading, signOut, isAdmin } = useAuth();
  const { notifications, unreadCount, markRead, markAllRead } = useNotifications();
  const router   = useRouter();
  const pathname = usePathname();
  const [notifOpen, setNotifOpen] = useState(false);
  const [menuOpen,  setMenuOpen]  = useState(false);

  useEffect(() => { if(!loading&&!user) router.replace("/login"); },[user,loading,router]);
  if(loading||!user) return (
    <div style={{minHeight:"100vh",background:DV.bg,display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{width:36,height:36,borderRadius:8,background:DV.red,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>◈</div>
    </div>
  );

  const navItems = isAdmin ? [...NAV,{href:"/dashboard/admin",icon:"⚙",label:"Admin"}] : NAV;

  return (
    <div style={{minHeight:"100vh",background:DV.bg,fontFamily:"sans-serif",display:"flex",flexDirection:"column"}}>
      {/* Header */}
      <header style={{position:"sticky",top:0,zIndex:100,
        background:`rgba(15,15,20,0.97)`,backdropFilter:"blur(16px)",
        borderBottom:`1px solid ${DV.border}`,
        boxShadow:`0 1px 0 0 rgba(227,6,19,0.1)`,
        padding:"0 24px",height:58,display:"flex",alignItems:"center",gap:20}}>

        {/* Logo */}
        <Link href="/dashboard" style={{display:"flex",alignItems:"center",gap:10,textDecoration:"none",flexShrink:0}}>
          <div style={{width:30,height:30,borderRadius:8,background:DV.red,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:900,color:DV.white,
            boxShadow:`0 0 12px rgba(227,6,19,0.4)`}}>◈</div>
          <div>
            <div style={{fontSize:13,fontWeight:800,color:DV.white,lineHeight:1,letterSpacing:"-0.01em"}}>Initiative Tracker</div>
            <div style={{fontSize:9,color:DV.red,letterSpacing:"0.12em",textTransform:"uppercase",fontWeight:700}}>Davivienda · AI & Automations</div>
          </div>
        </Link>

        {/* Nav */}
        <nav style={{display:"flex",gap:2,flex:1,justifyContent:"center"}}>
          {navItems.map(item=>{
            const active = pathname===item.href||(item.href!=="/dashboard"&&pathname.startsWith(item.href));
            return <Link key={item.href} href={item.href} style={{
              padding:"6px 16px",
              background: active ? DV.redBg : "none",
              border: active ? `1px solid ${DV.redBd}` : "1px solid transparent",
              borderRadius:10,textDecoration:"none",
              display:"flex",alignItems:"center",gap:6,
              color: active ? DV.white : DV.text3,
              fontSize:13,fontWeight: active ? 700 : 500,
              transition:"all 0.15s",
            }}
            onMouseEnter={e=>{ if(!active){ e.currentTarget.style.background="rgba(255,255,255,0.04)"; e.currentTarget.style.color=DV.text2; }}}
            onMouseLeave={e=>{ if(!active){ e.currentTarget.style.background="none"; e.currentTarget.style.color=DV.text3; }}}>
              <span>{item.icon}</span>{item.label}
            </Link>;
          })}
        </nav>

        {/* Actions */}
        <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
          {/* Notificaciones */}
          <div style={{position:"relative"}}>
            <button onClick={()=>{setNotifOpen(p=>!p);setMenuOpen(false);}}
              style={{width:36,height:36,borderRadius:10,background:"rgba(255,255,255,0.04)",
                border:`1px solid ${DV.border}`,cursor:"pointer",display:"flex",
                alignItems:"center",justifyContent:"center",fontSize:16,position:"relative",
                color:DV.text2,transition:"all 0.15s"}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=DV.redBd;}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=DV.border;}}>
              🔔
              {unreadCount>0&&<span style={{position:"absolute",top:-5,right:-5,minWidth:18,height:18,borderRadius:9,
                background:DV.red,fontSize:9,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",
                color:DV.white,padding:"0 4px",boxShadow:`0 0 8px ${DV.red}`}}>{unreadCount}</span>}
            </button>

            {notifOpen&&<div style={{position:"absolute",right:0,top:46,width:360,zIndex:200,
              background:DV.bg2,border:`1px solid rgba(227,6,19,0.2)`,borderRadius:14,
              boxShadow:`0 20px 60px rgba(0,0,0,0.6),0 0 30px rgba(227,6,19,0.06)`,overflow:"hidden"}}>
              <div style={{padding:"12px 16px",borderBottom:`1px solid ${DV.border}`,
                display:"flex",justifyContent:"space-between",alignItems:"center",
                background:`linear-gradient(135deg,rgba(227,6,19,0.08),transparent)`}}>
                <span style={{fontSize:13,fontWeight:700,color:DV.white}}>Notificaciones</span>
                {unreadCount>0&&<button onClick={markAllRead}
                  style={{fontSize:11,color:DV.red,background:"none",border:"none",cursor:"pointer",fontFamily:"inherit",fontWeight:600}}>
                  Marcar todo leído
                </button>}
              </div>
              {notifications.length===0
                ? <div style={{padding:28,textAlign:"center",color:DV.text4,fontSize:13}}>Sin notificaciones</div>
                : notifications.slice(0,8).map(n=>(
                  <div key={n.id} onClick={()=>markRead(n.id)}
                    style={{padding:"12px 16px",borderBottom:`1px solid ${DV.border}`,
                      background:n.read?"none":"rgba(227,6,19,0.04)",display:"flex",gap:10,cursor:"pointer",
                      transition:"background 0.15s"}}
                    onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.03)"}
                    onMouseLeave={e=>e.currentTarget.style.background=n.read?"none":"rgba(227,6,19,0.04)"}>
                    <span style={{fontSize:14,flexShrink:0,marginTop:1}}>
                      {n.type==="warning"?"⚠":n.type==="success"?"✓":n.type==="error"?"✕":"ℹ"}
                    </span>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:12,fontWeight:700,color:DV.white,marginBottom:2}}>{n.title}</div>
                      <div style={{fontSize:12,color:DV.text3,lineHeight:1.4}}>{n.body}</div>
                      <div style={{fontSize:11,color:DV.text4,marginTop:3}}>{fmtRel(n.createdAt)}</div>
                    </div>
                    {!n.read&&<span style={{width:7,height:7,borderRadius:"50%",background:DV.red,flexShrink:0,marginTop:4,boxShadow:`0 0 6px ${DV.red}`}}/>}
                  </div>
                ))
              }
            </div>}
          </div>

          {/* User menu */}
          <div style={{position:"relative"}}>
            <button onClick={()=>{setMenuOpen(p=>!p);setNotifOpen(false);}}
              style={{display:"flex",alignItems:"center",gap:8,background:"rgba(255,255,255,0.04)",
                border:`1px solid ${DV.border}`,padding:"5px 12px 5px 8px",borderRadius:10,cursor:"pointer",
                transition:"all 0.15s"}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=DV.redBd;}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=DV.border;}}>
              <Avatar name={user.name} photoURL={user.photoURL} size={26}/>
              <span style={{fontSize:13,fontWeight:600,color:DV.text2}}>{user.name.split(" ")[0]}</span>
            </button>

            {menuOpen&&<div style={{position:"absolute",right:0,top:46,width:220,zIndex:200,
              background:DV.bg2,border:`1px solid rgba(227,6,19,0.15)`,borderRadius:12,
              boxShadow:"0 20px 60px rgba(0,0,0,0.6)",overflow:"hidden"}}>
              <div style={{padding:"14px 16px",borderBottom:`1px solid ${DV.border}`,
                background:`linear-gradient(135deg,rgba(227,6,19,0.08),transparent)`}}>
                <div style={{fontSize:13,fontWeight:700,color:DV.white}}>{user.name}</div>
                <div style={{fontSize:11,color:DV.text3,marginTop:2}}>{user.email}</div>
              </div>
              <button onClick={async()=>{await signOut();router.replace("/login");toast.success("Sesión cerrada");}}
                style={{width:"100%",padding:"12px 16px",background:"none",border:"none",
                  color:"#F87171",fontSize:13,cursor:"pointer",textAlign:"left",
                  fontFamily:"inherit",display:"flex",alignItems:"center",gap:8,
                  transition:"background 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(248,113,113,0.06)"}
                onMouseLeave={e=>e.currentTarget.style.background="none"}>
                ⎋ Cerrar sesión
              </button>
            </div>}
          </div>
        </div>
      </header>

      <main style={{flex:1,padding:"28px 24px",maxWidth:1240,margin:"0 auto",width:"100%"}}>
        {children}
      </main>

      {(notifOpen||menuOpen)&&<div style={{position:"fixed",inset:0,zIndex:150}} onClick={()=>{setNotifOpen(false);setMenuOpen(false);}}/>}
    </div>
  );
}
