"use client";
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/hooks/useAuth";
import { useNotifications } from "@/lib/hooks/useTasks";
import { fmtRel } from "@/lib/utils";
import toast from "react-hot-toast";
const NAV = [{href:"/dashboard",icon:"◈",label:"Dashboard"},{href:"/dashboard/initiatives",icon:"▦",label:"Iniciativas"},{href:"/dashboard/reports",icon:"▤",label:"Reportes"},{href:"/dashboard/team",icon:"◉",label:"Equipo"}];
function Avatar({ name, size=32, photoURL }) {
  const i=name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  const c=["#22d3ee","#a78bfa","#4ade80","#f59e0b","#f87171"][name.charCodeAt(0)%5];
  if(photoURL) return <img src={photoURL} alt={name} style={{width:size,height:size,borderRadius:"50%",objectFit:"cover"}}/>;
  return <div style={{width:size,height:size,borderRadius:"50%",background:`${c}22`,border:`1.5px solid ${c}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.35,fontWeight:700,color:c}}>{i}</div>;
}
export default function Layout({ children }) {
  const { user, loading, signOut, isAdmin } = useAuth();
  const { notifications, unreadCount, markRead, markAllRead } = useNotifications();
  const router = useRouter();
  const pathname = usePathname();
  const [notifOpen,setNotifOpen] = useState(false);
  const [menuOpen,setMenuOpen]   = useState(false);
  useEffect(() => { if(!loading&&!user) router.replace("/login"); },[user,loading,router]);
  if(loading||!user) return <div style={{minHeight:"100vh",background:"#060b14",display:"flex",alignItems:"center",justifyContent:"center"}}><div style={{width:32,height:32,borderRadius:8,background:"linear-gradient(135deg,#22d3ee,#a78bfa)"}}/></div>;
  const navItems = isAdmin ? [...NAV,{href:"/dashboard/admin",icon:"⚙",label:"Admin"}] : NAV;
  return <div style={{minHeight:"100vh",background:"#060b14",fontFamily:"sans-serif",display:"flex",flexDirection:"column"}}>
    <header style={{position:"sticky",top:0,zIndex:100,background:"rgba(6,11,20,0.95)",backdropFilter:"blur(12px)",borderBottom:"1px solid rgba(255,255,255,0.06)",padding:"0 24px",height:56,display:"flex",alignItems:"center",gap:24}}>
      <Link href="/dashboard" style={{display:"flex",alignItems:"center",gap:10,textDecoration:"none",flexShrink:0}}>
        <div style={{width:28,height:28,borderRadius:8,background:"linear-gradient(135deg,#22d3ee,#a78bfa)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:900,color:"#fff"}}>◈</div>
        <div><div style={{fontSize:13,fontWeight:800,color:"#f1f5f9",lineHeight:1}}>Initiative Tracker</div><div style={{fontSize:9,color:"#334155",letterSpacing:"0.1em",textTransform:"uppercase"}}>Davivienda AI & Automations</div></div>
      </Link>
      <nav style={{display:"flex",gap:4,flex:1,justifyContent:"center"}}>
        {navItems.map(item=>{
          const active=pathname===item.href||(item.href!=="/dashboard"&&pathname.startsWith(item.href));
          return <Link key={item.href} href={item.href} style={{padding:"6px 14px",background:active?"rgba(34,211,238,0.1)":"none",border:active?"1px solid rgba(34,211,238,0.2)":"1px solid transparent",borderRadius:10,textDecoration:"none",display:"flex",alignItems:"center",gap:6,color:active?"#22d3ee":"#475569",fontSize:13,fontWeight:active?700:500,transition:"all 0.15s"}}>
            <span>{item.icon}</span>{item.label}
          </Link>;
        })}
      </nav>
      <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
        <div style={{position:"relative"}}>
          <button onClick={()=>{setNotifOpen(p=>!p);setMenuOpen(false);}} style={{width:36,height:36,borderRadius:10,background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,position:"relative",color:"#94a3b8"}}>🔔
            {unreadCount>0&&<span style={{position:"absolute",top:-4,right:-4,width:16,height:16,borderRadius:"50%",background:"#f87171",fontSize:9,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff"}}>{unreadCount}</span>}
          </button>
          {notifOpen&&<div style={{position:"absolute",right:0,top:44,width:350,zIndex:200,background:"#0d1628",border:"1px solid rgba(255,255,255,0.1)",borderRadius:14,boxShadow:"0 20px 60px rgba(0,0,0,0.5)",overflow:"hidden"}}>
            <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",justifyContent:"space-between"}}>
              <span style={{fontSize:13,fontWeight:700,color:"#e2e8f0"}}>Notificaciones</span>
              {unreadCount>0&&<button onClick={markAllRead} style={{fontSize:11,color:"#22d3ee",background:"none",border:"none",cursor:"pointer",fontFamily:"inherit"}}>Marcar todo leído</button>}
            </div>
            {notifications.length===0?<div style={{padding:24,textAlign:"center",color:"#334155",fontSize:13}}>Sin notificaciones</div>:
            notifications.slice(0,8).map(n=><div key={n.id} onClick={()=>markRead(n.id)} style={{padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,0.04)",background:n.read?"none":"rgba(34,211,238,0.04)",display:"flex",gap:10,cursor:"pointer"}}>
              <span style={{fontSize:12,color:n.type==="warning"?"#f59e0b":n.type==="success"?"#4ade80":"#22d3ee",flexShrink:0}}>{n.type==="warning"?"⚠":n.type==="success"?"✓":"ℹ"}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:12,fontWeight:700,color:"#e2e8f0",marginBottom:2}}>{n.title}</div>
                <div style={{fontSize:12,color:"#64748b",lineHeight:1.4}}>{n.body}</div>
                <div style={{fontSize:11,color:"#334155",marginTop:3}}>{fmtRel(n.createdAt)}</div>
              </div>
              {!n.read&&<span style={{width:6,height:6,borderRadius:"50%",background:"#22d3ee",flexShrink:0,marginTop:3}}/>}
            </div>)}
          </div>}
        </div>
        <div style={{position:"relative"}}>
          <button onClick={()=>{setMenuOpen(p=>!p);setNotifOpen(false);}} style={{display:"flex",alignItems:"center",gap:8,background:"none",border:"none",cursor:"pointer",padding:"4px 8px",borderRadius:10}}>
            <Avatar name={user.name} size={30} photoURL={user.photoURL}/>
            <span style={{fontSize:13,fontWeight:600,color:"#94a3b8"}}>{user.name.split(" ")[0]}</span>
          </button>
          {menuOpen&&<div style={{position:"absolute",right:0,top:44,width:220,zIndex:200,background:"#0d1628",border:"1px solid rgba(255,255,255,0.1)",borderRadius:12,boxShadow:"0 20px 60px rgba(0,0,0,0.5)",overflow:"hidden"}}>
            <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
              <div style={{fontSize:13,fontWeight:700,color:"#e2e8f0"}}>{user.name}</div>
              <div style={{fontSize:11,color:"#475569"}}>{user.email}</div>
            </div>
            <button onClick={async()=>{await signOut();router.replace("/login");toast.success("Sesión cerrada");}} style={{width:"100%",padding:"12px 16px",background:"none",border:"none",color:"#f87171",fontSize:13,cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",alignItems:"center",gap:8}}>⎋ Cerrar sesión</button>
          </div>}
        </div>
      </div>
    </header>
    <main style={{flex:1,padding:"28px 24px",maxWidth:1200,margin:"0 auto",width:"100%"}}>{children}</main>
    {(notifOpen||menuOpen)&&<div style={{position:"fixed",inset:0,zIndex:150}} onClick={()=>{setNotifOpen(false);setMenuOpen(false);}}/>}
  </div>;
}
