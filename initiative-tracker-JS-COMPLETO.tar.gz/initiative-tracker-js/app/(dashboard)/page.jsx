"use client";

import { useMemo } from "react";
import Link from "next/link";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import {
  INITIATIVE_STATUS, PRIORITY_CONFIG, CATEGORY_CONFIG,
  progressColor, budgetPct, budgetColor, fmtDate, daysLeftLabel,
} from "@/lib/utils";

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

function ProgressRing({ pct, size = 52 }) {
  const stroke = 4;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const color = progressColor(pct);
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color}
        strokeWidth={stroke} strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round" style={{ transition: "stroke-dashoffset 0.6s ease" }} />
      <text x={size/2} y={size/2} textAnchor="middle" dominantBaseline="middle"
        style={{ transform: "rotate(90deg)", transformOrigin: "center", fill: "#f1f5f9",
          fontSize: size * 0.22, fontWeight: 700, fontFamily: "var(--font-dm-sans)" }}>
        {pct}%
      </text>
    </svg>
  );
}

function KPICard({ label, value, sub, color = "#22d3ee", icon }) {
  return (
    <div style={{
      background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: 16, padding: "20px 24px", position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: -10, right: -10, fontSize: 64, opacity: 0.04, lineHeight: 1 }}>{icon}</div>
      <div style={{ fontSize: 11, color: "#64748b", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 34, fontWeight: 800, color, fontFamily: "var(--font-space-mono, monospace)", lineHeight: 1, marginBottom: 4 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: "#475569" }}>{sub}</div>}
    </div>
  );
}

function StatusBadge({ status }) {
  const cfg = INITIATIVE_STATUS[status];
  if (!cfg) return null;
  return (
    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600,
      color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.color}30` }}>
      {cfg.label}
    </span>
  );
}

function PriorityDot({ priority }) {
  const cfg = PRIORITY_CONFIG[priority];
  return (
    <span style={{ color: cfg.color, fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: cfg.color, display: "inline-block" }} />
      {cfg.label}
    </span>
  );
}

function InitiativeRow({ ini }) {
  const dl = daysLeftLabel(ini.dueDate);
  const bp = budgetPct(ini.budgetSpent, ini.budget);
  const bc = budgetColor(ini.budgetSpent, ini.budget);
  const cat = CATEGORY_CONFIG[ini.category];
  const progColor = progressColor(ini.progress);

  return (
    <Link href={`/dashboard/initiatives/${ini.id}`} style={{ textDecoration: "none" }}>
      <div style={{
        background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)",
        borderRadius: 14, padding: "16px 20px", cursor: "pointer",
        display: "grid", gridTemplateColumns: "1fr auto", gap: 16, alignItems: "center",
        transition: "all 0.15s",
      }}
        onMouseEnter={e => { (e.currentTarget).style.borderColor = "#22d3ee44"; (e.currentTarget).style.background = "rgba(34,211,238,0.04)"; }}
        onMouseLeave={e => { (e.currentTarget).style.borderColor = "rgba(255,255,255,0.07)"; (e.currentTarget).style.background = "rgba(255,255,255,0.025)"; }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <span style={{ fontSize: 11, color: "#22d3ee", fontFamily: "var(--font-space-mono, monospace)", fontWeight: 700 }}>{ini.code}</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: "#f1f5f9" }}>{ini.title}</span>
            <StatusBadge status={ini.status} />
            <PriorityDot priority={ini.priority} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ flex: 1, height: 4, background: "rgba(255,255,255,0.08)", borderRadius: 4, maxWidth: 240 }}>
              <div style={{ height: "100%", width: `${ini.progress}%`, borderRadius: 4, background: progColor, transition: "width 0.5s" }} />
            </div>
            <span style={{ fontSize: 12, color: "#94a3b8" }}>{ini.progress}%</span>
          </div>
          <div style={{ display: "flex", gap: 16, fontSize: 12, color: "#64748b", flexWrap: "wrap" }}>
            <span>{cat.icon} {cat.label}</span>
            <span style={{ color: dl.color }}>{dl.label}</span>
            <span style={{ color: bc }}>Budget {bp}%</span>
          </div>
        </div>
        <ProgressRing pct={ini.progress} />
      </div>
    </Link>
  );
}

// ─── PAGE ────────────────────────────────────────────────────────────────────

export default function DashboardPage() {
  const { user } = useAuth();
  const { initiatives, loading } = useInitiatives();

  const stats = useMemo(() => {
    const active = initiatives.filter(i => i.status === "active");
    return {
      activeCount: active.length,
      onHoldCount: initiatives.filter(i => i.status === "on_hold").length,
      completedCount: initiatives.filter(i => i.status === "completed").length,
      criticalCount: active.filter(i => i.priority === "critical").length,
      avgProgress: active.length ? Math.round(active.reduce((s, i) => s + i.progress, 0) / active.length) : 0,
      overBudgetCount: active.filter(i => budgetPct(i.budgetSpent, i.budget) > 85).length,
      totalBudget: initiatives.reduce((s, i) => s + (i.budget || 0), 0),
      totalSpent: initiatives.reduce((s, i) => s + (i.budgetSpent || 0), 0),
    };
  }, [initiatives]);

  const activeAndOnHold = initiatives.filter(i => i.status === "active" || i.status === "on_hold");

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300 }}>
        <div style={{ width: 24, height: 24, borderRadius: "50%", border: "2px solid #22d3ee", borderTopColor: "transparent", animation: "spin 0.8s linear infinite" }} />
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
      {/* Breadcrumb */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "#334155" }}>
        <span>AI & Automations</span>
        <span>›</span>
        <span style={{ color: "#22d3ee" }}>Dashboard</span>
        <span style={{ marginLeft: "auto", fontSize: 13, color: "#475569" }}>
          Bienvenido, <span style={{ color: "#f1f5f9", fontWeight: 600 }}>{user?.name.split(" ")[0]}</span>
        </span>
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        <KPICard label="Iniciativas activas" value={stats.activeCount} sub={`${stats.onHoldCount} en pausa`} color="#22d3ee" icon="◈" />
        <KPICard label="Completadas" value={stats.completedCount} sub="total histórico" color="#4ade80" icon="✓" />
        <KPICard label="Avance promedio" value={`${stats.avgProgress}%`} sub="en iniciativas activas" color="#a78bfa" icon="▲" />
        <KPICard label="Críticas activas" value={stats.criticalCount}
          sub={stats.overBudgetCount > 0 ? `${stats.overBudgetCount} sobre presupuesto` : "Presupuesto OK"}
          color={stats.criticalCount > 0 ? "#f87171" : "#4ade80"} icon="!" />
      </div>

      {/* Active initiatives */}
      <section>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase" }}>
            Iniciativas en curso
          </h3>
          <Link href="/dashboard/initiatives" style={{ fontSize: 12, color: "#22d3ee", textDecoration: "none" }}>
            Ver todas →
          </Link>
        </div>
        {activeAndOnHold.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40, color: "#334155", fontSize: 14 }}>
            No hay iniciativas activas.{" "}
            <Link href="/dashboard/initiatives/new" style={{ color: "#22d3ee" }}>Crea la primera</Link>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {activeAndOnHold.map(ini => <InitiativeRow key={ini.id} ini={ini} />)}
          </div>
        )}
      </section>

      {/* Budget summary */}
      <section>
        <div style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "18px 22px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase" }}>Presupuesto global</h3>
            <span style={{ fontSize: 12, color: "#475569" }}>
              ${(stats.totalSpent/1000).toFixed(1)}k / ${(stats.totalBudget/1000).toFixed(1)}k
            </span>
          </div>
          <div style={{ height: 6, background: "rgba(255,255,255,0.07)", borderRadius: 4 }}>
            <div style={{
              height: "100%", borderRadius: 4, transition: "width 0.6s",
              width: `${budgetPct(stats.totalSpent, stats.totalBudget)}%`,
              background: budgetColor(stats.totalSpent, stats.totalBudget),
            }} />
          </div>
          <div style={{ fontSize: 12, color: "#475569", marginTop: 6 }}>
            {budgetPct(stats.totalSpent, stats.totalBudget)}% ejecutado · ${((stats.totalBudget - stats.totalSpent)/1000).toFixed(1)}k disponible
          </div>
        </div>
      </section>
    </div>
  );
}
