"use client";
import { useMemo } from "react";
import Link from "next/link";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import { INIT_STATUS, PRIORITY, CATEGORY, progColor, budgetPct, budgetColor, fmtDate, daysLeftLabel } from "@/lib/utils";
import { ProgressRing, StatusBadge, PriorityBadge, Spinner } from "@/components/ui";

function KPI({ label, value, sub, color="#22d3ee", icon }) {
  return <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:"20px 24px",position:"relative",overflow:"hidden"}}>
    <div style={{position:"absolute",top:-10,right:-10,fontSize:64,opacity:0.04,lineHeight:1}}>{icon}</div>
    <div style={{fontSize:11,color:"#64748b",fontWeight:600,letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:8}}>{label}</div>
    <div style={{fontSize:34,fontWeight:800,color,fontFamily:"monospace",lineHeight:1,marginBottom:4}}>{value}</div>
    {sub&&<div style={{fontSize:12,color:"#475569"}}>{sub}</div>}
  </div>;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { initiatives, loading } = useInitiatives();
  const stats = useMemo(()=>{
    const active = initiatives.filter(i=>i.status==="active");
    return {
      activeCount: active.length,
      onHoldCount: initiatives.filter(i=>i.status==="on_hold").length,
      completedCount: initiatives.filter(i=>i.status==="completed").length,
      criticalCount: active.filter(i=>i.priority==="critical").length,
      avgProgress: active.length?Math.round(active.reduce((s,i)=>s+i.progress,0)/active.length):0,
      totalBudget: initiatives.reduce((s,i)=>s+(i.budget||0),0),
      totalSpent:  initiatives.reduce((s,i)=>s+(i.budgetSpent||0),0),
    };
  },[initiatives]);
  const activeList = initiatives.filter(i=>i.status==="active"||i.status==="on_hold");
  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;
  return <div style={{display:"flex",flexDirection:"column",gap:28}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div>
        <div style={{fontSize:12,color:"#334155",marginBottom:4}}>AI & Automations › <span style={{color:"#22d3ee"}}>Dashboard</span></div>
        <h1 style={{fontSize:22,fontWeight:800,color:"#f1f5f9"}}>Bienvenido, {user?.name?.split(" ")[0]}</h1>
      </div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:16}}>
      <KPI label="Iniciativas activas" value={stats.activeCount} sub={`${stats.onHoldCount} en pausa`} color="#22d3ee" icon="◈"/>
      <KPI label="Completadas" value={stats.completedCount} sub="total histórico" color="#4ade80" icon="✓"/>
      <KPI label="Avance promedio" value={`${stats.avgProgress}%`} sub="en activas" color="#a78bfa" icon="▲"/>
      <KPI label="Críticas activas" value={stats.criticalCount} color={stats.criticalCount>0?"#f87171":"#4ade80"} icon="!"/>
    </div>
    <section>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
        <h3 style={{fontSize:13,fontWeight:700,color:"#64748b",letterSpacing:"0.1em",textTransform:"uppercase"}}>Iniciativas en curso</h3>
        <Link href="/dashboard/initiatives" style={{fontSize:12,color:"#22d3ee",textDecoration:"none"}}>Ver todas →</Link>
      </div>
      {activeList.length===0?<div style={{textAlign:"center",padding:40,color:"#334155",fontSize:14}}>
        No hay iniciativas activas. <Link href="/dashboard/initiatives/new" style={{color:"#22d3ee"}}>Crea la primera</Link>
      </div>:<div style={{display:"flex",flexDirection:"column",gap:10}}>
        {activeList.map(ini=>{
          const dl=daysLeftLabel(ini.dueDate), bp=budgetPct(ini.budgetSpent,ini.budget), bc=budgetColor(ini.budgetSpent,ini.budget);
          return <Link key={ini.id} href={`/dashboard/initiatives/${ini.id}`} style={{textDecoration:"none"}}>
            <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px 20px",cursor:"pointer",display:"grid",gridTemplateColumns:"1fr auto",gap:16,alignItems:"center",transition:"all 0.15s"}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor="#22d3ee44";e.currentTarget.style.background="rgba(34,211,238,0.04)";}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.07)";e.currentTarget.style.background="rgba(255,255,255,0.025)";}}>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
                  <span style={{fontSize:11,color:"#22d3ee",fontFamily:"monospace",fontWeight:700}}>{ini.code}</span>
                  <span style={{fontSize:14,fontWeight:700,color:"#f1f5f9"}}>{ini.title}</span>
                  <StatusBadge status={ini.status}/><PriorityBadge priority={ini.priority}/>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{flex:1,height:4,background:"rgba(255,255,255,0.08)",borderRadius:4,maxWidth:260}}>
                    <div style={{height:"100%",width:`${ini.progress}%`,borderRadius:4,background:progColor(ini.progress),transition:"width 0.5s"}}/>
                  </div>
                  <span style={{fontSize:12,color:"#94a3b8"}}>{ini.progress}%</span>
                </div>
                <div style={{display:"flex",gap:16,fontSize:12,color:"#64748b",flexWrap:"wrap"}}>
                  <span>{CATEGORY[ini.category]?.icon} {CATEGORY[ini.category]?.label}</span>
                  <span style={{color:dl.color}}>{dl.label}</span>
                  {ini.budget>0&&<span style={{color:bc}}>Budget {bp}%</span>}
                </div>
              </div>
              <ProgressRing pct={ini.progress} size={52}/>
            </div>
          </Link>;
        })}
      </div>}
    </section>
    {stats.totalBudget>0&&<div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px 22px"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:12}}>
        <h3 style={{fontSize:13,fontWeight:700,color:"#64748b",letterSpacing:"0.1em",textTransform:"uppercase"}}>Presupuesto global</h3>
        <span style={{fontSize:12,color:"#475569"}}>${(stats.totalSpent/1000).toFixed(1)}k / ${(stats.totalBudget/1000).toFixed(1)}k</span>
      </div>
      <div style={{height:6,background:"rgba(255,255,255,0.07)",borderRadius:4}}>
        <div style={{height:"100%",borderRadius:4,width:`${budgetPct(stats.totalSpent,stats.totalBudget)}%`,background:budgetColor(stats.totalSpent,stats.totalBudget),transition:"width 0.6s"}}/>
      </div>
    </div>}
  </div>;
}
