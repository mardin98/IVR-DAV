"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import { INIT_STATUS, PRIORITY, CATEGORY, progColor, budgetPct, budgetColor, fmtDate, daysLeftLabel } from "@/lib/utils";
import { StatusBadge, PriorityBadge, CategoryChip, ProgressRing, Button, Spinner, EmptyState } from "@/components/ui";
const PORDER = {critical:0,high:1,medium:2,low:3};
export default function InitiativesPage() {
  const { isLeader } = useAuth();
  const { initiatives, loading } = useInitiatives();
  const router = useRouter();
  const [fs,setFs] = useState("all");
  const [fc,setFc] = useState("all");
  const [sort,setSort] = useState("priority");
  const [search,setSearch] = useState("");
  const filtered = initiatives
    .filter(i=>fs==="all"||i.status===fs)
    .filter(i=>fc==="all"||i.category===fc)
    .filter(i=>!search||i.title.toLowerCase().includes(search.toLowerCase())||i.code.toLowerCase().includes(search.toLowerCase()))
    .sort((a,b)=>sort==="priority"?PORDER[a.priority]-PORDER[b.priority]:sort==="progress"?b.progress-a.progress:sort==="due"?(a.dueDate?.seconds??0)-(b.dueDate?.seconds??0):(b.createdAt?.seconds??0)-(a.createdAt?.seconds??0));
  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;
  return <div style={{display:"flex",flexDirection:"column",gap:20}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div>
        <div style={{fontSize:12,color:"#334155",marginBottom:4}}>AI & Automations › <span style={{color:"#22d3ee"}}>Iniciativas</span></div>
        <h1 style={{fontSize:22,fontWeight:800,color:"#f1f5f9"}}>Iniciativas</h1>
      </div>
      {isLeader&&<Button variant="primary" onClick={()=>router.push("/dashboard/initiatives/new")}>+ Nueva iniciativa</Button>}
    </div>
    <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar…" style={{width:200,padding:"7px 12px",fontSize:13}}/>
      <div style={{display:"flex",gap:2,background:"rgba(255,255,255,0.04)",borderRadius:10,padding:3}}>
        {[["all","Todas"],["active","Activas"],["on_hold","Pausa"],["completed","Completadas"],["draft","Borrador"]].map(([k,v])=>(
          <button key={k} onClick={()=>setFs(k)} style={{padding:"5px 12px",borderRadius:8,border:"none",cursor:"pointer",background:fs===k?"rgba(34,211,238,0.15)":"none",color:fs===k?"#22d3ee":"#475569",fontSize:12,fontWeight:fs===k?700:500,fontFamily:"inherit"}}>{v}</button>
        ))}
      </div>
      <select value={sort} onChange={e=>setSort(e.target.value)} style={{width:"auto",padding:"7px 12px",marginLeft:"auto"}}>
        <option value="priority">Prioridad</option><option value="progress">Avance</option>
        <option value="due">Vencimiento</option><option value="created">Recientes</option>
      </select>
    </div>
    {filtered.length===0?<EmptyState icon="◈" title="Sin iniciativas" sub={search?"Intenta con otro término":undefined} action={isLeader?<Button variant="primary" onClick={()=>router.push("/dashboard/initiatives/new")}>+ Crear primera iniciativa</Button>:undefined}/>:
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      {filtered.map(ini=>{
        const dl=daysLeftLabel(ini.dueDate), bp=budgetPct(ini.budgetSpent,ini.budget), bc=budgetColor(ini.budgetSpent,ini.budget);
        return <Link key={ini.id} href={`/dashboard/initiatives/${ini.id}`} style={{textDecoration:"none"}}>
          <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px 22px",cursor:"pointer",transition:"all 0.15s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor="#22d3ee33";e.currentTarget.style.background="rgba(34,211,238,0.04)";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.07)";e.currentTarget.style.background="rgba(255,255,255,0.025)";}}>
            <div style={{display:"flex",alignItems:"flex-start",gap:16}}>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8,flexWrap:"wrap"}}>
                  <span style={{fontSize:11,color:"#22d3ee",fontFamily:"monospace",fontWeight:700}}>{ini.code}</span>
                  <span style={{fontSize:15,fontWeight:700,color:"#f1f5f9"}}>{ini.title}</span>
                </div>
                <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:10}}>
                  <StatusBadge status={ini.status}/><PriorityBadge priority={ini.priority}/><CategoryChip category={ini.category}/>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8,maxWidth:320}}>
                  <div style={{flex:1,height:5,background:"rgba(255,255,255,0.07)",borderRadius:4}}>
                    <div style={{height:"100%",width:`${ini.progress}%`,borderRadius:4,background:progColor(ini.progress)}}/>
                  </div>
                  <span style={{fontSize:12,color:"#64748b"}}>{ini.progress}%</span>
                </div>
                <div style={{display:"flex",gap:16,fontSize:12,color:"#475569",flexWrap:"wrap"}}>
                  <span style={{color:dl.color}}>{dl.label}</span>
                  <span>Vence {fmtDate(ini.dueDate)}</span>
                  {ini.budget>0&&<span style={{color:bc}}>💰 {bp}% budget</span>}
                </div>
              </div>
              <ProgressRing pct={ini.progress} size={56}/>
            </div>
          </div>
        </Link>;
      })}
    </div>}
  </div>;
}
