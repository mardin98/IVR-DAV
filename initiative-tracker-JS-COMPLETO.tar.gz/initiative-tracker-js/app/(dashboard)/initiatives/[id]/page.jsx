"use client";
import { use, useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { subOne, updateInitiative, updateStatus, deleteInitiative } from "@/lib/firestore/initiatives";
import { getAllUsers } from "@/lib/firestore/users";
import { useTasks } from "@/lib/hooks/useTasks";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtDate, daysLeftLabel, budgetPct, budgetColor, INIT_STATUS, TASK_STATUS } from "@/lib/utils";
import { Avatar, StatusBadge, PriorityBadge, CategoryChip, ProgressRing, ProgressBar, Button, Modal, MetaItem, Spinner, RoleBadge } from "@/components/ui";
import TaskTree from "@/components/tasks/TaskTree";
import TaskForm from "@/components/tasks/TaskForm";
import TaskComments from "@/components/tasks/TaskComments";
import InitiativeForm from "@/components/initiatives/InitiativeForm";
import toast from "react-hot-toast";

export default function DetailPage({ params }) {
  const { id } = use(params);
  const { user, isAdmin } = useAuth();
  const router = useRouter();
  const [ini,setIni]         = useState(null);
  const [users,setUsers]     = useState([]);
  const [tab,setTab]         = useState("tasks");
  const [taskModal,setTM]    = useState({open:false});
  const [logModal,setLM]     = useState({open:false});
  const [hours,setHours]     = useState("");
  const [delConf,setDelConf] = useState(false);
  const [commentModal,setCM]  = useState({open:false,taskId:null,taskTitle:""});
  const { taskTree, create, update, changeStatus, changeProgress, addHours, remove } = useTasks(id);

  useEffect(()=>{ const unsub=subOne(id,setIni); getAllUsers().then(setUsers); return unsub; },[id]);
  if(!ini) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;

  const leader = users.find(u=>u.id===ini.leaderId);
  const dl  = daysLeftLabel(ini.dueDate);
  const bp  = budgetPct(ini.budgetSpent,ini.budget);
  const bc  = budgetColor(ini.budgetSpent,ini.budget);
  const canEdit = isAdmin || user?.id===ini.leaderId;
  const memberRole = user?.id ? ini.memberRoles?.[user.id] : undefined;
  const totalEst    = taskTree.reduce((s,t)=>s+(t.estimatedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.estimatedHours||0),0)||0),0);
  const totalLogged = taskTree.reduce((s,t)=>s+(t.loggedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.loggedHours||0),0)||0),0);

  return <div style={{display:"flex",flexDirection:"column",gap:24,maxWidth:1000,margin:"0 auto"}}>
    <div style={{display:"flex",alignItems:"center",gap:8,fontSize:12,color:"#334155"}}>
      <button onClick={()=>router.push("/dashboard/initiatives")} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",color:"#94a3b8",borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>← Iniciativas</button>
      <span>›</span><span style={{fontFamily:"monospace",color:"#22d3ee",fontWeight:700}}>{ini.code}</span>
      {memberRole&&<RoleBadge role={memberRole}/>}
    </div>
    <div style={{display:"flex",alignItems:"flex-start",gap:16}}>
      <div style={{flex:1}}>
        <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:8}}>
          <StatusBadge status={ini.status}/><PriorityBadge priority={ini.priority}/><CategoryChip category={ini.category}/>
        </div>
        <h1 style={{fontSize:24,fontWeight:800,color:"#f1f5f9",lineHeight:1.3,marginBottom:8}}>{ini.title}</h1>
        {ini.description&&<p style={{fontSize:13,color:"#64748b",lineHeight:1.7}}>{ini.description}</p>}
        {canEdit&&<div style={{display:"flex",gap:6,marginTop:12,flexWrap:"wrap"}}>
          {["draft","active","on_hold","completed","cancelled"].filter(s=>s!==ini.status).map(s=>(
            <button key={s} onClick={async()=>{await updateStatus(id,s,user?.id);toast.success(`Estado: ${INIT_STATUS[s].label}`);}} style={{padding:"4px 12px",borderRadius:20,cursor:"pointer",fontSize:11,fontWeight:600,fontFamily:"inherit",border:`1px solid ${INIT_STATUS[s].color}44`,background:`${INIT_STATUS[s].color}0d`,color:INIT_STATUS[s].color}}>→ {INIT_STATUS[s].label}</button>
          ))}
        </div>}
      </div>
      <ProgressRing pct={ini.progress} size={72}/>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10}}>
      <MetaItem label="Líder">{leader&&<><Avatar name={leader.name} size={20} photoURL={leader.photoURL}/>{leader.name.split(" ")[0]}</>}</MetaItem>
      <MetaItem label="Inicio">{fmtDate(ini.startDate)}</MetaItem>
      <MetaItem label="Vencimiento"><span style={{color:dl.color}}>{fmtDate(ini.dueDate)}</span></MetaItem>
      <MetaItem label="Horas">{totalLogged}h / {totalEst}h</MetaItem>
      {ini.budget>0&&<MetaItem label="Presupuesto"><span style={{color:bc}}>${(ini.budgetSpent/1000).toFixed(1)}k / ${(ini.budget/1000).toFixed(1)}k ({bp}%)</span></MetaItem>}
    </div>
    {ini.budget>0&&<div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,padding:"14px 18px"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,fontSize:12}}><span style={{color:"#64748b"}}>Ejecución presupuestaria</span><span style={{color:bc,fontWeight:700}}>{bp}%</span></div>
      <ProgressBar pct={bp} height={6}/>
      {bp>85&&<div style={{fontSize:11,color:"#f87171",marginTop:6}}>⚠ Presupuesto al {bp}% — revisar con líder</div>}
    </div>}
    <div>
      <div style={{display:"flex",gap:2,borderBottom:"1px solid rgba(255,255,255,0.07)",marginBottom:20}}>
        {[["tasks","Tareas"],["team","Equipo"],["timeline","Timeline"],...(canEdit?[["edit","Editar"]]:[])]
          .map(([k,v])=><button key={k} onClick={()=>setTab(k)} style={{padding:"10px 18px",background:"none",border:"none",cursor:"pointer",fontSize:13,fontWeight:tab===k?700:500,color:tab===k?"#22d3ee":"#475569",borderBottom:tab===k?"2px solid #22d3ee":"2px solid transparent",transition:"all 0.15s",fontFamily:"inherit"}}>{v}</button>)}
      </div>
      {tab==="tasks"&&<div style={{display:"flex",flexDirection:"column",gap:12}}>
        {canEdit&&<div style={{display:"flex",justifyContent:"flex-end"}}><Button variant="primary" onClick={()=>setTM({open:true})}>+ Nueva tarea</Button></div>}
        {taskTree.length===0?<div style={{textAlign:"center",padding:40,color:"#334155",fontSize:14}}>No hay tareas.{canEdit&&<> <button onClick={()=>setTM({open:true})} style={{color:"#22d3ee",background:"none",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:14}}>Crea la primera</button></>}</div>:
        <TaskTree taskTree={taskTree} users={users} canEdit={canEdit}
          onAddSubtask={pid=>setTM({open:true,parentId:pid})}
          onEditTask={t=>setTM({open:true,editing:t})}
          onDeleteTask={async tid=>{await remove(tid);toast.success("Tarea eliminada");}}
          onChangeStatus={changeStatus} onChangeProgress={changeProgress}
          onViewComments={t=>setCM({open:true,taskId:t.id,taskTitle:t.title})}
          onLogHours={tid=>{setLM({open:true,taskId:tid});setHours("");}}/>}
      </div>}
      {tab==="team"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
        {ini.members.map(mid=>{
          const u=users.find(u=>u.id===mid); if(!u) return null;
          const role=ini.memberRoles?.[mid]??"observer";
          const open=taskTree.flatMap(t=>[t,...(t.subtasks||[])]).filter(t=>t.assigneeId===mid&&t.status!=="done").length;
          return <div key={mid} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12}}>
            <Avatar name={u.name} size={38} photoURL={u.photoURL}/>
            <div style={{flex:1}}><div style={{fontSize:14,fontWeight:600,color:"#e2e8f0"}}>{u.name}</div><div style={{fontSize:12,color:"#475569"}}>{u.email}</div></div>
            <div style={{fontSize:12,color:open>3?"#f59e0b":"#475569"}}>{open} tareas abiertas</div>
            <RoleBadge role={role}/>
          </div>;
        })}
      </div>}
      {tab==="timeline"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
        {taskTree.filter(t=>t.dueDate).length===0?<div style={{textAlign:"center",padding:40,color:"#334155",fontSize:14}}>Agrega fechas a las tareas para ver el timeline</div>:
        taskTree.filter(t=>t.dueDate).map(task=>{
          const start=ini.startDate?.toDate?.()??new Date(), end=ini.dueDate?.toDate?.()??new Date(), tEnd=task.dueDate?.toDate?.()??new Date();
          const total=end-start, elapsed=tEnd-start;
          const off=Math.max(0,Math.min(70,(elapsed/total)*80));
          const cfg=TASK_STATUS[task.status];
          return <div key={task.id} style={{display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:12,color:"#475569",width:200,flexShrink:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{task.title}</span>
            <div style={{flex:1,height:22,background:"rgba(255,255,255,0.04)",borderRadius:6,position:"relative"}}>
              <div style={{position:"absolute",left:`${off}%`,width:`${100-off}%`,height:"100%",background:`${cfg?.color}25`,borderRadius:6,border:`1px solid ${cfg?.color}55`,display:"flex",alignItems:"center",paddingLeft:8,fontSize:11,color:cfg?.color,overflow:"hidden"}}>{task.progress}%</div>
            </div>
            <span style={{fontSize:11,color:"#334155",width:80,textAlign:"right",flexShrink:0}}>{fmtDate(task.dueDate)}</span>
          </div>;
        })}
      </div>}
      {tab==="edit"&&canEdit&&<div>
        <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:24,marginBottom:20}}>
          <InitiativeForm initial={{title:ini.title,description:ini.description,status:ini.status,priority:ini.priority,category:ini.category,leaderId:ini.leaderId,startDate:ini.startDate?.toDate?.()?.toISOString()?.split("T")[0]??"",dueDate:ini.dueDate?.toDate?.()?.toISOString()?.split("T")[0]??"",budget:ini.budget}}
            onSubmit={async d=>{await updateInitiative(id,d,user?.id);toast.success("Iniciativa actualizada");setTab("tasks");}}
            onCancel={()=>setTab("tasks")} submitLabel="Guardar cambios"/>
        </div>
        {isAdmin&&<div style={{background:"rgba(248,113,113,0.05)",border:"1px solid rgba(248,113,113,0.2)",borderRadius:12,padding:16}}>
          <div style={{fontSize:13,fontWeight:600,color:"#f87171",marginBottom:8}}>Zona de peligro</div>
          {!delConf?<Button variant="danger" onClick={()=>setDelConf(true)}>Eliminar iniciativa</Button>:
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            <span style={{fontSize:12,color:"#f87171"}}>¿Confirmar?</span>
            <Button variant="danger" onClick={async()=>{await deleteInitiative(id,user?.id);toast.success("Eliminada");router.push("/dashboard/initiatives");}}>Sí, eliminar</Button>
            <Button variant="ghost" onClick={()=>setDelConf(false)}>Cancelar</Button>
          </div>}
        </div>}
      </div>}
    </div>
    {taskModal.open&&<Modal title={taskModal.editing?"Editar tarea":taskModal.parentId?"Nueva subtarea":"Nueva tarea"} onClose={()=>setTM({open:false})}>
      <TaskForm initiativeMembers={ini.members} parentTaskId={taskModal.parentId}
        initial={taskModal.editing?{title:taskModal.editing.title,description:taskModal.editing.description,assigneeId:taskModal.editing.assigneeId,status:taskModal.editing.status,priority:taskModal.editing.priority,progress:taskModal.editing.progress,estimatedHours:taskModal.editing.estimatedHours,dueDate:taskModal.editing.dueDate?.toDate?.()?.toISOString()?.split("T")[0]}:undefined}
        onSubmit={async d=>{taskModal.editing?await update(taskModal.editing.id,d):await create(d);toast.success(taskModal.editing?"Actualizada":"Tarea creada");setTM({open:false});}}
        onCancel={()=>setTM({open:false})} submitLabel={taskModal.editing?"Guardar":"Crear tarea"}/>
    </Modal>}
    {commentModal.open&&<Modal title={`💬 ${commentModal.taskTitle}`} onClose={()=>setCM({open:false,taskId:null,taskTitle:""})} width={580}>
      <TaskComments iniId={id} taskId={commentModal.taskId}/>
    </Modal>}
    {logModal.open&&<Modal title="Registrar horas" onClose={()=>setLM({open:false})} width={360}>
      <div style={{display:"flex",flexDirection:"column",gap:14}}>
        <label>Horas trabajadas</label>
        <input type="number" value={hours} onChange={e=>setHours(e.target.value)} placeholder="Ej: 2.5" min="0" step="0.5" autoFocus/>
        <div style={{display:"flex",gap:8,justifyContent:"flex-end"}}>
          <Button variant="ghost" onClick={()=>setLM({open:false})}>Cancelar</Button>
          <Button variant="primary" onClick={async()=>{const h=parseFloat(hours);if(!h||!logModal.taskId)return;await addHours(logModal.taskId,h);toast.success(`${h}h registradas`);setLM({open:false});setHours("");}} disabled={!hours||isNaN(parseFloat(hours))}>Registrar</Button>
        </div>
      </div>
    </Modal>}
  </div>;
}
