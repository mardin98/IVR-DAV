"use client";
import { use, useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { subscribeInitiative, updateInitiative, updateInitiativeStatus, deleteInitiative } from "@/lib/firestore/initiatives";
import { getAllUsers } from "@/lib/firestore/users";
import { useTasks } from "@/lib/hooks/useTasks";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtDate, daysLeftLabel, budgetPct, budgetColor, INITIATIVE_STATUS, TASK_STATUS } from "@/lib/utils";
import {
  Avatar, StatusBadge, PriorityBadge, CategoryChip,
  ProgressRing, ProgressBar, Button, Modal, MetaItem, Spinner, RoleBadge,
} from "@/components/ui";
import TaskTree from "@/components/tasks/TaskTree";
import TaskForm from "@/components/tasks/TaskForm";
import InitiativeForm from "@/components/initiatives/InitiativeForm";
import toast from "react-hot-toast";

export default function InitiativeDetailPage({ params }) {
  const { id } = use(params);
  const { user, isAdmin } = useAuth();
  const router = useRouter();
  const [initiative, setInitiative] = useState(null);
  const [users, setUsers]           = useState([]);
  const [tab, setTab]               = useState("tasks");
  const [taskModal, setTaskModal]   = useState({ open:false });
  const [logModal, setLogModal]     = useState({ open:false });
  const [hoursInput, setHoursInput] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState(false);

  const { taskTree, create, update, changeStatus, changeProgress, addHours, remove } = useTasks(id);

  useEffect(() => {
    const unsub = subscribeInitiative(id, setInitiative);
    getAllUsers().then(setUsers);
    return unsub;
  }, [id]);

  if (!initiative) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:300 }}>
      <Spinner size={28} />
    </div>
  );

  const leader              = users.find(u => u.id === initiative.leaderId);
  const dl                  = daysLeftLabel(initiative.dueDate);
  const bp                  = budgetPct(initiative.budgetSpent, initiative.budget);
  const bc                  = budgetColor(initiative.budgetSpent, initiative.budget);
  const isInitiativeLeader  = user?.id === initiative.leaderId;
  const canEdit             = isAdmin || isInitiativeLeader;
  const memberRole          = user?.id ? initiative.memberRoles?.[user.id] : undefined;
  const totalEst            = taskTree.reduce((s,t) => s+(t.estimatedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.estimatedHours||0),0)||0),0);
  const totalLogged         = taskTree.reduce((s,t) => s+(t.loggedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.loggedHours||0),0)||0),0);

  const handleStatusChange = async (status) => {
    await updateInitiativeStatus(id, status, user?.id);
    toast.success(`Estado: ${INITIATIVE_STATUS[status].label}`);
  };

  const handleEdit = async (data) => {
    await updateInitiative(id, data, user?.id);
    toast.success("Iniciativa actualizada");
    setTab("tasks");
  };

  const handleDelete = async () => {
    await deleteInitiative(id, user?.id);
    toast.success("Iniciativa eliminada");
    router.push("/dashboard/initiatives");
  };

  const handleCreateTask = async (data) => {
    await create(data);
    toast.success("Tarea creada");
    setTaskModal({ open:false });
  };

  const handleEditTask = async (data) => {
    if (!taskModal.editing) return;
    await update(taskModal.editing.id, data);
    toast.success("Tarea actualizada");
    setTaskModal({ open:false });
  };

  const handleLogHours = async () => {
    const hours = parseFloat(hoursInput);
    if (!hours || !logModal.taskId) return;
    await addHours(logModal.taskId, hours);
    toast.success(`${hours}h registradas`);
    setLogModal({ open:false });
    setHoursInput("");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24, maxWidth:1000, margin:"0 auto" }}>
      {/* Breadcrumb */}
      <div style={{ display:"flex", alignItems:"center", gap:8, fontSize:12, color:"#334155" }}>
        <button onClick={() => router.push("/dashboard/initiatives")}
          style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)",
            color:"#94a3b8", borderRadius:8, padding:"5px 12px", cursor:"pointer", fontSize:12, fontFamily:"inherit" }}>
          ← Iniciativas
        </button>
        <span>›</span>
        <span style={{ fontFamily:"monospace", color:"#22d3ee", fontWeight:700 }}>{initiative.code}</span>
        {memberRole && <RoleBadge role={memberRole} />}
      </div>

      {/* Title */}
      <div style={{ display:"flex", alignItems:"flex-start", gap:16 }}>
        <div style={{ flex:1 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:8 }}>
            <StatusBadge status={initiative.status} />
            <PriorityBadge priority={initiative.priority} />
            <CategoryChip category={initiative.category} />
          </div>
          <h1 style={{ fontSize:24, fontWeight:800, color:"#f1f5f9", lineHeight:1.3, marginBottom:8 }}>{initiative.title}</h1>
          {initiative.description && (
            <p style={{ fontSize:13, color:"#64748b", lineHeight:1.7 }}>{initiative.description}</p>
          )}
          {canEdit && (
            <div style={{ display:"flex", gap:6, marginTop:12, flexWrap:"wrap" }}>
              {["draft","active","on_hold","completed","cancelled"].filter(s => s !== initiative.status).map(s => (
                <button key={s} onClick={() => handleStatusChange(s)} style={{
                  padding:"4px 12px", borderRadius:20, cursor:"pointer", fontSize:11, fontWeight:600, fontFamily:"inherit",
                  border:`1px solid ${INITIATIVE_STATUS[s].color}44`,
                  background:`${INITIATIVE_STATUS[s].color}0d`, color:INITIATIVE_STATUS[s].color,
                }}>→ {INITIATIVE_STATUS[s].label}</button>
              ))}
            </div>
          )}
        </div>
        <ProgressRing pct={initiative.progress} size={72} />
      </div>

      {/* Meta grid */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(140px, 1fr))", gap:10 }}>
        <MetaItem label="Líder">
          {leader && <><Avatar name={leader.name} size={20} photoURL={leader.photoURL} />{leader.name.split(" ")[0]}</>}
        </MetaItem>
        <MetaItem label="Inicio">{fmtDate(initiative.startDate)}</MetaItem>
        <MetaItem label="Vencimiento"><span style={{ color:dl.color }}>{fmtDate(initiative.dueDate)}</span></MetaItem>
        <MetaItem label="Horas">{totalLogged}h / {totalEst}h</MetaItem>
        {initiative.budget > 0 && (
          <MetaItem label="Presupuesto">
            <span style={{ color:bc }}>${(initiative.budgetSpent/1000).toFixed(1)}k / ${(initiative.budget/1000).toFixed(1)}k ({bp}%)</span>
          </MetaItem>
        )}
        {initiative.googleDriveFolderId && (
          <MetaItem label="Drive">
            <a href={`https://drive.google.com/drive/folders/${initiative.googleDriveFolderId}`}
              target="_blank" rel="noopener noreferrer"
              style={{ color:"#22d3ee", textDecoration:"none", fontSize:12 }}>📁 Abrir carpeta</a>
          </MetaItem>
        )}
      </div>

      {/* Budget bar */}
      {initiative.budget > 0 && (
        <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, padding:"14px 18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8, fontSize:12 }}>
            <span style={{ color:"#64748b" }}>Ejecución presupuestaria</span>
            <span style={{ color:bc, fontWeight:700 }}>{bp}%</span>
          </div>
          <ProgressBar pct={bp} height={6} />
          {bp > 85 && <div style={{ fontSize:11, color:"#f87171", marginTop:6 }}>⚠ Presupuesto al {bp}% — revisar con líder</div>}
        </div>
      )}

      {/* Deadline pill */}
      <div style={{ padding:"10px 16px", borderRadius:10, fontSize:12, color:dl.color, display:"flex", alignItems:"center", gap:6,
        background:`${dl.color}10`, border:`1px solid ${dl.color}22` }}>
        📅 {dl.label} · Vence el {fmtDate(initiative.dueDate)}
      </div>

      {/* Tabs */}
      <div>
        <div style={{ display:"flex", gap:2, borderBottom:"1px solid rgba(255,255,255,0.07)", marginBottom:20 }}>
          {[["tasks","Tareas"],["team","Equipo"],["timeline","Timeline"],...(canEdit?[["edit","Editar"]]:[])]
            .map(([k,v]) => (
              <button key={k} onClick={() => setTab(k)} style={{
                padding:"10px 18px", background:"none", border:"none", cursor:"pointer",
                fontSize:13, fontWeight:tab===k?700:500, color:tab===k?"#22d3ee":"#475569",
                borderBottom:tab===k?"2px solid #22d3ee":"2px solid transparent",
                transition:"all 0.15s", fontFamily:"inherit",
              }}>{v}</button>
            ))}
        </div>

        {/* TASKS */}
        {tab === "tasks" && (
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            {canEdit && (
              <div style={{ display:"flex", justifyContent:"flex-end" }}>
                <Button variant="primary" onClick={() => setTaskModal({ open:true })}>+ Nueva tarea</Button>
              </div>
            )}
            {taskTree.length === 0 ? (
              <div style={{ textAlign:"center", padding:40, color:"#334155", fontSize:14 }}>
                No hay tareas aún.{canEdit && <> <button onClick={() => setTaskModal({ open:true })}
                  style={{ color:"#22d3ee", background:"none", border:"none", cursor:"pointer", fontFamily:"inherit", fontSize:14 }}>
                  Crea la primera
                </button></>}
              </div>
            ) : (
              <TaskTree taskTree={taskTree} users={users} canEdit={canEdit}
                onAddSubtask={parentId => setTaskModal({ open:true, parentId })}
                onEditTask={task => setTaskModal({ open:true, editing:task })}
                onDeleteTask={id => remove(id).then(() => toast.success("Tarea eliminada"))}
                onChangeStatus={changeStatus} onChangeProgress={changeProgress}
                onLogHours={taskId => { setLogModal({ open:true, taskId }); setHoursInput(""); }}
              />
            )}
          </div>
        )}

        {/* TEAM */}
        {tab === "team" && (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {initiative.members.map(mid => {
              const u = users.find(u => u.id === mid);
              if (!u) return null;
              const role = initiative.memberRoles?.[mid] ?? "observer";
              const openTasks = taskTree.flatMap(t => [t,...(t.subtasks||[])]).filter(t => t.assigneeId===mid && t.status!=="done").length;
              return (
                <div key={mid} style={{ display:"flex", alignItems:"center", gap:12, padding:"14px 16px",
                  background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12 }}>
                  <Avatar name={u.name} size={38} photoURL={u.photoURL} />
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:600, color:"#e2e8f0" }}>{u.name}</div>
                    <div style={{ fontSize:12, color:"#475569" }}>{u.email}</div>
                  </div>
                  <div style={{ fontSize:12, color:openTasks>3?"#f59e0b":"#475569" }}>
                    {openTasks} tarea{openTasks!==1?"s":""} abiertas
                  </div>
                  <RoleBadge role={role} />
                </div>
              );
            })}
          </div>
        )}

        {/* TIMELINE */}
        {tab === "timeline" && (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {taskTree.filter(t => t.dueDate).length === 0 ? (
              <div style={{ textAlign:"center", padding:40, color:"#334155", fontSize:14 }}>
                Agrega fechas a las tareas para ver el timeline
              </div>
            ) : (
              taskTree.filter(t => t.dueDate).map(task => {
                const start   = initiative.startDate?.toDate?.() ?? new Date();
                const end     = initiative.dueDate?.toDate?.()   ?? new Date();
                const taskEnd = task.dueDate?.toDate?.()         ?? new Date();
                const total   = end.getTime() - start.getTime();
                const elapsed = taskEnd.getTime() - start.getTime();
                const offsetPct = Math.max(0, Math.min(70, (elapsed/total)*80));
                const cfg = TASK_STATUS[task.status];
                return (
                  <div key={task.id} style={{ display:"flex", alignItems:"center", gap:12 }}>
                    <span style={{ fontSize:12, color:"#475569", width:200, flexShrink:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{task.title}</span>
                    <div style={{ flex:1, height:22, background:"rgba(255,255,255,0.04)", borderRadius:6, position:"relative" }}>
                      <div style={{ position:"absolute", left:`${offsetPct}%`, width:`${100-offsetPct}%`,
                        height:"100%", background:`${cfg?.color}25`, borderRadius:6,
                        border:`1px solid ${cfg?.color}55`, display:"flex", alignItems:"center",
                        paddingLeft:8, fontSize:11, color:cfg?.color, overflow:"hidden" }}>
                        {task.progress}%
                      </div>
                    </div>
                    <span style={{ fontSize:11, color:"#334155", width:80, textAlign:"right", flexShrink:0 }}>{fmtDate(task.dueDate)}</span>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* EDIT */}
        {tab === "edit" && canEdit && (
          <div>
            <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:24, marginBottom:20 }}>
              <InitiativeForm
                initial={{
                  title: initiative.title, description: initiative.description,
                  status: initiative.status, priority: initiative.priority, category: initiative.category,
                  leaderId: initiative.leaderId,
                  startDate: initiative.startDate?.toDate?.()?.toISOString()?.split("T")[0] ?? "",
                  dueDate:   initiative.dueDate?.toDate?.()?.toISOString()?.split("T")[0]   ?? "",
                  budget: initiative.budget,
                }}
                onSubmit={handleEdit}
                onCancel={() => setTab("tasks")}
                submitLabel="Guardar cambios"
              />
            </div>
            {isAdmin && (
              <div style={{ background:"rgba(248,113,113,0.05)", border:"1px solid rgba(248,113,113,0.2)", borderRadius:12, padding:16 }}>
                <div style={{ fontSize:13, fontWeight:600, color:"#f87171", marginBottom:8 }}>Zona de peligro</div>
                <div style={{ fontSize:12, color:"#64748b", marginBottom:12 }}>Eliminar esta iniciativa y todas sus tareas. Irreversible.</div>
                {!deleteConfirm ? (
                  <Button variant="danger" onClick={() => setDeleteConfirm(true)}>Eliminar iniciativa</Button>
                ) : (
                  <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                    <span style={{ fontSize:12, color:"#f87171" }}>¿Confirmar?</span>
                    <Button variant="danger" onClick={handleDelete}>Sí, eliminar</Button>
                    <Button variant="ghost" onClick={() => setDeleteConfirm(false)}>Cancelar</Button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Task modal */}
      {taskModal.open && (
        <Modal title={taskModal.editing?"Editar tarea":taskModal.parentId?"Nueva subtarea":"Nueva tarea"}
          onClose={() => setTaskModal({ open:false })}>
          <TaskForm
            initiativeMembers={initiative.members}
            parentTaskId={taskModal.parentId}
            initial={taskModal.editing ? {
              title: taskModal.editing.title, description: taskModal.editing.description,
              assigneeId: taskModal.editing.assigneeId, status: taskModal.editing.status,
              priority: taskModal.editing.priority, progress: taskModal.editing.progress,
              estimatedHours: taskModal.editing.estimatedHours,
              dueDate: taskModal.editing.dueDate?.toDate?.()?.toISOString()?.split("T")[0],
            } : undefined}
            onSubmit={taskModal.editing ? handleEditTask : handleCreateTask}
            onCancel={() => setTaskModal({ open:false })}
            submitLabel={taskModal.editing?"Guardar cambios":"Crear tarea"}
          />
        </Modal>
      )}

      {/* Log hours modal */}
      {logModal.open && (
        <Modal title="Registrar horas" onClose={() => setLogModal({ open:false })} width={360}>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <label>Horas trabajadas</label>
            <input type="number" value={hoursInput} onChange={e => setHoursInput(e.target.value)}
              placeholder="Ej: 2.5" min="0" step="0.5" autoFocus />
            <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
              <Button variant="ghost" onClick={() => setLogModal({ open:false })}>Cancelar</Button>
              <Button variant="primary" onClick={handleLogHours}
                disabled={!hoursInput || isNaN(parseFloat(hoursInput))}>Registrar</Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
