"use client";
import { use, useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { subOne, updateInitiative, updateStatus, deleteInitiative } from "@/lib/firestore/initiatives";
import { getAllUsers } from "@/lib/firestore/users";
import { useTasks } from "@/lib/hooks/useTasks";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtDate, daysLeftLabel, budgetPct, budgetColor, INIT_STATUS, TASK_STATUS, DV } from "@/lib/utils";
import {
  Avatar, StatusBadge, PriorityBadge, CategoryChip,
  ProgressRing, ProgressBar, Button, Modal, MetaItem, Spinner, RoleBadge,
} from "@/components/ui";
import TaskTree        from "@/components/tasks/TaskTree";
import KanbanBoard     from "@/components/tasks/KanbanBoard";
import TaskForm        from "@/components/tasks/TaskForm";
import TaskComments    from "@/components/tasks/TaskComments";
import TaskAttachments from "@/components/tasks/TaskAttachments";
import InitiativeForm  from "@/components/initiatives/InitiativeForm";
import toast from "react-hot-toast";

export default function DetailPage({ params }) {
  const { id } = use(params);
  const { user, isAdmin } = useAuth();
  const router = useRouter();

  const [ini,      setIni]      = useState(null);
  const [users,    setUsers]    = useState([]);
  const [tab,      setTab]      = useState("board");   // board | list | team | timeline | edit
  const [taskView, setTaskView] = useState("board");   // board | list (dentro de tab tasks)
  const [taskModal, setTM]      = useState({ open:false });
  const [logModal,  setLM]      = useState({ open:false, taskId:null });
  const [commentModal, setCM]   = useState({ open:false, taskId:null, taskTitle:"" });
  const [hoursInput, setHours]  = useState("");
  const [delConf,  setDelConf]  = useState(false);

  const {
    taskTree, create, update, changeStatus, changeProgress, addHours, remove,
  } = useTasks(id);

  useEffect(() => {
    const unsub = subOne(id, setIni);
    getAllUsers().then(setUsers);
    return unsub;
  }, [id]);

  if (!ini) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:300 }}>
      <Spinner size={28} />
    </div>
  );

  const leader     = users.find(u => u.id === ini.leaderId);
  const dl         = daysLeftLabel(ini.dueDate);
  const bp         = budgetPct(ini.budgetSpent, ini.budget);
  const bc         = budgetColor(ini.budgetSpent, ini.budget);
  const canEdit    = isAdmin || user?.id === ini.leaderId;
  const memberRole = user?.id ? ini.memberRoles?.[user.id] : undefined;
  const totalEst    = taskTree.reduce((s,t)=>s+(t.estimatedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.estimatedHours||0),0)||0),0);
  const totalLogged = taskTree.reduce((s,t)=>s+(t.loggedHours||0)+(t.subtasks?.reduce((ss,st)=>ss+(st.loggedHours||0),0)||0),0);

  const openTaskModal = (opts={}) => setTM({ open:true, ...opts });
  const openComments  = (task)    => setCM({ open:true, taskId:task.id, taskTitle:task.title });
  const openLogHours  = (taskId)  => { setLM({ open:true, taskId }); setHours(""); };

  const handleCreateTask = async (data) => {
    await create(data); toast.success("Tarea creada"); setTM({ open:false });
  };
  const handleEditTask = async (data) => {
    await update(taskModal.editing.id, data); toast.success("Tarea actualizada"); setTM({ open:false });
  };
  const handleLogHours = async () => {
    const h = parseFloat(hoursInput);
    if (!h || !logModal.taskId) return;
    await addHours(logModal.taskId, h);
    toast.success(`${h}h registradas`);
    setLM({ open:false }); setHours("");
  };

  const TABS = [
    { key:"board",    label:"Kanban" },
    { key:"list",     label:"Lista" },
    { key:"team",     label:"Equipo" },
    { key:"timeline", label:"Timeline" },
    ...(canEdit ? [{ key:"edit", label:"Editar" }] : []),
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24, maxWidth:1100, margin:"0 auto" }}>

      {/* Breadcrumb */}
      <div style={{ display:"flex", alignItems:"center", gap:8, fontSize:12, color:DV.text3 }}>
        <button onClick={() => router.push("/dashboard/initiatives")}
          style={{ background:"rgba(255,255,255,0.05)", border:`1px solid ${DV.border}`,
            color:DV.text2, borderRadius:8, padding:"5px 12px", cursor:"pointer",
            fontSize:12, fontFamily:"inherit" }}>
          ← Iniciativas
        </button>
        <span>›</span>
        <span style={{ fontFamily:"monospace", color:DV.red, fontWeight:700 }}>{ini.code}</span>
        {memberRole && <RoleBadge role={memberRole} />}
      </div>

      {/* Header de la iniciativa */}
      <div style={{ display:"flex", alignItems:"flex-start", gap:16 }}>
        <div style={{ flex:1 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:8 }}>
            <StatusBadge status={ini.status} />
            <PriorityBadge priority={ini.priority} />
            <CategoryChip category={ini.category} />
          </div>
          <h1 style={{ fontSize:24, fontWeight:800, color:DV.white, lineHeight:1.3, marginBottom:8 }}>
            {ini.title}
          </h1>
          {ini.description && (
            <p style={{ fontSize:13, color:DV.text3, lineHeight:1.7 }}>{ini.description}</p>
          )}
          {canEdit && (
            <div style={{ display:"flex", gap:6, marginTop:12, flexWrap:"wrap" }}>
              {["draft","active","on_hold","completed","cancelled"]
                .filter(s => s !== ini.status)
                .map(s => (
                  <button key={s}
                    onClick={async()=>{ await updateStatus(id,s,user?.id); toast.success(`→ ${INIT_STATUS[s].label}`); }}
                    style={{ padding:"4px 12px", borderRadius:20, cursor:"pointer", fontSize:11,
                      fontWeight:600, fontFamily:"inherit",
                      border:`1px solid ${INIT_STATUS[s].color}44`,
                      background:`${INIT_STATUS[s].color}0d`,
                      color:INIT_STATUS[s].color }}>
                    → {INIT_STATUS[s].label}
                  </button>
                ))}
            </div>
          )}
        </div>
        <ProgressRing pct={ini.progress} size={72} />
      </div>

      {/* Meta grid */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:10 }}>
        <MetaItem label="Líder">
          {leader && <><Avatar name={leader.name} size={20} photoURL={leader.photoURL} />{leader.name.split(" ")[0]}</>}
        </MetaItem>
        <MetaItem label="Inicio">{fmtDate(ini.startDate)}</MetaItem>
        <MetaItem label="Vencimiento">
          <span style={{ color:dl.color }}>{fmtDate(ini.dueDate)}</span>
        </MetaItem>
        <MetaItem label="Horas">{totalLogged}h / {totalEst}h</MetaItem>
        {ini.budget > 0 && (
          <MetaItem label="Presupuesto">
            <span style={{ color:bc }}>${(ini.budgetSpent/1000).toFixed(1)}k / ${(ini.budget/1000).toFixed(1)}k ({bp}%)</span>
          </MetaItem>
        )}
        {ini.googleDriveFolderId && (
          <MetaItem label="Drive">
            <a href={`https://drive.google.com/drive/folders/${ini.googleDriveFolderId}`}
              target="_blank" rel="noopener noreferrer"
              style={{ color:DV.red, textDecoration:"none", fontSize:12 }}>📁 Abrir carpeta</a>
          </MetaItem>
        )}
      </div>

      {/* Budget bar */}
      {ini.budget > 0 && (
        <div style={{ background:"rgba(255,255,255,0.025)", border:`1px solid ${DV.border}`,
          borderRadius:12, padding:"14px 18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8, fontSize:12 }}>
            <span style={{ color:DV.text3 }}>Ejecución presupuestaria</span>
            <span style={{ color:bc, fontWeight:700 }}>{bp}%</span>
          </div>
          <ProgressBar pct={bp} height={6} />
          {bp > 85 && <div style={{ fontSize:11, color:"#F87171", marginTop:6 }}>⚠ Presupuesto al {bp}%</div>}
        </div>
      )}

      {/* Deadline pill */}
      <div style={{ padding:"10px 16px", borderRadius:10, fontSize:12, color:dl.color,
        display:"flex", alignItems:"center", gap:6,
        background:`${dl.color}10`, border:`1px solid ${dl.color}22` }}>
        📅 {dl.label} · Vence el {fmtDate(ini.dueDate)}
      </div>

      {/* Tabs */}
      <div>
        <div style={{ display:"flex", gap:2, borderBottom:`1px solid ${DV.border}`, marginBottom:24 }}>
          {TABS.map(({ key, label }) => (
            <button key={key} onClick={() => setTab(key)} style={{
              padding:"10px 18px", background:"none", border:"none", cursor:"pointer",
              fontSize:13, fontWeight:tab===key?700:500,
              color: tab===key ? DV.white : DV.text3,
              borderBottom: tab===key ? `2px solid ${DV.red}` : "2px solid transparent",
              transition:"all 0.15s", fontFamily:"inherit",
            }}>{label}</button>
          ))}

          {/* Add task button siempre visible en tabs de tareas */}
          {(tab==="board"||tab==="list") && canEdit && (
            <Button variant="brand" size="sm"
              style={{ marginLeft:"auto", alignSelf:"center" }}
              onClick={() => openTaskModal()}>
              + Nueva tarea
            </Button>
          )}
        </div>

        {/* ── KANBAN ── */}
        {tab === "board" && (
          <KanbanBoard
            taskTree={taskTree}
            users={users}
            canEdit={canEdit}
            onAddTask={(parentId, defaultStatus) => openTaskModal({ parentId, defaultStatus })}
            onEditTask={task => openTaskModal({ editing:task })}
            onDeleteTask={async tid => { await remove(tid); toast.success("Tarea eliminada"); }}
            onViewComments={openComments}
            onLogHours={openLogHours}
            onChangeStatus={changeStatus}
          />
        )}

        {/* ── LISTA ── */}
        {tab === "list" && (
          taskTree.length === 0
            ? <div style={{ textAlign:"center", padding:40, color:DV.text4, fontSize:14 }}>
                No hay tareas.{" "}
                {canEdit && <button onClick={()=>openTaskModal()}
                  style={{ color:DV.red, background:"none", border:"none", cursor:"pointer",
                    fontFamily:"inherit", fontSize:14 }}>Crea la primera</button>}
              </div>
            : <TaskTree
                taskTree={taskTree}
                users={users}
                canEdit={canEdit}
                onAddSubtask={pid => openTaskModal({ parentId:pid })}
                onEditTask={task => openTaskModal({ editing:task })}
                onDeleteTask={async tid => { await remove(tid); toast.success("Tarea eliminada"); }}
                onChangeStatus={changeStatus}
                onChangeProgress={changeProgress}
                onLogHours={openLogHours}
                onViewComments={openComments}
              />
        )}

        {/* ── EQUIPO ── */}
        {tab === "team" && (
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {ini.members.map(mid => {
              const u    = users.find(u=>u.id===mid); if (!u) return null;
              const role = ini.memberRoles?.[mid] ?? "observer";
              const allTasks = taskTree.flatMap(t=>[t,...(t.subtasks||[])]);
              const open = allTasks.filter(t=>t.assigneeId===mid&&t.status!=="done").length;
              const done = allTasks.filter(t=>t.assigneeId===mid&&t.status==="done").length;
              return (
                <div key={mid} style={{ display:"flex", alignItems:"center", gap:14, padding:"16px 18px",
                  background:"rgba(255,255,255,0.025)", border:`1px solid ${DV.border}`, borderRadius:14 }}>
                  <Avatar name={u.name} size={42} photoURL={u.photoURL} />
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:600, color:DV.white }}>{u.name}</div>
                    <div style={{ fontSize:12, color:DV.text3 }}>{u.email}</div>
                  </div>
                  <div style={{ display:"flex", gap:16, fontSize:12 }}>
                    <div style={{ textAlign:"center" }}>
                      <div style={{ fontSize:20, fontWeight:800, color:DV.red, fontFamily:"monospace" }}>{open}</div>
                      <div style={{ color:DV.text3 }}>abiertas</div>
                    </div>
                    <div style={{ textAlign:"center" }}>
                      <div style={{ fontSize:20, fontWeight:800, color:DV.green, fontFamily:"monospace" }}>{done}</div>
                      <div style={{ color:DV.text3 }}>completadas</div>
                    </div>
                  </div>
                  <RoleBadge role={role} />
                </div>
              );
            })}
          </div>
        )}

        {/* ── TIMELINE ── */}
        {tab === "timeline" && (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {taskTree.filter(t=>t.dueDate).length === 0
              ? <div style={{ textAlign:"center", padding:40, color:DV.text4, fontSize:14 }}>
                  Agrega fechas a las tareas para ver el timeline
                </div>
              : taskTree.filter(t=>t.dueDate).map(task => {
                  const start = ini.startDate?.toDate?.() ?? new Date();
                  const end   = ini.dueDate?.toDate?.()   ?? new Date();
                  const tEnd  = task.dueDate?.toDate?.()  ?? new Date();
                  const total = end-start, elapsed = tEnd-start;
                  const off   = Math.max(0, Math.min(70, (elapsed/total)*80));
                  const cfg   = TASK_STATUS[task.status];
                  return (
                    <div key={task.id} style={{ display:"flex", alignItems:"center", gap:12 }}>
                      <span style={{ fontSize:12, color:DV.text3, width:200, flexShrink:0,
                        overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                        {task.title}
                      </span>
                      <div style={{ flex:1, height:22, background:"rgba(255,255,255,0.04)", borderRadius:6, position:"relative" }}>
                        <div style={{ position:"absolute", left:`${off}%`, width:`${100-off}%`, height:"100%",
                          background:`${cfg?.color}20`, borderRadius:6, border:`1px solid ${cfg?.color}50`,
                          display:"flex", alignItems:"center", paddingLeft:8, fontSize:11, color:cfg?.color,
                          overflow:"hidden" }}>
                          {task.progress}%
                        </div>
                      </div>
                      <span style={{ fontSize:11, color:DV.text4, width:80, textAlign:"right", flexShrink:0 }}>
                        {fmtDate(task.dueDate)}
                      </span>
                    </div>
                  );
                })
            }
          </div>
        )}

        {/* ── EDITAR ── */}
        {tab === "edit" && canEdit && (
          <div>
            <div style={{ background:"rgba(255,255,255,0.025)", border:`1px solid ${DV.border}`,
              borderRadius:16, padding:24, marginBottom:20 }}>
              <InitiativeForm
                initial={{
                  title:       ini.title,
                  description: ini.description,
                  status:      ini.status,
                  priority:    ini.priority,
                  category:    ini.category,
                  leaderId:    ini.leaderId,
                  startDate:   ini.startDate?.toDate?.()?.toISOString()?.split("T")[0] ?? "",
                  dueDate:     ini.dueDate?.toDate?.()?.toISOString()?.split("T")[0]   ?? "",
                  budget:      ini.budget,
                }}
                onSubmit={async d => {
                  await updateInitiative(id, d, user?.id);
                  toast.success("Iniciativa actualizada");
                  setTab("board");
                }}
                onCancel={() => setTab("board")}
                submitLabel="Guardar cambios"
              />
            </div>
            {isAdmin && (
              <div style={{ background:"rgba(248,113,113,0.05)", border:"1px solid rgba(248,113,113,0.2)",
                borderRadius:12, padding:16 }}>
                <div style={{ fontSize:13, fontWeight:600, color:"#F87171", marginBottom:8 }}>Zona de peligro</div>
                {!delConf
                  ? <Button variant="danger" onClick={()=>setDelConf(true)}>Eliminar iniciativa</Button>
                  : <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                      <span style={{ fontSize:12, color:"#F87171" }}>¿Confirmar?</span>
                      <Button variant="danger" onClick={async()=>{
                        await deleteInitiative(id, user?.id);
                        toast.success("Eliminada");
                        router.push("/dashboard/initiatives");
                      }}>Sí, eliminar</Button>
                      <Button variant="ghost" onClick={()=>setDelConf(false)}>Cancelar</Button>
                    </div>
                }
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── MODAL TAREA ── */}
      {taskModal.open && (
        <Modal
          title={taskModal.editing ? "Editar tarea" : taskModal.parentId ? "Nueva subtarea" : "Nueva tarea"}
          onClose={() => setTM({ open:false })}
          width={560}
        >
          <TaskForm
            initiativeMembers={ini.members}
            memberRoles={ini.memberRoles}
            parentTaskId={taskModal.parentId}
            initial={taskModal.editing ? {
              title:          taskModal.editing.title,
              description:    taskModal.editing.description,
              assigneeId:     taskModal.editing.assigneeId,
              status:         taskModal.editing.status,
              priority:       taskModal.editing.priority,
              progress:       taskModal.editing.progress,
              estimatedHours: taskModal.editing.estimatedHours,
              dueDate:        taskModal.editing.dueDate?.toDate?.()?.toISOString()?.split("T")[0],
            } : undefined}
            onSubmit={taskModal.editing ? handleEditTask : handleCreateTask}
            onCancel={() => setTM({ open:false })}
            submitLabel={taskModal.editing ? "Guardar cambios" : "Crear tarea"}
          />
        </Modal>
      )}

      {/* ── MODAL COMENTARIOS + ADJUNTOS ── */}
      {commentModal.open && (
        <Modal
          title={`💬 ${commentModal.taskTitle}`}
          onClose={() => setCM({ open:false, taskId:null, taskTitle:"" })}
          width={620}
        >
          <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
            <TaskAttachments iniId={id} taskId={commentModal.taskId} />
            <div style={{ borderTop:`1px solid ${DV.border}`, paddingTop:20 }}>
              <TaskComments iniId={id} taskId={commentModal.taskId} />
            </div>
          </div>
        </Modal>
      )}

      {/* ── MODAL HORAS ── */}
      {logModal.open && (
        <Modal title="Registrar horas" onClose={() => setLM({ open:false })} width={360}>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <label>Horas trabajadas</label>
            <input type="number" value={hoursInput} onChange={e=>setHours(e.target.value)}
              placeholder="Ej: 2.5" min="0" step="0.5" autoFocus />
            <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
              <Button variant="ghost" onClick={()=>setLM({ open:false })}>Cancelar</Button>
              <Button variant="brand"
                onClick={handleLogHours}
                disabled={!hoursInput || isNaN(parseFloat(hoursInput))}>
                Registrar
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
