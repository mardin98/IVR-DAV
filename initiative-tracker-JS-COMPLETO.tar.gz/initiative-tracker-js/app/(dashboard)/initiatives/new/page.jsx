"use client";
import { useRouter } from "next/navigation";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import InitiativeForm from "@/components/initiatives/InitiativeForm";
import { createDriveFolder, createCalendarEvent } from "@/lib/integrations/googleWorkspace";
import { updateInitiative } from "@/lib/firestore/initiatives";
import { getAllUsers } from "@/lib/firestore/users";
import toast from "react-hot-toast";

export default function NewInitiativePage() {
  const { create } = useInitiatives();
  const { user, isLeader } = useAuth();
  const router = useRouter();

  if (!isLeader) return (
    <div style={{ textAlign:"center", padding:60, color:"#475569" }}>
      No tienes permisos para crear iniciativas.
    </div>
  );

  const handleSubmit = async (data) => {
    const initiative = await create(data);
    toast.success(`${initiative.code} creada correctamente`);

    try {
      const users  = await getAllUsers();
      const leader = users.find(u => u.id === initiative.leaderId);
      await Promise.allSettled([
        createDriveFolder(initiative.id, initiative.code, initiative.title),
        leader ? createCalendarEvent(initiative.id, initiative.title, data.dueDate, leader.email) : Promise.resolve(null),
      ]).then(([folder]) => {
        if (folder.status === "fulfilled") toast.success("📁 Carpeta Drive creada");
      });
    } catch { /* non-blocking */ }

    router.push(`/dashboard/initiatives/${initiative.id}`);
  };

  return (
    <div style={{ maxWidth:680, margin:"0 auto" }}>
      <div style={{ marginBottom:24 }}>
        <div style={{ fontSize:12, color:"#334155", marginBottom:4 }}>
          AI & Automations › <a href="/dashboard/initiatives" style={{ color:"#475569", textDecoration:"none" }}>Iniciativas</a> › <span style={{ color:"#22d3ee" }}>Nueva</span>
        </div>
        <h1 style={{ fontSize:22, fontWeight:800, color:"#f1f5f9" }}>Nueva iniciativa</h1>
      </div>
      <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:18, padding:28 }}>
        <InitiativeForm
          onSubmit={handleSubmit}
          onCancel={() => router.push("/dashboard/initiatives")}
          submitLabel="Crear iniciativa"
        />
      </div>
    </div>
  );
}
