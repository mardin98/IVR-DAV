"use client";
import { useEffect, useState } from "react";
import {
  collection, doc, setDoc, updateDoc, deleteDoc,
  onSnapshot, serverTimestamp, query, orderBy,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/hooks/useAuth";
import { Avatar, RoleBadge, Button, Spinner } from "@/components/ui";
import toast from "react-hot-toast";

const ROLES = [
  { value:"admin",       label:"Admin"       },
  { value:"leader",      label:"Líder"       },
  { value:"responsible", label:"Responsable" },
];

const EMPTY_FORM = { name:"", email:"", globalRole:"responsible" };

export default function AdminPage() {
  const { user: currentUser, isAdmin } = useAuth();
  const [authorized, setAuthorized] = useState([]);
  const [users,      setUsers]      = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [form,       setForm]       = useState(EMPTY_FORM);
  const [adding,     setAdding]     = useState(false);
  const [showForm,   setShowForm]   = useState(false);

  // Suscripción en tiempo real a authorizedUsers
  useEffect(() => {
    if (!isAdmin) return;
    const unsub = onSnapshot(
      query(collection(db, "authorizedUsers")),
      snap => {
        setAuthorized(snap.docs.map(d => ({ id:d.id, ...d.data() })));
        setLoading(false);
      }
    );
    return unsub;
  }, [isAdmin]);

  // Suscripción a users (perfiles creados)
  useEffect(() => {
    if (!isAdmin) return;
    const unsub = onSnapshot(
      query(collection(db, "users")),
      snap => setUsers(snap.docs.map(d => ({ id:d.id, ...d.data() })))
    );
    return unsub;
  }, [isAdmin]);

  if (!isAdmin) return (
    <div style={{ textAlign:"center", padding:60, color:"#475569", fontSize:14 }}>
      Acceso restringido — solo administradores.
    </div>
  );

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:300 }}>
      <Spinner size={28} />
    </div>
  );

  const handleAdd = async () => {
    if (!form.email || !form.name) return;
    if (!form.email.endsWith("@davivienda.com.sv")) {
      toast.error("El email debe ser @davivienda.com.sv");
      return;
    }
    if (authorized.find(a => a.id === form.email)) {
      toast.error("Este email ya está autorizado");
      return;
    }
    setAdding(true);
    try {
      await setDoc(doc(db, "authorizedUsers", form.email), {
        name:       form.name,
        email:      form.email,
        globalRole: form.globalRole,
        active:     true,
        addedBy:    currentUser.id,
        createdAt:  serverTimestamp(),
      });
      toast.success(`${form.email} autorizado correctamente`);
      setForm(EMPTY_FORM);
      setShowForm(false);
    } catch (e) {
      toast.error("Error al agregar usuario");
    } finally {
      setAdding(false);
    }
  };

  const handleRoleChange = async (email, role) => {
    await updateDoc(doc(db, "authorizedUsers", email), { globalRole: role });
    // Si el usuario ya tiene perfil, actualizar también ahí
    const userProfile = users.find(u => u.email === email);
    if (userProfile) {
      await updateDoc(doc(db, "users", userProfile.id), { globalRole: role });
    }
    toast.success("Rol actualizado");
  };

  const handleToggleActive = async (email, currentActive) => {
    await updateDoc(doc(db, "authorizedUsers", email), { active: !currentActive });
    toast.success(currentActive ? "Usuario desactivado" : "Usuario reactivado");
  };

  const handleRemove = async (email) => {
    if (!confirm(`¿Eliminar acceso de ${email}? Podrás volver a agregarlo después.`)) return;
    await deleteDoc(doc(db, "authorizedUsers", email));
    toast.success("Acceso revocado");
  };

  const set = (k, v) => setForm(p => ({ ...p, [k]:v }));

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div>
          <div style={{ fontSize:12, color:"#334155", marginBottom:4 }}>
            AI & Automations › <span style={{ color:"#22d3ee" }}>Admin</span>
          </div>
          <h1 style={{ fontSize:22, fontWeight:800, color:"#f1f5f9" }}>Administración</h1>
        </div>
        <Button variant="primary" onClick={() => setShowForm(p => !p)}>
          {showForm ? "Cancelar" : "+ Autorizar usuario"}
        </Button>
      </div>

      {/* Formulario para agregar */}
      {showForm && (
        <div style={{ background:"rgba(34,211,238,0.05)", border:"1px solid rgba(34,211,238,0.2)",
          borderRadius:16, padding:24 }}>
          <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:16 }}>
            Autorizar nuevo usuario
          </h3>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 180px auto", gap:12, alignItems:"end" }}>
            <div>
              <label>Nombre completo</label>
              <input value={form.name} onChange={e => set("name", e.target.value)}
                placeholder="Ej: Ana Reyes" />
            </div>
            <div>
              <label>Email corporativo</label>
              <input value={form.email} onChange={e => set("email", e.target.value.toLowerCase())}
                placeholder="areyes@davivienda.com.sv" type="email" />
            </div>
            <div>
              <label>Rol</label>
              <select value={form.globalRole} onChange={e => set("globalRole", e.target.value)}>
                {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </div>
            <Button variant="primary" onClick={handleAdd} disabled={adding || !form.email || !form.name}>
              {adding ? "Guardando…" : "Autorizar"}
            </Button>
          </div>
          <p style={{ fontSize:11, color:"#475569", marginTop:10 }}>
            El usuario podrá ingresar la próxima vez que intente hacer login con esa cuenta Google.
          </p>
        </div>
      )}

      {/* Lista de usuarios autorizados */}
      <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)",
        borderRadius:16, overflow:"hidden" }}>
        <div style={{ padding:"14px 20px", borderBottom:"1px solid rgba(255,255,255,0.07)",
          display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <span style={{ fontSize:13, fontWeight:700, color:"#e2e8f0" }}>
            Usuarios autorizados ({authorized.length})
          </span>
          <span style={{ fontSize:12, color:"#475569" }}>
            {authorized.filter(a => a.active).length} activos ·{" "}
            {authorized.filter(a => !a.active).length} inactivos
          </span>
        </div>

        {/* Cabecera tabla */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 160px 200px 120px",
          gap:12, padding:"10px 20px",
          fontSize:11, fontWeight:700, color:"#334155",
          textTransform:"uppercase", letterSpacing:"0.07em",
          borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
          <span>Usuario</span>
          <span>Rol actual</span>
          <span>Cambiar rol</span>
          <span>Acciones</span>
        </div>

        {authorized.length === 0 && (
          <div style={{ padding:40, textAlign:"center", color:"#334155", fontSize:14 }}>
            No hay usuarios autorizados aún.
          </div>
        )}

        {authorized.map((a, i) => {
          const hasProfile = users.find(u => u.email === a.email);
          const isCurrentUser = currentUser?.email === a.email;
          return (
            <div key={a.id} style={{
              display:"grid", gridTemplateColumns:"1fr 160px 200px 120px",
              gap:12, padding:"12px 20px", alignItems:"center",
              borderBottom: i < authorized.length-1 ? "1px solid rgba(255,255,255,0.04)" : "none",
              background: !a.active ? "rgba(248,113,113,0.04)"
                : isCurrentUser ? "rgba(34,211,238,0.04)" : "none",
              opacity: a.active ? 1 : 0.6,
            }}>
              {/* Usuario */}
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                {hasProfile
                  ? <Avatar name={a.name} size={34} photoURL={hasProfile.photoURL} />
                  : <div style={{ width:34, height:34, borderRadius:"50%",
                      background:"rgba(100,116,139,0.2)", border:"1px dashed #475569",
                      display:"flex", alignItems:"center", justifyContent:"center",
                      fontSize:12, color:"#475569" }}>?</div>
                }
                <div>
                  <div style={{ fontSize:13, fontWeight:600, color:"#e2e8f0" }}>
                    {a.name}
                    {isCurrentUser && <span style={{ fontSize:11, color:"#22d3ee", marginLeft:6 }}>(tú)</span>}
                    {!a.active && <span style={{ fontSize:11, color:"#f87171", marginLeft:6 }}>inactivo</span>}
                  </div>
                  <div style={{ fontSize:11, color:"#475569" }}>{a.email}</div>
                  {!hasProfile && (
                    <div style={{ fontSize:10, color:"#64748b", fontStyle:"italic" }}>
                      Aún no ha ingresado al sistema
                    </div>
                  )}
                </div>
              </div>

              {/* Rol actual */}
              <RoleBadge role={a.globalRole} />

              {/* Cambiar rol */}
              <select value={a.globalRole}
                onChange={e => handleRoleChange(a.email, e.target.value)}
                disabled={isCurrentUser}
                style={{ padding:"6px 10px", fontSize:12,
                  opacity: isCurrentUser ? 0.4 : 1 }}>
                {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>

              {/* Acciones */}
              <div style={{ display:"flex", gap:6 }}>
                <Button size="sm" variant={a.active ? "secondary" : "primary"}
                  disabled={isCurrentUser}
                  onClick={() => handleToggleActive(a.email, a.active)}>
                  {a.active ? "Desactivar" : "Reactivar"}
                </Button>
                {!isCurrentUser && (
                  <Button size="sm" variant="danger"
                    onClick={() => handleRemove(a.email)}>
                    ✕
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Info del sistema */}
      <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)",
        borderRadius:16, padding:"18px 22px" }}>
        <div style={{ fontSize:13, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>
          Información del sistema
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, fontSize:13 }}>
          {[
            ["Stack","Next.js 14 + Firebase (JS)"],
            ["Base de datos","Cloud Firestore"],
            ["Auth","Google OAuth — lista blanca por email"],
            ["Hosting","Firebase Hosting"],
            ["Functions","Cloud Functions Gen2"],
            ["Integraciones","Google Drive + Calendar"],
          ].map(([k,v]) => (
            <div key={k} style={{ display:"flex", gap:8 }}>
              <span style={{ color:"#475569", minWidth:110 }}>{k}:</span>
              <span style={{ color:"#94a3b8" }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
