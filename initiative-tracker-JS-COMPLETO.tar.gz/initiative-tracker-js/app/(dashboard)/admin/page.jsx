"use client";
import { useEffect, useState } from "react";
import { collection, doc, setDoc, updateDoc, deleteDoc, onSnapshot, query, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/hooks/useAuth";
import { Avatar, RoleBadge, Button, Spinner } from "@/components/ui";
import toast from "react-hot-toast";
const ROLES=[{value:"admin",label:"Admin"},{value:"leader",label:"Líder"},{value:"responsible",label:"Responsable"}];
const EMPTY={name:"",email:"",globalRole:"responsible"};
export default function AdminPage() {
  const { user: me, isAdmin } = useAuth();
  const [authorized,setAuth] = useState([]);
  const [users,setUsers]     = useState([]);
  const [loading,setLoading] = useState(true);
  const [form,setForm]       = useState(EMPTY);
  const [adding,setAdding]   = useState(false);
  const [showForm,setShow]   = useState(false);
  useEffect(()=>{ if(!isAdmin) return; const u=onSnapshot(query(collection(db,"authorizedUsers")),s=>{setAuth(s.docs.map(d=>({id:d.id,...d.data()})));setLoading(false);}); return u; },[isAdmin]);
  useEffect(()=>{ if(!isAdmin) return; return onSnapshot(query(collection(db,"users")),s=>setUsers(s.docs.map(d=>({id:d.id,...d.data()})))); },[isAdmin]);
  if(!isAdmin) return <div style={{textAlign:"center",padding:60,color:"#475569",fontSize:14}}>Acceso restringido — solo administradores.</div>;
  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;
  const set=(k,v)=>setForm(p=>({...p,[k]:v}));
  const handleAdd=async()=>{
    if(!form.email||!form.name) return;
    if(!form.email.endsWith("@davivienda.com.sv")){toast.error("Email debe ser @davivienda.com.sv");return;}
    if(authorized.find(a=>a.id===form.email)){toast.error("Email ya autorizado");return;}
    setAdding(true);
    try{
      await setDoc(doc(db,"authorizedUsers",form.email),{name:form.name,email:form.email,globalRole:form.globalRole,active:true,addedBy:me.id,createdAt:serverTimestamp()});
      toast.success(`${form.email} autorizado`); setForm(EMPTY); setShow(false);
    }catch{toast.error("Error al agregar");}finally{setAdding(false);}
  };
  const handleRole=async(email,role)=>{
    await updateDoc(doc(db,"authorizedUsers",email),{globalRole:role});
    const up=users.find(u=>u.email===email);
    if(up) await updateDoc(doc(db,"users",up.id),{globalRole:role});
    toast.success("Rol actualizado");
  };
  const handleToggle=async(email,active)=>{ await updateDoc(doc(db,"authorizedUsers",email),{active:!active}); toast.success(active?"Desactivado":"Reactivado"); };
  const handleRemove=async(email)=>{ if(!confirm(`¿Eliminar acceso de ${email}?`)) return; await deleteDoc(doc(db,"authorizedUsers",email)); toast.success("Acceso revocado"); };
  return <div style={{display:"flex",flexDirection:"column",gap:24}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div><div style={{fontSize:12,color:"#334155",marginBottom:4}}>AI & Automations › <span style={{color:"#22d3ee"}}>Admin</span></div><h1 style={{fontSize:22,fontWeight:800,color:"#f1f5f9"}}>Administración</h1></div>
      <Button variant="primary" onClick={()=>setShow(p=>!p)}>{showForm?"Cancelar":"+ Autorizar usuario"}</Button>
    </div>
    {showForm&&<div style={{background:"rgba(34,211,238,0.05)",border:"1px solid rgba(34,211,238,0.2)",borderRadius:16,padding:24}}>
      <h3 style={{fontSize:14,fontWeight:700,color:"#e2e8f0",marginBottom:16}}>Autorizar nuevo usuario</h3>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 180px auto",gap:12,alignItems:"end"}}>
        <div><label>Nombre completo</label><input value={form.name} onChange={e=>set("name",e.target.value)} placeholder="Ej: Ana Reyes"/></div>
        <div><label>Email corporativo</label><input value={form.email} onChange={e=>set("email",e.target.value.toLowerCase())} placeholder="areyes@davivienda.com.sv" type="email"/></div>
        <div><label>Rol</label><select value={form.globalRole} onChange={e=>set("globalRole",e.target.value)}>{ROLES.map(r=><option key={r.value} value={r.value}>{r.label}</option>)}</select></div>
        <Button variant="primary" onClick={handleAdd} disabled={adding||!form.email||!form.name}>{adding?"Guardando…":"Autorizar"}</Button>
      </div>
      <p style={{fontSize:11,color:"#475569",marginTop:10}}>El usuario podrá ingresar la próxima vez que haga login con esa cuenta Google.</p>
    </div>}
    <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,overflow:"hidden"}}>
      <div style={{padding:"14px 20px",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",justifyContent:"space-between"}}>
        <span style={{fontSize:13,fontWeight:700,color:"#e2e8f0"}}>Usuarios autorizados ({authorized.length})</span>
        <span style={{fontSize:12,color:"#475569"}}>{authorized.filter(a=>a.active).length} activos</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 160px 200px 140px",gap:12,padding:"10px 20px",fontSize:11,fontWeight:700,color:"#334155",textTransform:"uppercase",letterSpacing:"0.07em",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
        <span>Usuario</span><span>Rol</span><span>Cambiar rol</span><span>Acciones</span>
      </div>
      {authorized.length===0&&<div style={{padding:40,textAlign:"center",color:"#334155",fontSize:14}}>No hay usuarios aún.</div>}
      {authorized.map((a,i)=>{
        const hasP=users.find(u=>u.email===a.email);
        const isMe=me?.email===a.email;
        return <div key={a.id} style={{display:"grid",gridTemplateColumns:"1fr 160px 200px 140px",gap:12,padding:"12px 20px",alignItems:"center",borderBottom:i<authorized.length-1?"1px solid rgba(255,255,255,0.04)":"none",background:!a.active?"rgba(248,113,113,0.04)":isMe?"rgba(34,211,238,0.04)":"none",opacity:a.active?1:0.6}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            {hasP?<Avatar name={a.name} size={34} photoURL={hasP.photoURL}/>:<div style={{width:34,height:34,borderRadius:"50%",background:"rgba(100,116,139,0.2)",border:"1px dashed #475569",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,color:"#475569"}}>?</div>}
            <div>
              <div style={{fontSize:13,fontWeight:600,color:"#e2e8f0"}}>{a.name}{isMe&&<span style={{fontSize:11,color:"#22d3ee",marginLeft:6}}>(tú)</span>}{!a.active&&<span style={{fontSize:11,color:"#f87171",marginLeft:6}}>inactivo</span>}</div>
              <div style={{fontSize:11,color:"#475569"}}>{a.email}</div>
              {!hasP&&<div style={{fontSize:10,color:"#64748b",fontStyle:"italic"}}>Aún no ha ingresado</div>}
            </div>
          </div>
          <RoleBadge role={a.globalRole}/>
          <select value={a.globalRole} onChange={e=>handleRole(a.email,e.target.value)} disabled={isMe} style={{padding:"6px 10px",fontSize:12,opacity:isMe?0.4:1}}>
            {ROLES.map(r=><option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
          <div style={{display:"flex",gap:6}}>
            <Button size="sm" variant={a.active?"secondary":"primary"} disabled={isMe} onClick={()=>handleToggle(a.email,a.active)}>{a.active?"Desactivar":"Reactivar"}</Button>
            {!isMe&&<Button size="sm" variant="danger" onClick={()=>handleRemove(a.email)}>✕</Button>}
          </div>
        </div>;
      })}
    </div>
  </div>;
}
