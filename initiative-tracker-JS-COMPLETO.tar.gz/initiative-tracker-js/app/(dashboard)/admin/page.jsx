"use client";
import { useEffect, useState } from "react";
import { getAllUsers, updateUserRole, deactivateUser } from "@/lib/firestore/users";
import { useAuth } from "@/lib/hooks/useAuth";
import { Avatar, RoleBadge, Button, Spinner } from "@/components/ui";
import toast from "react-hot-toast";

const ROLES = [
  { value: "admin",       label: "Admin"       },
  { value: "leader",      label: "Líder"       },
  { value: "responsible", label: "Responsable" },
];

export default function AdminPage() {
  const { user: currentUser, isAdmin } = useAuth();
  const [users, setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAllUsers().then(u => { setUsers(u); setLoading(false); });
  }, []);

  if (!isAdmin) return (
    <div style={{ textAlign:"center", padding:60, color:"#475569", fontSize:14 }}>
      Acceso restringido — solo administradores.
    </div>
  );

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:300 }}>
      <Spinner size={28} />
    </div>
  );

  const handleRoleChange = async (uid, role) => {
    await updateUserRole(uid, role);
    setUsers(prev => prev.map(u => u.id === uid ? { ...u, globalRole: role } : u));
    toast.success("Rol actualizado");
  };

  const handleDeactivate = async (uid, name) => {
    if (!confirm(`¿Desactivar a ${name}?`)) return;
    await deactivateUser(uid);
    setUsers(prev => prev.filter(u => u.id !== uid));
    toast.success("Usuario desactivado");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <div>
        <div style={{ fontSize:12, color:"#334155", marginBottom:4 }}>
          AI & Automations › <span style={{ color:"#22d3ee" }}>Admin</span>
        </div>
        <h1 style={{ fontSize:22, fontWeight:800, color:"#f1f5f9" }}>Administración</h1>
      </div>

      <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, overflow:"hidden" }}>
        <div style={{ padding:"14px 20px", borderBottom:"1px solid rgba(255,255,255,0.07)", display:"flex", justifyContent:"space-between" }}>
          <span style={{ fontSize:13, fontWeight:700, color:"#e2e8f0" }}>Usuarios ({users.length})</span>
          <span style={{ fontSize:12, color:"#475569" }}>Nuevos usuarios se crean en el primer login</span>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 160px 180px auto", gap:12, padding:"10px 20px",
          fontSize:11, fontWeight:700, color:"#334155", textTransform:"uppercase", letterSpacing:"0.07em",
          borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
          <span>Usuario</span><span>Rol global</span><span>Cambiar rol</span><span>Acciones</span>
        </div>
        {users.map((u, i) => (
          <div key={u.id} style={{ display:"grid", gridTemplateColumns:"1fr 160px 180px auto", gap:12,
            padding:"12px 20px", alignItems:"center",
            borderBottom: i < users.length-1 ? "1px solid rgba(255,255,255,0.04)" : "none",
            background: u.id === currentUser?.id ? "rgba(34,211,238,0.04)" : "none" }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <Avatar name={u.name} size={34} photoURL={u.photoURL} />
              <div>
                <div style={{ fontSize:13, fontWeight:600, color:"#e2e8f0" }}>
                  {u.name} {u.id === currentUser?.id && <span style={{ fontSize:11, color:"#22d3ee" }}>(tú)</span>}
                </div>
                <div style={{ fontSize:11, color:"#475569" }}>{u.email}</div>
              </div>
            </div>
            <RoleBadge role={u.globalRole} />
            <select value={u.globalRole} onChange={e => handleRoleChange(u.id, e.target.value)}
              disabled={u.id === currentUser?.id}
              style={{ padding:"6px 10px", fontSize:12, opacity: u.id === currentUser?.id ? 0.4 : 1 }}>
              {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
            <Button size="sm" variant="danger" disabled={u.id === currentUser?.id}
              onClick={() => handleDeactivate(u.id, u.name)}>
              Desactivar
            </Button>
          </div>
        ))}
      </div>

      <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"20px 22px" }}>
        <div style={{ fontSize:13, fontWeight:700, color:"#e2e8f0", marginBottom:14 }}>Información del sistema</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, fontSize:13 }}>
          {[["Stack","Next.js 14 + Firebase"],["Base de datos","Cloud Firestore"],
            ["Auth","Google OAuth (davivienda.com.sv)"],["Hosting","Firebase Hosting"],
            ["Functions","Cloud Functions Gen2"],["Integraciones","Google Drive + Calendar"]
          ].map(([k,v]) => (
            <div key={k} style={{ display:"flex", gap:8 }}>
              <span style={{ color:"#475569", minWidth:110 }}>{k}:</span>
              <span style={{ color:"#94a3b8" }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
