"use client";
import { useEffect, useState } from "react";
import { getAllUsers } from "@/lib/firestore/users";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { Avatar, RoleBadge, Spinner } from "@/components/ui";
export default function TeamPage() {
  const [users,setUsers]     = useState([]);
  const [loadU,setLoadU]     = useState(true);
  const { initiatives, loading } = useInitiatives();
  useEffect(()=>{ getAllUsers().then(u=>{setUsers(u);setLoadU(false);}); },[]);
  if(loadU||loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:300}}><Spinner size={28}/></div>;
  return <div style={{display:"flex",flexDirection:"column",gap:24}}>
    <div><div style={{fontSize:12,color:"#334155",marginBottom:4}}>AI & Automations › <span style={{color:"#22d3ee"}}>Equipo</span></div><h1 style={{fontSize:22,fontWeight:800,color:"#f1f5f9"}}>Equipo</h1></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:14}}>
      {users.map(u=>{
        const uis=initiatives.filter(i=>i.members.includes(u.id));
        const leading=initiatives.filter(i=>i.leaderId===u.id&&i.status==="active");
        return <div key={u.id} style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:20}}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
            <Avatar name={u.name} size={44} photoURL={u.photoURL}/>
            <div style={{flex:1}}>
              <div style={{fontSize:14,fontWeight:700,color:"#f1f5f9"}}>{u.name}</div>
              <div style={{fontSize:11,color:"#475569",marginBottom:4}}>{u.email}</div>
              <RoleBadge role={u.globalRole}/>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
            {[{l:"Iniciativas",v:uis.length,c:"#22d3ee"},{l:"Lidera",v:leading.length,c:"#a78bfa"}].map((s,i)=>(
              <div key={i} style={{background:"rgba(255,255,255,0.03)",borderRadius:10,padding:"10px 12px"}}>
                <div style={{fontSize:22,fontWeight:800,color:s.c,fontFamily:"monospace"}}>{s.v}</div>
                <div style={{fontSize:11,color:"#334155"}}>{s.l}</div>
              </div>
            ))}
          </div>
          {uis.length>0&&<div>
            <div style={{fontSize:10,color:"#334155",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:6}}>Iniciativas</div>
            {uis.slice(0,3).map(ini=><div key={ini.id} style={{display:"flex",alignItems:"center",gap:6,fontSize:11,marginBottom:3}}>
              <span style={{color:"#22d3ee",fontFamily:"monospace"}}>{ini.code}</span>
              <span style={{color:"#475569",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ini.title}</span>
              {ini.leaderId===u.id&&<span style={{color:"#a78bfa",flexShrink:0}}>líder</span>}
            </div>)}
            {uis.length>3&&<span style={{fontSize:11,color:"#334155"}}>+{uis.length-3} más</span>}
          </div>}
        </div>;
      })}
    </div>
  </div>;
}
