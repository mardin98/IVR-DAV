"use client";

import { useEffect, useState } from "react";
import { getAllUsers } from "@/lib/firestore/users";
import { useInitiatives } from "@/lib/hooks/useInitiatives";
import { useAuth } from "@/lib/hooks/useAuth";
import { Avatar, RoleBadge, SectionTitle, Spinner } from "@/components/ui";
import { CATEGORY_CONFIG } from "@/lib/utils";

export default function TeamPage() {
  const [users, setUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const { initiatives, loading: loadingIni } = useInitiatives();
  const { isAdmin } = useAuth();

  useEffect(() => {
    getAllUsers().then(u => { setUsers(u); setLoadingUsers(false); });
  }, []);

  if (loadingUsers || loadingIni) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300 }}>
      <Spinner size={28} />
    </div>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div>
        <div style={{ fontSize: 12, color: "#334155", marginBottom: 4 }}>AI & Automations › <span style={{ color: "#22d3ee" }}>Equipo</span></div>
        <h1 style={{ fontSize: 22, fontWeight: 800, color: "#f1f5f9" }}>Equipo</h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 14 }}>
        {users.map(user => {
          const userIni = initiatives.filter(i => i.members.includes(user.id));
          const leading = initiatives.filter(i => i.leaderId === user.id && i.status === "active");
          const allTasks = [];

          return (
            <div key={user.id} style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "20px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                <Avatar name={user.name} size={44} photoURL={user.photoURL} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#f1f5f9" }}>{user.name}</div>
                  <div style={{ fontSize: 11, color: "#475569", marginBottom: 4 }}>{user.email}</div>
                  <RoleBadge role={user.globalRole} />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
                {[
                  { label: "Iniciativas", value: userIni.length, color: "#22d3ee" },
                  { label: "Lidera", value: leading.length, color: "#a78bfa" },
                ].map((s, i) => (
                  <div key={i} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: "10px 12px" }}>
                    <div style={{ fontSize: 22, fontWeight: 800, color: s.color, fontFamily: "var(--font-space-mono, monospace)" }}>{s.value}</div>
                    <div style={{ fontSize: 11, color: "#334155" }}>{s.label}</div>
                  </div>
                ))}
              </div>

              {/* Initiatives preview */}
              {userIni.length > 0 && (
                <div>
                  <div style={{ fontSize: 10, color: "#334155", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Iniciativas</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                    {userIni.slice(0, 3).map(ini => {
                      const isLeader = ini.leaderId === user.id;
                      return (
                        <div key={ini.id} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11 }}>
                          <span style={{ color: "#22d3ee", fontFamily: "var(--font-space-mono, monospace)" }}>{ini.code}</span>
                          <span style={{ color: "#475569", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ini.title}</span>
                          {isLeader && <span style={{ color: "#a78bfa", flexShrink: 0 }}>líder</span>}
                        </div>
                      );
                    })}
                    {userIni.length > 3 && <span style={{ fontSize: 11, color: "#334155" }}>+{userIni.length - 3} más</span>}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
