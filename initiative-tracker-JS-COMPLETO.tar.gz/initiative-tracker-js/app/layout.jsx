import { AuthProvider } from "@/lib/hooks/useAuth";
import { Toaster } from "react-hot-toast";
import "./globals.css";
export const metadata = {
  title: "Initiative Tracker — Davivienda AI & Automations",
  description: "Sistema de gestión de iniciativas",
};
export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />
      </head>
      <body>
        <AuthProvider>
          {children}
          <Toaster position="bottom-right" toastOptions={{
            style: { background:"#0d1628", color:"#f1f5f9", border:"1px solid rgba(255,255,255,0.1)", fontFamily:"sans-serif", fontSize:"13px" },
            success: { iconTheme: { primary:"#4ade80", secondary:"#0d1628" } },
            error:   { iconTheme: { primary:"#f87171", secondary:"#0d1628" } },
          }} />
        </AuthProvider>
      </body>
    </html>
  );
}
