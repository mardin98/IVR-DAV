"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { collection, getDocs, query, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/hooks/useAuth";
import { DV } from "@/lib/utils";
import toast from "react-hot-toast";

export default function LoginPage() {
  const { user, loading, unauthorized, signInWithGoogle } = useAuth();
  const router = useRouter();
  const [isFirst,  setIsFirst]  = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    getDocs(query(collection(db,"authorizedUsers"),limit(1)))
      .then(s=>{ setIsFirst(s.empty); setChecking(false); })
      .catch(()=>setChecking(false));
  },[]);

  useEffect(() => { if(!loading&&user) router.replace("/dashboard"); },[user,loading,router]);

  const handleLogin = async () => {
    try { await signInWithGoogle(); }
    catch(e) { if(e?.code==="auth/popup-closed-by-user") return; toast.error("Error al iniciar sesión"); }
  };

  return (
    <div style={{minHeight:"100vh",background:DV.bg,display:"flex",fontFamily:"sans-serif",position:"relative",overflow:"hidden"}}>
      {/* Left panel — brand */}
      <div style={{width:"42%",background:`linear-gradient(160deg,${DV.redDeep} 0%,${DV.red} 50%,${DV.redDark} 100%)`,
        display:"flex",flexDirection:"column",justifyContent:"space-between",padding:"48px 40px",position:"relative",overflow:"hidden"}}>
        {/* Pattern overlay */}
        <div style={{position:"absolute",inset:0,opacity:0.06,
          backgroundImage:"radial-gradient(circle at 30% 20%,#fff 1px,transparent 1px),radial-gradient(circle at 70% 60%,#fff 1px,transparent 1px),radial-gradient(circle at 50% 80%,#fff 1px,transparent 1px)",
          backgroundSize:"60px 60px"}}/>
        <div style={{position:"relative",zIndex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:48}}>
            <div style={{width:40,height:40,background:"rgba(255,255,255,0.2)",borderRadius:10,
              display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,border:"1px solid rgba(255,255,255,0.3)"}}>◈</div>
            <span style={{fontSize:16,fontWeight:800,color:DV.white,letterSpacing:"-0.02em"}}>Davivienda</span>
          </div>
          <h1 style={{fontSize:36,fontWeight:900,color:DV.white,lineHeight:1.1,marginBottom:16,letterSpacing:"-0.02em"}}>
            Initiative<br/>Tracker
          </h1>
          <p style={{fontSize:14,color:"rgba(255,255,255,0.8)",lineHeight:1.7,maxWidth:260}}>
            Sistema de gestión de iniciativas del área de AI & Automations
          </p>
        </div>
        <div style={{position:"relative",zIndex:1}}>
          {[["◈","Iniciativas en tiempo real"],["▦","Tareas y subtareas"],["📊","Reportes automáticos"],["🔔","Notificaciones y emails"]].map(([icon,label])=>(
            <div key={label} style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
              <span style={{fontSize:14,width:24,textAlign:"center"}}>{icon}</span>
              <span style={{fontSize:13,color:"rgba(255,255,255,0.8)"}}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel — login */}
      <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",padding:48}}>
        <div style={{width:"100%",maxWidth:400}}>
          <div style={{marginBottom:40}}>
            <h2 style={{fontSize:26,fontWeight:800,color:DV.white,marginBottom:8}}>Bienvenido</h2>
            <p style={{fontSize:14,color:DV.text3}}>Accede con tu cuenta corporativa de Davivienda</p>
          </div>

          {!checking&&isFirst&&(
            <div style={{marginBottom:24,padding:"14px 16px",borderRadius:12,
              background:"rgba(227,6,19,0.08)",border:"1px solid rgba(227,6,19,0.25)"}}>
              <div style={{fontSize:13,fontWeight:700,color:DV.red,marginBottom:4}}>✦ Primera configuración</div>
              <div style={{fontSize:12,color:DV.text2,lineHeight:1.6}}>
                El sistema aún no tiene usuarios. La primera persona que ingrese será
                asignada automáticamente como <b style={{color:DV.white}}>Administrador</b>.
              </div>
            </div>
          )}

          {unauthorized&&(
            <div style={{marginBottom:24,padding:"14px 16px",borderRadius:12,
              background:"rgba(248,113,113,0.08)",border:"1px solid rgba(248,113,113,0.25)"}}>
              <div style={{fontSize:13,fontWeight:700,color:"#F87171",marginBottom:4}}>Acceso no autorizado</div>
              <div style={{fontSize:12,color:DV.text2,lineHeight:1.6}}>
                Tu cuenta no está en la lista de usuarios autorizados.
                Contacta al administrador del sistema.
              </div>
            </div>
          )}

          <div style={{background:DV.bg3,border:`1px solid ${DV.border}`,borderRadius:16,padding:28}}>
            <label style={{marginBottom:6}}>Email corporativo</label>
            <div style={{padding:"10px 14px",background:"rgba(255,255,255,0.04)",border:`1px solid ${DV.border}`,
              borderRadius:10,fontSize:13,color:DV.text3,marginBottom:24}}>
              @davivienda.com.sv
            </div>

            <button onClick={handleLogin} disabled={loading||checking}
              style={{width:"100%",padding:"13px 20px",
                background:loading||checking?"rgba(255,255,255,0.06)":DV.red,
                border:`1px solid ${loading||checking?DV.border:DV.redDark}`,
                borderRadius:12,cursor:(loading||checking)?"not-allowed":"pointer",
                display:"flex",alignItems:"center",justifyContent:"center",gap:12,
                color:DV.white,fontSize:14,fontWeight:700,fontFamily:"inherit",
                transition:"all 0.2s",opacity:(loading||checking)?0.6:1,
                boxShadow:loading||checking?"none":"0 4px 20px rgba(227,6,19,0.3)"}}
              onMouseEnter={e=>{if(!loading&&!checking){e.currentTarget.style.background=DV.redDark;e.currentTarget.style.transform="translateY(-1px)";}}}
              onMouseLeave={e=>{e.currentTarget.style.background=loading||checking?"rgba(255,255,255,0.06)":DV.red;e.currentTarget.style.transform="none";}}>
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              {checking?"Verificando…":loading?"Entrando…":"Continuar con Google"}
            </button>
          </div>

          <p style={{textAlign:"center",fontSize:12,color:DV.text4,marginTop:24}}>
            Acceso restringido · Solo personal autorizado · Davivienda El Salvador
          </p>
        </div>
      </div>
    </div>
  );
}
