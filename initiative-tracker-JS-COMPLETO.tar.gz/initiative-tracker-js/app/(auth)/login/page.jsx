"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { collection, getDocs, query, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/hooks/useAuth";
import toast from "react-hot-toast";
export default function LoginPage() {
  const { user, loading, unauthorized, signInWithGoogle } = useAuth();
  const router = useRouter();
  const [isFirst,setIsFirst]       = useState(false);
  const [checking,setChecking]     = useState(true);
  useEffect(() => {
    getDocs(query(collection(db,"authorizedUsers"),limit(1))).then(s=>{ setIsFirst(s.empty); setChecking(false); }).catch(()=>setChecking(false));
  },[]);
  useEffect(() => { if(!loading&&user) router.replace("/dashboard"); },[user,loading,router]);
  const handleLogin = async () => { try{ await signInWithGoogle(); }catch(e){ if(e?.code==="auth/popup-closed-by-user") return; toast.error("Error al iniciar sesión"); } };
  return <div style={{minHeight:"100vh",background:"#060b14",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"sans-serif",position:"relative",overflow:"hidden"}}>
    <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(rgba(34,211,238,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(34,211,238,0.03) 1px,transparent 1px)",backgroundSize:"40px 40px"}}/>
    <div style={{position:"absolute",top:"20%",left:"50%",transform:"translateX(-50%)",width:600,height:300,borderRadius:"50%",background:"radial-gradient(ellipse,rgba(34,211,238,0.08) 0%,transparent 70%)",pointerEvents:"none"}}/>
    <div style={{position:"relative",zIndex:10,width:"100%",maxWidth:440,padding:"0 24px"}}>
      <div style={{textAlign:"center",marginBottom:40}}>
        <div style={{width:56,height:56,borderRadius:16,margin:"0 auto 16px",background:"linear-gradient(135deg,#22d3ee,#a78bfa)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,boxShadow:"0 0 40px rgba(34,211,238,0.3)"}}>◈</div>
        <h1 style={{fontSize:26,fontWeight:800,color:"#f1f5f9",marginBottom:4}}>Initiative Tracker</h1>
        <p style={{fontSize:13,color:"#475569"}}>Davivienda · AI & Automations</p>
      </div>
      <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:20,padding:"28px 28px 32px",backdropFilter:"blur(12px)"}}>
        {!checking&&isFirst&&<div style={{marginBottom:20,padding:"14px 16px",borderRadius:12,background:"rgba(34,211,238,0.08)",border:"1px solid rgba(34,211,238,0.25)"}}>
          <div style={{fontSize:13,fontWeight:700,color:"#22d3ee",marginBottom:4}}>✦ Primera configuración</div>
          <div style={{fontSize:12,color:"#94a3b8",lineHeight:1.6}}>El sistema aún no tiene usuarios. La primera persona que ingrese será asignada automáticamente como <b style={{color:"#f1f5f9"}}>Administrador</b>.</div>
        </div>}
        {unauthorized&&<div style={{marginBottom:20,padding:"14px 16px",borderRadius:12,background:"rgba(248,113,113,0.08)",border:"1px solid rgba(248,113,113,0.25)"}}>
          <div style={{fontSize:13,fontWeight:700,color:"#f87171",marginBottom:4}}>Acceso no autorizado</div>
          <div style={{fontSize:12,color:"#94a3b8",lineHeight:1.6}}>Tu cuenta no está en la lista de usuarios autorizados. Contacta al administrador del sistema.</div>
        </div>}
        <h2 style={{fontSize:16,fontWeight:700,color:"#e2e8f0",marginBottom:6,textAlign:"center"}}>Acceso corporativo</h2>
        <p style={{fontSize:13,color:"#475569",textAlign:"center",marginBottom:24,lineHeight:1.6}}>Usa tu cuenta Google de Davivienda<br/><span style={{color:"#22d3ee"}}>@davivienda.com.sv</span></p>
        <button onClick={handleLogin} disabled={loading||checking} style={{width:"100%",padding:"13px 20px",background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.12)",borderRadius:12,cursor:(loading||checking)?"not-allowed":"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:12,color:"#f1f5f9",fontSize:14,fontWeight:600,fontFamily:"inherit",transition:"all 0.2s",opacity:(loading||checking)?0.6:1}}
          onMouseEnter={e=>{if(!loading){e.currentTarget.style.borderColor="rgba(34,211,238,0.4)";e.currentTarget.style.background="rgba(34,211,238,0.08)";}}}
          onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.12)";e.currentTarget.style.background="rgba(255,255,255,0.06)";}}>
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          {checking?"Verificando…":loading?"Entrando…":"Continuar con Google"}
        </button>
      </div>
      <p style={{textAlign:"center",fontSize:12,color:"#1e3a5f",marginTop:20}}>Acceso restringido · Solo personal autorizado</p>
    </div>
  </div>;
}
