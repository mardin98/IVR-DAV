"use client";
import { INITIATIVE_STATUS, TASK_STATUS, PRIORITY_CONFIG, CATEGORY_CONFIG, ROLE_CONFIG, progressColor } from "@/lib/utils";

export function Avatar({ name, size = 32, photoURL }) {
  const initials = name.split(" ").slice(0, 2).map(n => n[0]).join("").toUpperCase();
  const colors = ["#22d3ee","#a78bfa","#4ade80","#f59e0b","#f87171","#818cf8"];
  const color  = colors[name.charCodeAt(0) % colors.length];
  if (photoURL) return <img src={photoURL} alt={name} style={{ width:size, height:size, borderRadius:"50%", objectFit:"cover", flexShrink:0 }} />;
  return (
    <div style={{ width:size, height:size, borderRadius:"50%", background:`${color}22`, border:`1.5px solid ${color}44`,
      display:"flex", alignItems:"center", justifyContent:"center", fontSize:size*0.35, fontWeight:700, color, flexShrink:0 }}>
      {initials}
    </div>
  );
}

export function ProgressRing({ pct, size = 52, stroke = 4 }) {
  const r     = (size - stroke) / 2;
  const circ  = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const color  = progressColor(pct);
  return (
    <svg width={size} height={size} style={{ transform:"rotate(-90deg)", flexShrink:0 }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color}
        strokeWidth={stroke} strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round" style={{ transition:"stroke-dashoffset 0.6s ease" }} />
      <text x={size/2} y={size/2} textAnchor="middle" dominantBaseline="middle"
        style={{ transform:"rotate(90deg)", transformOrigin:"center", fill:"#f1f5f9", fontSize:size*0.22, fontWeight:700 }}>
        {pct}%
      </text>
    </svg>
  );
}

export function ProgressBar({ pct, height = 5, maxWidth }) {
  const color = progressColor(pct);
  return (
    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
      <div style={{ flex:1, height, background:"rgba(255,255,255,0.07)", borderRadius:height, maxWidth }}>
        <div style={{ height:"100%", width:`${pct}%`, borderRadius:height, background:color, transition:"width 0.5s" }} />
      </div>
      <span style={{ fontSize:12, color:"#94a3b8", minWidth:32 }}>{pct}%</span>
    </div>
  );
}

export function StatusBadge({ status }) {
  const cfg = INITIATIVE_STATUS[status];
  if (!cfg) return null;
  return <span style={{ padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600,
    color:cfg.color, background:cfg.bg, border:`1px solid ${cfg.color}30`, whiteSpace:"nowrap" }}>{cfg.label}</span>;
}

export function TaskStatusBadge({ status }) {
  const cfg = TASK_STATUS[status];
  if (!cfg) return null;
  return <span style={{ padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600,
    color:cfg.color, background:`${cfg.color}18`, border:`1px solid ${cfg.color}30`, whiteSpace:"nowrap" }}>{cfg.label}</span>;
}

export function PriorityBadge({ priority }) {
  const cfg = PRIORITY_CONFIG[priority];
  return <span style={{ color:cfg.color, fontSize:11, fontWeight:700, display:"inline-flex", alignItems:"center", gap:4 }}>
    <span style={{ width:6, height:6, borderRadius:"50%", background:cfg.color, display:"inline-block", flexShrink:0 }} />
    {cfg.label}
  </span>;
}

export function RoleBadge({ role }) {
  const cfg = ROLE_CONFIG[role];
  if (!cfg) return null;
  return <span style={{ padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:700,
    color:cfg.color, background:cfg.bg, whiteSpace:"nowrap" }}>{cfg.label}</span>;
}

export function CategoryChip({ category }) {
  const cfg = CATEGORY_CONFIG[category];
  if (!cfg) return null;
  return <span style={{ fontSize:11, color:"#64748b", display:"inline-flex", alignItems:"center", gap:4 }}>
    {cfg.icon} {cfg.label}
  </span>;
}

export function Card({ children, style = {} }) {
  return <div style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, ...style }}>
    {children}
  </div>;
}

export function SectionTitle({ children }) {
  return <h3 style={{ fontSize:12, fontWeight:700, color:"#64748b", letterSpacing:"0.1em",
    textTransform:"uppercase", marginBottom:14 }}>{children}</h3>;
}

export function Button({ children, onClick, variant = "secondary", disabled = false, style = {}, size = "md" }) {
  const base = {
    border:"none", borderRadius:10, cursor:disabled?"not-allowed":"pointer",
    fontFamily:"inherit", fontWeight:600, transition:"all 0.15s",
    display:"inline-flex", alignItems:"center", gap:6, opacity:disabled?0.5:1,
    padding: size==="sm" ? "6px 12px" : "9px 16px",
    fontSize: size==="sm" ? 12 : 13,
  };
  const variants = {
    primary:   { background:"rgba(34,211,238,0.15)",  border:"1px solid rgba(34,211,238,0.3)",  color:"#22d3ee" },
    secondary: { background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", color:"#94a3b8" },
    danger:    { background:"rgba(248,113,113,0.1)",  border:"1px solid rgba(248,113,113,0.3)", color:"#f87171" },
    ghost:     { background:"none", border:"1px solid transparent", color:"#64748b" },
  };
  return <button onClick={onClick} disabled={disabled} style={{ ...base, ...variants[variant], ...style }}>{children}</button>;
}

export function Modal({ title, onClose, children, width = 520 }) {
  return (
    <div style={{ position:"fixed", inset:0, zIndex:500, display:"flex", alignItems:"center", justifyContent:"center",
      padding:24, background:"rgba(0,0,0,0.7)", backdropFilter:"blur(4px)" }} onClick={onClose}>
      <div style={{ background:"#0d1628", border:"1px solid rgba(255,255,255,0.1)", borderRadius:20,
        width:"100%", maxWidth:width, boxShadow:"0 24px 80px rgba(0,0,0,0.6)", maxHeight:"90vh", overflow:"auto" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ padding:"20px 24px", borderBottom:"1px solid rgba(255,255,255,0.07)",
          display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <h2 style={{ fontSize:16, fontWeight:700, color:"#f1f5f9" }}>{title}</h2>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"#475569",
            cursor:"pointer", fontSize:18, lineHeight:1, fontFamily:"inherit" }}>✕</button>
        </div>
        <div style={{ padding:"20px 24px" }}>{children}</div>
      </div>
    </div>
  );
}

export function Spinner({ size = 24 }) {
  return <div style={{ width:size, height:size, borderRadius:"50%",
    border:`2px solid rgba(34,211,238,0.2)`, borderTopColor:"#22d3ee",
    animation:"spin 0.8s linear infinite" }} />;
}

export function MetaItem({ label, children }) {
  return (
    <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, padding:"12px 14px" }}>
      <div style={{ fontSize:10, color:"#475569", marginBottom:5, textTransform:"uppercase", letterSpacing:"0.08em" }}>{label}</div>
      <div style={{ fontSize:13, fontWeight:600, color:"#f1f5f9", display:"flex", alignItems:"center", gap:6 }}>{children}</div>
    </div>
  );
}

export function EmptyState({ icon, title, sub, action }) {
  return (
    <div style={{ textAlign:"center", padding:"48px 24px", color:"#334155" }}>
      <div style={{ fontSize:40, marginBottom:12 }}>{icon}</div>
      <div style={{ fontSize:15, fontWeight:600, color:"#475569", marginBottom:4 }}>{title}</div>
      {sub && <div style={{ fontSize:13, marginBottom:16 }}>{sub}</div>}
      {action}
    </div>
  );
}
