"use client";
import { INIT_STATUS, TASK_STATUS, PRIORITY, CATEGORY, ROLES, progColor, DV } from "@/lib/utils";

export function Avatar({ name, size=32, photoURL }) {
  const i = name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  // Davivienda-toned avatar colors
  const colors = [DV.red, DV.purple, DV.cyan, DV.yellow, DV.orange, DV.green];
  const c = colors[name.charCodeAt(0)%colors.length];
  if(photoURL) return <img src={photoURL} alt={name} style={{width:size,height:size,borderRadius:"50%",objectFit:"cover",flexShrink:0}}/>;
  return <div style={{width:size,height:size,borderRadius:"50%",background:`${c}18`,border:`1.5px solid ${c}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.36,fontWeight:700,color:c,flexShrink:0}}>{i}</div>;
}

export function ProgressRing({ pct, size=52, stroke=4 }) {
  const r=((size-stroke)/2), circ=2*Math.PI*r, offset=circ-(pct/100)*circ, color=progColor(pct);
  return <svg width={size} height={size} style={{transform:"rotate(-90deg)",flexShrink:0}}>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke}/>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
      strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
      style={{transition:"stroke-dashoffset 0.6s"}}/>
    <text x={size/2} y={size/2} textAnchor="middle" dominantBaseline="middle"
      style={{transform:"rotate(90deg)",transformOrigin:"center",fill:DV.white,fontSize:size*0.22,fontWeight:700}}>
      {pct}%
    </text>
  </svg>;
}

export function ProgressBar({ pct, height=5, maxWidth }) {
  return <div style={{display:"flex",alignItems:"center",gap:8}}>
    <div style={{flex:1,height,background:"rgba(255,255,255,0.07)",borderRadius:height,maxWidth}}>
      <div style={{height:"100%",width:`${pct}%`,borderRadius:height,background:progColor(pct),transition:"width 0.5s"}}/>
    </div>
    <span style={{fontSize:12,color:DV.text3,minWidth:32}}>{pct}%</span>
  </div>;
}

export function StatusBadge({ status }) {
  const c=INIT_STATUS[status]; if(!c) return null;
  return <span style={{padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700,
    color:c.color,background:c.bg,border:`1px solid ${c.color}30`,whiteSpace:"nowrap"}}>{c.label}</span>;
}

export function TaskStatusBadge({ status }) {
  const c=TASK_STATUS[status]; if(!c) return null;
  return <span style={{padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700,
    color:c.color,background:`${c.color}15`,border:`1px solid ${c.color}30`,whiteSpace:"nowrap"}}>{c.label}</span>;
}

export function PriorityBadge({ priority }) {
  const c=PRIORITY[priority]; if(!c) return null;
  return <span style={{color:c.color,fontSize:11,fontWeight:700,display:"inline-flex",alignItems:"center",gap:4}}>
    <span style={{width:6,height:6,borderRadius:"50%",background:c.color,display:"inline-block",flexShrink:0}}/>
    {c.label}
  </span>;
}

export function RoleBadge({ role }) {
  const c=ROLES[role]; if(!c) return null;
  return <span style={{padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700,
    color:c.color,background:c.bg,whiteSpace:"nowrap"}}>{c.label}</span>;
}

export function CategoryChip({ category }) {
  const c=CATEGORY[category]; if(!c) return null;
  return <span style={{fontSize:11,color:DV.text3,display:"inline-flex",alignItems:"center",gap:4}}>
    {c.icon} {c.label}
  </span>;
}

export function Button({ children, onClick, variant="secondary", disabled=false, style={}, size="md" }) {
  const base = {
    border:"none",borderRadius:10,cursor:disabled?"not-allowed":"pointer",
    fontFamily:"inherit",fontWeight:600,transition:"all 0.15s",
    display:"inline-flex",alignItems:"center",gap:6,
    opacity:disabled?0.45:1,
    padding:size==="sm"?"5px 12px":"9px 16px",
    fontSize:size==="sm"?12:13,
  };
  const vars = {
    primary:   {background:DV.redBg,  border:`1px solid ${DV.redBd}`,  color:DV.white},
    secondary: {background:"rgba(255,255,255,0.06)", border:`1px solid ${DV.border}`, color:DV.text2},
    danger:    {background:"rgba(248,113,113,0.1)", border:"1px solid rgba(248,113,113,0.3)", color:"#F87171"},
    ghost:     {background:"none", border:"1px solid transparent", color:DV.text3},
    brand:     {background:DV.red, border:`1px solid ${DV.redDark}`, color:DV.white},
  };
  return <button onClick={onClick} disabled={disabled} style={{...base,...vars[variant],...style}}>
    {children}
  </button>;
}

export function Modal({ title, onClose, children, width=520 }) {
  return <div style={{position:"fixed",inset:0,zIndex:500,display:"flex",alignItems:"center",justifyContent:"center",
    padding:24,background:"rgba(0,0,0,0.75)",backdropFilter:"blur(6px)"}} onClick={onClose}>
    <div style={{background:DV.bg2,border:`1px solid rgba(227,6,19,0.15)`,borderRadius:20,
      width:"100%",maxWidth:width,boxShadow:"0 24px 80px rgba(0,0,0,0.7),0 0 40px rgba(227,6,19,0.05)",
      maxHeight:"90vh",overflow:"auto"}} onClick={e=>e.stopPropagation()}>
      <div style={{padding:"20px 24px",borderBottom:`1px solid ${DV.border}`,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        background:"linear-gradient(135deg,rgba(227,6,19,0.06),transparent)"}}>
        <h2 style={{fontSize:16,fontWeight:700,color:DV.white}}>{title}</h2>
        <button onClick={onClose} style={{background:"none",border:"none",color:DV.text3,
          cursor:"pointer",fontSize:18,fontFamily:"inherit",lineHeight:1}}>✕</button>
      </div>
      <div style={{padding:"20px 24px"}}>{children}</div>
    </div>
  </div>;
}

export function Spinner({ size=24 }) {
  return <div style={{width:size,height:size,borderRadius:"50%",
    border:`2px solid rgba(227,6,19,0.2)`,borderTopColor:DV.red,
    animation:"spin 0.8s linear infinite"}}/>;
}

export function MetaItem({ label, children }) {
  return <div style={{background:"rgba(255,255,255,0.03)",border:`1px solid ${DV.border}`,
    borderRadius:12,padding:"12px 14px"}}>
    <div style={{fontSize:10,color:DV.text3,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.08em"}}>{label}</div>
    <div style={{fontSize:13,fontWeight:600,color:DV.white,display:"flex",alignItems:"center",gap:6}}>{children}</div>
  </div>;
}

export function SectionTitle({ children }) {
  return <h3 style={{fontSize:12,fontWeight:700,color:DV.text3,letterSpacing:"0.1em",
    textTransform:"uppercase",marginBottom:14}}>{children}</h3>;
}

export function EmptyState({ icon, title, sub, action }) {
  return <div style={{textAlign:"center",padding:"48px 24px",color:DV.text4}}>
    <div style={{fontSize:40,marginBottom:12}}>{icon}</div>
    <div style={{fontSize:15,fontWeight:600,color:DV.text3,marginBottom:4}}>{title}</div>
    {sub&&<div style={{fontSize:13,marginBottom:16,color:DV.text3}}>{sub}</div>}
    {action}
  </div>;
}

export function DvDivider() {
  return <div style={{height:1,background:`linear-gradient(90deg,${DV.red}40,transparent)`,margin:"4px 0"}}/>;
}
