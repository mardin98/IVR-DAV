"use client";
import { useState, useEffect } from "react";
import { getAllUsers } from "@/lib/firestore/users";
import { Button, RoleBadge } from "@/components/ui";
import { DV, ROLES } from "@/lib/utils";

const STATUSES   = [
  {value:"todo",        label:"Pendiente"},
  {value:"in_progress", label:"En progreso"},
  {value:"blocked",     label:"Bloqueada"},
  {value:"review",      label:"En revisión"},
  {value:"done",        label:"Completada"},
];
const PRIORITIES = [
  {value:"critical", label:"Crítica"},
  {value:"high",     label:"Alta"},
  {value:"medium",   label:"Media"},
  {value:"low",      label:"Baja"},
];

function Field({ label, children }) {
  return <div><label>{label}</label>{children}</div>;
}

// Pequeño avatar inline para el select custom
function UserOption({ user, roleLabel, roleColor }) {
  const initials = user.name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  return (
    <div style={{display:"flex",alignItems:"center",gap:10,padding:"8px 12px",cursor:"pointer"}}>
      <div style={{width:30,height:30,borderRadius:"50%",background:`${roleColor}20`,
        border:`1.5px solid ${roleColor}40`,display:"flex",alignItems:"center",
        justifyContent:"center",fontSize:11,fontWeight:700,color:roleColor,flexShrink:0}}>
        {user.photoURL
          ? <img src={user.photoURL} alt="" style={{width:"100%",height:"100%",borderRadius:"50%",objectFit:"cover"}}/>
          : initials}
      </div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontSize:13,fontWeight:600,color:DV.white,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.name}</div>
        <div style={{fontSize:11,color:DV.text3}}>{user.email.split("@")[0]}</div>
      </div>
      <span style={{fontSize:10,fontWeight:700,color:roleColor,background:`${roleColor}15`,
        padding:"2px 8px",borderRadius:10,flexShrink:0,whiteSpace:"nowrap"}}>{roleLabel}</span>
    </div>
  );
}

export default function TaskForm({
  initiativeMembers,  // array de UIDs de miembros de la iniciativa
  memberRoles,        // { uid: "leader"|"responsible"|"observer" } — roles en la iniciativa
  parentTaskId,
  initial,
  onSubmit,
  onCancel,
  submitLabel = "Crear tarea",
}) {
  const [allUsers, setAllUsers] = useState([]);
  const [loading,  setLoading]  = useState(false);
  const [form, setForm] = useState({
    title:          initial?.title          ?? "",
    description:    initial?.description    ?? "",
    assigneeId:     initial?.assigneeId     ?? "",
    status:         initial?.status         ?? "todo",
    priority:       initial?.priority       ?? "medium",
    progress:       initial?.progress       ?? 0,
    estimatedHours: initial?.estimatedHours ?? 0,
    dueDate:        initial?.dueDate        ?? "",
    parentTaskId:   parentTaskId ?? initial?.parentTaskId ?? null,
  });

  useEffect(() => {
    getAllUsers().then(all => setAllUsers(all));
  }, []);

  const set = (k, v) => setForm(p => ({...p, [k]: v}));

  // Construir lista de asignables:
  // 1. Miembros de la iniciativa con rol leader o responsible (no observers)
  // 2. Admins globales aunque no sean miembros (pueden supervisar cualquier tarea)
  const assignableUsers = allUsers
    .filter(u => {
      const iniRole  = memberRoles?.[u.id];
      const isGlobalAdmin = u.globalRole === "admin";
      const isMember = initiativeMembers?.includes(u.id);
      // Observers no reciben tareas
      if (isMember && iniRole === "observer") return false;
      // Miembros con rol leader o responsible
      if (isMember && (iniRole === "leader" || iniRole === "responsible")) return true;
      // Admins globales siempre pueden recibir tareas
      if (isGlobalAdmin) return true;
      // Líderes globales que son miembros
      if (isMember && u.globalRole === "leader") return true;
      return false;
    })
    .map(u => {
      // Determinar etiqueta de rol para mostrar
      const iniRole = memberRoles?.[u.id];
      let roleLabel, roleColor;
      if (iniRole === "leader" || u.globalRole === "admin") {
        roleLabel = iniRole === "leader" ? "Líder" : "Admin";
        roleColor = iniRole === "leader" ? DV.purple : DV.red;
      } else {
        roleLabel = "Responsable";
        roleColor = DV.cyan || "#06B6D4";
      }
      return { ...u, roleLabel, roleColor };
    })
    // Ordenar: líderes primero, luego responsables
    .sort((a, b) => {
      const order = { "Líder": 0, "Admin": 1, "Responsable": 2 };
      return (order[a.roleLabel] ?? 3) - (order[b.roleLabel] ?? 3);
    });

  const selectedUser = assignableUsers.find(u => u.id === form.assigneeId);

  const handleSubmit = async () => {
    if (!form.title || !form.assigneeId) return;
    setLoading(true);
    try { await onSubmit(form); } finally { setLoading(false); }
  };

  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Field label={parentTaskId ? "Título de subtarea *" : "Título de tarea *"}>
        <input value={form.title} onChange={e=>set("title",e.target.value)}
          placeholder={parentTaskId ? "Ej: Configurar webhook" : "Ej: Integrar Gemini API"} />
      </Field>

      <Field label="Descripción">
        <textarea value={form.description ?? ""} onChange={e=>set("description",e.target.value)}
          rows={2} style={{resize:"vertical"}} placeholder="Detalle adicional…" />
      </Field>

      {/* Asignado a — con selector visual */}
      <div>
        <label>Asignado a * <span style={{fontSize:10,color:DV.text3,fontWeight:500,textTransform:"none",letterSpacing:0}}>
          (líderes y responsables de esta iniciativa)
        </span></label>

        {assignableUsers.length === 0 ? (
          <div style={{padding:"10px 14px",background:"rgba(227,6,19,0.06)",border:"1px solid rgba(227,6,19,0.2)",
            borderRadius:10,fontSize:13,color:DV.text3}}>
            ⚠ No hay miembros con rol de líder o responsable en esta iniciativa todavía.
          </div>
        ) : (
          <select value={form.assigneeId} onChange={e=>set("assigneeId",e.target.value)}
            style={{cursor:"pointer"}}>
            <option value="">Seleccionar persona…</option>
            {/* Separar por grupo */}
            {assignableUsers.filter(u=>u.roleLabel==="Líder"||u.roleLabel==="Admin").length > 0 && <>
              <option disabled>── Líderes / Admins ──</option>
              {assignableUsers.filter(u=>u.roleLabel==="Líder"||u.roleLabel==="Admin").map(u=>
                <option key={u.id} value={u.id}>👑 {u.name} ({u.roleLabel})</option>
              )}
            </>}
            {assignableUsers.filter(u=>u.roleLabel==="Responsable").length > 0 && <>
              <option disabled>── Responsables ──</option>
              {assignableUsers.filter(u=>u.roleLabel==="Responsable").map(u=>
                <option key={u.id} value={u.id}>◉ {u.name}</option>
              )}
            </>}
          </select>
        )}

        {/* Preview del usuario seleccionado */}
        {selectedUser && (
          <div style={{marginTop:8,padding:"10px 12px",background:"rgba(255,255,255,0.03)",
            border:`1px solid ${selectedUser.roleColor}30`,borderRadius:10,
            display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:28,height:28,borderRadius:"50%",background:`${selectedUser.roleColor}20`,
              border:`1.5px solid ${selectedUser.roleColor}40`,display:"flex",alignItems:"center",
              justifyContent:"center",fontSize:11,fontWeight:700,color:selectedUser.roleColor,flexShrink:0}}>
              {selectedUser.photoURL
                ? <img src={selectedUser.photoURL} alt="" style={{width:"100%",height:"100%",borderRadius:"50%",objectFit:"cover"}}/>
                : selectedUser.name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase()}
            </div>
            <div>
              <div style={{fontSize:13,fontWeight:600,color:DV.white}}>{selectedUser.name}</div>
              <div style={{fontSize:11,color:DV.text3}}>{selectedUser.email}</div>
            </div>
            <span style={{marginLeft:"auto",fontSize:10,fontWeight:700,color:selectedUser.roleColor,
              background:`${selectedUser.roleColor}15`,padding:"2px 8px",borderRadius:10}}>
              {selectedUser.roleLabel}
            </span>
          </div>
        )}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        <Field label="Estado">
          <select value={form.status} onChange={e=>set("status",e.target.value)}>
            {STATUSES.map(s=><option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </Field>
        <Field label="Prioridad">
          <select value={form.priority} onChange={e=>set("priority",e.target.value)}>
            {PRIORITIES.map(p=><option key={p.value} value={p.value}>{p.label}</option>)}
          </select>
        </Field>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        <Field label="Horas estimadas">
          <input type="number" value={form.estimatedHours}
            onChange={e=>set("estimatedHours",Number(e.target.value))} min="0" />
        </Field>
        <Field label="Fecha límite">
          <input type="date" value={form.dueDate ?? ""}
            onChange={e=>set("dueDate",e.target.value)} />
        </Field>
      </div>

      <Field label={`Avance: ${form.progress}%`}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <input type="range" value={form.progress} onChange={e=>set("progress",Number(e.target.value))}
            min="0" max="100" step="5" style={{flex:1,background:"transparent",border:"none",padding:"8px 0",cursor:"pointer"}} />
          <div style={{width:40,height:40,borderRadius:"50%",background:`${DV.red}15`,
            border:`2px solid ${DV.red}40`,display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:12,fontWeight:700,color:DV.red,flexShrink:0}}>
            {form.progress}%
          </div>
        </div>
      </Field>

      <div style={{display:"flex",gap:10,justifyContent:"flex-end",marginTop:4,
        paddingTop:16,borderTop:`1px solid ${DV.border}`}}>
        <Button variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button variant="brand" onClick={handleSubmit}
          disabled={loading || !form.title || !form.assigneeId}>
          {loading ? "Guardando…" : submitLabel}
        </Button>
      </div>
    </div>
  );
}
