"use client";
import { useState, useEffect, useRef } from "react";
import { subscribeComments, addComment, editComment, deleteComment } from "@/lib/firestore/comments";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtRel } from "@/lib/utils";
import { Spinner } from "@/components/ui";

function Avatar({ name, photoURL, size = 28 }) {
  const initials = name.split(" ").slice(0, 2).map(n => n[0]).join("").toUpperCase();
  const colors   = ["#22d3ee","#a78bfa","#4ade80","#f59e0b","#f87171"];
  const color    = colors[name.charCodeAt(0) % colors.length];
  if (photoURL) return <img src={photoURL} alt={name} style={{ width:size, height:size, borderRadius:"50%", objectFit:"cover", flexShrink:0 }} />;
  return <div style={{ width:size, height:size, borderRadius:"50%", background:`${color}22`, border:`1.5px solid ${color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:size*0.36, fontWeight:700, color, flexShrink:0 }}>{initials}</div>;
}

function Comment({ comment, currentUserId, iniId, taskId }) {
  const [editing,  setEditing]  = useState(false);
  const [editText, setEditText] = useState(comment.text);
  const [loading,  setLoading]  = useState(false);
  const isOwn = comment.authorId === currentUserId;

  const handleEdit = async () => {
    if (!editText.trim() || editText.trim() === comment.text) { setEditing(false); return; }
    setLoading(true);
    await editComment(iniId, taskId, comment.id, editText, currentUserId);
    setLoading(false);
    setEditing(false);
  };

  const handleDelete = async () => {
    if (!confirm("¿Eliminar este comentario?")) return;
    await deleteComment(iniId, taskId, comment.id, currentUserId);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleEdit();
    if (e.key === "Escape") { setEditing(false); setEditText(comment.text); }
  };

  return (
    <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
      <Avatar name={comment.authorName} photoURL={comment.authorPhoto} size={28} />
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
          <span style={{ fontSize:13, fontWeight:600, color:"#e2e8f0" }}>{comment.authorName}</span>
          <span style={{ fontSize:11, color:"#334155" }}>{fmtRel(comment.createdAt)}</span>
          {comment.edited && <span style={{ fontSize:10, color:"#475569", fontStyle:"italic" }}>(editado)</span>}
          {isOwn && !editing && (
            <div style={{ marginLeft:"auto", display:"flex", gap:6, opacity:0, transition:"opacity 0.15s" }}
              className="comment-actions">
              <button onClick={() => { setEditing(true); setEditText(comment.text); }}
                style={{ background:"none", border:"none", color:"#64748b", cursor:"pointer", fontSize:11, fontFamily:"inherit", padding:"2px 6px", borderRadius:6 }}>
                Editar
              </button>
              <button onClick={handleDelete}
                style={{ background:"none", border:"none", color:"#f87171", cursor:"pointer", fontSize:11, fontFamily:"inherit", padding:"2px 6px", borderRadius:6 }}>
                Eliminar
              </button>
            </div>
          )}
        </div>

        {editing ? (
          <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
            <textarea
              value={editText}
              onChange={e => setEditText(e.target.value)}
              onKeyDown={handleKey}
              rows={2}
              autoFocus
              style={{ resize:"vertical", fontSize:13 }}
            />
            <div style={{ display:"flex", gap:6 }}>
              <button onClick={handleEdit} disabled={loading || !editText.trim()}
                style={{ padding:"5px 12px", borderRadius:8, background:"rgba(34,211,238,0.15)", border:"1px solid rgba(34,211,238,0.3)", color:"#22d3ee", cursor:"pointer", fontSize:12, fontWeight:600, fontFamily:"inherit" }}>
                {loading ? "Guardando…" : "Guardar"}
              </button>
              <button onClick={() => { setEditing(false); setEditText(comment.text); }}
                style={{ padding:"5px 12px", borderRadius:8, background:"none", border:"1px solid rgba(255,255,255,0.1)", color:"#64748b", cursor:"pointer", fontSize:12, fontFamily:"inherit" }}>
                Cancelar
              </button>
              <span style={{ fontSize:11, color:"#334155", alignSelf:"center" }}>Ctrl+Enter para guardar</span>
            </div>
          </div>
        ) : (
          <p style={{ fontSize:13, color:"#94a3b8", lineHeight:1.6, margin:0, whiteSpace:"pre-wrap", wordBreak:"break-word" }}>
            {comment.text}
          </p>
        )}
      </div>

      <style>{`.comment-actions { opacity: 0; } div:hover > div > .comment-actions { opacity: 1; }`}</style>
    </div>
  );
}

export default function TaskComments({ iniId, taskId }) {
  const { user }                          = useAuth();
  const [comments,  setComments]          = useState([]);
  const [loading,   setLoading]           = useState(true);
  const [text,      setText]              = useState("");
  const [submitting,setSubmitting]        = useState(false);
  const bottomRef                         = useRef(null);

  useEffect(() => {
    const unsub = subscribeComments(iniId, taskId, data => {
      setComments(data);
      setLoading(false);
    });
    return unsub;
  }, [iniId, taskId]);

  // Auto-scroll al último comentario
  useEffect(() => {
    if (!loading) bottomRef.current?.scrollIntoView({ behavior:"smooth" });
  }, [comments.length, loading]);

  const handleSubmit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    await addComment(iniId, taskId, text, user);
    setText("");
    setSubmitting(false);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSubmit();
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ fontSize:12, fontWeight:700, color:"#64748b", textTransform:"uppercase", letterSpacing:"0.07em" }}>
          Comentarios
        </span>
        {comments.length > 0 && (
          <span style={{ fontSize:11, color:"#475569", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:10, padding:"1px 8px" }}>
            {comments.length}
          </span>
        )}
      </div>

      {/* Lista de comentarios */}
      {loading ? (
        <div style={{ display:"flex", justifyContent:"center", padding:16 }}><Spinner size={20} /></div>
      ) : comments.length === 0 ? (
        <div style={{ textAlign:"center", padding:"20px 0", color:"#334155", fontSize:13 }}>
          Sin comentarios aún. Sé el primero en comentar.
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:14, maxHeight:320, overflowY:"auto", paddingRight:4 }}>
          {comments.map(c => (
            <Comment key={c.id} comment={c} currentUserId={user?.id} iniId={iniId} taskId={taskId} />
          ))}
          <div ref={bottomRef} />
        </div>
      )}

      {/* Input nuevo comentario */}
      <div style={{ borderTop:"1px solid rgba(255,255,255,0.07)", paddingTop:14 }}>
        <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
          <Avatar name={user?.name || "?"} photoURL={user?.photoURL} size={28} />
          <div style={{ flex:1, display:"flex", flexDirection:"column", gap:6 }}>
            <textarea
              value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Escribe un comentario… (Ctrl+Enter para enviar)"
              rows={2}
              style={{ resize:"vertical", fontSize:13 }}
            />
            <div style={{ display:"flex", justifyContent:"flex-end", gap:6 }}>
              <span style={{ fontSize:11, color:"#334155", alignSelf:"center" }}>Ctrl+Enter</span>
              <button onClick={handleSubmit} disabled={submitting || !text.trim()}
                style={{ padding:"6px 16px", borderRadius:9, background: text.trim() ? "rgba(34,211,238,0.15)" : "rgba(255,255,255,0.04)", border:`1px solid ${text.trim() ? "rgba(34,211,238,0.3)" : "rgba(255,255,255,0.08)"}`, color: text.trim() ? "#22d3ee" : "#475569", cursor: text.trim() ? "pointer" : "not-allowed", fontSize:12, fontWeight:600, fontFamily:"inherit", transition:"all 0.15s" }}>
                {submitting ? "Enviando…" : "Comentar"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
