"use client";
import { useState, useEffect, useRef } from "react";
import { subscribeComments, addComment, editComment, deleteComment } from "@/lib/firestore/comments";
import { getAllUsers } from "@/lib/firestore/users";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtRel, DV } from "@/lib/utils";
import { Spinner } from "@/components/ui";

function Avatar({ name, photoURL, size = 28 }) {
  const initials = name.split(" ").slice(0,2).map(n=>n[0]).join("").toUpperCase();
  const colors   = [DV.red, DV.purple, "#06B6D4", DV.yellow, DV.orange];
  const color    = colors[name.charCodeAt(0) % colors.length];
  if (photoURL) return <img src={photoURL} alt={name} style={{ width:size, height:size, borderRadius:"50%", objectFit:"cover", flexShrink:0 }} />;
  return <div style={{ width:size, height:size, borderRadius:"50%", background:`${color}20`, border:`1.5px solid ${color}40`,
    display:"flex", alignItems:"center", justifyContent:"center", fontSize:size*0.36, fontWeight:700, color, flexShrink:0 }}>{initials}</div>;
}

// Renderiza texto con @menciones resaltadas
function CommentText({ text }) {
  const parts = text.split(/(@\w+(?:\s\w+)?)/g);
  return (
    <p style={{ fontSize:13, color:DV.text2, lineHeight:1.7, margin:0, whiteSpace:"pre-wrap", wordBreak:"break-word" }}>
      {parts.map((part, i) =>
        part.startsWith("@")
          ? <span key={i} style={{ color:DV.red, fontWeight:700, background:DV.redBg,
              borderRadius:4, padding:"0 4px" }}>{part}</span>
          : <span key={i}>{part}</span>
      )}
    </p>
  );
}

// Input con autocompletado de @menciones
function CommentInput({ value, onChange, onSubmit, members, placeholder }) {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions,     setSuggestions]     = useState([]);
  const [mentionStart,    setMentionStart]    = useState(-1);
  const textareaRef = useRef(null);

  const handleChange = (e) => {
    const val = e.target.value;
    const cursor = e.target.selectionStart;
    onChange(val);

    // Detectar si estamos escribiendo una mención
    const textBefore = val.slice(0, cursor);
    const match = textBefore.match(/@(\w*)$/);
    if (match) {
      const query = match[1].toLowerCase();
      const filtered = members.filter(m =>
        m.name.toLowerCase().includes(query) && query.length >= 0
      ).slice(0, 5);
      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
      setMentionStart(cursor - match[0].length);
    } else {
      setShowSuggestions(false);
    }
  };

  const selectMention = (member) => {
    const before = value.slice(0, mentionStart);
    const after  = value.slice(textareaRef.current?.selectionStart ?? value.length);
    const newVal = `${before}@${member.name.split(" ")[0]} ${after}`;
    onChange(newVal);
    setShowSuggestions(false);
    setTimeout(() => textareaRef.current?.focus(), 0);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) onSubmit();
    if (e.key === "Escape") setShowSuggestions(false);
  };

  return (
    <div style={{ position:"relative", flex:1 }}>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={handleChange}
        onKeyDown={handleKey}
        placeholder={placeholder}
        rows={2}
        style={{ resize:"vertical", fontSize:13, width:"100%" }}
      />
      {showSuggestions && (
        <div style={{ position:"absolute", bottom:"100%", left:0, marginBottom:4, zIndex:50,
          background:DV.bg2, border:`1px solid rgba(227,6,19,0.25)`, borderRadius:10,
          boxShadow:"0 8px 24px rgba(0,0,0,0.5)", minWidth:220, overflow:"hidden" }}>
          {suggestions.map(m => (
            <div key={m.id} onClick={() => selectMention(m)}
              style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 14px",
                cursor:"pointer", transition:"background 0.1s" }}
              onMouseEnter={e=>e.currentTarget.style.background=DV.redBg}
              onMouseLeave={e=>e.currentTarget.style.background="none"}>
              <Avatar name={m.name} photoURL={m.photoURL} size={24} />
              <div>
                <div style={{ fontSize:13, fontWeight:600, color:DV.white }}>{m.name}</div>
                <div style={{ fontSize:11, color:DV.text3 }}>{m.globalRole}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Comment({ comment, currentUserId, iniId, taskId, members }) {
  const [editing,  setEditing]  = useState(false);
  const [editText, setEditText] = useState(comment.text);
  const [loading,  setLoading]  = useState(false);
  const isOwn = comment.authorId === currentUserId;

  const handleEdit = async () => {
    if (!editText.trim() || editText.trim() === comment.text) { setEditing(false); return; }
    setLoading(true);
    await editComment(iniId, taskId, comment.id, editText, currentUserId);
    setLoading(false);
    setEditing(false);
  };

  const handleDelete = async () => {
    if (!confirm("¿Eliminar este comentario?")) return;
    await deleteComment(iniId, taskId, comment.id, currentUserId);
  };

  return (
    <div style={{ display:"flex", gap:10, alignItems:"flex-start",
      animation:"fadeIn 0.2s ease" }}>
      <Avatar name={comment.authorName} photoURL={comment.authorPhoto} size={28} />
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5, flexWrap:"wrap" }}>
          <span style={{ fontSize:13, fontWeight:700, color:DV.white }}>{comment.authorName}</span>
          <span style={{ fontSize:11, color:DV.text4 }}>{fmtRel(comment.createdAt)}</span>
          {comment.edited && <span style={{ fontSize:10, color:DV.text4, fontStyle:"italic" }}>(editado)</span>}
          {isOwn && !editing && (
            <div style={{ marginLeft:"auto", display:"flex", gap:4 }}>
              <button onClick={() => { setEditing(true); setEditText(comment.text); }}
                style={{ background:"none", border:"none", color:DV.text3, cursor:"pointer",
                  fontSize:11, fontFamily:"inherit", padding:"2px 8px", borderRadius:6,
                  transition:"color 0.15s" }}
                onMouseEnter={e=>e.target.style.color=DV.white}
                onMouseLeave={e=>e.target.style.color=DV.text3}>
                Editar
              </button>
              <button onClick={handleDelete}
                style={{ background:"none", border:"none", color:"rgba(248,113,113,0.6)", cursor:"pointer",
                  fontSize:11, fontFamily:"inherit", padding:"2px 8px", borderRadius:6,
                  transition:"color 0.15s" }}
                onMouseEnter={e=>e.target.style.color="#F87171"}
                onMouseLeave={e=>e.target.style.color="rgba(248,113,113,0.6)"}>
                Eliminar
              </button>
            </div>
          )}
        </div>

        {editing ? (
          <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
            <CommentInput
              value={editText}
              onChange={setEditText}
              onSubmit={handleEdit}
              members={members}
              placeholder="Editar comentario…"
            />
            <div style={{ display:"flex", gap:6, alignItems:"center" }}>
              <button onClick={handleEdit} disabled={loading || !editText.trim()}
                style={{ padding:"5px 14px", borderRadius:8, background:DV.redBg,
                  border:`1px solid ${DV.redBd}`, color:DV.white, cursor:"pointer",
                  fontSize:12, fontWeight:700, fontFamily:"inherit", opacity:loading||!editText.trim()?0.5:1 }}>
                {loading ? "Guardando…" : "Guardar"}
              </button>
              <button onClick={() => { setEditing(false); setEditText(comment.text); }}
                style={{ padding:"5px 14px", borderRadius:8, background:"none",
                  border:`1px solid ${DV.border}`, color:DV.text3, cursor:"pointer",
                  fontSize:12, fontFamily:"inherit" }}>
                Cancelar
              </button>
              <span style={{ fontSize:11, color:DV.text4 }}>Ctrl+Enter para guardar</span>
            </div>
          </div>
        ) : (
          <div style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${DV.border}`,
            borderRadius:10, padding:"10px 14px" }}>
            <CommentText text={comment.text} />
          </div>
        )}
      </div>
    </div>
  );
}

export default function TaskComments({ iniId, taskId }) {
  const { user }                          = useAuth();
  const [comments,   setComments]         = useState([]);
  const [members,    setMembers]          = useState([]);
  const [loading,    setLoading]          = useState(true);
  const [text,       setText]             = useState("");
  const [submitting, setSubmitting]       = useState(false);
  const bottomRef                         = useRef(null);

  useEffect(() => {
    const unsub = subscribeComments(iniId, taskId, data => {
      setComments(data);
      setLoading(false);
    });
    return unsub;
  }, [iniId, taskId]);

  // Cargar miembros para autocomplete de @menciones
  useEffect(() => {
    getAllUsers().then(setMembers);
  }, []);

  useEffect(() => {
    if (!loading) bottomRef.current?.scrollIntoView({ behavior:"smooth" });
  }, [comments.length, loading]);

  const handleSubmit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    await addComment(iniId, taskId, text, user);
    setText("");
    setSubmitting(false);
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ fontSize:12, fontWeight:700, color:DV.text3,
          textTransform:"uppercase", letterSpacing:"0.07em" }}>Comentarios</span>
        {comments.length > 0 && (
          <span style={{ fontSize:11, color:DV.text3, background:"rgba(255,255,255,0.06)",
            border:`1px solid ${DV.border}`, borderRadius:10, padding:"1px 8px" }}>
            {comments.length}
          </span>
        )}
        <span style={{ fontSize:11, color:DV.text4, marginLeft:4 }}>
          Usa @ para mencionar a alguien
        </span>
      </div>

      {/* Lista */}
      {loading ? (
        <div style={{ display:"flex", justifyContent:"center", padding:16 }}><Spinner size={20} /></div>
      ) : comments.length === 0 ? (
        <div style={{ textAlign:"center", padding:"20px 0", color:DV.text4, fontSize:13 }}>
          Sin comentarios aún. Usa <b style={{ color:DV.text3 }}>@nombre</b> para mencionar a alguien.
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:14,
          maxHeight:320, overflowY:"auto", paddingRight:4 }}>
          {comments.map(c => (
            <Comment key={c.id} comment={c} currentUserId={user?.id}
              iniId={iniId} taskId={taskId} members={members} />
          ))}
          <div ref={bottomRef} />
        </div>
      )}

      {/* Input */}
      <div style={{ borderTop:`1px solid ${DV.border}`, paddingTop:14 }}>
        <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
          <Avatar name={user?.name || "?"} photoURL={user?.photoURL} size={28} />
          <div style={{ flex:1, display:"flex", flexDirection:"column", gap:6 }}>
            <CommentInput
              value={text}
              onChange={setText}
              onSubmit={handleSubmit}
              members={members}
              placeholder="Escribe un comentario… (@nombre para mencionar)"
            />
            <div style={{ display:"flex", justifyContent:"flex-end", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:11, color:DV.text4 }}>Ctrl+Enter para enviar</span>
              <button onClick={handleSubmit} disabled={submitting || !text.trim()}
                style={{ padding:"6px 18px", borderRadius:9,
                  background: text.trim() ? DV.red : "rgba(255,255,255,0.04)",
                  border: `1px solid ${text.trim() ? DV.redDark : DV.border}`,
                  color: DV.white, cursor: text.trim() ? "pointer" : "not-allowed",
                  fontSize:12, fontWeight:700, fontFamily:"inherit", transition:"all 0.15s",
                  opacity: submitting ? 0.6 : 1,
                  boxShadow: text.trim() ? `0 4px 12px rgba(227,6,19,0.25)` : "none" }}>
                {submitting ? "Enviando…" : "Comentar"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
