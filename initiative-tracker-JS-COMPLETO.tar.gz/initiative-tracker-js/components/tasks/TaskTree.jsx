"use client";
import { useState } from "react";
import { TASK_STATUS, fmtDate, daysLeftLabel } from "@/lib/utils";
import { Avatar, TaskStatusBadge, ProgressBar, Button } from "@/components/ui";
const NEXT = { todo:"in_progress", in_progress:"review", review:"done" };

function Row({ task, users, depth=0, canEdit, onAddSub, onEdit, onDelete, onStatus, onProgress, onHours, onComments }) {
  const [exp,setExp]     = useState(true);
  const [show,setShow]   = useState(false);
  const assignee = users.find(u=>u.id===task.assigneeId);
  const cfg = TASK_STATUS[task.status];
  const dl  = daysLeftLabel(task.dueDate);
  const has = (task.subtasks?.length??0)>0;
  return <div>
    <div style={{paddingLeft:depth*24+12,paddingRight:12,paddingTop:12,paddingBottom:12,borderBottom:"1px solid rgba(255,255,255,0.04)",background:depth>0?"rgba(0,0,0,0.15)":"transparent",transition:"background 0.1s"}}
      onMouseEnter={e=>{e.currentTarget.style.background=depth>0?"rgba(0,0,0,0.25)":"rgba(255,255,255,0.02)";setShow(true);}}
      onMouseLeave={e=>{e.currentTarget.style.background=depth>0?"rgba(0,0,0,0.15)":"transparent";setShow(false);}}>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <button onClick={()=>setExp(p=>!p)} style={{width:16,height:16,background:"none",border:"none",cursor:"pointer",color:"#475569",fontSize:9,padding:0,flexShrink:0,opacity:has?1:0,transition:"transform 0.2s",transform:exp?"rotate(90deg)":"none"}}>▶</button>
        <div style={{width:8,height:8,borderRadius:"50%",background:cfg?.color,flexShrink:0}}/>
        <span style={{flex:1,fontSize:depth>0?13:14,color:task.status==="done"?"#475569":"#e2e8f0",fontWeight:depth>0?500:600,textDecoration:task.status==="done"?"line-through":"none"}}>{task.title}</span>
        <button onClick={e=>{e.stopPropagation();onComments&&onComments(task);}} title="Ver comentarios"
          style={{background:"none",border:"none",cursor:"pointer",color:task.commentCount>0?"#22d3ee":"#334155",fontSize:11,fontFamily:"inherit",display:"flex",alignItems:"center",gap:3,padding:"2px 6px",borderRadius:6,flexShrink:0,transition:"color 0.15s"}}
          onMouseEnter={e=>e.currentTarget.style.color="#22d3ee"} onMouseLeave={e=>e.currentTarget.style.color=task.commentCount>0?"#22d3ee":"#334155"}>
          💬{task.commentCount>0&&<span style={{fontSize:11,fontWeight:700}}>{task.commentCount}</span>}
        </button>
        <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
          {task.status!=="done"&&canEdit&&NEXT[task.status]&&show&&<Button size="sm" variant="ghost" onClick={()=>onStatus(task.id,NEXT[task.status])}>→ {TASK_STATUS[NEXT[task.status]]?.label}</Button>}
          <TaskStatusBadge status={task.status}/>
          {assignee&&<Avatar name={assignee.name} size={22} photoURL={assignee.photoURL}/>}
          {task.dueDate&&<span style={{fontSize:11,color:dl.color,minWidth:80,textAlign:"right"}}>{fmtDate(task.dueDate)}</span>}
          {task.estimatedHours>0&&<span style={{fontSize:11,color:"#475569",minWidth:64,textAlign:"right"}}>{task.loggedHours}h/{task.estimatedHours}h</span>}
          {canEdit&&show&&<div style={{display:"flex",gap:4}}>
            {depth===0&&<Button size="sm" variant="ghost" onClick={()=>onAddSub(task.id)}>+ Sub</Button>}
            <Button size="sm" variant="ghost" onClick={()=>onHours(task.id)}>⏱</Button>
            <Button size="sm" variant="ghost" onClick={()=>onEdit(task)}>✎</Button>
            <Button size="sm" variant="danger" onClick={()=>onDelete(task.id)}>✕</Button>
          </div>}
        </div>
      </div>
      {depth===0&&task.estimatedHours>0&&<div style={{paddingLeft:34,marginTop:8}}><ProgressBar pct={task.progress} height={3} maxWidth={200}/></div>}
    </div>
    {exp&&has&&task.subtasks.map(st=><Row key={st.id} task={st} users={users} depth={depth+1} canEdit={canEdit} onAddSub={onAddSub} onEdit={onEdit} onDelete={onDelete} onStatus={onStatus} onProgress={onProgress} onHours={onHours} onComments={onComments}/>)}
  </div>;
}

export default function TaskTree(props) {
  if(!props.taskTree.length) return null;
  return <div style={{border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,overflow:"hidden"}}>
    <div style={{display:"grid",gridTemplateColumns:"1fr auto",padding:"10px 12px 10px 56px",borderBottom:"1px solid rgba(255,255,255,0.07)",fontSize:11,color:"#334155",fontWeight:600,letterSpacing:"0.06em",textTransform:"uppercase"}}>
      <span>Tarea</span>
      <div style={{display:"flex",gap:10,paddingRight:4}}>
        <span style={{minWidth:80,textAlign:"right"}}>Estado</span>
        <span style={{minWidth:22}}/>
        <span style={{minWidth:80,textAlign:"right"}}>Vence</span>
        <span style={{minWidth:64,textAlign:"right"}}>Horas</span>
      </div>
    </div>
    {props.taskTree.map(t=><Row key={t.id} task={t} users={props.users} depth={0} canEdit={props.canEdit} onAddSub={props.onAddSubtask} onEdit={props.onEditTask} onDelete={props.onDeleteTask} onStatus={props.onChangeStatus} onProgress={props.onChangeProgress} onHours={props.onLogHours} onComments={props.onViewComments}/>)}
  </div>;
}
