"use client";
import { useState } from "react";
import { TASK_STATUS, PRIORITY, DV, fmtDate, daysLeftLabel } from "@/lib/utils";
import { Avatar, TaskStatusBadge, PriorityBadge } from "@/components/ui";

const COLUMNS = ["todo","in_progress","review","blocked","done"];

const COL_CONFIG = {
  todo:        { label:"Pendiente",   color:DV.text3,  icon:"○" },
  in_progress: { label:"En progreso", color:DV.red,    icon:"◎" },
  review:      { label:"Revisión",    color:"#A78BFA", icon:"◈" },
  blocked:     { label:"Bloqueada",   color:"#F87171", icon:"⊘" },
  done:        { label:"Completada",  color:DV.green,  icon:"●" },
};

function TaskCard({ task, users, canEdit, onEdit, onDelete, onComments, onLogHours, onChangeStatus }) {
  const [dragging, setDragging] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const assignee = users.find(u => u.id === task.assigneeId);
  const dl       = daysLeftLabel(task.dueDate);
  const pri      = PRIORITY[task.priority];

  return (
    <div
      draggable={canEdit}
      onDragStart={e => {
        e.dataTransfer.setData("taskId", task.id);
        e.dataTransfer.setData("fromStatus", task.status);
        setDragging(true);
      }}
      onDragEnd={() => setDragging(false)}
      style={{
        background: DV.bg3,
        border: `1px solid ${dragging ? DV.red : DV.border}`,
        borderRadius: 12,
        padding: "12px 14px",
        cursor: canEdit ? "grab" : "default",
        opacity: dragging ? 0.5 : 1,
        transition: "all 0.15s",
        position: "relative",
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.transform = "translateY(-1px)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = DV.border; e.currentTarget.style.transform = "none"; setShowMenu(false); }}
    >
      {/* Priority stripe */}
      {pri && <div style={{ position:"absolute", top:0, left:0, width:3, height:"100%",
        background:pri.color, borderRadius:"12px 0 0 12px", opacity:0.8 }} />}

      <div style={{ paddingLeft:6 }}>
        {/* Title + menu */}
        <div style={{ display:"flex", alignItems:"flex-start", gap:6, marginBottom:8 }}>
          <span style={{ flex:1, fontSize:13, fontWeight:600, color:DV.white,
            lineHeight:1.4, wordBreak:"break-word" }}>
            {task.title}
          </span>
          {canEdit && (
            <div style={{ position:"relative", flexShrink:0 }}>
              <button onClick={e=>{ e.stopPropagation(); setShowMenu(p=>!p); }}
                style={{ background:"none", border:"none", color:DV.text3, cursor:"pointer",
                  fontSize:16, lineHeight:1, padding:"0 4px", fontFamily:"inherit" }}>
                ⋯
              </button>
              {showMenu && (
                <div style={{ position:"absolute", right:0, top:20, zIndex:50, width:160,
                  background:DV.bg2, border:`1px solid ${DV.border}`, borderRadius:10,
                  boxShadow:"0 8px 24px rgba(0,0,0,0.5)", overflow:"hidden" }}>
                  {[
                    { label:"✎ Editar",        action:()=>{ onEdit(task); setShowMenu(false); } },
                    { label:"💬 Comentarios",   action:()=>{ onComments(task); setShowMenu(false); } },
                    { label:"⏱ Loggear horas", action:()=>{ onLogHours(task.id); setShowMenu(false); } },
                    { label:"✕ Eliminar",       action:()=>{ onDelete(task.id); setShowMenu(false); }, danger:true },
                  ].map(item => (
                    <button key={item.label} onClick={item.action}
                      style={{ width:"100%", padding:"9px 14px", background:"none", border:"none",
                        textAlign:"left", fontSize:12, cursor:"pointer", fontFamily:"inherit",
                        color: item.danger ? "#F87171" : DV.text2, transition:"background 0.1s" }}
                      onMouseEnter={e=>e.currentTarget.style.background=item.danger?"rgba(248,113,113,0.08)":"rgba(255,255,255,0.04)"}
                      onMouseLeave={e=>e.currentTarget.style.background="none"}>
                      {item.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Subtasks count */}
        {(task.subtasks?.length ?? 0) > 0 && (
          <div style={{ fontSize:11, color:DV.text3, marginBottom:6, display:"flex", alignItems:"center", gap:4 }}>
            <span>▸</span>
            {task.subtasks.filter(s=>s.status==="done").length}/{task.subtasks.length} subtareas
          </div>
        )}

        {/* Progress bar */}
        {task.estimatedHours > 0 && (
          <div style={{ marginBottom:8 }}>
            <div style={{ height:3, background:"rgba(255,255,255,0.07)", borderRadius:2 }}>
              <div style={{ height:"100%", width:`${task.progress}%`, borderRadius:2,
                background: task.progress>=80?DV.green:task.progress>=50?DV.yellow:DV.red,
                transition:"width 0.4s" }} />
            </div>
          </div>
        )}

        {/* Meta row */}
        <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
          <PriorityBadge priority={task.priority} />
          {task.dueDate && (
            <span style={{ fontSize:10, color:dl.color, fontWeight:600 }}>{dl.label}</span>
          )}
          {task.commentCount > 0 && (
            <button onClick={e=>{e.stopPropagation();onComments(task);}}
              style={{ fontSize:11, color:DV.text3, background:"none", border:"none",
                cursor:"pointer", fontFamily:"inherit", display:"flex", alignItems:"center", gap:2,
                padding:"1px 4px", borderRadius:4, transition:"color 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.color=DV.white}
              onMouseLeave={e=>e.currentTarget.style.color=DV.text3}>
              💬 {task.commentCount}
            </button>
          )}
          {task.estimatedHours > 0 && (
            <span style={{ fontSize:10, color:DV.text4 }}>{task.loggedHours}h/{task.estimatedHours}h</span>
          )}
          {assignee && (
            <div style={{ marginLeft:"auto", flexShrink:0 }}>
              <Avatar name={assignee.name} size={20} photoURL={assignee.photoURL} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function KanbanColumn({ status, tasks, users, canEdit, onEdit, onDelete, onComments, onLogHours, onChangeStatus, onAddTask }) {
  const [dragOver, setDragOver] = useState(false);
  const cfg = COL_CONFIG[status];

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const taskId    = e.dataTransfer.getData("taskId");
    const fromStatus= e.dataTransfer.getData("fromStatus");
    if (taskId && fromStatus !== status) {
      onChangeStatus(taskId, status);
    }
  };

  return (
    <div
      onDragOver={e=>{ e.preventDefault(); setDragOver(true); }}
      onDragLeave={()=>setDragOver(false)}
      onDrop={handleDrop}
      style={{
        flex: "0 0 260px",
        display: "flex",
        flexDirection: "column",
        gap: 8,
        minWidth: 0,
      }}
    >
      {/* Column header */}
      <div style={{ display:"flex", alignItems:"center", gap:8, padding:"10px 14px",
        background: dragOver ? `${cfg.color}10` : DV.bg3,
        border: `1px solid ${dragOver ? cfg.color+"40" : DV.border}`,
        borderRadius: 10, transition:"all 0.15s", flexShrink:0 }}>
        <span style={{ fontSize:14, color:cfg.color }}>{cfg.icon}</span>
        <span style={{ fontSize:13, fontWeight:700, color:DV.white, flex:1 }}>{cfg.label}</span>
        <span style={{ fontSize:11, color:DV.text3, background:"rgba(255,255,255,0.06)",
          borderRadius:8, padding:"1px 8px", fontWeight:600 }}>{tasks.length}</span>
        {canEdit && status !== "done" && (
          <button onClick={()=>onAddTask(status)}
            style={{ background:"none", border:"none", color:DV.text3, cursor:"pointer",
              fontSize:16, lineHeight:1, padding:"0 2px", fontFamily:"inherit", transition:"color 0.15s" }}
            title="Agregar tarea"
            onMouseEnter={e=>e.target.style.color=cfg.color}
            onMouseLeave={e=>e.target.style.color=DV.text3}>
            +
          </button>
        )}
      </div>

      {/* Drop zone indicator */}
      {dragOver && (
        <div style={{ border:`2px dashed ${cfg.color}60`, borderRadius:10, height:60,
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:12, color:cfg.color, background:`${cfg.color}08` }}>
          Soltar aquí
        </div>
      )}

      {/* Cards */}
      <div style={{ display:"flex", flexDirection:"column", gap:8, flex:1,
        minHeight:100, overflowY:"auto", paddingBottom:8, paddingRight:2 }}>
        {tasks.length === 0 && !dragOver && (
          <div style={{ padding:"16px 0", textAlign:"center", color:DV.text4, fontSize:12 }}>
            Sin tareas
          </div>
        )}
        {tasks.map(task => (
          <TaskCard key={task.id} task={task} users={users} canEdit={canEdit}
            onEdit={onEdit} onDelete={onDelete} onComments={onComments}
            onLogHours={onLogHours} onChangeStatus={onChangeStatus} />
        ))}
      </div>
    </div>
  );
}

export default function KanbanBoard({ taskTree, users, canEdit, onAddTask, onEditTask, onDeleteTask, onViewComments, onLogHours, onChangeStatus }) {
  // Aplanar todas las tareas (raíz + subtareas) para el kanban
  const allTasks = taskTree.flatMap(t => [t, ...(t.subtasks || [])]);

  const tasksByStatus = COLUMNS.reduce((acc, status) => {
    acc[status] = allTasks.filter(t => t.status === status);
    return acc;
  }, {});

  const totalDone   = tasksByStatus.done.length;
  const totalActive = allTasks.filter(t=>t.status!=="done").length;

  return (
    <div>
      {/* Stats row */}
      <div style={{ display:"flex", gap:16, marginBottom:16, fontSize:12, color:DV.text3 }}>
        <span>{allTasks.length} tareas en total</span>
        <span style={{ color:DV.green }}>●  {totalDone} completadas</span>
        <span style={{ color:DV.red }}>◎  {tasksByStatus.in_progress.length} en progreso</span>
        {tasksByStatus.blocked.length > 0 && (
          <span style={{ color:"#F87171" }}>⊘  {tasksByStatus.blocked.length} bloqueadas</span>
        )}
      </div>

      {/* Board */}
      <div style={{ display:"flex", gap:12, overflowX:"auto", paddingBottom:16,
        scrollSnapType:"x mandatory" }}>
        {COLUMNS.map(status => (
          <KanbanColumn
            key={status}
            status={status}
            tasks={tasksByStatus[status]}
            users={users}
            canEdit={canEdit}
            onEdit={onEditTask}
            onDelete={onDeleteTask}
            onComments={onViewComments}
            onLogHours={onLogHours}
            onChangeStatus={onChangeStatus}
            onAddTask={(st) => onAddTask(null, st)}
          />
        ))}
      </div>
    </div>
  );
}
