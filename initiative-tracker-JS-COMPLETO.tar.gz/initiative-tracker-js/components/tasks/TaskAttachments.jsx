"use client";
import { useState, useEffect, useRef } from "react";
import { subscribeAttachments, uploadAttachment, deleteAttachment, formatFileSize, fileIcon } from "@/lib/firestore/attachments";
import { useAuth } from "@/lib/hooks/useAuth";
import { fmtDate, DV } from "@/lib/utils";
import { Spinner } from "@/components/ui";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const ALLOWED_TYPES = [
  "image/", "application/pdf", "application/msword",
  "application/vnd.openxmlformats", "application/vnd.ms-",
  "text/", "application/zip", "application/json",
];

function isAllowed(file) {
  return ALLOWED_TYPES.some(t => file.type.startsWith(t)) || file.size < MAX_FILE_SIZE;
}

export default function TaskAttachments({ iniId, taskId }) {
  const { user }                             = useAuth();
  const [attachments, setAttachments]        = useState([]);
  const [loading,     setLoading]            = useState(true);
  const [uploading,   setUploading]          = useState(false);
  const [progress,    setProgress]           = useState(0);
  const [dragOver,    setDragOver]           = useState(false);
  const [error,       setError]              = useState("");
  const fileInputRef                         = useRef(null);

  useEffect(() => {
    const unsub = subscribeAttachments(iniId, taskId, data => {
      setAttachments(data);
      setLoading(false);
    });
    return unsub;
  }, [iniId, taskId]);

  const handleUpload = async (files) => {
    const file = files[0];
    if (!file) return;
    setError("");

    if (file.size > MAX_FILE_SIZE) {
      setError(`El archivo excede el límite de 10 MB (${formatFileSize(file.size)})`);
      return;
    }

    setUploading(true);
    setProgress(0);
    try {
      await uploadAttachment(iniId, taskId, file, user, setProgress);
    } catch (e) {
      setError("Error al subir el archivo. Intenta de nuevo.");
      console.error(e);
    } finally {
      setUploading(false);
      setProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleUpload(e.dataTransfer.files);
  };

  const handleDelete = async (att) => {
    if (!confirm(`¿Eliminar "${att.name}"?`)) return;
    await deleteAttachment(iniId, taskId, att.id, att.storagePath, user.id);
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ fontSize:12, fontWeight:700, color:DV.text3, textTransform:"uppercase", letterSpacing:"0.07em" }}>
          Archivos adjuntos
        </span>
        {attachments.length > 0 && (
          <span style={{ fontSize:11, color:DV.text3, background:"rgba(255,255,255,0.06)",
            border:`1px solid ${DV.border}`, borderRadius:10, padding:"1px 8px" }}>
            {attachments.length}
          </span>
        )}
      </div>

      {/* Drop zone */}
      <div
        onDragOver={e=>{ e.preventDefault(); setDragOver(true); }}
        onDragLeave={()=>setDragOver(false)}
        onDrop={handleDrop}
        onClick={()=>!uploading && fileInputRef.current?.click()}
        style={{
          border: `2px dashed ${dragOver ? DV.red : "rgba(255,255,255,0.12)"}`,
          borderRadius: 12,
          padding: "20px 16px",
          textAlign: "center",
          cursor: uploading ? "not-allowed" : "pointer",
          background: dragOver ? DV.redBg : "rgba(255,255,255,0.02)",
          transition: "all 0.15s",
        }}
      >
        <input
          ref={fileInputRef}
          type="file"
          style={{ display:"none" }}
          onChange={e => handleUpload(e.target.files)}
          accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.md,.csv,.zip,.json"
        />

        {uploading ? (
          <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:10 }}>
            <Spinner size={24} />
            <div style={{ fontSize:13, color:DV.text2 }}>Subiendo… {progress}%</div>
            <div style={{ width:"100%", maxWidth:200, height:4, background:"rgba(255,255,255,0.08)", borderRadius:4 }}>
              <div style={{ height:"100%", width:`${progress}%`, background:DV.red, borderRadius:4, transition:"width 0.3s" }} />
            </div>
          </div>
        ) : (
          <div>
            <div style={{ fontSize:24, marginBottom:8 }}>📎</div>
            <div style={{ fontSize:13, fontWeight:600, color: dragOver ? DV.white : DV.text2, marginBottom:4 }}>
              {dragOver ? "Suelta el archivo aquí" : "Arrastra archivos o haz clic para seleccionar"}
            </div>
            <div style={{ fontSize:11, color:DV.text3 }}>PDF, imágenes, documentos, ZIP — máx. 10 MB</div>
          </div>
        )}
      </div>

      {/* Error */}
      {error && (
        <div style={{ padding:"10px 14px", borderRadius:10, background:"rgba(248,113,113,0.08)",
          border:"1px solid rgba(248,113,113,0.25)", fontSize:12, color:"#F87171" }}>
          ⚠ {error}
        </div>
      )}

      {/* Lista de archivos */}
      {loading ? (
        <div style={{ display:"flex", justifyContent:"center", padding:12 }}><Spinner size={20} /></div>
      ) : attachments.length === 0 ? (
        <div style={{ textAlign:"center", padding:"12px 0", color:DV.text4, fontSize:13 }}>
          Sin archivos adjuntos aún
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {attachments.map(att => (
            <div key={att.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 14px",
              background:"rgba(255,255,255,0.03)", border:`1px solid ${DV.border}`, borderRadius:10,
              transition:"border-color 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(255,255,255,0.15)"}
              onMouseLeave={e=>e.currentTarget.style.borderColor=DV.border}>

              {/* Thumbnail o ícono */}
              {att.type?.startsWith("image/") ? (
                <img src={att.url} alt={att.name}
                  style={{ width:40, height:40, borderRadius:8, objectFit:"cover", flexShrink:0,
                    border:`1px solid ${DV.border}` }} />
              ) : (
                <div style={{ width:40, height:40, borderRadius:8, background:"rgba(255,255,255,0.06)",
                  border:`1px solid ${DV.border}`, display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:20, flexShrink:0 }}>
                  {fileIcon(att.ext)}
                </div>
              )}

              {/* Info */}
              <div style={{ flex:1, minWidth:0 }}>
                <a href={att.url} target="_blank" rel="noopener noreferrer"
                  style={{ fontSize:13, fontWeight:600, color:DV.white, textDecoration:"none",
                    display:"block", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}
                  onMouseEnter={e=>e.target.style.color=DV.red}
                  onMouseLeave={e=>e.target.style.color=DV.white}>
                  {att.name}
                </a>
                <div style={{ fontSize:11, color:DV.text3, marginTop:2 }}>
                  {formatFileSize(att.size)} · {att.uploaderName} · {fmtDate(att.createdAt)}
                </div>
              </div>

              {/* Acciones */}
              <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                <a href={att.url} target="_blank" rel="noopener noreferrer" download={att.name}>
                  <button style={{ background:"none", border:`1px solid ${DV.border}`, color:DV.text3,
                    cursor:"pointer", fontSize:12, padding:"4px 10px", borderRadius:8, fontFamily:"inherit",
                    transition:"all 0.15s" }}
                    title="Descargar"
                    onMouseEnter={e=>{e.currentTarget.style.borderColor=DV.red;e.currentTarget.style.color=DV.red;}}
                    onMouseLeave={e=>{e.currentTarget.style.borderColor=DV.border;e.currentTarget.style.color=DV.text3;}}>
                    ↓
                  </button>
                </a>
                {att.uploadedBy === user?.id && (
                  <button onClick={() => handleDelete(att)}
                    style={{ background:"none", border:"1px solid rgba(248,113,113,0.25)", color:"#F87171",
                      cursor:"pointer", fontSize:12, padding:"4px 10px", borderRadius:8, fontFamily:"inherit",
                      transition:"all 0.15s" }}
                    title="Eliminar"
                    onMouseEnter={e=>{e.currentTarget.style.background="rgba(248,113,113,0.1)";}}
                    onMouseLeave={e=>{e.currentTarget.style.background="none";}}>
                    ✕
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
