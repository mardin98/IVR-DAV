# Initiative Tracker — Guía de Deploy
**Davivienda El Salvador · AI & Automations**

---

## 1. Crear proyecto Firebase

1. Ve a [console.firebase.google.com](https://console.firebase.google.com)
2. **Add project** → nombre: `initiative-tracker-davivienda`
3. Activa **Google Analytics** (opcional)
4. En **Authentication** → Sign-in methods → habilita **Google**
5. En **Firestore Database** → Create database → modo **Production** → región `us-central1`
6. En **Project Settings** → Your apps → Add app → Web → copia las credenciales

---

## 2. Configurar .env.local

```bash
cp .env.local.example .env.local
```

Llena con los valores de Firebase Console:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=initiative-tracker-davivienda.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=initiative-tracker-davivienda
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=initiative-tracker-davivienda.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123:web:abc123
```

---

## 3. Configurar Google OAuth (dominio corporativo)

1. Firebase Console → Authentication → Settings → **Authorized domains**
2. Agrega: `initiative-tracker-davivienda.web.app` y tu dominio custom si tienes
3. En [console.cloud.google.com](https://console.cloud.google.com) → APIs & Services → Credentials
4. Edita el OAuth 2.0 Client → Authorized JavaScript origins:
   - `https://initiative-tracker-davivienda.web.app`
5. El parámetro `hd: "davivienda.com.sv"` en `lib/firebase.ts` ya restringe el login al dominio corporativo

---

## 4. Configurar SMTP para emails

### Opción A: Gmail con App Password (más simple)
1. En tu cuenta Google corporativa → Security → 2-Step Verification → **App passwords**
2. Genera una contraseña para "Mail"
3. Guárdala como secret de Firebase:

```bash
firebase functions:secrets:set SMTP_PASSWORD
# Pega la app password cuando lo solicite
```

### Opción B: SMTP corporativo (recomendado para producción)
Usa el servidor SMTP de Davivienda. Coordina con el equipo de infraestructura para obtener:
- Host SMTP
- Puerto (generalmente 587)
- Usuario y contraseña de cuenta de servicio

```bash
firebase functions:secrets:set SMTP_PASSWORD
```

---

## 5. Configurar Google Drive + Calendar

### 5.1 Service Account con Domain-Wide Delegation

1. GCP Console → IAM & Admin → **Service Accounts** → Create
   - Nombre: `initiative-tracker-sa`
   - Rol: `Editor`
2. En el service account → **Keys** → Add key → JSON → guarda el archivo
3. En **Details** → note el **Client ID** (formato: `1234567890`)

4. En [admin.google.com](https://admin.google.com) (Google Workspace Admin):
   - Security → API controls → **Domain-wide delegation** → Add new
   - Client ID: (el del paso 3)
   - Scopes:
     ```
     https://www.googleapis.com/auth/drive,https://www.googleapis.com/auth/calendar
     ```

5. En GCP Console → APIs & Services → **Enable APIs**:
   - Google Drive API
   - Google Calendar API

6. Sube el JSON del service account a Cloud Run (se usa automáticamente con ADC):
   ```bash
   # En Cloud Shell / entorno de deploy:
   export GOOGLE_APPLICATION_CREDENTIALS="path/to/service-account.json"
   ```

### 5.2 Configurar carpeta Drive

1. En Google Drive, crea una carpeta: `📁 Initiative Tracker`
2. Comparte con el service account (editor)
3. Copia el ID de la carpeta de la URL: `drive.google.com/drive/folders/ESTE_ES_EL_ID`

### 5.3 Variables de Functions

```bash
firebase functions:params:set \
  SMTP_HOST="smtp.gmail.com" \
  SMTP_PORT="587" \
  SMTP_USER="noreply@davivienda.com.sv" \
  DRIVE_PARENT_FOLDER_ID="1abc...xyz" \
  GOOGLE_CALENDAR_ID="primary" \
  SERVICE_ACCOUNT_EMAIL="initiative-tracker-sa@proyecto.iam.gserviceaccount.com"
```

---

## 6. Deploy

### Automático (recomendado)
```bash
bash deploy.sh
```

### Manual paso a paso
```bash
# 1. Build Next.js
npm ci && npm run build

# 2. Build Functions
cd functions && npm ci && npm run build && cd ..

# 3. Deploy todo
firebase deploy --project initiative-tracker-davivienda
```

---

## 7. CI/CD con GitHub Actions

1. En GitHub → Settings → Secrets → Actions → agrega:
   - `FIREBASE_API_KEY` = valor de .env.local
   - `FIREBASE_AUTH_DOMAIN`
   - `FIREBASE_PROJECT_ID`
   - `FIREBASE_STORAGE_BUCKET`
   - `FIREBASE_MESSAGING_SENDER_ID`
   - `FIREBASE_APP_ID`
   - `FIREBASE_SERVICE_ACCOUNT` = JSON completo de la service account de Firebase (no la de Drive)
     ```bash
     # Obtener:
     firebase init hosting:github
     # Esto crea automáticamente el secret en GitHub
     ```

2. Cada `push` a `main` despliega automáticamente.

---

## 8. Post-deploy: Primer acceso

1. Entra a `https://initiative-tracker-davivienda.web.app`
2. Login con tu cuenta `@davivienda.com.sv`
3. En **Firebase Console → Firestore**, busca `users/{tu-uid}` y cambia `globalRole` a `"admin"`
4. Recarga la app — ya tendrás acceso completo de admin

---

## 9. Estructura de costos (Firebase Free Tier)

| Recurso | Límite gratis | Uso estimado (30 ini.) |
|---|---|---|
| Firestore reads | 50,000/día | ~500/día ✅ |
| Firestore writes | 20,000/día | ~200/día ✅ |
| Auth | Ilimitado | ✅ |
| Functions invocations | 2M/mes | ~10k/mes ✅ |
| Hosting bandwidth | 10 GB/mes | ~1 GB/mes ✅ |
| **Costo mensual** | **$0** | **$0** ✅ |

---

## 10. Troubleshooting

| Error | Solución |
|---|---|
| `auth/unauthorized-domain` | Agregar dominio en Firebase Console → Auth → Settings → Authorized domains |
| `permission-denied` en Firestore | Verificar que tu `globalRole` sea `admin` o `leader` en Firestore |
| Functions no despliegan | `firebase login --reauth` y reintentar |
| Emails no llegan | Verificar SMTP_PASSWORD secret y que el puerto 587 esté abierto |
| Drive folder no se crea | Verificar Domain-Wide Delegation y que las APIs estén habilitadas |
| `SMTP_PASSWORD` not found | `firebase functions:secrets:set SMTP_PASSWORD` |
