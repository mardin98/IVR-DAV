const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");
const { differenceInDays } = require("date-fns");
const { sendOverdueTasks, sendWeeklyReport } = require("../integrations/emailService");
const db=admin.firestore(), TZ="America/El_Salvador", APP=process.env.APP_URL||"https://tu-proyecto.web.app";
exports.cronDailyOverdueCheck = onSchedule({schedule:"0 8 * * *",timeZone:TZ,memory:"256MiB"},async()=>{
  const now=admin.firestore.Timestamp.now();
  const snap=await db.collectionGroup("tasks").where("status","in",["todo","in_progress","blocked"]).where("dueDate","<",now).get();
  const byUser={};
  for(const t of snap.docs){
    const task=t.data(), iniId=t.ref.parent.parent?.id;
    if(!iniId||!task.assigneeId) continue;
    const iDoc=await db.collection("initiatives").doc(iniId).get();
    if(!iDoc.exists) continue; const ini=iDoc.data();
    if(ini.status==="completed"||ini.status==="cancelled") continue;
    if(!byUser[task.assigneeId]) byUser[task.assigneeId]=[];
    byUser[task.assigneeId].push({title:task.title,initiativeCode:ini.code,dueDate:task.dueDate.toDate().toLocaleDateString("es-SV")});
    await db.collection("notifications").doc(task.assigneeId).collection("items").add({type:"warning",title:"Tarea vencida",body:`${ini.code} › "${task.title}" sigue pendiente`,entityType:"task",entityId:t.id,read:false,createdAt:now});
  }
  for(const [uid,tasks] of Object.entries(byUser)){const u=await db.collection("users").doc(uid).get();if(u.exists)try{await sendOverdueTasks({to:u.data().email,userName:u.data().name,tasks,appUrl:APP});}catch(e){console.warn("Email failed:",e);}}
});
exports.cronWeeklyReport = onSchedule({schedule:"0 7 * * 1",timeZone:TZ,memory:"256MiB"},async()=>{
  const [iniSnap,usersSnap]=await Promise.all([db.collection("initiatives").get(),db.collection("users").where("globalRole","in",["admin","leader"]).where("active","==",true).get()]);
  const all=iniSnap.docs.map(d=>({id:d.id,...d.data()})), active=all.filter(i=>i.status==="active"), now=admin.firestore.Timestamp.now();
  const overSnap=await db.collectionGroup("tasks").where("status","in",["todo","in_progress","blocked"]).where("dueDate","<",now).get();
  const stats={activeCount:active.length,completedCount:all.filter(i=>i.status==="completed").length,avgProgress:active.length?Math.round(active.reduce((s,i)=>s+(i.progress||0),0)/active.length):0,overdueTasksCount:overSnap.size,totalBudget:all.reduce((s,i)=>s+(i.budget||0),0),totalSpent:all.reduce((s,i)=>s+(i.budgetSpent||0),0)};
  const pO={critical:0,high:1,medium:2,low:3};
  const top=active.sort((a,b)=>(pO[a.priority]||2)-(pO[b.priority]||2)).slice(0,6).map(i=>({code:i.code,title:i.title,progress:i.progress||0,status:i.status,daysLeft:i.dueDate?differenceInDays(i.dueDate.toDate(),new Date()):999}));
  for(const u of usersSnap.docs){try{await sendWeeklyReport({to:u.data().email,userName:u.data().name,stats,topInitiatives:top,appUrl:APP});}catch(e){console.warn("Weekly email failed:",e);}}
});
