const scheduler = require("firebase-functions/v2/scheduler");
const admin     = require("firebase-admin");
const { differenceInDays } = require("date-fns");
const { sendOverdueTasks, sendWeeklyReport } = require("../integrations/emailService");

const db      = admin.firestore();
const APP_URL = process.env.APP_URL || "https://initiative-tracker.web.app";
const TZ      = "America/El_Salvador";

exports.cronDailyOverdueCheck = scheduler.onSchedule({ schedule:"0 8 * * *", timeZone:TZ, memory:"256MiB" }, async () => {
  const now  = admin.firestore.Timestamp.now();
  const snap = await db.collectionGroup("tasks")
    .where("status","in",["todo","in_progress","blocked"])
    .where("dueDate","<",now).get();

  const byAssignee = {};
  for (const taskDoc of snap.docs) {
    const task          = taskDoc.data();
    const initiativeId  = taskDoc.ref.parent.parent?.id;
    if (!initiativeId || !task.assigneeId) continue;

    const iDoc = await db.collection("initiatives").doc(initiativeId).get();
    if (!iDoc.exists) continue;
    const ini = iDoc.data();
    if (ini.status === "completed" || ini.status === "cancelled") continue;

    const uid = task.assigneeId;
    if (!byAssignee[uid]) byAssignee[uid] = [];
    byAssignee[uid].push({
      title: task.title, initiativeCode: ini.code,
      dueDate: task.dueDate.toDate().toLocaleDateString("es-SV"),
    });

    await db.collection("notifications").doc(uid).collection("items").add({
      type:"warning", title:"Tarea vencida",
      body:`${ini.code} › "${task.title}" sigue pendiente`,
      entityType:"task", entityId: taskDoc.id,
      read:false, createdAt: now,
    });
  }

  for (const [uid, tasks] of Object.entries(byAssignee)) {
    const uDoc = await db.collection("users").doc(uid).get();
    if (!uDoc.exists) continue;
    const user = uDoc.data();
    try {
      await sendOverdueTasks({ to: user.email, userName: user.name, tasks, appUrl: APP_URL });
    } catch(e) { console.warn(`Email failed for ${user.email}:`, e); }
  }
});

exports.cronWeeklyReport = scheduler.onSchedule({ schedule:"0 7 * * 1", timeZone:TZ, memory:"256MiB" }, async () => {
  const [iniSnap, usersSnap] = await Promise.all([
    db.collection("initiatives").get(),
    db.collection("users").where("globalRole","in",["admin","leader"]).where("active","==",true).get(),
  ]);

  const all    = iniSnap.docs.map(d => ({ id:d.id, ...d.data() }));
  const active = all.filter(i => i.status === "active");
  const now    = admin.firestore.Timestamp.now();

  const overdueSnap = await db.collectionGroup("tasks")
    .where("status","in",["todo","in_progress","blocked"])
    .where("dueDate","<",now).get();

  const stats = {
    activeCount:       active.length,
    completedCount:    all.filter(i => i.status==="completed").length,
    avgProgress:       active.length ? Math.round(active.reduce((s,i) => s+(i.progress||0), 0)/active.length) : 0,
    overdueTasksCount: overdueSnap.size,
    totalBudget:       all.reduce((s,i) => s+(i.budget||0), 0),
    totalSpent:        all.reduce((s,i) => s+(i.budgetSpent||0), 0),
  };

  const pOrder = { critical:0, high:1, medium:2, low:3 };
  const topInitiatives = active
    .sort((a,b) => (pOrder[a.priority]||2) - (pOrder[b.priority]||2))
    .slice(0,6)
    .map(i => ({
      code: i.code, title: i.title, progress: i.progress||0, status: i.status,
      daysLeft: i.dueDate ? differenceInDays(i.dueDate.toDate(), new Date()) : 999,
    }));

  for (const uDoc of usersSnap.docs) {
    const user = uDoc.data();
    try {
      await sendWeeklyReport({ to: user.email, userName: user.name, stats, topInitiatives, appUrl: APP_URL });
      await db.collection("notifications").doc(uDoc.id).collection("items").add({
        type:"info", title:"Resumen semanal disponible",
        body:`${active.length} activas · ${stats.avgProgress}% avance · ${overdueSnap.size} tareas vencidas`,
        read:false, createdAt: now,
      });
    } catch(e) { console.warn(`Weekly report failed for ${user.email}:`, e); }
  }
});

exports.cronMonthlyBudgetReport = scheduler.onSchedule({ schedule:"0 9 1 * *", timeZone:TZ, memory:"256MiB" }, async () => {
  const now     = admin.firestore.Timestamp.now();
  const [aSnap, admSnap] = await Promise.all([
    db.collection("initiatives").where("status","==","active").get(),
    db.collection("users").where("globalRole","==","admin").where("active","==",true).get(),
  ]);

  const highBudget = aSnap.docs.filter(d => {
    const i = d.data();
    return i.budget > 0 && (i.budgetSpent/i.budget) > 0.7;
  });

  for (const aDoc of admSnap.docs) {
    await db.collection("notifications").doc(aDoc.id).collection("items").add({
      type: highBudget.length > 0 ? "warning" : "info",
      title:"Reporte mensual de presupuesto",
      body:`${highBudget.length} iniciativa${highBudget.length!==1?"s":""} con más del 70% ejecutado`,
      read:false, createdAt: now,
    });
  }
});
