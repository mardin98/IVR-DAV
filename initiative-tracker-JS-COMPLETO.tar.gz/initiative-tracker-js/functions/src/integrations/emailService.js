const nodemailer = require("nodemailer");
const { defineString, defineSecret } = require("firebase-functions/params");

const SMTP_HOST = defineString("SMTP_HOST", { default: "smtp.gmail.com" });
const SMTP_PORT = defineString("SMTP_PORT", { default: "587" });
const SMTP_USER = defineString("SMTP_USER", { default: "noreply@davivienda.com.sv" });
const SMTP_PASS = defineSecret("SMTP_PASSWORD");
const FROM_NAME = "Initiative Tracker · Davivienda";

function createTransport() {
  return nodemailer.createTransport({
    host: SMTP_HOST.value(), port: parseInt(SMTP_PORT.value()),
    secure: false,
    auth: { user: SMTP_USER.value(), pass: SMTP_PASS.value() },
    tls: { rejectUnauthorized: false },
  });
}

function base(content, preheader = "") {
  return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<style>
* {margin:0;padding:0;box-sizing:border-box}
body{background:#060b14;font-family:'Segoe UI',Arial,sans-serif;color:#f1f5f9}
.w{max-width:600px;margin:0 auto;padding:32px 16px}
.hdr{border-bottom:1px solid rgba(255,255,255,.08);padding-bottom:20px;margin-bottom:32px}
.logo{display:inline-block;width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#22d3ee,#a78bfa);text-align:center;line-height:40px;font-size:20px}
.card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:28px;margin-bottom:20px}
.badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:700}
.b-info{color:#22d3ee;background:rgba(34,211,238,.12);border:1px solid rgba(34,211,238,.3)}
.b-warn{color:#f59e0b;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3)}
.b-ok{color:#4ade80;background:rgba(74,222,128,.12);border:1px solid rgba(74,222,128,.3)}
.b-err{color:#f87171;background:rgba(248,113,113,.12);border:1px solid rgba(248,113,113,.3)}
.bar-bg{background:rgba(255,255,255,.07);border-radius:4px;height:6px;margin:8px 0}
.btn{display:inline-block;padding:12px 24px;border-radius:10px;font-size:14px;font-weight:700;text-decoration:none;color:#060b14;background:linear-gradient(135deg,#22d3ee,#0e7490)}
.mono{font-family:'Courier New',monospace;color:#22d3ee;font-weight:700}
.foot{text-align:center;font-size:11px;color:#1e3a5f;margin-top:32px}
h1{font-size:22px;font-weight:800;color:#f1f5f9;margin-bottom:6px}
h2{font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:12px}
p{font-size:14px;color:#94a3b8;line-height:1.7;margin-bottom:12px}
</style></head><body>
${preheader ? `<div style="display:none;max-height:0;overflow:hidden;">${preheader}</div>` : ""}
<div class="w">
<div class="hdr"><span class="logo">◈</span>
<span style="font-size:16px;font-weight:800;color:#f1f5f9;margin-left:12px;">Initiative Tracker</span>
<span style="font-size:10px;color:#334155;margin-left:8px;text-transform:uppercase;letter-spacing:.1em;">Davivienda AI & Automations</span></div>
${content}
<div class="foot">Mensaje automático · Initiative Tracker · Davivienda El Salvador<br>No responder a este correo</div>
</div></body></html>`;
}

async function sendTaskAssigned({ to, userName, taskTitle, initiativeCode, initiativeTitle, assignedBy, dueDate, initiativeUrl }) {
  await createTransport().sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to, subject: `📋 Nueva tarea asignada: ${taskTitle}`,
    html: base(`<div class="card">
      <p>Hola <strong>${userName}</strong>,</p>
      <h1>Nueva tarea asignada</h1>
      <p>Se te asignó una tarea en <span class="mono">${initiativeCode}</span></p>
      <div style="background:rgba(34,211,238,.06);border:1px solid rgba(34,211,238,.2);border-radius:12px;padding:16px;margin:20px 0">
        <div style="font-size:16px;font-weight:700;color:#f1f5f9;margin-bottom:8px">${taskTitle}</div>
        <div style="font-size:13px;color:#64748b">${initiativeCode} — ${initiativeTitle}</div>
        ${dueDate ? `<div style="font-size:12px;color:#f59e0b;margin-top:6px">📅 Vence el ${dueDate}</div>` : ""}
      </div>
      <div style="border-bottom:1px solid rgba(255,255,255,.05);padding:8px 0;display:flex;justify-content:space-between;font-size:13px">
        <span style="color:#64748b">Asignado por</span><span style="color:#e2e8f0;font-weight:600">${assignedBy}</span>
      </div>
      <div style="margin-top:24px"><a href="${initiativeUrl}" class="btn">Ver iniciativa →</a></div>
    </div>`, `Nueva tarea: ${taskTitle}`),
  });
}

async function sendOverdueTasks({ to, userName, tasks, appUrl }) {
  const rows = tasks.map(t => `
    <div style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,.05)">
      <span class="mono">${t.initiativeCode}</span>
      <span style="font-size:13px;color:#e2e8f0;margin-left:10px">${t.title}</span>
      <span style="font-size:12px;color:#f87171;margin-left:10px">Venció ${t.dueDate}</span>
    </div>`).join("");
  await createTransport().sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to, subject: `⚠ ${tasks.length} tarea${tasks.length > 1 ? "s" : ""} vencida${tasks.length > 1 ? "s" : ""} — Initiative Tracker`,
    html: base(`<div class="card">
      <span class="badge b-warn">⚠ Alerta de vencimiento</span>
      <h1 style="margin-top:12px">Tienes ${tasks.length} tarea${tasks.length > 1 ? "s" : ""} vencida${tasks.length > 1 ? "s" : ""}</h1>
      <p>Hola <strong>${userName}</strong>, las siguientes tareas han superado su fecha límite:</p>
      <div style="margin:20px 0">${rows}</div>
      <div style="margin-top:20px"><a href="${appUrl}" class="btn">Ir al sistema →</a></div>
    </div>`, `${tasks.length} tareas vencidas`),
  });
}

async function sendWeeklyReport({ to, userName, stats, topInitiatives, appUrl }) {
  const bp = stats.totalBudget > 0 ? Math.round((stats.totalSpent / stats.totalBudget) * 100) : 0;
  const bColor = bp > 85 ? "#dc2626" : bp > 60 ? "#d97706" : "#0e7490";
  const kpiRows = [
    { l: "Activas", v: stats.activeCount, c: "#22d3ee" },
    { l: "Completadas", v: stats.completedCount, c: "#4ade80" },
    { l: "Avance promedio", v: `${stats.avgProgress}%`, c: "#a78bfa" },
    { l: "Tareas vencidas", v: stats.overdueTasksCount, c: stats.overdueTasksCount > 0 ? "#f87171" : "#4ade80" },
  ].map(k => `<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:14px;display:inline-block;width:48%;margin:1%">
    <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">${k.l}</div>
    <div style="font-size:26px;font-weight:800;color:${k.c};font-family:'Courier New',monospace">${k.v}</div>
  </div>`).join("");
  const iniRows = topInitiatives.map(i => {
    const c = i.progress >= 80 ? "#4ade80" : i.progress >= 50 ? "#22d3ee" : "#f59e0b";
    const dlc = i.daysLeft < 0 ? "#f87171" : i.daysLeft < 7 ? "#f59e0b" : "#64748b";
    return `<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,.05)">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px">
        <div><span class="mono" style="font-size:11px">${i.code}</span>
        <span style="font-size:13px;font-weight:600;color:#e2e8f0;margin-left:8px">${i.title}</span></div>
        <span style="font-size:12px;color:${dlc}">${i.daysLeft < 0 ? `Venció hace ${Math.abs(i.daysLeft)}d` : `${i.daysLeft}d restantes`}</span>
      </div>
      <div class="bar-bg"><div style="height:6px;border-radius:4px;width:${i.progress}%;background:${c}"></div></div>
      <div style="font-size:11px;color:#64748b;text-align:right">${i.progress}%</div>
    </div>`;
  }).join("");
  await createTransport().sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to, subject: `📊 Resumen semanal — ${stats.activeCount} iniciativas activas`,
    html: base(`<div class="card">
      <span class="badge b-info">📊 Reporte semanal</span>
      <h1 style="margin-top:12px">Resumen de la semana</h1>
      <p>Hola <strong>${userName}</strong>, aquí está el resumen del área de AI & Automations:</p>
      <div style="margin:24px 0">${kpiRows}</div>
      <div style="margin-bottom:16px">
        <div style="font-size:12px;color:#64748b;margin-bottom:6px">PRESUPUESTO GLOBAL — ${bp}% ejecutado</div>
        <div class="bar-bg"><div style="height:6px;border-radius:4px;width:${Math.min(bp,100)}%;background:${bColor}"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:#475569;margin-top:4px">
          <span>Ejecutado: $${(stats.totalSpent/1000).toFixed(1)}k</span>
          <span>Total: $${(stats.totalBudget/1000).toFixed(1)}k</span>
        </div>
      </div>
    </div>
    <div class="card"><h2>Iniciativas activas</h2>${iniRows}
      <div style="margin-top:20px"><a href="${appUrl}" class="btn">Ver dashboard completo →</a></div>
    </div>`, `${stats.activeCount} activas · ${stats.avgProgress}% avance promedio`),
  });
}

async function sendStatusChanged({ to, userName, initiativeCode, initiativeTitle, oldStatus, newStatus, initiativeUrl }) {
  const labels = { active:"Activa", on_hold:"En pausa", completed:"Completada", cancelled:"Cancelada", draft:"Borrador" };
  const classes = { active:"b-info", on_hold:"b-warn", completed:"b-ok", cancelled:"b-err" };
  await createTransport().sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to: Array.isArray(to) ? to.join(",") : to,
    subject: `🔄 ${initiativeCode} — Estado: ${labels[newStatus] || newStatus}`,
    html: base(`<div class="card">
      <h1>Iniciativa actualizada</h1>
      <p><strong>${userName}</strong> actualizó el estado de <span class="mono">${initiativeCode}</span></p>
      <div style="display:flex;align-items:center;gap:16px;margin:20px 0;padding:16px;background:rgba(255,255,255,.03);border-radius:10px">
        <span class="badge ${classes[oldStatus]||''}">${labels[oldStatus]||oldStatus}</span>
        <span style="color:#475569;font-size:18px">→</span>
        <span class="badge ${classes[newStatus]||''}">${labels[newStatus]||newStatus}</span>
      </div>
      <div style="font-size:15px;font-weight:600;color:#f1f5f9">${initiativeTitle}</div>
      <div style="margin-top:24px"><a href="${initiativeUrl}" class="btn">Ver iniciativa →</a></div>
    </div>`, `${initiativeCode} → ${labels[newStatus]||newStatus}`),
  });
}

async function sendBudgetAlert({ to, initiativeCode, initiativeTitle, budgetPct, spent, total, initiativeUrl }) {
  const bColor = budgetPct > 95 ? "#f87171" : "#f59e0b";
  await createTransport().sendMail({
    from: `"${FROM_NAME}" <${SMTP_USER.value()}>`,
    to, subject: `💰 Alerta: ${initiativeCode} al ${budgetPct}% del presupuesto`,
    html: base(`<div class="card">
      <span class="badge b-warn">💰 Alerta de presupuesto</span>
      <h1 style="margin-top:12px">${initiativeCode} al ${budgetPct}% del presupuesto</h1>
      <p>La iniciativa <strong>${initiativeTitle}</strong> ha consumido el <strong style="color:#f59e0b">${budgetPct}%</strong> de su presupuesto.</p>
      <div style="margin:20px 0">
        <div class="bar-bg"><div style="height:8px;border-radius:4px;width:${Math.min(budgetPct,100)}%;background:${bColor}"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#475569;margin-top:4px">
          <span>${budgetPct}% ejecutado · $${spent.toLocaleString()}</span>
          <span>Total: $${total.toLocaleString()}</span>
        </div>
      </div>
      <a href="${initiativeUrl}" class="btn">Revisar iniciativa →</a>
    </div>`, `${initiativeCode} al ${budgetPct}% del presupuesto`),
  });
}

module.exports = { sendTaskAssigned, sendOverdueTasks, sendWeeklyReport, sendStatusChanged, sendBudgetAlert };
