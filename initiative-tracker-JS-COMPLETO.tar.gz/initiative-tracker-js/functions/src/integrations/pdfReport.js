const PDFDocument = require("pdfkit");
const { google }  = require("googleapis");
const admin       = require("firebase-admin");
const { Readable } = require("stream");

const STATUS_LABELS   = { active:"Activa", draft:"Borrador", on_hold:"En pausa", completed:"Completada", cancelled:"Cancelada" };
const STATUS_COLORS   = { active:"#22d3ee", draft:"#64748b", on_hold:"#f59e0b", completed:"#4ade80", cancelled:"#f87171" };
const PRIORITY_LABELS = { critical:"Crítica", high:"Alta", medium:"Media", low:"Baja" };
const CATEGORY_LABELS = { ai:"IA", automation:"Automatización", infra:"Infraestructura", process:"Proceso" };

async function generateInitiativeReportPDF(filters, generatedBy) {
  const db = admin.firestore();
  let q = db.collection("initiatives");
  if (filters.status?.length)   q = q.where("status",   "in", filters.status);
  if (filters.leaderId)          q = q.where("leaderId", "==", filters.leaderId);
  if (filters.category?.length) q = q.where("category", "in", filters.category);

  const snap = await q.orderBy("createdAt", "desc").get();
  const initiatives = snap.docs.map(d => ({ id: d.id, ...d.data() }));

  const leaderIds = [...new Set(initiatives.map(i => i.leaderId))];
  const userMap = {};
  for (const uid of leaderIds) {
    const u = await db.collection("users").doc(uid).get();
    if (u.exists) userMap[uid] = u.data().name;
  }

  const active    = initiatives.filter(i => i.status === "active");
  const completed = initiatives.filter(i => i.status === "completed");
  const avgProg   = active.length ? Math.round(active.reduce((s,i) => s + i.progress, 0) / active.length) : 0;
  const totBudget = initiatives.reduce((s,i) => s + (i.budget||0), 0);
  const totSpent  = initiatives.reduce((s,i) => s + (i.budgetSpent||0), 0);
  const dateStr   = new Date().toLocaleDateString("es-SV", { day:"2-digit", month:"long", year:"numeric" });

  const DARK="#0d1628", ACCENT="#0e7490", GRAY="#64748b", LIGHT="#e2e8f0", W=515;

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size:"A4", margin:40 });
    const bufs = [];
    doc.on("data", c => bufs.push(c));
    doc.on("end",  () => resolve(Buffer.concat(bufs)));
    doc.on("error", reject);

    // Header
    doc.rect(0,0,595,80).fill(DARK);
    doc.fontSize(22).fillColor(LIGHT).font("Helvetica-Bold").text("Initiative Tracker",40,22);
    doc.fontSize(10).fillColor(GRAY).font("Helvetica").text("Davivienda El Salvador · AI & Automations",40,50);
    doc.fontSize(9).fillColor(ACCENT).text(`Generado el ${dateStr}`,40,62);
    doc.moveDown(2);

    doc.fontSize(16).fillColor(DARK).font("Helvetica-Bold").text("Reporte de Iniciativas",40,100);
    doc.fontSize(10).fillColor(GRAY).font("Helvetica")
       .text(`${generatedBy||"Sistema"} · ${initiatives.length} iniciativas`,40,120);

    // KPIs
    const kpis = [
      {l:"Total",v:String(initiatives.length),c:DARK},
      {l:"Activas",v:String(active.length),c:"#0e7490"},
      {l:"Completadas",v:String(completed.length),c:"#16a34a"},
      {l:"Avance prom.",v:`${avgProg}%`,c:"#7c3aed"},
    ];
    kpis.forEach((k,i) => {
      const x=40+i*(117+10), y=140;
      doc.roundedRect(x,y,117,50,6).fillAndStroke("#f8fafc","#e2e8f0");
      doc.fontSize(8).fillColor(GRAY).font("Helvetica").text(k.l.toUpperCase(),x+8,y+10);
      doc.fontSize(18).fillColor(k.c).font("Helvetica-Bold").text(k.v,x+8,y+22);
    });

    // Budget bar
    const bpct = totBudget > 0 ? Math.min(totSpent/totBudget,1) : 0;
    const bc   = bpct>.85?"#dc2626":bpct>.6?"#d97706":"#0e7490";
    doc.fontSize(9).fillColor(GRAY).font("Helvetica").text("EJECUCIÓN PRESUPUESTARIA",40,205);
    doc.rect(40,219,W,8).fillAndStroke("#e2e8f0","#e2e8f0");
    doc.rect(40,219,W*bpct,8).fill(bc);
    doc.fontSize(9).fillColor(GRAY).text(`$${(totSpent/1000).toFixed(1)}k de $${(totBudget/1000).toFixed(1)}k · ${Math.round(bpct*100)}%`,40,233);

    // Table header
    const tY=252, cols={code:40,title:110,status:310,prio:375,prog:425,bud:470};
    doc.rect(40,tY,W,22).fill(DARK);
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica-Bold");
    ["CÓDIGO","TÍTULO","ESTADO","PRIO","AVANCE","BDGT"].forEach((h,i) => {
      const xs=[cols.code,cols.title,cols.status,cols.prio,cols.prog,cols.bud];
      doc.text(h,xs[i],tY+7);
    });

    let rowY=tY+22;
    initiatives.slice(0,20).forEach((ini,i) => {
      doc.rect(40,rowY,W,28).fill(i%2===0?"#ffffff":"#f8fafc");
      const pc=ini.progress/100, budp=ini.budget>0?ini.budgetSpent/ini.budget:0;
      const pCol=ini.progress>=80?"#16a34a":ini.progress>=50?"#0e7490":"#d97706";
      const bCol=budp>.85?"#dc2626":budp>.6?"#d97706":"#0e7490";
      const dueStr=ini.dueDate?.toDate?.()?.toLocaleDateString("es-SV",{day:"2-digit",month:"short"})??"—";

      doc.fontSize(8).font("Helvetica-Bold").fillColor(ACCENT).text(ini.code,cols.code,rowY+5);
      doc.font("Helvetica").fillColor(DARK).text((ini.title.substring(0,28)+(ini.title.length>28?"…":"")),cols.title,rowY+5);

      const sc=STATUS_COLORS[ini.status]||GRAY;
      doc.roundedRect(cols.status,rowY+4,55,14,7).fill(`${sc}22`);
      doc.fontSize(7).fillColor(sc).font("Helvetica-Bold").text(STATUS_LABELS[ini.status]||ini.status,cols.status+4,rowY+8);

      doc.fontSize(8).fillColor(GRAY).font("Helvetica").text(PRIORITY_LABELS[ini.priority]||ini.priority,cols.prio,rowY+9);

      doc.rect(cols.prog,rowY+9,36,5).fill("#e2e8f0");
      doc.rect(cols.prog,rowY+9,36*pc,5).fill(pCol);
      doc.fontSize(7).fillColor(pCol).font("Helvetica-Bold").text(`${ini.progress}%`,cols.prog+38,rowY+8);
      doc.fontSize(7).fillColor(bCol).font("Helvetica-Bold").text(`${Math.round(budp*100)}%`,cols.bud,rowY+9);

      doc.fontSize(7).fillColor(GRAY).font("Helvetica")
         .text(`${CATEGORY_LABELS[ini.category]||ini.category} · ${userMap[ini.leaderId]||"—"} · Vence: ${dueStr}`,cols.title,rowY+17,{width:200});
      rowY+=28;
      if(rowY>750){doc.addPage();rowY=40;}
    });

    if(initiatives.length>20) doc.fontSize(9).fillColor(GRAY).font("Helvetica-Oblique").text(`… y ${initiatives.length-20} más`,40,rowY+8);
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica").text(`Initiative Tracker · Davivienda · ${dateStr}`,40,810,{align:"center",width:W});
    doc.end();
  });
}

async function uploadPDFToDrive(pdfBuffer, fileName, parentFolderId) {
  const auth  = new google.auth.GoogleAuth({ scopes:["https://www.googleapis.com/auth/drive.file"] });
  const drive = google.drive({ version:"v3", auth: await auth.getClient() });
  const res   = await drive.files.create({
    requestBody: { name: fileName, mimeType:"application/pdf", parents: parentFolderId ? [parentFolderId] : [] },
    media: { mimeType:"application/pdf", body: Readable.from(pdfBuffer) },
    fields: "id, webViewLink",
  });
  return { fileId: res.data.id||"", webViewLink: res.data.webViewLink||"" };
}

module.exports = { generateInitiativeReportPDF, uploadPDFToDrive };
