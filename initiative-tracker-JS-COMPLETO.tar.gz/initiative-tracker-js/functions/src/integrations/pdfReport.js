const PDFDocument = require("pdfkit");
const { google } = require("googleapis");
const admin = require("firebase-admin");
const { Readable } = require("stream");
const LABELS = { status:{active:"Activa",draft:"Borrador",on_hold:"En pausa",completed:"Completada",cancelled:"Cancelada"}, priority:{critical:"Crítica",high:"Alta",medium:"Media",low:"Baja"}, category:{ai:"IA",automation:"Automatización",infra:"Infraestructura",process:"Proceso"} };
const COLORS = { active:"#22d3ee", on_hold:"#f59e0b", completed:"#4ade80", cancelled:"#f87171", draft:"#64748b" };
async function generateInitiativeReportPDF(filters, generatedBy) {
  const db=admin.firestore();
  let q=db.collection("initiatives");
  if(filters.status?.length)   q=q.where("status","in",filters.status);
  if(filters.leaderId)          q=q.where("leaderId","==",filters.leaderId);
  if(filters.category?.length) q=q.where("category","in",filters.category);
  const snap=await q.orderBy("createdAt","desc").get();
  const initiatives=snap.docs.map(d=>({id:d.id,...d.data()}));
  const leaderIds=[...new Set(initiatives.map(i=>i.leaderId))];
  const userMap={};
  for(const uid of leaderIds){const u=await db.collection("users").doc(uid).get();if(u.exists)userMap[uid]=u.data().name;}
  const active=initiatives.filter(i=>i.status==="active");
  const totB=initiatives.reduce((s,i)=>s+(i.budget||0),0);
  const totS=initiatives.reduce((s,i)=>s+(i.budgetSpent||0),0);
  const dateStr=new Date().toLocaleDateString("es-SV",{day:"2-digit",month:"long",year:"numeric"});
  const W=515, DARK="#0d1628", ACCENT="#0e7490", GRAY="#64748b", LIGHT="#e2e8f0";
  return new Promise((resolve,reject)=>{
    const doc=new PDFDocument({size:"A4",margin:40});
    const bufs=[]; doc.on("data",c=>bufs.push(c)); doc.on("end",()=>resolve(Buffer.concat(bufs))); doc.on("error",reject);
    doc.rect(0,0,595,80).fill(DARK);
    doc.fontSize(22).fillColor(LIGHT).font("Helvetica-Bold").text("Initiative Tracker",40,22);
    doc.fontSize(10).fillColor(GRAY).font("Helvetica").text("Davivienda El Salvador · AI & Automations",40,50);
    doc.fontSize(9).fillColor(ACCENT).text(`Generado el ${dateStr} por ${generatedBy||"Sistema"}`,40,62);
    doc.fontSize(16).fillColor(DARK).font("Helvetica-Bold").text("Reporte de Iniciativas",40,100);
    const kpis=[{l:"Total",v:String(initiatives.length),c:DARK},{l:"Activas",v:String(active.length),c:"#0e7490"},{l:"Completadas",v:String(initiatives.filter(i=>i.status==="completed").length),c:"#16a34a"},{l:"Avance prom.",v:`${active.length?Math.round(active.reduce((s,i)=>s+i.progress,0)/active.length):0}%`,c:"#7c3aed"}];
    kpis.forEach((k,i)=>{const x=40+i*(117+10),y=130;doc.roundedRect(x,y,117,48,6).fillAndStroke("#f8fafc","#e2e8f0");doc.fontSize(8).fillColor(GRAY).font("Helvetica").text(k.l.toUpperCase(),x+8,y+10);doc.fontSize(18).fillColor(k.c).font("Helvetica-Bold").text(k.v,x+8,y+22);});
    const bp=totB>0?Math.min(totS/totB,1):0,bc=bp>.85?"#dc2626":bp>.6?"#d97706":"#0e7490";
    doc.fontSize(9).fillColor(GRAY).font("Helvetica").text("EJECUCIÓN PRESUPUESTARIA",40,195);
    doc.rect(40,209,W,7).fillAndStroke("#e2e8f0","#e2e8f0");doc.rect(40,209,W*bp,7).fill(bc);
    doc.fontSize(9).fillColor(GRAY).text(`$${(totS/1000).toFixed(1)}k de $${(totB/1000).toFixed(1)}k · ${Math.round(bp*100)}%`,40,222);
    const tY=240,cols={code:40,title:110,status:305,prio:370,prog:420,bud:465};
    doc.rect(40,tY,W,22).fill(DARK);
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica-Bold");
    ["CÓDIGO","TÍTULO","ESTADO","PRIO","AVANCE","BDGT"].forEach((h,i)=>{doc.text(h,[cols.code,cols.title,cols.status,cols.prio,cols.prog,cols.bud][i],tY+7);});
    let rowY=tY+22;
    initiatives.slice(0,22).forEach((ini,i)=>{
      doc.rect(40,rowY,W,26).fill(i%2===0?"#ffffff":"#f8fafc");
      const pc=ini.progress/100,budp=ini.budget>0?ini.budgetSpent/ini.budget:0;
      const pCol=ini.progress>=80?"#16a34a":ini.progress>=50?"#0e7490":"#d97706";
      const bCol=budp>.85?"#dc2626":budp>.6?"#d97706":"#0e7490";
      const due=ini.dueDate?.toDate?.()?.toLocaleDateString("es-SV",{day:"2-digit",month:"short"})??"—";
      doc.fontSize(8).font("Helvetica-Bold").fillColor(ACCENT).text(ini.code,cols.code,rowY+5);
      doc.font("Helvetica").fillColor(DARK).text((ini.title.substring(0,26)+(ini.title.length>26?"…":"")),cols.title,rowY+5);
      const sc=COLORS[ini.status]||GRAY;doc.roundedRect(cols.status,rowY+4,52,13,6).fill(`${sc}22`);doc.fontSize(7).fillColor(sc).font("Helvetica-Bold").text(LABELS.status[ini.status]||ini.status,cols.status+4,rowY+8);
      doc.fontSize(8).fillColor(GRAY).font("Helvetica").text(LABELS.priority[ini.priority]||ini.priority,cols.prio,rowY+9);
      doc.rect(cols.prog,rowY+9,34,4).fill("#e2e8f0");doc.rect(cols.prog,rowY+9,34*pc,4).fill(pCol);
      doc.fontSize(7).fillColor(pCol).font("Helvetica-Bold").text(`${ini.progress}%`,cols.prog+36,rowY+8);
      doc.fontSize(7).fillColor(bCol).font("Helvetica-Bold").text(`${Math.round(budp*100)}%`,cols.bud,rowY+9);
      doc.fontSize(7).fillColor(GRAY).font("Helvetica").text(`${LABELS.category[ini.category]||ini.category} · ${userMap[ini.leaderId]||"—"} · ${due}`,cols.title,rowY+16,{width:200});
      rowY+=26; if(rowY>750){doc.addPage();rowY=40;}
    });
    doc.fontSize(8).fillColor("#94a3b8").font("Helvetica").text(`Initiative Tracker · Davivienda · ${dateStr}`,40,810,{align:"center",width:W});
    doc.end();
  });
}
async function uploadPDFToDrive(buf, fileName, parentFolderId) {
  const auth=new google.auth.GoogleAuth({scopes:["https://www.googleapis.com/auth/drive.file"]});
  const drive=google.drive({version:"v3",auth:await auth.getClient()});
  const res=await drive.files.create({requestBody:{name:fileName,mimeType:"application/pdf",parents:parentFolderId?[parentFolderId]:[]},media:{mimeType:"application/pdf",body:Readable.from(buf)},fields:"id,webViewLink"});
  return {fileId:res.data.id||"",webViewLink:res.data.webViewLink||""};
}
module.exports = { generateInitiativeReportPDF, uploadPDFToDrive };
