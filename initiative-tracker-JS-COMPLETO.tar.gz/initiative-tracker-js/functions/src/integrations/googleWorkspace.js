const { google }         = require("googleapis");
const admin              = require("firebase-admin");
const { defineString }   = require("firebase-functions/params");

const DRIVE_PARENT_FOLDER   = defineString("DRIVE_PARENT_FOLDER_ID", { default: "" });
const CALENDAR_ID           = defineString("GOOGLE_CALENDAR_ID",     { default: "primary" });
const SERVICE_ACCOUNT_EMAIL = defineString("SERVICE_ACCOUNT_EMAIL",  { default: "" });

async function getAuth(impersonate) {
  const auth = new google.auth.GoogleAuth({
    scopes: ["https://www.googleapis.com/auth/drive","https://www.googleapis.com/auth/calendar"],
  });
  return auth.getClient();
}

async function createInitiativeDriveFolder(initiativeId, code, title) {
  const auth   = await getAuth();
  const drive  = google.drive({ version: "v3", auth });
  const name   = `[${code}] ${title}`;
  const parents = DRIVE_PARENT_FOLDER.value() ? [DRIVE_PARENT_FOLDER.value()] : [];

  const res = await drive.files.create({
    requestBody: { name, mimeType: "application/vnd.google-apps.folder", parents },
    fields: "id, webViewLink, name",
  });
  const folder = res.data;
  if (!folder.id) throw new Error("Drive folder creation failed");

  await Promise.all(["📄 Documentos","📊 Reportes","🎨 Diseños","📋 Actas"].map(n =>
    drive.files.create({ requestBody: { name: n, mimeType: "application/vnd.google-apps.folder", parents: [folder.id] } })
  ));

  await admin.firestore().collection("initiatives").doc(initiativeId).update({
    googleDriveFolderId: folder.id,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { id: folder.id, webViewLink: folder.webViewLink || `https://drive.google.com/drive/folders/${folder.id}`, name: folder.name };
}

async function createInitiativeCalendarEvent(initiativeId, title, dueDate, leaderEmail, memberEmails = []) {
  const auth     = await getAuth();
  const calendar = google.calendar({ version: "v3", auth });
  const attendees = [...new Set([leaderEmail, ...memberEmails])].map(email => ({ email }));

  const res = await calendar.events.insert({
    calendarId: CALENDAR_ID.value() || "primary",
    sendUpdates: "all",
    requestBody: {
      summary: `📋 Vence: [${title}]`,
      start: { date: dueDate }, end: { date: dueDate },
      attendees,
      reminders: { useDefault: false, overrides: [
        { method: "email", minutes: 24*60*7 },
        { method: "email", minutes: 24*60*3 },
        { method: "popup", minutes: 24*60 },
      ]},
      colorId: "11",
    },
  });
  const event = res.data;
  if (!event.id) throw new Error("Calendar event creation failed");

  await admin.firestore().collection("initiatives").doc(initiativeId).update({
    googleCalendarEventId: event.id,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { id: event.id, htmlLink: event.htmlLink || "" };
}

async function updateInitiativeCalendarEvent(eventId, newDueDate) {
  const auth     = await getAuth();
  const calendar = google.calendar({ version: "v3", auth });
  await calendar.events.patch({
    calendarId: CALENDAR_ID.value() || "primary", eventId,
    requestBody: { start: { date: newDueDate }, end: { date: newDueDate } },
  });
}

async function deleteInitiativeCalendarEvent(eventId) {
  const auth     = await getAuth();
  const calendar = google.calendar({ version: "v3", auth });
  await calendar.events.delete({ calendarId: CALENDAR_ID.value() || "primary", eventId });
}

module.exports = {
  createInitiativeDriveFolder, createInitiativeCalendarEvent,
  updateInitiativeCalendarEvent, deleteInitiativeCalendarEvent,
};
