const { google } = require("googleapis");
const admin = require("firebase-admin");
const { defineString } = require("firebase-functions/params");
const DRIVE_FOLDER = defineString("DRIVE_PARENT_FOLDER_ID", { default:"" });
const CALENDAR_ID  = defineString("GOOGLE_CALENDAR_ID", { default:"primary" });
const SA_EMAIL     = defineString("SERVICE_ACCOUNT_EMAIL", { default:"" });
async function getAuth() { return (new google.auth.GoogleAuth({ scopes:["https://www.googleapis.com/auth/drive","https://www.googleapis.com/auth/calendar"] })).getClient(); }
async function createInitiativeDriveFolder(initiativeId, code, title) {
  const auth=await getAuth(), drive=google.drive({version:"v3",auth}), name=`[${code}] ${title}`;
  const parents=DRIVE_FOLDER.value()?[DRIVE_FOLDER.value()]:[];
  const res=await drive.files.create({requestBody:{name,mimeType:"application/vnd.google-apps.folder",parents},fields:"id,webViewLink,name"});
  if(!res.data.id) throw new Error("Drive folder creation failed");
  await Promise.all(["📄 Documentos","📊 Reportes","🎨 Diseños","📋 Actas"].map(n=>drive.files.create({requestBody:{name:n,mimeType:"application/vnd.google-apps.folder",parents:[res.data.id]}})));
  await admin.firestore().collection("initiatives").doc(initiativeId).update({googleDriveFolderId:res.data.id,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
  return {id:res.data.id,webViewLink:res.data.webViewLink||`https://drive.google.com/drive/folders/${res.data.id}`,name:res.data.name};
}
async function createInitiativeCalendarEvent(initiativeId, title, dueDate, leaderEmail, memberEmails=[]) {
  const auth=await getAuth(), cal=google.calendar({version:"v3",auth});
  const attendees=[...new Set([leaderEmail,...memberEmails])].map(email=>({email}));
  const res=await cal.events.insert({calendarId:CALENDAR_ID.value()||"primary",sendUpdates:"all",requestBody:{summary:`📋 Vence: [${title}]`,start:{date:dueDate},end:{date:dueDate},attendees,reminders:{useDefault:false,overrides:[{method:"email",minutes:24*60*7},{method:"email",minutes:24*60*3},{method:"popup",minutes:24*60}]},colorId:"11"}});
  if(!res.data.id) throw new Error("Calendar event failed");
  await admin.firestore().collection("initiatives").doc(initiativeId).update({googleCalendarEventId:res.data.id,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
  return {id:res.data.id,htmlLink:res.data.htmlLink||""};
}
async function updateCalEvent(eventId, newDate) { const auth=await getAuth(), cal=google.calendar({version:"v3",auth}); await cal.events.patch({calendarId:CALENDAR_ID.value()||"primary",eventId,requestBody:{start:{date:newDate},end:{date:newDate}}}); }
async function deleteCalEvent(eventId) { const auth=await getAuth(), cal=google.calendar({version:"v3",auth}); await cal.events.delete({calendarId:CALENDAR_ID.value()||"primary",eventId}); }
module.exports = { createInitiativeDriveFolder, createInitiativeCalendarEvent, updateCalEvent, deleteCalEvent };
