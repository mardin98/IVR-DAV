const admin = require("firebase-admin");
if (!admin.apps.length) admin.initializeApp();

const { onTaskWrite, onInitiativeWrite }                                      = require("./triggers");
const { cronDailyOverdueCheck, cronWeeklyReport, cronMonthlyBudgetReport }    = require("./scheduled");
const { onCall, HttpsError }                                                   = require("firebase-functions/v2/https");
const { defineSecret, defineString }                                           = require("firebase-functions/params");
const { createInitiativeDriveFolder, createInitiativeCalendarEvent,
        updateInitiativeCalendarEvent, deleteInitiativeCalendarEvent }         = require("./integrations/googleWorkspace");
const { generateInitiativeReportPDF, uploadPDFToDrive }                       = require("./integrations/pdfReport");

const SMTP_PASSWORD       = defineSecret("SMTP_PASSWORD");
const DRIVE_PARENT_FOLDER = defineString("DRIVE_PARENT_FOLDER_ID", { default:"" });

exports.onTaskWrite            = onTaskWrite;
exports.onInitiativeWrite      = onInitiativeWrite;
exports.cronDailyOverdueCheck  = cronDailyOverdueCheck;
exports.cronWeeklyReport       = cronWeeklyReport;
exports.cronMonthlyBudgetReport = cronMonthlyBudgetReport;

exports.createDriveFolder = onCall({ secrets:[SMTP_PASSWORD], memory:"256MiB" }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated","Login required");
  const { initiativeId, code, title } = req.data;
  try { return await createInitiativeDriveFolder(initiativeId, code, title); }
  catch(e) { throw new HttpsError("internal", e.message); }
});

exports.createCalendarEvent = onCall({ memory:"256MiB" }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated","Login required");
  const { initiativeId, title, dueDate, leaderEmail, memberEmails } = req.data;
  try { return await createInitiativeCalendarEvent(initiativeId, title, dueDate, leaderEmail, memberEmails||[]); }
  catch(e) { throw new HttpsError("internal", e.message); }
});

exports.updateCalendarEvent = onCall({ memory:"256MiB" }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated","Login required");
  try { await updateInitiativeCalendarEvent(req.data.eventId, req.data.newDueDate); return { success:true }; }
  catch(e) { throw new HttpsError("internal", e.message); }
});

exports.deleteCalendarEvent = onCall({ memory:"256MiB" }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated","Login required");
  try { await deleteInitiativeCalendarEvent(req.data.eventId); return { success:true }; }
  catch(e) { throw new HttpsError("internal", e.message); }
});

exports.generateReportPDF = onCall({ memory:"512MiB", timeoutSeconds:120 }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated","Login required");
  const { filters={}, saveToDrive=false } = req.data;
  const db    = admin.firestore();
  const uDoc  = await db.collection("users").doc(req.auth.uid).get();
  const genBy = uDoc.exists ? uDoc.data().name : req.auth.uid;
  try {
    const buf = await generateInitiativeReportPDF(filters, genBy);
    if (!saveToDrive) return { base64: buf.toString("base64"), fileName:`reporte-${new Date().toISOString().split("T")[0]}.pdf` };
    const name = `Reporte Iniciativas ${new Date().toLocaleDateString("es-SV")}.pdf`;
    return await uploadPDFToDrive(buf, name, DRIVE_PARENT_FOLDER.value()||undefined);
  } catch(e) { throw new HttpsError("internal", e.message); }
});
