const admin = require("firebase-admin");
if(!admin.apps.length) admin.initializeApp();
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret, defineString } = require("firebase-functions/params");
const { createInitiativeDriveFolder, createInitiativeCalendarEvent, updateCalEvent, deleteCalEvent } = require("./integrations/googleWorkspace");
const { generateInitiativeReportPDF, uploadPDFToDrive } = require("./integrations/pdfReport");
const SMTP_PASS = defineSecret("SMTP_PASSWORD");
const DRIVE_FOLDER = defineString("DRIVE_PARENT_FOLDER_ID",{default:""});
exports.onTaskWrite       = require("./triggers").onTaskWrite;
exports.onInitiativeWrite = require("./triggers").onInitiativeWrite;
exports.cronDailyOverdueCheck = require("./scheduled").cronDailyOverdueCheck;
exports.cronWeeklyReport      = require("./scheduled").cronWeeklyReport;
exports.createDriveFolder = onCall({secrets:[SMTP_PASS],memory:"256MiB"},async(req)=>{
  if(!req.auth) throw new HttpsError("unauthenticated","Login required");
  try{return await createInitiativeDriveFolder(req.data.initiativeId,req.data.code,req.data.title);}catch(e){throw new HttpsError("internal",e.message);}
});
exports.createCalendarEvent = onCall({memory:"256MiB"},async(req)=>{
  if(!req.auth) throw new HttpsError("unauthenticated","Login required");
  try{return await createInitiativeCalendarEvent(req.data.initiativeId,req.data.title,req.data.dueDate,req.data.leaderEmail,req.data.memberEmails||[]);}catch(e){throw new HttpsError("internal",e.message);}
});
exports.updateCalendarEvent = onCall({memory:"256MiB"},async(req)=>{
  if(!req.auth) throw new HttpsError("unauthenticated","Login required");
  try{await updateCalEvent(req.data.eventId,req.data.newDueDate);return{success:true};}catch(e){throw new HttpsError("internal",e.message);}
});
exports.deleteCalendarEvent = onCall({memory:"256MiB"},async(req)=>{
  if(!req.auth) throw new HttpsError("unauthenticated","Login required");
  try{await deleteCalEvent(req.data.eventId);return{success:true};}catch(e){throw new HttpsError("internal",e.message);}
});
exports.generateReportPDF = onCall({memory:"512MiB",timeoutSeconds:120},async(req)=>{
  if(!req.auth) throw new HttpsError("unauthenticated","Login required");
  const db=admin.firestore(), uDoc=await db.collection("users").doc(req.auth.uid).get();
  const by=uDoc.exists?uDoc.data().name:req.auth.uid;
  try{
    const buf=await generateInitiativeReportPDF(req.data.filters||{},by);
    if(!req.data.saveToDrive) return{base64:buf.toString("base64"),fileName:`reporte-${new Date().toISOString().split("T")[0]}.pdf`};
    return await uploadPDFToDrive(buf,`Reporte Iniciativas ${new Date().toLocaleDateString("es-SV")}.pdf`,DRIVE_FOLDER.value()||undefined);
  }catch(e){throw new HttpsError("internal",e.message);}
});
