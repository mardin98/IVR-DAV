const functions = require("firebase-functions/v2/firestore");
const admin     = require("firebase-admin");
const { sendTaskAssigned, sendStatusChanged, sendBudgetAlert } = require("../integrations/emailService");

const db      = admin.firestore();
const APP_URL = process.env.APP_URL || "https://initiative-tracker.web.app";

exports.onTaskWrite = functions.onDocumentWritten("initiatives/{initiativeId}/tasks/{taskId}", async (event) => {
  const initiativeId = event.params.initiativeId;
  const before = event.data?.before?.data();
  const after  = event.data?.after?.data();

  // Recalc progress
  const snap  = await db.collection("initiatives").doc(initiativeId).collection("tasks").get();
  const roots = snap.docs.filter(d => !d.data().parentTaskId);
  if (roots.length) {
    const avg = roots.reduce((s,d) => s + (d.data().progress||0), 0) / roots.length;
    await db.collection("initiatives").doc(initiativeId).update({
      progress: Math.round(avg),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  // Notify new assignee
  if (!after || before?.assigneeId === after.assigneeId) return;
  const assigneeId = after.assigneeId;
  if (!assigneeId) return;

  const [aDoc, iDoc] = await Promise.all([
    db.collection("users").doc(assigneeId).get(),
    db.collection("initiatives").doc(initiativeId).get(),
  ]);
  if (!aDoc.exists || !iDoc.exists) return;

  const assignee = aDoc.data();
  const ini      = iDoc.data();

  await db.collection("notifications").doc(assigneeId).collection("items").add({
    type:"info", title:"Nueva tarea asignada",
    body:`Se te asignó: "${after.title}" en ${ini.code}`,
    entityType:"task", entityId: event.params.taskId,
    read:false, createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  try {
    await sendTaskAssigned({
      to: assignee.email, userName: assignee.name,
      taskTitle: after.title, initiativeCode: ini.code, initiativeTitle: ini.title,
      assignedBy: "Sistema",
      dueDate: after.dueDate ? after.dueDate.toDate().toLocaleDateString("es-SV") : null,
      initiativeUrl: `${APP_URL}/dashboard/initiatives/${initiativeId}`,
    });
  } catch(e) { console.warn("Email failed (task assigned):", e); }
});

exports.onInitiativeWrite = functions.onDocumentWritten("initiatives/{initiativeId}", async (event) => {
  const before = event.data?.before?.data();
  const after  = event.data?.after?.data();
  if (!after || !before) return;

  // Status change
  if (before.status !== after.status) {
    const members = after.members || [];
    const labels  = { active:"Activa", on_hold:"En pausa", completed:"Completada", cancelled:"Cancelada", draft:"Borrador" };
    const batch   = db.batch();
    for (const uid of members) {
      const ref = db.collection("notifications").doc(uid).collection("items").doc();
      batch.set(ref, {
        type: after.status==="completed"?"success":after.status==="cancelled"?"error":"info",
        title:"Estado de iniciativa actualizado",
        body:`${after.code} — ${after.title}: ${labels[before.status]} → ${labels[after.status]}`,
        entityType:"initiative", entityId: event.params.initiativeId,
        read:false, createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();

    try {
      const emails = [];
      for (const uid of members) {
        const u = await db.collection("users").doc(uid).get();
        if (u.exists) emails.push(u.data().email);
      }
      await sendStatusChanged({
        to: emails, userName: "Sistema",
        initiativeCode: after.code, initiativeTitle: after.title,
        oldStatus: before.status, newStatus: after.status,
        initiativeUrl: `${APP_URL}/dashboard/initiatives/${event.params.initiativeId}`,
      });
    } catch(e) { console.warn("Email failed (status):", e); }
  }

  // Budget alert >85%
  const bBefore = before.budget > 0 ? before.budgetSpent/before.budget : 0;
  const bAfter  = after.budget  > 0 ? after.budgetSpent/after.budget   : 0;
  if (bBefore < 0.85 && bAfter >= 0.85 && after.status === "active") {
    await db.collection("notifications").doc(after.leaderId).collection("items").add({
      type:"warning", title:"Alerta de presupuesto",
      body:`${after.code} ha consumido el ${Math.round(bAfter*100)}% del presupuesto`,
      entityType:"initiative", entityId: event.params.initiativeId,
      read:false, createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    try {
      const lDoc = await db.collection("users").doc(after.leaderId).get();
      if (lDoc.exists) await sendBudgetAlert({
        to: lDoc.data().email, initiativeCode: after.code, initiativeTitle: after.title,
        budgetPct: Math.round(bAfter*100), spent: after.budgetSpent, total: after.budget,
        initiativeUrl: `${APP_URL}/dashboard/initiatives/${event.params.initiativeId}`,
      });
    } catch(e) { console.warn("Email failed (budget):", e); }
  }
});
