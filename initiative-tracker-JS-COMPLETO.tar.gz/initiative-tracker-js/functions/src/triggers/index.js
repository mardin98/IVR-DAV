const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
const { sendTaskAssigned, sendStatusChanged, sendBudgetAlert } = require("../integrations/emailService");
const db = admin.firestore(), APP = process.env.APP_URL || "https://tu-proyecto.web.app";
exports.onTaskWrite = onDocumentWritten("initiatives/{iniId}/tasks/{taskId}", async (event) => {
  const iniId=event.params.iniId, before=event.data?.before?.data(), after=event.data?.after?.data();
  const snap=await db.collection("initiatives").doc(iniId).collection("tasks").get();
  const roots=snap.docs.filter(d=>!d.data().parentTaskId);
  if(roots.length){const avg=roots.reduce((s,d)=>s+(d.data().progress||0),0)/roots.length;await db.collection("initiatives").doc(iniId).update({progress:Math.round(avg),updatedAt:admin.firestore.FieldValue.serverTimestamp()});}
  if(!after||before?.assigneeId===after.assigneeId) return;
  const [aDoc,iDoc]=await Promise.all([db.collection("users").doc(after.assigneeId).get(),db.collection("initiatives").doc(iniId).get()]);
  if(!aDoc.exists||!iDoc.exists) return;
  const a=aDoc.data(), ini=iDoc.data();
  await db.collection("notifications").doc(after.assigneeId).collection("items").add({type:"info",title:"Nueva tarea asignada",body:`Se te asignó: "${after.title}" en ${ini.code}`,entityType:"task",entityId:event.params.taskId,read:false,createdAt:admin.firestore.FieldValue.serverTimestamp()});
  try{await sendTaskAssigned({to:a.email,userName:a.name,taskTitle:after.title,initiativeCode:ini.code,initiativeTitle:ini.title,assignedBy:"Sistema",dueDate:after.dueDate?after.dueDate.toDate().toLocaleDateString("es-SV"):null,initiativeUrl:`${APP}/dashboard/initiatives/${iniId}`});}catch(e){console.warn("Email failed:",e);}
});
exports.onInitiativeWrite = onDocumentWritten("initiatives/{iniId}", async (event) => {
  const before=event.data?.before?.data(), after=event.data?.after?.data();
  if(!after||!before) return;
  if(before.status!==after.status){
    const members=after.members||[], labels={active:"Activa",on_hold:"En pausa",completed:"Completada",cancelled:"Cancelada",draft:"Borrador"};
    const batch=db.batch();
    for(const uid of members){const ref=db.collection("notifications").doc(uid).collection("items").doc();batch.set(ref,{type:after.status==="completed"?"success":"info",title:"Estado actualizado",body:`${after.code} → ${labels[after.status]||after.status}`,entityType:"initiative",entityId:event.params.iniId,read:false,createdAt:admin.firestore.FieldValue.serverTimestamp()});}
    await batch.commit();
    try{const emails=[];for(const uid of members){const u=await db.collection("users").doc(uid).get();if(u.exists)emails.push(u.data().email);}
    await sendStatusChanged({to:emails,userName:"Sistema",initiativeCode:after.code,initiativeTitle:after.title,oldStatus:before.status,newStatus:after.status,initiativeUrl:`${APP}/dashboard/initiatives/${event.params.iniId}`});}catch(e){console.warn("Email failed:",e);}
  }
  const bBefore=before.budget>0?before.budgetSpent/before.budget:0, bAfter=after.budget>0?after.budgetSpent/after.budget:0;
  if(bBefore<0.85&&bAfter>=0.85&&after.status==="active"){
    await db.collection("notifications").doc(after.leaderId).collection("items").add({type:"warning",title:"Alerta de presupuesto",body:`${after.code} ha consumido el ${Math.round(bAfter*100)}% del presupuesto`,entityType:"initiative",entityId:event.params.iniId,read:false,createdAt:admin.firestore.FieldValue.serverTimestamp()});
    try{const lDoc=await db.collection("users").doc(after.leaderId).get();if(lDoc.exists)await sendBudgetAlert({to:lDoc.data().email,initiativeCode:after.code,initiativeTitle:after.title,budgetPct:Math.round(bAfter*100),spent:after.budgetSpent,total:after.budget,initiativeUrl:`${APP}/dashboard/initiatives/${event.params.iniId}`});}catch(e){console.warn("Email failed:",e);}
  }
});
