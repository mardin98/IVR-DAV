#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Initiative Tracker — Script de despliegue completo
# Davivienda El Salvador · AI & Automations
# ─────────────────────────────────────────────────────────────────────────────

set -e  # Exit on any error

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${CYAN}[deploy]${NC} $1"; }
ok()   { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# ─── PREREQS ──────────────────────────────────────────────────────────────────

log "Verificando prerrequisitos..."
command -v node  >/dev/null 2>&1 || err "Node.js no encontrado. Instalar v20+"
command -v npm   >/dev/null 2>&1 || err "npm no encontrado"
command -v firebase >/dev/null 2>&1 || { warn "Firebase CLI no encontrado. Instalando..."; npm install -g firebase-tools; }
ok "Prerrequisitos OK"

# ─── ENV CHECK ────────────────────────────────────────────────────────────────

if [ ! -f ".env.local" ]; then
  err ".env.local no encontrado. Copia .env.local.example y llena los valores de Firebase Console."
fi

if grep -q "^NEXT_PUBLIC_FIREBASE_API_KEY=$" .env.local; then
  err "NEXT_PUBLIC_FIREBASE_API_KEY está vacío en .env.local"
fi
ok ".env.local configurado"

# ─── FIREBASE PROJECT ─────────────────────────────────────────────────────────

PROJECT_ID=$(grep NEXT_PUBLIC_FIREBASE_PROJECT_ID .env.local | cut -d'=' -f2)
log "Proyecto Firebase: $PROJECT_ID"

firebase use "$PROJECT_ID" 2>/dev/null || {
  log "Agregando proyecto $PROJECT_ID..."
  firebase use --add "$PROJECT_ID"
}

# ─── SECRETS (solo en primer deploy) ─────────────────────────────────────────

log "Configurando secrets de Cloud Functions..."

if ! firebase functions:secrets:access SMTP_PASSWORD --project "$PROJECT_ID" >/dev/null 2>&1; then
  warn "SMTP_PASSWORD no configurado. Configúralo ahora:"
  firebase functions:secrets:set SMTP_PASSWORD
else
  ok "SMTP_PASSWORD ya configurado"
fi

# ─── FUNCTION CONFIG ──────────────────────────────────────────────────────────

log "Configurando variables de Functions..."

read -p "SMTP Host (ej: smtp.gmail.com): " SMTP_HOST_VAL
read -p "SMTP User (ej: noreply@davivienda.com.sv): " SMTP_USER_VAL
read -p "Google Drive Parent Folder ID (dejar en blanco para omitir): " DRIVE_FOLDER_VAL
read -p "Google Calendar ID (dejar en blanco para 'primary'): " CAL_ID_VAL
read -p "Service Account Email: " SA_EMAIL_VAL
read -p "App URL (ej: https://initiative-tracker.web.app): " APP_URL_VAL

firebase functions:params:set \
  SMTP_HOST="$SMTP_HOST_VAL" \
  SMTP_USER="$SMTP_USER_VAL" \
  DRIVE_PARENT_FOLDER_ID="${DRIVE_FOLDER_VAL:-}" \
  GOOGLE_CALENDAR_ID="${CAL_ID_VAL:-primary}" \
  SERVICE_ACCOUNT_EMAIL="$SA_EMAIL_VAL" \
  APP_URL="$APP_URL_VAL" \
  --project "$PROJECT_ID"

ok "Variables configuradas"

# ─── BUILD NEXT.JS ────────────────────────────────────────────────────────────

log "Instalando dependencias Next.js..."
npm ci

log "Compilando Next.js..."
npm run build
ok "Next.js compilado"

# ─── BUILD FUNCTIONS ──────────────────────────────────────────────────────────

log "Instalando dependencias de Functions..."
cd functions && npm ci

log "Compilando Functions TypeScript..."
npm run build
cd ..
ok "Functions compiladas"

# ─── FIRESTORE RULES & INDEXES ────────────────────────────────────────────────

log "Desplegando Firestore rules e indexes..."
firebase deploy --only firestore --project "$PROJECT_ID"
ok "Firestore rules desplegadas"

# ─── DEPLOY FUNCTIONS ─────────────────────────────────────────────────────────

log "Desplegando Cloud Functions..."
firebase deploy --only functions --project "$PROJECT_ID"
ok "Cloud Functions desplegadas"

# ─── DEPLOY HOSTING ───────────────────────────────────────────────────────────

log "Desplegando Firebase Hosting..."
firebase deploy --only hosting --project "$PROJECT_ID"
ok "Hosting desplegado"

# ─── DONE ─────────────────────────────────────────────────────────────────────

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  ✅ Deploy completo — Initiative Tracker live!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  🌐 URL: ${CYAN}https://${PROJECT_ID}.web.app${NC}"
echo ""
echo -e "  Próximos pasos:"
echo -e "  1. Entra con tu cuenta @davivienda.com.sv"
echo -e "  2. En Firebase Console → Firestore → asigna rol 'admin' a tu UID"
echo -e "  3. Activa Google Drive API + Calendar API en GCP Console"
echo -e "  4. Configura Domain-Wide Delegation en Google Workspace Admin"
echo ""
