// types/index.ts

export type JobStatus =
  | 'analyzing'
  | 'generating'
  | 'pending_approval'
  | 'approved'
  | 'rejected'
  | 'running'
  | 'passed'
  | 'failed'
  | 'error';

export type SourceType = 'gitlab' | 'folder' | 'manual';
export type AppType    = 'api' | 'web' | 'banking' | 'script';
export type Runner     = 'playwright' | 'jest' | 'pytest' | 'node';

export interface GeneratedScript {
  name:        string;
  description: string;
  runner:      Runner;
  filename:    string;
  filePath?:   string;
  code:        string;
}

export interface ExecutionResults {
  passed:      boolean;
  exitCode:    number;
  duration:    number;
  stdout:      string;
  stderr?:     string;
  logFile?:    string;
  runner:      Runner;
  executedAt:  string;
  scriptPath?: string;
  testSummary?: {
    total:   number;
    passed:  number;
    failed:  number;
    skipped: number;
  };
}

export interface Job {
  id:                string;
  source_type:       SourceType;
  app_type:          AppType | null;
  status:            JobStatus;
  source_meta:       Record<string, unknown>;
  raw_content?:      string;
  context?:          Record<string, unknown>;
  generated_scripts: GeneratedScript[] | null;
  approved_script?:  GeneratedScript | null;
  approved_by?:      string;
  approved_at?:      string;
  rejected_reason?:  string;
  execution_results: ExecutionResults | null;
  error_message?:    string;
  created_at:        string;
  updated_at:        string;
}

export interface Source {
  id:         string;
  name:       string;
  type:       'gitlab' | 'folder';
  config:     Record<string, string>;
  active:     number;
  created_at: string;
}

export interface Stats {
  jobs: {
    total:    number;
    byStatus: Record<string, number>;
    passRate: number | null;
  };
  queues: Record<string, {
    waiting:   number;
    active:    number;
    completed: number;
    failed:    number;
  }>;
}
