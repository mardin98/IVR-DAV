// lib/utils.ts
import { JobStatus, AppType, SourceType } from '@/types';

export function statusColor(status: JobStatus): string {
  const map: Record<JobStatus, string> = {
    analyzing:        'text-yellow-400 bg-yellow-400/10 border-yellow-400/20',
    generating:       'text-purple-400 bg-purple-400/10 border-purple-400/20',
    pending_approval: 'text-blue-400   bg-blue-400/10   border-blue-400/20',
    approved:         'text-cyan-400   bg-cyan-400/10   border-cyan-400/20',
    rejected:         'text-gray-400   bg-gray-400/10   border-gray-400/20',
    running:          'text-orange-400 bg-orange-400/10 border-orange-400/20',
    passed:           'text-green-400  bg-green-400/10  border-green-400/20',
    failed:           'text-red-400    bg-red-400/10    border-red-400/20',
    error:            'text-red-500    bg-red-500/10    border-red-500/20',
  };
  return map[status] ?? 'text-gray-400 bg-gray-400/10 border-gray-400/20';
}

export function statusLabel(status: JobStatus): string {
  const map: Record<JobStatus, string> = {
    analyzing:        'Analizando',
    generating:       'Generando',
    pending_approval: 'Esperando aprobación',
    approved:         'Aprobado',
    rejected:         'Rechazado',
    running:          'Ejecutando',
    passed:           'Exitoso',
    failed:           'Fallido',
    error:            'Error',
  };
  return map[status] ?? status;
}

export function appTypeLabel(type: AppType | null): string {
  const map: Record<string, string> = {
    api:     'API REST',
    web:     'Web / UI',
    banking: 'Sistema Bancario',
    script:  'Script',
  };
  return type ? (map[type] ?? type) : '—';
}

export function appTypeIcon(type: AppType | null): string {
  const map: Record<string, string> = {
    api:     '⚡',
    web:     '🌐',
    banking: '🏦',
    script:  '📜',
  };
  return type ? (map[type] ?? '📄') : '📄';
}

export function sourceTypeLabel(type: SourceType): string {
  const map: Record<SourceType, string> = {
    gitlab: 'GitLab',
    folder: 'Carpeta',
    manual: 'Manual',
  };
  return map[type] ?? type;
}

export function sourceTypeIcon(type: SourceType): string {
  const map: Record<SourceType, string> = {
    gitlab: '🦊',
    folder: '📁',
    manual: '⬆️',
  };
  return map[type] ?? '📄';
}

export function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60)       return 'hace un momento';
  if (s < 3600)     return `hace ${Math.floor(s / 60)}m`;
  if (s < 86400)    return `hace ${Math.floor(s / 3600)}h`;
  return `hace ${Math.floor(s / 86400)}d`;
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
}

export function isTerminalStatus(status: JobStatus): boolean {
  return ['passed', 'failed', 'error', 'rejected'].includes(status);
}

export function isActiveStatus(status: JobStatus): boolean {
  return ['analyzing', 'generating', 'running'].includes(status);
}
