// lib/api.ts
import { Job, Stats, Source } from '@/types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002';

async function fetchApi<T>(path: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ─── Jobs ─────────────────────────────────────────────────────────────────────
export async function getJobs(filters?: { status?: string; limit?: number }): Promise<{ jobs: Job[]; count: number }> {
  const params = new URLSearchParams();
  if (filters?.status) params.set('status', filters.status);
  if (filters?.limit)  params.set('limit', String(filters.limit));
  const qs = params.toString() ? `?${params}` : '';
  return fetchApi(`/api/jobs${qs}`);
}

export async function getJob(id: string): Promise<Job> {
  return fetchApi(`/api/jobs/${id}`);
}

export async function approveJob(id: string, payload: {
  approvedBy: string;
  editedScript?: { code: string; runner: string; filename: string };
}): Promise<{ message: string; jobId: string }> {
  return fetchApi(`/api/jobs/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function rejectJob(id: string, payload: {
  rejectedBy: string;
  reason: string;
}): Promise<{ message: string }> {
  return fetchApi(`/api/jobs/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function getJobResults(id: string): Promise<{
  jobId: string;
  status: string;
  executionResults: Job['execution_results'];
  log?: string;
}> {
  return fetchApi(`/api/jobs/${id}/results`);
}

// ─── Stats ─────────────────────────────────────────────────────────────────────
export async function getStats(): Promise<Stats> {
  return fetchApi('/api/stats');
}

// ─── Sources ──────────────────────────────────────────────────────────────────
export async function getSources(): Promise<{ sources: Source[] }> {
  return fetchApi('/api/sources');
}

// ─── Upload manual ────────────────────────────────────────────────────────────
export async function uploadFile(file: File, appType?: string, description?: string): Promise<{ jobId: string; message: string }> {
  const form = new FormData();
  form.append('file', file);
  if (appType)     form.append('appType', appType);
  if (description) form.append('description', description);

  const res = await fetch(`${process.env.NEXT_PUBLIC_COLLECTOR_URL || 'http://localhost:3001'}/upload`, {
    method: 'POST',
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}
