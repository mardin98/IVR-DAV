'use client';
// components/jobs/JobCard.tsx

import { useRouter } from 'next/navigation';
import { Job } from '@/types';
import { StatusBadge, Card } from '@/components/ui';
import { appTypeIcon, appTypeLabel, sourceTypeIcon, relativeTime } from '@/lib/utils';
import { ChevronRight, Clock } from 'lucide-react';

export default function JobCard({ job }: { job: Job }) {
  const router = useRouter();
  const meta = job.source_meta as Record<string, string>;

  const subtitle =
    meta?.filePath     ? meta.filePath.split('/').pop() :
    meta?.originalName ? meta.originalName :
    meta?.project      ? `${meta.project} · ${meta.branch || ''}` :
    job.id.slice(0, 8);

  return (
    <Card hover style={{ padding: '14px 18px' }} >
      <div
        onClick={() => router.push(`/jobs/${job.id}`)}
        style={{ display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
      >
        {/* App type icon */}
        <div style={{
          width: 36, height: 36, borderRadius: 8, flexShrink: 0,
          background: 'var(--bg-hover)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18,
        }}>
          {appTypeIcon(job.app_type)}
        </div>

        {/* Main info */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
            <span style={{
              fontFamily: 'Space Mono', fontSize: 12, color: 'var(--text)',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              maxWidth: 260,
            }}>
              {subtitle}
            </span>
            <StatusBadge status={job.status} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 11, color: 'var(--muted)' }}>
            <span>{sourceTypeIcon(job.source_type)} {job.source_type}</span>
            <span>·</span>
            <span>{appTypeLabel(job.app_type)}</span>
            <span>·</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <Clock size={10} />
              {relativeTime(job.created_at)}
            </span>
          </div>
        </div>

        {/* Execution result badge */}
        {job.execution_results && (
          <div style={{
            fontSize: 11, fontFamily: 'Space Mono',
            color: job.execution_results.passed ? 'var(--green)' : 'var(--red)',
            flexShrink: 0,
          }}>
            {job.execution_results.passed ? '✓ PASSED' : '✗ FAILED'}
          </div>
        )}

        <ChevronRight size={14} color="var(--muted)" style={{ flexShrink: 0 }} />
      </div>
    </Card>
  );
}
