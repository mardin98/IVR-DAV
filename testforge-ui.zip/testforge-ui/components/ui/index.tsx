'use client';
// components/ui/index.tsx — Reusable primitives

import { JobStatus } from '@/types';
import { statusColor, statusLabel } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

// ─── StatusBadge ──────────────────────────────────────────────────────────────
export function StatusBadge({ status }: { status: JobStatus }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 9px', borderRadius: 99, fontSize: 11, fontWeight: 500,
      border: '1px solid',
      fontFamily: 'Space Mono',
      letterSpacing: 0.3,
    }} className={statusColor(status)}>
      {['analyzing','generating','running'].includes(status) && (
        <Loader2 size={10} style={{ animation: 'spin-slow 1.5s linear infinite' }} />
      )}
      {statusLabel(status)}
    </span>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({
  children, style = {}, hover = false,
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
  hover?: boolean;
}) {
  return (
    <div style={{
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 10,
      ...(hover ? { transition: 'border-color 0.15s, background 0.15s', cursor: 'pointer' } : {}),
      ...style,
    }}
    onMouseEnter={hover ? e => {
      (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-2)';
      (e.currentTarget as HTMLElement).style.background = 'var(--bg-hover)';
    } : undefined}
    onMouseLeave={hover ? e => {
      (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)';
      (e.currentTarget as HTMLElement).style.background = 'var(--bg-card)';
    } : undefined}
    >
      {children}
    </div>
  );
}

// ─── PageHeader ───────────────────────────────────────────────────────────────
export function PageHeader({
  title, subtitle, actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
      marginBottom: 28,
    }}>
      <div>
        <h1 style={{
          fontFamily: 'Space Mono', fontSize: 22, fontWeight: 700,
          color: 'var(--text)', letterSpacing: -0.5,
        }}>{title}</h1>
        {subtitle && (
          <p style={{ marginTop: 4, fontSize: 13, color: 'var(--muted)' }}>{subtitle}</p>
        )}
      </div>
      {actions && <div style={{ display: 'flex', gap: 8 }}>{actions}</div>}
    </div>
  );
}

// ─── Button ───────────────────────────────────────────────────────────────────
type BtnVariant = 'primary' | 'danger' | 'ghost' | 'success';

export function Button({
  children, onClick, variant = 'primary', disabled = false, size = 'md', style = {},
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: BtnVariant;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  style?: React.CSSProperties;
}) {
  const variants: Record<BtnVariant, string> = {
    primary: 'bg-blue-600 hover:bg-blue-500 text-white border-blue-500',
    danger:  'bg-red-600/20 hover:bg-red-600/40 text-red-400 border-red-600/40',
    ghost:   'bg-transparent hover:bg-white/5 text-gray-400 border-white/10',
    success: 'bg-green-600/20 hover:bg-green-600/40 text-green-400 border-green-600/40',
  };
  const sizes = { sm: '6px 12px', md: '8px 16px', lg: '12px 24px' };
  const fontSizes = { sm: 12, md: 13, lg: 15 };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: sizes[size], borderRadius: 7,
        fontSize: fontSizes[size], fontWeight: 500,
        border: '1px solid',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'all 0.15s',
        fontFamily: 'inherit',
        ...style,
      }}
      className={variants[variant]}
    >
      {children}
    </button>
  );
}

// ─── EmptyState ───────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, subtitle }: { icon: string; title: string; subtitle?: string }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '60px 20px', textAlign: 'center',
    }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>{icon}</div>
      <div style={{ fontFamily: 'Space Mono', fontSize: 15, color: 'var(--text)', marginBottom: 8 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 13, color: 'var(--muted)', maxWidth: 300 }}>{subtitle}</div>}
    </div>
  );
}

// ─── Spinner ──────────────────────────────────────────────────────────────────
export function Spinner({ size = 20 }: { size?: number }) {
  return <Loader2 size={size} style={{ animation: 'spin-slow 1s linear infinite', color: 'var(--accent)' }} />;
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
export function StatCard({
  label, value, sub, color = 'var(--text)',
}: {
  label: string; value: string | number; sub?: string; color?: string;
}) {
  return (
    <Card style={{ padding: '18px 20px' }}>
      <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'Space Mono', letterSpacing: 0.5, marginBottom: 8 }}>
        {label.toUpperCase()}
      </div>
      <div style={{ fontSize: 32, fontWeight: 700, color, fontFamily: 'Space Mono', lineHeight: 1 }}>
        {value}
      </div>
      {sub && <div style={{ marginTop: 6, fontSize: 11, color: 'var(--muted)' }}>{sub}</div>}
    </Card>
  );
}
