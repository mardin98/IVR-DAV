'use client';
// components/layout/Sidebar.tsx

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, ListChecks, Clock, Upload,
  Settings, Zap, FolderOpen, ChevronRight
} from 'lucide-react';

const NAV = [
  { href: '/',           label: 'Dashboard',   icon: LayoutDashboard },
  { href: '/jobs',       label: 'Todos los Jobs', icon: ListChecks },
  { href: '/jobs?status=pending_approval', label: 'Por Aprobar', icon: Clock, badge: true },
  { href: '/upload',     label: 'Subir Archivo', icon: Upload },
  { href: '/sources',    label: 'Fuentes',      icon: FolderOpen },
  { href: '/settings',   label: 'Configuración', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside style={{
      position: 'fixed', top: 0, left: 0, height: '100vh', width: '220px',
      background: 'var(--bg-card)',
      borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      zIndex: 50,
    }}>
      {/* Logo */}
      <div style={{
        padding: '20px 18px 16px',
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Zap size={16} color="#fff" />
          </div>
          <div>
            <div style={{ fontFamily: 'Space Mono', fontWeight: 700, fontSize: 13, color: 'var(--text)', letterSpacing: 1 }}>
              TESTFORGE
            </div>
            <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 0.5 }}>v1 · on-premise</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '12px 10px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(({ href, label, icon: Icon, badge }) => {
          const active = pathname === href || (href !== '/' && pathname.startsWith(href.split('?')[0]));
          return (
            <Link key={href} href={href} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 10px', borderRadius: 7,
              background: active ? 'var(--accent)/15' : 'transparent',
              border: `1px solid ${active ? 'var(--accent)/30' : 'transparent'}`,
              color: active ? 'var(--accent)' : 'var(--muted)',
              textDecoration: 'none', fontSize: 13, fontWeight: active ? 500 : 400,
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'var(--bg-hover)'; (e.currentTarget as HTMLElement).style.color = 'var(--text)'; }}}
            onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = 'var(--muted)'; }}}
            >
              <Icon size={15} />
              <span style={{ flex: 1 }}>{label}</span>
              {badge && (
                <span style={{
                  fontSize: 10, fontFamily: 'Space Mono',
                  background: 'var(--accent)', color: '#fff',
                  borderRadius: 10, padding: '1px 6px',
                }}>●</span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div style={{
        padding: '12px 18px',
        borderTop: '1px solid var(--border)',
        fontSize: 11, color: 'var(--muted)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', animation: 'pulse-dot 1.4s ease infinite' }} />
          Davivienda El Salvador
        </div>
        <div style={{ marginTop: 2 }}>Área IA & Automatizaciones</div>
      </div>
    </aside>
  );
}
