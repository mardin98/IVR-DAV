'use client';
// app/page.tsx — Dashboard

import { useEffect, useState, useCallback } from 'react';
import { getStats, getJobs } from '@/lib/api';
import { Stats, Job } from '@/types';
import { PageHeader, StatCard, Card, Spinner, EmptyState } from '@/components/ui';
import JobCard from '@/components/jobs/JobCard';
import { RefreshCw, Activity } from 'lucide-react';

export default function Dashboard() {
  const [stats,   setStats]   = useState<Stats | null>(null);
  const [pending, setPending] = useState<Job[]>([]);
  const [recent,  setRecent]  = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const load = useCallback(async () => {
    try {
      const [s, p, r] = await Promise.all([
        getStats(),
        getJobs({ status: 'pending_approval', limit: 5 }),
        getJobs({ limit: 10 }),
      ]);
      setStats(s);
      setPending(p.jobs);
      setRecent(r.jobs);
      setLastRefresh(new Date());
    } catch (e) {
      console.error('Error cargando dashboard:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load]);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <Spinner size={32} />
    </div>
  );

  const byStatus = stats?.jobs.byStatus ?? {};
  const total    = stats?.jobs.total ?? 0;
  const passRate = stats?.jobs.passRate;

  return (
    <div style={{ padding: '32px 36px', maxWidth: 1100 }} className="animate-fade-in">
      <PageHeader
        title="Dashboard"
        subtitle={`Actualizado a las ${lastRefresh.toLocaleTimeString('es-SV')}`}
        actions={
          <button onClick={load} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '7px 13px', borderRadius: 7,
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            color: 'var(--muted)', fontSize: 12, cursor: 'pointer',
          }}>
            <RefreshCw size={13} />
            Actualizar
          </button>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 32 }}>
        <StatCard label="Total Jobs" value={total} sub="Desde el inicio" />
        <StatCard
          label="Por Aprobar"
          value={byStatus.pending_approval ?? 0}
          sub="Esperando revisión"
          color={(byStatus.pending_approval ?? 0) > 0 ? 'var(--accent)' : 'var(--text)'}
        />
        <StatCard
          label="Tasa de Éxito"
          value={passRate !== null && passRate !== undefined ? `${passRate}%` : '—'}
          sub="Tests ejecutados"
          color={passRate !== null && passRate !== undefined
            ? (passRate >= 80 ? 'var(--green)' : passRate >= 50 ? 'var(--yellow)' : 'var(--red)')
            : 'var(--text)'}
        />
        <StatCard
          label="En Progreso"
          value={(byStatus.analyzing ?? 0) + (byStatus.generating ?? 0) + (byStatus.running ?? 0)}
          sub="Activos ahora"
          color="var(--purple)"
        />
      </div>

      <Card style={{ padding: '16px 20px', marginBottom: 32 }}>
        <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'Space Mono', letterSpacing: 0.5, marginBottom: 14 }}>
          ESTADO DEL PIPELINE
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
          {[
            { label: 'Analizando',  key: 'analyzing',        color: '#f59e0b' },
            { label: 'Generando',   key: 'generating',       color: '#a855f7' },
            { label: 'Aprobación',  key: 'pending_approval', color: '#3b82f6' },
            { label: 'Ejecutando',  key: 'running',          color: '#f97316' },
            { label: 'Exitosos',    key: 'passed',           color: '#22c55e' },
            { label: 'Fallidos',    key: 'failed',           color: '#ef4444' },
          ].map((step, i) => {
            const count = byStatus[step.key] ?? 0;
            return (
              <div key={step.key} style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
                <div style={{ flex: 1, textAlign: 'center' }}>
                  <div style={{
                    padding: '10px 8px', borderRadius: 8, border: '1px solid',
                    borderColor: count > 0 ? step.color + '60' : 'var(--border)',
                    background: count > 0 ? step.color + '12' : 'var(--bg-hover)',
                  }}>
                    <div style={{ fontFamily: 'Space Mono', fontSize: 20, fontWeight: 700, color: count > 0 ? step.color : 'var(--muted)' }}>
                      {count}
                    </div>
                    <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>{step.label}</div>
                  </div>
                </div>
                {i < 5 && <div style={{ color: 'var(--border-2)', fontSize: 18, padding: '0 4px', flexShrink: 0 }}>›</div>}
              </div>
            );
          })}
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <Activity size={14} color="var(--accent)" />
            <span style={{ fontFamily: 'Space Mono', fontSize: 12, color: 'var(--text)' }}>PENDIENTES DE APROBACIÓN</span>
            {pending.length > 0 && (
              <span style={{ fontSize: 10, fontFamily: 'Space Mono', background: 'var(--accent)', color: '#fff', borderRadius: 10, padding: '1px 7px' }}>
                {pending.length}
              </span>
            )}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {pending.length === 0
              ? <EmptyState icon="✅" title="Todo al día" subtitle="No hay scripts esperando aprobación" />
              : pending.map(j => <JobCard key={j.id} job={j} />)
            }
          </div>
        </div>
        <div>
          <div style={{ marginBottom: 14 }}>
            <span style={{ fontFamily: 'Space Mono', fontSize: 12, color: 'var(--text)' }}>ACTIVIDAD RECIENTE</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {recent.length === 0
              ? <EmptyState icon="📭" title="Sin actividad" subtitle="Aún no se han procesado jobs" />
              : recent.map(j => <JobCard key={j.id} job={j} />)
            }
          </div>
        </div>
      </div>
    </div>
  );
}
