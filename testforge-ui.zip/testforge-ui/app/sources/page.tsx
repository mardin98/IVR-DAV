'use client';
// app/sources/page.tsx

import { useEffect, useState } from 'react';
import { getSources } from '@/lib/api';
import { Source } from '@/types';
import { PageHeader, Card, EmptyState, Spinner } from '@/components/ui';
import { FolderOpen, GitBranch, Circle } from 'lucide-react';

export default function SourcesPage() {
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getSources().then(r => setSources(r.sources)).finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ padding: '32px 36px', maxWidth: 800 }} className="animate-fade-in">
      <PageHeader
        title="Fuentes"
        subtitle="Orígenes de código configurados en TESTFORGE"
      />

      <Card style={{ padding: '14px 18px', marginBottom: 24, background: 'var(--accent)/5', borderColor: 'var(--accent)/20' }}>
        <div style={{ fontSize: 12, color: 'var(--muted)' }}>
          <strong style={{ color: 'var(--accent)' }}>Fuentes disponibles:</strong> Las fuentes de carpeta se configuran
          via API del Collector. Los webhooks de GitLab se configuran directamente en tu repositorio GitLab
          apuntando a <code style={{ color: 'var(--accent)', fontFamily: 'Space Mono', fontSize: 11 }}>http://tu-servidor:3001/webhook/gitlab</code>
        </div>
      </Card>

      {/* GitLab endpoint info */}
      <Card style={{ padding: '18px 20px', marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8, flexShrink: 0,
            background: 'var(--orange)/15', border: '1px solid var(--orange)/30',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18,
          }}>🦊</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--text)', marginBottom: 6 }}>
              GitLab Webhook
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
              Configura en tu repo: Settings → Webhooks → URL
            </div>
            <div style={{
              background: 'var(--bg)', border: '1px solid var(--border)',
              borderRadius: 6, padding: '8px 12px',
              fontFamily: 'Space Mono', fontSize: 11, color: 'var(--accent)',
            }}>
              POST http://TU_SERVIDOR:3001/webhook/gitlab
            </div>
            <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 8 }}>
              Eventos: Push events, Merge request events
            </div>
          </div>
        </div>
      </Card>

      {/* Folder watcher endpoint info */}
      <Card style={{ padding: '18px 20px', marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8, flexShrink: 0,
            background: 'var(--yellow)/15', border: '1px solid var(--yellow)/30',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18,
          }}>📁</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--text)', marginBottom: 6 }}>
              Folder Watcher
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
              Agrega una carpeta local a monitorear via API:
            </div>
            <pre style={{
              background: 'var(--bg)', border: '1px solid var(--border)',
              borderRadius: 6, padding: '10px 12px', margin: 0,
              fontFamily: 'Space Mono', fontSize: 11, color: '#e8ecf0',
            }}>{`curl -X POST http://localhost:3001/sources/folder \\
  -H "Content-Type: application/json" \\
  -d '{"name": "Mi Proyecto", "folderPath": "/ruta/al/codigo"}'`}</pre>
          </div>
        </div>
      </Card>

      {/* Active sources */}
      <div style={{ fontFamily: 'Space Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: 0.5, marginBottom: 12 }}>
        FUENTES ACTIVAS
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><Spinner /></div>
      ) : sources.length === 0 ? (
        <EmptyState icon="📡" title="Sin fuentes configuradas" subtitle="Agrega un Folder Watcher o configura un GitLab Webhook para empezar" />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {sources.map(s => (
            <Card key={s.id} style={{ padding: '14px 18px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ fontSize: 20 }}>{s.type === 'folder' ? '📁' : '🦊'}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--text)', marginBottom: 2 }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'Space Mono' }}>
                    {s.config?.path || s.config?.url || JSON.stringify(s.config)}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--green)' }}>
                  <Circle size={6} fill="var(--green)" stroke="none" />
                  Activo
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
