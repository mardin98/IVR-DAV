'use client';
// app/upload/page.tsx — Subir archivo manualmente

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { uploadFile } from '@/lib/api';
import { PageHeader, Card, Button, Spinner } from '@/components/ui';
import { Upload, FileCode, CheckCircle } from 'lucide-react';

const APP_TYPES = [
  { value: '',        label: '🤖 Auto-detectar' },
  { value: 'api',     label: '⚡ API REST' },
  { value: 'web',     label: '🌐 Web / Frontend' },
  { value: 'banking', label: '🏦 Sistema Bancario' },
  { value: 'script',  label: '📜 Script' },
];

export default function UploadPage() {
  const router   = useRouter();
  const [file,        setFile]        = useState<File | null>(null);
  const [appType,     setAppType]     = useState('');
  const [description, setDescription] = useState('');
  const [dragging,    setDragging]    = useState(false);
  const [uploading,   setUploading]   = useState(false);
  const [done,        setDone]        = useState('');
  const [error,       setError]       = useState('');

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) setFile(f);
  };

  const handleSubmit = async () => {
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      const res = await uploadFile(file, appType || undefined, description || undefined);
      setDone(res.jobId);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Error subiendo archivo');
    } finally {
      setUploading(false);
    }
  };

  if (done) return (
    <div style={{ padding: '32px 36px', maxWidth: 600 }}>
      <Card style={{ padding: 40, textAlign: 'center' }}>
        <CheckCircle size={48} color="var(--green)" style={{ margin: '0 auto 16px' }} />
        <div style={{ fontFamily: 'Space Mono', fontSize: 18, color: 'var(--text)', marginBottom: 8 }}>
          ¡Archivo recibido!
        </div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}>
          Job creado: <code style={{ color: 'var(--accent)' }}>{done.slice(0, 8).toUpperCase()}</code>
          <br />El Analyzer y Gemini están procesando el archivo.
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
          <Button onClick={() => router.push(`/jobs/${done}`)}>Ver Job</Button>
          <Button variant="ghost" onClick={() => { setFile(null); setDone(''); setDescription(''); }}>Subir otro</Button>
        </div>
      </Card>
    </div>
  );

  return (
    <div style={{ padding: '32px 36px', maxWidth: 680 }} className="animate-fade-in">
      <PageHeader
        title="Subir Archivo"
        subtitle="Sube código para que TESTFORGE genere scripts de prueba automáticamente"
      />

      <Card style={{ padding: 28 }}>
        {/* Drop zone */}
        <div
          onDragOver={e => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => document.getElementById('file-input')?.click()}
          style={{
            border: `2px dashed ${dragging ? 'var(--accent)' : file ? 'var(--green)' : 'var(--border)'}`,
            borderRadius: 10, padding: '36px 24px', textAlign: 'center',
            cursor: 'pointer', transition: 'all 0.2s',
            background: dragging ? 'var(--accent)/5' : file ? 'var(--green)/5' : 'var(--bg-hover)',
            marginBottom: 24,
          }}
        >
          <input
            id="file-input"
            type="file"
            style={{ display: 'none' }}
            accept=".js,.ts,.py,.json,.yaml,.yml,.txt"
            onChange={e => setFile(e.target.files?.[0] || null)}
          />
          {file ? (
            <div>
              <FileCode size={32} color="var(--green)" style={{ margin: '0 auto 10px' }} />
              <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--green)' }}>{file.name}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>
                {(file.size / 1024).toFixed(1)} KB
              </div>
            </div>
          ) : (
            <div>
              <Upload size={32} color="var(--muted)" style={{ margin: '0 auto 10px' }} />
              <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--text)', marginBottom: 4 }}>
                Arrastra un archivo aquí
              </div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                o haz clic para seleccionar
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 8 }}>
                .js .ts .py .json .yaml .yml — máx 5MB
              </div>
            </div>
          )}
        </div>

        {/* App type */}
        <div style={{ marginBottom: 18 }}>
          <label style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'Space Mono', display: 'block', marginBottom: 8 }}>
            TIPO DE APLICACIÓN
          </label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {APP_TYPES.map(t => (
              <button
                key={t.value}
                onClick={() => setAppType(t.value)}
                style={{
                  padding: '7px 13px', borderRadius: 7, fontSize: 12, cursor: 'pointer',
                  border: '1px solid',
                  borderColor: appType === t.value ? 'var(--accent)' : 'var(--border)',
                  background: appType === t.value ? 'var(--accent)/15' : 'var(--bg-hover)',
                  color: appType === t.value ? 'var(--accent)' : 'var(--muted)',
                  transition: 'all 0.15s',
                }}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div style={{ marginBottom: 24 }}>
          <label style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'Space Mono', display: 'block', marginBottom: 8 }}>
            DESCRIPCIÓN (opcional)
          </label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Ej: Módulo de transferencias del sistema MIG C..."
            rows={3}
            style={{
              width: '100%', background: 'var(--bg)', border: '1px solid var(--border)',
              borderRadius: 7, padding: '10px 12px', color: 'var(--text)', fontSize: 12,
              fontFamily: 'inherit', resize: 'vertical', outline: 'none',
            }}
            onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
            onBlur={e  => { e.target.style.borderColor = 'var(--border)'; }}
          />
        </div>

        {error && (
          <div style={{
            padding: '10px 14px', borderRadius: 7, marginBottom: 16,
            background: 'var(--red)/10', border: '1px solid var(--red)/30',
            fontSize: 12, color: 'var(--red)',
          }}>
            ⚠ {error}
          </div>
        )}

        <Button onClick={handleSubmit} disabled={!file || uploading} size="lg">
          {uploading ? <Spinner size={16} /> : <Upload size={16} />}
          {uploading ? 'Subiendo...' : 'Subir y Analizar'}
        </Button>
      </Card>
    </div>
  );
}
