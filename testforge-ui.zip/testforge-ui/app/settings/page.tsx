'use client';
// app/settings/page.tsx

import { PageHeader, Card } from '@/components/ui';
import { Settings } from 'lucide-react';

const ENV_VARS = [
  { key: 'GEMINI_API_KEY',          desc: 'Clave de API de Gemini (Google AI Studio)', required: true },
  { key: 'GEMINI_MODEL',            desc: 'Modelo a usar (default: gemini-1.5-flash)', required: false },
  { key: 'REDIS_HOST',              desc: 'Host de Redis (default: 127.0.0.1)',         required: false },
  { key: 'REDIS_PORT',              desc: 'Puerto de Redis (default: 6379)',             required: false },
  { key: 'GITLAB_WEBHOOK_SECRET',   desc: 'Token secreto para validar webhooks de GitLab', required: false },
  { key: 'COLLECTOR_PORT',          desc: 'Puerto del Collector (default: 3001)',        required: false },
  { key: 'API_PORT',                desc: 'Puerto de la API (default: 3002)',            required: false },
  { key: 'SMTP_HOST',               desc: 'Host SMTP para notificaciones por email',    required: false },
  { key: 'NOTIFY_EMAIL',            desc: 'Email destino de notificaciones',            required: false },
];

const COMMANDS = [
  { label: 'Arrancar todo',      cmd: 'pm2 start ecosystem.config.js' },
  { label: 'Ver estado',         cmd: 'pm2 status' },
  { label: 'Ver logs',           cmd: 'pm2 logs' },
  { label: 'Reiniciar todo',     cmd: 'pm2 restart ecosystem.config.js' },
  { label: 'Detener todo',       cmd: 'pm2 stop ecosystem.config.js' },
  { label: 'Health Collector',   cmd: 'curl http://localhost:3001/health' },
  { label: 'Health API',         cmd: 'curl http://localhost:3002/health' },
  { label: 'Test upload',        cmd: 'curl -X POST http://localhost:3001/upload -F "file=@test.js"' },
];

export default function SettingsPage() {
  return (
    <div style={{ padding: '32px 36px', maxWidth: 800 }} className="animate-fade-in">
      <PageHeader title="Configuración" subtitle="Variables de entorno y comandos útiles" />

      {/* .env variables */}
      <div style={{ marginBottom: 8, fontFamily: 'Space Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: 0.5 }}>
        VARIABLES DE ENTORNO (.env)
      </div>
      <Card style={{ marginBottom: 28 }}>
        {ENV_VARS.map((v, i) => (
          <div key={v.key} style={{
            display: 'flex', gap: 14, alignItems: 'flex-start',
            padding: '12px 18px',
            borderBottom: i < ENV_VARS.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            <div style={{ flex: '0 0 240px' }}>
              <code style={{ fontFamily: 'Space Mono', fontSize: 11, color: 'var(--accent)' }}>{v.key}</code>
              {v.required && (
                <span style={{ marginLeft: 6, fontSize: 9, color: 'var(--red)', fontFamily: 'Space Mono' }}>REQ</span>
              )}
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>{v.desc}</div>
          </div>
        ))}
      </Card>

      {/* Commands */}
      <div style={{ marginBottom: 8, fontFamily: 'Space Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: 0.5 }}>
        COMANDOS ÚTILES
      </div>
      <Card style={{ marginBottom: 28 }}>
        {COMMANDS.map((c, i) => (
          <div key={c.cmd} style={{
            display: 'flex', gap: 14, alignItems: 'center',
            padding: '11px 18px',
            borderBottom: i < COMMANDS.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            <div style={{ flex: '0 0 160px', fontSize: 12, color: 'var(--muted)' }}>{c.label}</div>
            <code style={{ fontFamily: 'Space Mono', fontSize: 11, color: 'var(--text)' }}>{c.cmd}</code>
          </div>
        ))}
      </Card>

      {/* Architecture */}
      <div style={{ marginBottom: 8, fontFamily: 'Space Mono', fontSize: 11, color: 'var(--muted)', letterSpacing: 0.5 }}>
        ARQUITECTURA DE PUERTOS
      </div>
      <Card style={{ padding: '18px 20px' }}>
        {[
          { port: '3000', service: 'UI (Next.js)',     note: 'Este panel' },
          { port: '3001', service: 'Collector',        note: 'Webhooks + uploads' },
          { port: '3002', service: 'API',              note: 'REST para la UI' },
          { port: '6379', service: 'Redis',            note: 'Colas Bull' },
        ].map((p, i, arr) => (
          <div key={p.port} style={{
            display: 'flex', gap: 20, alignItems: 'center',
            padding: '10px 0',
            borderBottom: i < arr.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            <code style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--accent)', flex: '0 0 60px' }}>:{p.port}</code>
            <div style={{ fontSize: 12, color: 'var(--text)', flex: '0 0 160px' }}>{p.service}</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }}>{p.note}</div>
          </div>
        ))}
      </Card>
    </div>
  );
}
