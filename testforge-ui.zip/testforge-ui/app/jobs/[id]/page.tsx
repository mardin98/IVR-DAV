'use client';
// app/jobs/[id]/page.tsx — Detalle del job + pantalla de aprobación

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getJob, approveJob, rejectJob, getJobResults } from '@/lib/api';
import { Job, GeneratedScript } from '@/types';
import { StatusBadge, Card, Button, Spinner, PageHeader } from '@/components/ui';
import {
  appTypeLabel, appTypeIcon, sourceTypeIcon, relativeTime,
  formatDuration, isTerminalStatus, isActiveStatus
} from '@/lib/utils';
import {
  CheckCircle, XCircle, ChevronLeft, Terminal,
  Clock, FileCode, RefreshCw, AlertTriangle, Copy, Check
} from 'lucide-react';

export default function JobDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  const [job,          setJob]          = useState<Job | null>(null);
  const [loading,      setLoading]      = useState(true);
  const [approving,    setApproving]    = useState(false);
  const [rejecting,    setRejecting]    = useState(false);
  const [editedCode,   setEditedCode]   = useState('');
  const [isEditing,    setIsEditing]    = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [showReject,   setShowReject]   = useState(false);
  const [copied,       setCopied]       = useState(false);
  const [activeTab,    setActiveTab]    = useState<'script' | 'context' | 'results'>('script');
  const [log,          setLog]          = useState('');

  const loadJob = useCallback(async () => {
    try {
      const j = await getJob(id);
      setJob(j);
      const scripts = Array.isArray(j.generated_scripts) ? j.generated_scripts : [];
      if (scripts[0] && !editedCode) setEditedCode(scripts[0].code);
      if (isTerminalStatus(j.status)) {
        const r = await getJobResults(id);
        if (r.log) setLog(r.log);
      }
    } catch {
      router.push('/jobs');
    } finally {
      setLoading(false);
    }
  }, [id, editedCode, router]);

  useEffect(() => { loadJob(); }, [loadJob]);

  // Auto-refresh si está en estado activo
  useEffect(() => {
    if (!job || isTerminalStatus(job.status) || job.status === 'pending_approval') return;
    const t = setInterval(loadJob, 4000);
    return () => clearInterval(t);
  }, [job, loadJob]);

  const handleApprove = async () => {
    if (!job) return;
    setApproving(true);
    try {
      const scripts = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];
      const base = scripts[0];
      await approveJob(id, {
        approvedBy: 'admin',
        editedScript: isEditing ? { code: editedCode, runner: base?.runner ?? 'node', filename: base?.filename ?? 'test.js' } : undefined,
      });
      await loadJob();
    } catch (e: unknown) {
      alert(`Error: ${e instanceof Error ? e.message : 'Error desconocido'}`);
    } finally {
      setApproving(false);
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) { alert('Indica un motivo de rechazo'); return; }
    setRejecting(true);
    try {
      await rejectJob(id, { rejectedBy: 'admin', reason: rejectReason });
      await loadJob();
      setShowReject(false);
    } finally {
      setRejecting(false);
    }
  };

  const copyCode = async () => {
    const scripts = Array.isArray(job?.generated_scripts) ? job!.generated_scripts : [];
    await navigator.clipboard.writeText(editedCode || scripts[0]?.code || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <Spinner size={32} />
    </div>
  );

  if (!job) return null;

  const scripts: GeneratedScript[] = Array.isArray(job.generated_scripts) ? job.generated_scripts : [];
  const script = scripts[0];
  const meta = job.source_meta as Record<string, string>;
  const isPending = job.status === 'pending_approval';
  const isActive  = isActiveStatus(job.status);

  return (
    <div style={{ padding: '32px 36px', maxWidth: 1100 }} className="animate-fade-in">
      {/* Back */}
      <button onClick={() => router.push('/jobs')} style={{
        display: 'flex', alignItems: 'center', gap: 6,
        background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer',
        fontSize: 12, marginBottom: 20, padding: 0,
      }}>
        <ChevronLeft size={14} /> Volver a Jobs
      </button>

      <PageHeader
        title={`Job ${id.slice(0, 8).toUpperCase()}`}
        subtitle={`${appTypeIcon(job.app_type)} ${appTypeLabel(job.app_type)} · ${sourceTypeIcon(job.source_type)} ${job.source_type} · ${relativeTime(job.created_at)}`}
        actions={<StatusBadge status={job.status} />}
      />

      {/* Meta info */}
      <Card style={{ padding: '14px 18px', marginBottom: 20 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }}>
          {[
            { label: 'Fuente',   value: meta?.filePath?.split('/').pop() || meta?.originalName || meta?.project || '—' },
            { label: 'Rama',     value: meta?.branch     || '—' },
            { label: 'Commit',   value: meta?.commit?.slice(0, 8) || '—' },
            { label: 'Creado',   value: new Date(job.created_at).toLocaleString('es-SV') },
            { label: 'Actualizado', value: new Date(job.updated_at).toLocaleString('es-SV') },
            { label: 'Runner',   value: script?.runner   || '—' },
          ].map(({ label, value }) => (
            <div key={label}>
              <div style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'Space Mono', letterSpacing: 0.4, marginBottom: 2 }}>{label.toUpperCase()}</div>
              <div style={{ fontSize: 12, color: 'var(--text)', fontFamily: 'Space Mono' }}>{value}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Error message */}
      {job.error_message && (
        <Card style={{ padding: '14px 18px', marginBottom: 20, borderColor: 'var(--red)/40', background: 'var(--red)/5' }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <AlertTriangle size={16} color="var(--red)" style={{ flexShrink: 0, marginTop: 1 }} />
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--red)', marginBottom: 4 }}>Error</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'Space Mono' }}>{job.error_message}</div>
            </div>
          </div>
        </Card>
      )}

      {/* Active spinner */}
      {isActive && (
        <Card style={{ padding: '20px', marginBottom: 20, textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
            <Spinner size={20} />
            <span style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--muted)' }}>
              {job.status === 'analyzing' ? 'Analizando código...' :
               job.status === 'generating' ? 'Gemini generando scripts...' :
               'Ejecutando tests...'}
            </span>
          </div>
        </Card>
      )}

      {/* Tabs */}
      {script && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', gap: 0, marginBottom: 0, borderBottom: '1px solid var(--border)' }}>
            {([
              { key: 'script',  label: '📄 Script' },
              { key: 'context', label: '🔍 Contexto' },
              ...(isTerminalStatus(job.status) ? [{ key: 'results', label: '📊 Resultados' }] : []),
            ] as { key: typeof activeTab; label: string }[]).map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  padding: '10px 18px', background: 'none', border: 'none',
                  borderBottom: `2px solid ${activeTab === tab.key ? 'var(--accent)' : 'transparent'}`,
                  color: activeTab === tab.key ? 'var(--accent)' : 'var(--muted)',
                  cursor: 'pointer', fontSize: 12, fontFamily: 'Space Mono',
                  transition: 'all 0.15s', marginBottom: -1,
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab: Script */}
          {activeTab === 'script' && (
            <Card style={{ marginTop: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0 }}>
              {/* Script header */}
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '12px 16px', borderBottom: '1px solid var(--border)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <FileCode size={14} color="var(--accent)" />
                  <span style={{ fontFamily: 'Space Mono', fontSize: 12, color: 'var(--text)' }}>
                    {script.filename}
                  </span>
                  <span style={{
                    fontSize: 10, fontFamily: 'Space Mono',
                    padding: '2px 7px', borderRadius: 99,
                    background: 'var(--accent)/15', color: 'var(--accent)',
                    border: '1px solid var(--accent)/30',
                  }}>{script.runner}</span>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={copyCode} style={{
                    display: 'flex', alignItems: 'center', gap: 5,
                    padding: '5px 10px', borderRadius: 6, fontSize: 11,
                    background: 'var(--bg-hover)', border: '1px solid var(--border)',
                    color: 'var(--muted)', cursor: 'pointer',
                  }}>
                    {copied ? <Check size={11} color="var(--green)" /> : <Copy size={11} />}
                    {copied ? 'Copiado' : 'Copiar'}
                  </button>
                  {isPending && (
                    <button onClick={() => setIsEditing(!isEditing)} style={{
                      padding: '5px 10px', borderRadius: 6, fontSize: 11,
                      background: isEditing ? 'var(--accent)/20' : 'var(--bg-hover)',
                      border: `1px solid ${isEditing ? 'var(--accent)/40' : 'var(--border)'}`,
                      color: isEditing ? 'var(--accent)' : 'var(--muted)',
                      cursor: 'pointer',
                    }}>
                      {isEditing ? '✓ Editando' : '✏️ Editar'}
                    </button>
                  )}
                </div>
              </div>

              {/* Script description */}
              {script.description && (
                <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--border)', fontSize: 12, color: 'var(--muted)' }}>
                  {script.description}
                </div>
              )}

              {/* Code viewer / editor */}
              {isEditing ? (
                <textarea
                  value={editedCode}
                  onChange={e => setEditedCode(e.target.value)}
                  style={{
                    width: '100%', minHeight: 500,
                    background: '#050709', color: '#e8ecf0',
                    fontFamily: 'Space Mono', fontSize: 12, lineHeight: 1.7,
                    padding: '16px', border: 'none', resize: 'vertical',
                    outline: '2px solid var(--accent)',
                    borderBottomLeftRadius: 10, borderBottomRightRadius: 10,
                  }}
                />
              ) : (
                <pre style={{
                  margin: 0, padding: 16, background: '#050709',
                  borderRadius: '0 0 10px 10px', border: 'none',
                  maxHeight: 600, overflow: 'auto',
                  fontSize: 12, lineHeight: 1.7, color: '#e8ecf0',
                }}>
                  {editedCode || script.code}
                </pre>
              )}
            </Card>
          )}

          {/* Tab: Context */}
          {activeTab === 'context' && (
            <Card style={{ marginTop: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0 }}>
              <pre style={{
                margin: 0, padding: 16, background: '#050709',
                borderRadius: '0 0 10px 10px', border: 'none',
                maxHeight: 600, overflow: 'auto',
                fontSize: 12, lineHeight: 1.7, color: '#e8ecf0',
              }}>
                {JSON.stringify(job.context, null, 2) || '—'}
              </pre>
            </Card>
          )}

          {/* Tab: Results */}
          {activeTab === 'results' && job.execution_results && (
            <Card style={{ marginTop: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0, padding: 0 }}>
              {/* Summary */}
              <div style={{
                padding: '16px 20px', borderBottom: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', gap: 20,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {job.execution_results.passed
                    ? <CheckCircle size={20} color="var(--green)" />
                    : <XCircle    size={20} color="var(--red)" />
                  }
                  <span style={{
                    fontFamily: 'Space Mono', fontSize: 16, fontWeight: 700,
                    color: job.execution_results.passed ? 'var(--green)' : 'var(--red)',
                  }}>
                    {job.execution_results.passed ? 'PASSED' : 'FAILED'}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--muted)', display: 'flex', gap: 16 }}>
                  <span>⏱ {formatDuration(job.execution_results.duration)}</span>
                  <span>Exit code: {job.execution_results.exitCode}</span>
                  <span>Runner: {job.execution_results.runner}</span>
                </div>
                {job.execution_results.testSummary && (
                  <div style={{ display: 'flex', gap: 12, fontSize: 12 }}>
                    <span style={{ color: 'var(--green)' }}>✓ {job.execution_results.testSummary.passed} passed</span>
                    <span style={{ color: 'var(--red)' }}>✗ {job.execution_results.testSummary.failed} failed</span>
                    <span style={{ color: 'var(--muted)' }}>⊘ {job.execution_results.testSummary.skipped} skipped</span>
                  </div>
                )}
              </div>
              {/* Log output */}
              {(log || job.execution_results.stdout) && (
                <div>
                  <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--border)', fontSize: 11, color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Terminal size={11} /> Salida de ejecución
                  </div>
                  <pre style={{
                    margin: 0, padding: 16, background: '#050709',
                    borderRadius: '0 0 10px 10px', border: 'none',
                    maxHeight: 400, overflow: 'auto',
                    fontSize: 11, lineHeight: 1.7, color: '#e8ecf0',
                  }}>
                    {log || job.execution_results.stdout}
                  </pre>
                </div>
              )}
            </Card>
          )}
        </div>
      )}

      {/* Approval actions */}
      {isPending && (
        <div>
          <Card style={{ padding: '20px', border: '1px solid var(--accent)/30', background: 'var(--accent)/5' }}>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontFamily: 'Space Mono', fontSize: 13, color: 'var(--text)', marginBottom: 4 }}>
                ¿Aprobar este script?
              </div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                {isEditing
                  ? 'Se ejecutará la versión editada del script.'
                  : 'Se ejecutará el script generado por Gemini tal como aparece arriba. Puedes editarlo antes de aprobar.'}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <Button variant="success" onClick={handleApprove} disabled={approving}>
                {approving ? <Spinner size={14} /> : <CheckCircle size={14} />}
                {approving ? 'Aprobando...' : 'Aprobar y Ejecutar'}
              </Button>
              <Button variant="danger" onClick={() => setShowReject(!showReject)}>
                <XCircle size={14} />
                Rechazar
              </Button>
              <Button variant="ghost" onClick={loadJob}>
                <RefreshCw size={13} />
              </Button>
            </div>

            {/* Reject form */}
            {showReject && (
              <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)' }}>
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>Motivo del rechazo:</div>
                <textarea
                  value={rejectReason}
                  onChange={e => setRejectReason(e.target.value)}
                  placeholder="Ej: El script no cubre los endpoints de autenticación..."
                  rows={3}
                  style={{
                    width: '100%', background: 'var(--bg)', border: '1px solid var(--border)',
                    borderRadius: 7, padding: '10px 12px', color: 'var(--text)', fontSize: 12,
                    fontFamily: 'inherit', resize: 'vertical', outline: 'none', marginBottom: 10,
                  }}
                />
                <Button variant="danger" onClick={handleReject} disabled={rejecting}>
                  {rejecting ? <Spinner size={14} /> : null}
                  Confirmar Rechazo
                </Button>
              </div>
            )}
          </Card>
        </div>
      )}

      {/* Approved/rejected info */}
      {(job.approved_by || job.rejected_reason) && (
        <Card style={{ padding: '14px 18px', marginTop: 16 }}>
          <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'Space Mono', letterSpacing: 0.4, marginBottom: 8 }}>
            {job.rejected_reason ? 'RECHAZADO' : 'APROBADO'}
          </div>
          {job.approved_by  && <div style={{ fontSize: 12, color: 'var(--text)' }}>Por: {job.approved_by}</div>}
          {job.approved_at  && <div style={{ fontSize: 11, color: 'var(--muted)' }}>En: {new Date(job.approved_at).toLocaleString('es-SV')}</div>}
          {job.rejected_reason && <div style={{ fontSize: 12, color: 'var(--red)', marginTop: 4 }}>Motivo: {job.rejected_reason}</div>}
        </Card>
      )}
    </div>
  );
}
