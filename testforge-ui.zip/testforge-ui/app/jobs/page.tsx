'use client';
// app/jobs/page.tsx — Lista de todos los jobs

import { useEffect, useState, useCallback, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { getJobs } from '@/lib/api';
import { Job, JobStatus } from '@/types';
import { PageHeader, Spinner, EmptyState } from '@/components/ui';
import JobCard from '@/components/jobs/JobCard';
import { RefreshCw } from 'lucide-react';

const STATUS_FILTERS: { value: string; label: string }[] = [
  { value: '',                 label: 'Todos' },
  { value: 'pending_approval', label: '⏳ Por aprobar' },
  { value: 'running',          label: '⚡ Ejecutando' },
  { value: 'passed',           label: '✅ Exitosos' },
  { value: 'failed',           label: '❌ Fallidos' },
  { value: 'error',            label: '⚠️ Errores' },
  { value: 'rejected',         label: '🚫 Rechazados' },
];

function JobsContent() {
  const searchParams = useSearchParams();
  const [jobs,    setJobs]    = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState(searchParams.get('status') || '');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getJobs({ status: filter || undefined, limit: 100 });
      setJobs(res.jobs);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  return (
    <div style={{ padding: '32px 36px', maxWidth: 900 }} className="animate-fade-in">
      <PageHeader
        title="Jobs"
        subtitle={`${jobs.length} job${jobs.length !== 1 ? 's' : ''} encontrado${jobs.length !== 1 ? 's' : ''}`}
        actions={
          <button onClick={load} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '7px 13px', borderRadius: 7,
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            color: 'var(--muted)', fontSize: 12, cursor: 'pointer',
          }}>
            <RefreshCw size={13} />
            Actualizar
          </button>
        }
      />

      {/* Filtros */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {STATUS_FILTERS.map(f => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            style={{
              padding: '5px 12px', borderRadius: 99, fontSize: 12,
              border: '1px solid',
              borderColor: filter === f.value ? 'var(--accent)' : 'var(--border)',
              background: filter === f.value ? 'var(--accent)/15' : 'var(--bg-card)',
              color: filter === f.value ? 'var(--accent)' : 'var(--muted)',
              cursor: 'pointer', transition: 'all 0.15s',
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
          <Spinner size={24} />
        </div>
      ) : jobs.length === 0 ? (
        <EmptyState
          icon="🔍"
          title="Sin resultados"
          subtitle={filter ? `No hay jobs con estado "${filter}"` : 'Aún no se han creado jobs'}
        />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {jobs.map(j => <JobCard key={j.id} job={j} />)}
        </div>
      )}
    </div>
  );
}

export default function JobsPage() {
  return (
    <Suspense fallback={<div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}><Spinner size={24} /></div>}>
      <JobsContent />
    </Suspense>
  );
}
